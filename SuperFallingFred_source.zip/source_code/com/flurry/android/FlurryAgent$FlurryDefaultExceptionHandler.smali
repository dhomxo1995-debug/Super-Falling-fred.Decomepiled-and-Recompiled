.class public Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;
.super Ljava/lang/Object;
.implements Ljava/lang/Thread$UncaughtExceptionHandler;

.field private a:Ljava/lang/Thread$UncaughtExceptionHandler;

.method constructor <init>()V
    .registers 2
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;
    move-result-object v0
    iput-object v0, v1, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;->a Ljava/lang/Thread$UncaughtExceptionHandler;
    return-void
.end method

.method public uncaughtException(Ljava/lang/Thread; Ljava/lang/Throwable;)V
    .registers 6
    invoke-static Lcom/flurry/android/FlurryAgent;->f()Lcom/flurry/android/FlurryAgent;
    move-result-object v0
    invoke-virtual v0, v5, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/Throwable;)V
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;->a Ljava/lang/Thread$UncaughtExceptionHandler;
    if-eqz v0, +007h
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;->a Ljava/lang/Thread$UncaughtExceptionHandler;
    invoke-interface v0, v4, v5, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread; Ljava/lang/Throwable;)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -12h
.end method
