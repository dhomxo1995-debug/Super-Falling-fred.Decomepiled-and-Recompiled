.class final Lcom/flurry/android/h;
.super Ljava/util/LinkedHashMap;

.field private synthetic a:Lcom/flurry/android/af;

.method constructor <init>(Lcom/flurry/android/af; I F)V
    .registers 5
    iput-object v2, v1, Lcom/flurry/android/h;->a Lcom/flurry/android/af;
    const/4 v0, 1
    invoke-direct v1, v3, v4, v0, Ljava/util/LinkedHashMap;-><init>(I F Z)V
    return-void
.end method

.method protected final removeEldestEntry(Ljava/util/Map$Entry;)Z
    .registers 4
    invoke-virtual v2, Lcom/flurry/android/h;->size()I
    move-result v0
    iget-object v1, v2, Lcom/flurry/android/h;->a Lcom/flurry/android/af;
    invoke-static v1, Lcom/flurry/android/af;->a(Lcom/flurry/android/af;)I
    move-result v1
    if-le v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method
