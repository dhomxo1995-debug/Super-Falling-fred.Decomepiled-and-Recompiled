package com.flurry.android;
final class r {

    r()
    {
        return;
    }

    static int a(android.content.Context p2, int p3)
    {
        return ((int) ((p2.getResources().getDisplayMetrics().density * ((float) p3)) + 1056964608));
    }

    static String a(String p3)
    {
        try {
            String v0_1 = java.net.URLEncoder.encode(p3, "UTF-8");
        } catch (String v0) {
            com.flurry.android.ah.d("FlurryAgent", new StringBuilder().append("Cannot encode \'").append(p3).append("\'").toString());
            v0_1 = "";
        }
        return v0_1;
    }

    static String a(String p1, int p2)
    {
        if (p1 != null) {
            if (p1.length() > p2) {
                p1 = p1.substring(0, p2);
            }
        } else {
            p1 = "";
        }
        return p1;
    }

    static void a(android.content.Context p1, android.widget.ImageView p2, int p3, int p4)
    {
        p2.setAdjustViewBounds(1);
        p2.setMinimumWidth(com.flurry.android.r.a(p1, p3));
        p2.setMinimumHeight(com.flurry.android.r.a(p1, p4));
        p2.setMaxWidth(com.flurry.android.r.a(p1, p3));
        p2.setMaxHeight(com.flurry.android.r.a(p1, p4));
        return;
    }

    static void a(java.io.Closeable p1)
    {
        if (p1 != null) {
            try {
                p1.close();
            } catch (Throwable v0) {
            }
        }
        return;
    }
}
