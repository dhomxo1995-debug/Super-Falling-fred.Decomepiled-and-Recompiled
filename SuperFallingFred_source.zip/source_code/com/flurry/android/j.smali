.class final Lcom/flurry/android/j;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/util/List;

.method constructor <init>(Ljava/util/List;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/j;->a Ljava/util/List;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/flurry/android/j;->a Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00ch
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/o;
    invoke-virtual v0, Lcom/flurry/android/o;->a()V
    goto -fh
    return-void
.end method
