.class public final Lcom/flurry/android/OfferInSdk;
.super Ljava/lang/Object;

.field  a:J
.field  b:Lcom/flurry/android/p;
.field  c:Ljava/lang/String;
.field  d:Ljava/lang/String;
.field  e:I
.field  f:Lcom/flurry/android/AdImage;

.method constructor <init>(J Lcom/flurry/android/p; Lcom/flurry/android/AdImage; Ljava/lang/String; Ljava/lang/String; I)V
    .registers 8
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-wide v1, v0, Lcom/flurry/android/OfferInSdk;->a J
    iput-object v3, v0, Lcom/flurry/android/OfferInSdk;->b Lcom/flurry/android/p;
    iput-object v5, v0, Lcom/flurry/android/OfferInSdk;->c Ljava/lang/String;
    iput-object v4, v0, Lcom/flurry/android/OfferInSdk;->f Lcom/flurry/android/AdImage;
    iput-object v6, v0, Lcom/flurry/android/OfferInSdk;->d Ljava/lang/String;
    iput v7, v0, Lcom/flurry/android/OfferInSdk;->e I
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 5
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "[id="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-wide v2, v4, Lcom/flurry/android/OfferInSdk;->a J
    invoke-virtual v1, v2, v3, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, ",name="
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    iget-object v3, v4, Lcom/flurry/android/OfferInSdk;->c Ljava/lang/String;
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "]"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
