package com.flurry.android;
final class h extends java.util.LinkedHashMap {
    private synthetic com.flurry.android.af a;

    h(com.flurry.android.af p2, int p3, float p4)
    {
        this.a = p2;
        super(p3, p4, 1);
        return;
    }

    protected final boolean removeEldestEntry(java.util.Map$Entry p3)
    {
        int v0_1;
        if (this.size() <= com.flurry.android.af.a(this.a)) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }
}
