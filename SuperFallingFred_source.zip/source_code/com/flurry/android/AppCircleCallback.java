package com.flurry.android;
public interface AppCircleCallback {

    public abstract void onAdsUpdated(com.flurry.android.CallbackEvent p0);

    public abstract void onMarketAppLaunchError(com.flurry.android.CallbackEvent p0);
}
