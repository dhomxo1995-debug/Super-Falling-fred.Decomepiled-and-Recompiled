.class final Lcom/flurry/android/r;
.super Ljava/lang/Object;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method static a(Landroid/content/Context; I)I
    .registers 4
    invoke-virtual v2, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    move-result-object v0
    invoke-virtual v0, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    move-result-object v0
    iget v0, v0, Landroid/util/DisplayMetrics;->density F
    int-to-float v1, v3
    mul-float/2addr v0, v1
    const/high16 v1, 1056964608
    add-float/2addr v0, v1
    float-to-int v0, v0
    return v0
.end method

.method static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    const-string v0, "UTF-8"
    invoke-static v3, v0, Ljava/net/URLEncoder;->encode(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
    move-exception v0
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Cannot encode '"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, "'"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    const-string v0, ""
    goto -22h
.end method

.method static a(Ljava/lang/String; I)Ljava/lang/String;
    .registers 3
    if-nez v1, +005h
    const-string v1, ""
    return-object v1
    invoke-virtual v1, Ljava/lang/String;->length()I
    move-result v0
    if-le v0, v2, -005h
    const/4 v0, 0
    invoke-virtual v1, v0, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v1
    goto -ch
.end method

.method static a(Landroid/content/Context; Landroid/widget/ImageView; I I)V
    .registers 5
    const/4 v0, 1
    invoke-virtual v2, v0, Landroid/widget/ImageView;->setAdjustViewBounds(Z)V
    invoke-static v1, v3, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v0
    invoke-virtual v2, v0, Landroid/widget/ImageView;->setMinimumWidth(I)V
    invoke-static v1, v4, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v0
    invoke-virtual v2, v0, Landroid/widget/ImageView;->setMinimumHeight(I)V
    invoke-static v1, v3, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v0
    invoke-virtual v2, v0, Landroid/widget/ImageView;->setMaxWidth(I)V
    invoke-static v1, v4, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v0
    invoke-virtual v2, v0, Landroid/widget/ImageView;->setMaxHeight(I)V
    return-void
.end method

.method static a(Ljava/io/Closeable;)V
    .registers 2
    if-eqz v1, +005h
    invoke-interface v1, Ljava/io/Closeable;->close()V
    return-void
    move-exception v0
    goto -2h
.end method
