package com.flurry.android;
final class i {
    private String a;
    private java.util.Map b;
    private long c;
    private boolean d;
    private long e;
    private byte[] f;

    public i(String p1, java.util.Map p2, long p3, boolean p5)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        this.d = p5;
        return;
    }

    public final void a()
    {
        this.e = (android.os.SystemClock.elapsedRealtime() - this.c);
        return;
    }

    public final boolean a(String p5)
    {
        if ((!this.d) || ((this.e != 0) || (!this.a.equals(p5)))) {
            int v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }

    public final byte[] b()
    {
        if (this.f == null) {
            String v0_6 = 0;
            try {
                java.io.ByteArrayOutputStream v3_1 = new java.io.ByteArrayOutputStream();
                boolean v2_1 = new java.io.DataOutputStream(v3_1);
                try {
                    v2_1.writeUTF(this.a);
                } catch (String v0) {
                    v0_6 = v2_1;
                    try {
                        int v1_5 = new byte[0];
                        this.f = v1_5;
                        com.flurry.android.r.a(v0_6);
                    } catch (int v1_6) {
                        v2_1 = v0_6;
                        String v0_15 = v1_6;
                        com.flurry.android.r.a(v2_1);
                        throw v0_15;
                    }
                } catch (String v0_15) {
                }
                if (this.b != null) {
                    v2_1.writeShort(this.b.size());
                    java.util.Iterator v4 = this.b.entrySet().iterator();
                    while (v4.hasNext()) {
                        String v0_10 = ((java.util.Map$Entry) v4.next());
                        v2_1.writeUTF(com.flurry.android.r.a(((String) v0_10.getKey()), 255));
                        v2_1.writeUTF(com.flurry.android.r.a(((String) v0_10.getValue()), 255));
                    }
                } else {
                    v2_1.writeShort(0);
                }
                v2_1.writeLong(this.c);
                v2_1.writeLong(this.e);
                v2_1.flush();
                this.f = v3_1.toByteArray();
                com.flurry.android.r.a(v2_1);
            } catch (int v1) {
            } catch (int v1_7) {
                v2_1 = 0;
                v0_15 = v1_7;
            }
        }
        return this.f;
    }
}
