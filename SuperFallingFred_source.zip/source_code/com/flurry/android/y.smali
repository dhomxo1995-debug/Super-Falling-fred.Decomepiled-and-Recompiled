.class final Lcom/flurry/android/y;
.super Landroid/widget/RelativeLayout;

.field private a:Lcom/flurry/android/u;
.field private b:Lcom/flurry/android/p;
.field private c:Ljava/lang/String;
.field private d:I

.method public constructor <init>(Landroid/content/Context; Lcom/flurry/android/u; Lcom/flurry/android/p; Lcom/flurry/android/e; I Z)V
    .registers 11
    const/4 v3, 0
    const/4 v2, 1
    invoke-direct v4, v5, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V
    iput-object v6, v4, Lcom/flurry/android/y;->a Lcom/flurry/android/u;
    iput-object v7, v4, Lcom/flurry/android/y;->b Lcom/flurry/android/p;
    iget-object v0, v7, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iput v9, v4, Lcom/flurry/android/y;->d I
    iget v1, v4, Lcom/flurry/android/y;->d I
    packed-switch v1, +000001bh
    invoke-virtual v4, v2, Lcom/flurry/android/y;->setFocusable(Z)V
    return-void
    if-eqz v10, +00bh
    invoke-direct v4, v5, v8, v0, v3, Lcom/flurry/android/y;->a(Landroid/content/Context; Lcom/flurry/android/e; Lcom/flurry/android/v; Z)V
    if-eqz v10, +00ah
    invoke-direct v4, v5, v8, v0, v3, Lcom/flurry/android/y;->a(Landroid/content/Context; Lcom/flurry/android/e; Lcom/flurry/android/v; Z)V
    goto -eh
    invoke-direct v4, v5, v8, v0, v2, Lcom/flurry/android/y;->a(Landroid/content/Context; Lcom/flurry/android/e; Lcom/flurry/android/v; Z)V
    goto -9h
    invoke-direct v4, v5, v8, v0, v2, Lcom/flurry/android/y;->a(Landroid/content/Context; Lcom/flurry/android/e; Lcom/flurry/android/v; Z)V
    goto -16h
    nop
    packed-switch-payload 1 2
.end method

.method private a(Landroid/content/Context; Lcom/flurry/android/e; Lcom/flurry/android/v; Z)V
    .registers 19
    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;
    const/4 v2, -1
    const/4 v3, -1
    invoke-direct v1, v2, v3, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    invoke-virtual v14, v1, Lcom/flurry/android/y;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    move-object/from16 v0, v16
    iget-object v3, v0, Lcom/flurry/android/e;->d Lcom/flurry/android/c;
    new-instance v4, Landroid/widget/ImageView;
    invoke-direct v4, v15, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    const/4 v1, 1
    invoke-virtual v4, v1, Landroid/widget/ImageView;->setId(I)V
    move-object/from16 v0, v17
    iget-object v1, v0, Lcom/flurry/android/v;->h Lcom/flurry/android/AdImage;
    if-eqz v1, +0d9h
    iget-object v1, v1, Lcom/flurry/android/AdImage;->e [B
    const/4 v2, 0
    array-length v5, v1
    invoke-static v1, v2, v5, Landroid/graphics/BitmapFactory;->decodeByteArray([B I I)Landroid/graphics/Bitmap;
    move-result-object v5
    if-nez v5, +028h
    const-string v2, "FlurryAgent"
    new-instance v6, Ljava/lang/StringBuilder;
    invoke-direct v6, Ljava/lang/StringBuilder;-><init>()V
    const-string v7, "Ad with bad image: "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    move-object/from16 v0, v17
    iget-object v7, v0, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    const-string v7, ", data: "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v2, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    if-eqz v5, +0a7h
    invoke-virtual v5, Landroid/graphics/Bitmap;->getWidth()I
    move-result v1
    invoke-virtual v5, Landroid/graphics/Bitmap;->getHeight()I
    move-result v2
    sget-object v6, Landroid/graphics/Bitmap$Config;->ARGB_8888 Landroid/graphics/Bitmap$Config;
    invoke-static v1, v2, v6, Landroid/graphics/Bitmap;->createBitmap(I I Landroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    move-result-object v2
    new-instance v1, Landroid/graphics/Canvas;
    invoke-direct v1, v2, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V
    new-instance v6, Landroid/graphics/Paint;
    invoke-direct v6, Landroid/graphics/Paint;-><init>()V
    new-instance v7, Landroid/graphics/Rect;
    const/4 v8, 0
    const/4 v9, 0
    invoke-virtual v5, Landroid/graphics/Bitmap;->getWidth()I
    move-result v10
    invoke-virtual v5, Landroid/graphics/Bitmap;->getHeight()I
    move-result v11
    invoke-direct v7, v8, v9, v10, v11, Landroid/graphics/Rect;-><init>(I I I I)V
    new-instance v8, Landroid/graphics/RectF;
    invoke-direct v8, v7, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V
    const/16 v9, 8
    invoke-static v15, v9, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v9
    int-to-float v9, v9
    const/4 v10, 1
    invoke-virtual v6, v10, Landroid/graphics/Paint;->setAntiAlias(Z)V
    const/4 v10, 0
    const/4 v11, 0
    const/4 v12, 0
    const/4 v13, 0
    invoke-virtual v1, v10, v11, v12, v13, Landroid/graphics/Canvas;->drawARGB(I I I I)V
    const/high16 v10, -16777216
    invoke-virtual v6, v10, Landroid/graphics/Paint;->setColor(I)V
    invoke-virtual v1, v8, v9, v9, v6, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF; F F Landroid/graphics/Paint;)V
    new-instance v8, Landroid/graphics/PorterDuffXfermode;
    sget-object v9, Landroid/graphics/PorterDuff$Mode;->SRC_IN Landroid/graphics/PorterDuff$Mode;
    invoke-direct v8, v9, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V
    invoke-virtual v6, v8, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;
    invoke-virtual v1, v5, v7, v7, v6, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap; Landroid/graphics/Rect; Landroid/graphics/Rect; Landroid/graphics/Paint;)V
    sget-object v1, Landroid/os/Build$VERSION;->SDK Ljava/lang/String;
    invoke-static v1, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v1
    const/4 v5, 4
    if-le v1, v5, +1b3h
    new-instance v1, Landroid/graphics/BlurMaskFilter;
    const/high16 v5, 1077936128
    sget-object v6, Landroid/graphics/BlurMaskFilter$Blur;->OUTER Landroid/graphics/BlurMaskFilter$Blur;
    invoke-direct v1, v5, v6, Landroid/graphics/BlurMaskFilter;-><init>(F Landroid/graphics/BlurMaskFilter$Blur;)V
    new-instance v5, Landroid/graphics/Paint;
    invoke-direct v5, Landroid/graphics/Paint;-><init>()V
    invoke-virtual v5, v1, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;
    const/4 v1, 2
    new-array v6, v1, [I
    invoke-virtual v2, v5, v6, Landroid/graphics/Bitmap;->extractAlpha(Landroid/graphics/Paint; [I)Landroid/graphics/Bitmap;
    move-result-object v1
    sget-object v5, Landroid/graphics/Bitmap$Config;->ARGB_8888 Landroid/graphics/Bitmap$Config;
    const/4 v7, 1
    invoke-virtual v1, v5, v7, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config; Z)Landroid/graphics/Bitmap;
    move-result-object v1
    new-instance v5, Landroid/graphics/Canvas;
    invoke-direct v5, v1, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V
    const/4 v7, 0
    aget v7, v6, v7
    neg-int v7, v7
    int-to-float v7, v7
    const/4 v8, 1
    aget v6, v6, v8
    neg-int v6, v6
    int-to-float v6, v6
    const/4 v8, 0
    invoke-virtual v5, v2, v7, v6, v8, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap; F F Landroid/graphics/Paint;)V
    invoke-virtual v4, v1, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    iget v1, v3, Lcom/flurry/android/c;->m I
    invoke-static v15, v1, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v1
    iget v2, v3, Lcom/flurry/android/c;->n I
    invoke-static v15, v2, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v2
    invoke-static v15, v4, v1, v2, Lcom/flurry/android/r;->a(Landroid/content/Context; Landroid/widget/ImageView; I I)V
    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_XY Landroid/widget/ImageView$ScaleType;
    invoke-virtual v4, v1, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V
    iget-object v1, v14, Lcom/flurry/android/y;->a Lcom/flurry/android/u;
    iget-wide v5, v3, Lcom/flurry/android/c;->c J
    invoke-virtual v1, v5, v6, Lcom/flurry/android/u;->a(J)Lcom/flurry/android/AdImage;
    move-result-object v1
    if-eqz v1, +02ah
    iget-object v1, v1, Lcom/flurry/android/AdImage;->e [B
    const/4 v2, 0
    array-length v5, v1
    invoke-static v1, v2, v5, Landroid/graphics/BitmapFactory;->decodeByteArray([B I I)Landroid/graphics/Bitmap;
    move-result-object v2
    invoke-virtual v2, Landroid/graphics/Bitmap;->getNinePatchChunk()[B
    move-result-object v1
    invoke-static v1, Landroid/graphics/NinePatch;->isNinePatchChunk([B)Z
    move-result v1
    if-eqz v1, +105h
    new-instance v1, Landroid/graphics/drawable/NinePatchDrawable;
    invoke-virtual v2, Landroid/graphics/Bitmap;->getNinePatchChunk()[B
    move-result-object v5
    new-instance v6, Landroid/graphics/Rect;
    const/4 v7, 0
    const/4 v8, 0
    const/4 v9, 0
    const/4 v10, 0
    invoke-direct v6, v7, v8, v9, v10, Landroid/graphics/Rect;-><init>(I I I I)V
    const/4 v7, 0
    invoke-direct v1, v2, v5, v6, v7, Landroid/graphics/drawable/NinePatchDrawable;-><init>(Landroid/graphics/Bitmap; [B Landroid/graphics/Rect; Ljava/lang/String;)V
    invoke-virtual v14, v1, Lcom/flurry/android/y;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    new-instance v1, Landroid/widget/TextView;
    invoke-direct v1, v15, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    const/4 v2, 5
    invoke-virtual v1, v2, Landroid/widget/TextView;->setId(I)V
    const/4 v2, 0
    const/4 v5, 0
    const/4 v6, 0
    const/4 v7, 0
    invoke-virtual v1, v2, v5, v6, v7, Landroid/widget/TextView;->setPadding(I I I I)V
    new-instance v2, Landroid/widget/TextView;
    invoke-direct v2, v15, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    const/4 v5, 3
    invoke-virtual v2, v5, Landroid/widget/TextView;->setId(I)V
    const/4 v5, 0
    const/4 v6, 0
    const/4 v7, 0
    const/4 v8, 0
    invoke-virtual v2, v5, v6, v7, v8, Landroid/widget/TextView;->setPadding(I I I I)V
    if-eqz v18, +0d4h
    iget v5, v3, Lcom/flurry/android/c;->f I
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTextColor(I)V
    iget v5, v3, Lcom/flurry/android/c;->e I
    int-to-float v5, v5
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTextSize(F)V
    new-instance v5, Ljava/lang/String;
    new-instance v6, Ljava/lang/StringBuilder;
    invoke-direct v6, Ljava/lang/StringBuilder;-><init>()V
    const-string v7, "• "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    iget-object v7, v3, Lcom/flurry/android/c;->b Ljava/lang/String;
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v6
    invoke-direct v5, v6, Ljava/lang/String;-><init>(Ljava/lang/String;)V
    invoke-virtual v1, v5, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    iget-object v5, v3, Lcom/flurry/android/c;->d Ljava/lang/String;
    const/4 v6, 0
    invoke-static v5, v6, Landroid/graphics/Typeface;->create(Ljava/lang/String; I)Landroid/graphics/Typeface;
    move-result-object v5
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    iget v5, v3, Lcom/flurry/android/c;->i I
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTextColor(I)V
    iget v5, v3, Lcom/flurry/android/c;->h I
    int-to-float v5, v5
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTextSize(F)V
    iget-object v5, v3, Lcom/flurry/android/c;->g Ljava/lang/String;
    const/4 v6, 0
    invoke-static v5, v6, Landroid/graphics/Typeface;->create(Ljava/lang/String; I)Landroid/graphics/Typeface;
    move-result-object v5
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    move-object/from16 v0, v17
    iget-object v5, v0, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v2, v5, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    new-instance v5, Landroid/view/ViewGroup$LayoutParams;
    const/4 v6, -2
    const/4 v7, -2
    invoke-direct v5, v6, v7, Landroid/view/ViewGroup$LayoutParams;-><init>(I I)V
    invoke-virtual v14, v5, Lcom/flurry/android/y;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v5, Landroid/widget/RelativeLayout$LayoutParams;
    const/4 v6, -1
    const/4 v7, -2
    invoke-direct v5, v6, v7, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    new-instance v6, Landroid/widget/ImageView;
    invoke-direct v6, v15, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    invoke-virtual v14, v6, v5, Lcom/flurry/android/y;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    iget v5, v3, Lcom/flurry/android/c;->q I
    iget v6, v3, Lcom/flurry/android/c;->o I
    shl-int/lit8 v6, v6, 1
    sub-int/2addr v5, v6
    iget v6, v3, Lcom/flurry/android/c;->m I
    sub-int/2addr v5, v6
    new-instance v6, Landroid/widget/RelativeLayout$LayoutParams;
    const/4 v7, -2
    const/4 v8, -2
    invoke-direct v6, v7, v8, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/16 v7, 9
    invoke-virtual v6, v7, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V
    iget v7, v3, Lcom/flurry/android/c;->o I
    iget v3, v3, Lcom/flurry/android/c;->p I
    const/4 v8, 0
    invoke-virtual v6, v7, v3, v5, v8, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(I I I I)V
    invoke-virtual v14, v4, v6, Lcom/flurry/android/y;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v3, Landroid/widget/RelativeLayout$LayoutParams;
    const/4 v5, -2
    const/4 v6, -2
    invoke-direct v3, v5, v6, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/4 v5, 6
    invoke-virtual v4, Landroid/widget/ImageView;->getId()I
    move-result v6
    invoke-virtual v3, v5, v6, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    const/4 v5, 1
    invoke-virtual v4, Landroid/widget/ImageView;->getId()I
    move-result v6
    invoke-virtual v3, v5, v6, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    const/4 v5, 0
    const/4 v6, 0
    const/4 v7, 0
    const/4 v8, 0
    invoke-virtual v3, v5, v6, v7, v8, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(I I I I)V
    invoke-virtual v14, v1, v3, Lcom/flurry/android/y;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v3, Landroid/widget/RelativeLayout$LayoutParams;
    const/4 v5, -2
    const/4 v6, -2
    invoke-direct v3, v5, v6, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/4 v5, 1
    invoke-virtual v4, Landroid/widget/ImageView;->getId()I
    move-result v4
    invoke-virtual v3, v5, v4, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    const/4 v4, 3
    invoke-virtual v1, Landroid/widget/TextView;->getId()I
    move-result v1
    invoke-virtual v3, v4, v1, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    const/4 v1, 0
    const/4 v4, -2
    const/4 v5, 0
    const/4 v6, 0
    invoke-virtual v3, v1, v4, v5, v6, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(I I I I)V
    invoke-virtual v14, v2, v3, Lcom/flurry/android/y;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    return-void
    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;
    invoke-direct v1, v2, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V
    goto/16 -0f5h
    const/4 v5, 3
    invoke-virtual v1, v5, Landroid/widget/TextView;->setId(I)V
    move-object/from16 v0, v17
    iget-object v5, v0, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v1, v5, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    iget v5, v3, Lcom/flurry/android/c;->i I
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTextColor(I)V
    iget v5, v3, Lcom/flurry/android/c;->h I
    int-to-float v5, v5
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTextSize(F)V
    iget-object v5, v3, Lcom/flurry/android/c;->g Ljava/lang/String;
    const/4 v6, 0
    invoke-static v5, v6, Landroid/graphics/Typeface;->create(Ljava/lang/String; I)Landroid/graphics/Typeface;
    move-result-object v5
    invoke-virtual v1, v5, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    const/4 v5, 4
    invoke-virtual v2, v5, Landroid/widget/TextView;->setId(I)V
    move-object/from16 v0, v17
    iget-object v5, v0, Lcom/flurry/android/v;->c Ljava/lang/String;
    invoke-virtual v2, v5, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    iget v5, v3, Lcom/flurry/android/c;->l I
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTextColor(I)V
    iget v5, v3, Lcom/flurry/android/c;->k I
    int-to-float v5, v5
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTextSize(F)V
    iget-object v5, v3, Lcom/flurry/android/c;->j Ljava/lang/String;
    const/4 v6, 0
    invoke-static v5, v6, Landroid/graphics/Typeface;->create(Ljava/lang/String; I)Landroid/graphics/Typeface;
    move-result-object v5
    invoke-virtual v2, v5, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    goto/16 -0c4h
    move-object v1, v2
    goto/16 -180h
.end method

.method final a()Lcom/flurry/android/p;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/y;->b Lcom/flurry/android/p;
    return-object v0
.end method

.method final a(Ljava/lang/String;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/y;->c Ljava/lang/String;
    return-void
.end method

.method final b(Ljava/lang/String;)Ljava/lang/String;
    .registers 5
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v3, Lcom/flurry/android/y;->c Ljava/lang/String;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v1
    invoke-virtual v0, v1, v2, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
