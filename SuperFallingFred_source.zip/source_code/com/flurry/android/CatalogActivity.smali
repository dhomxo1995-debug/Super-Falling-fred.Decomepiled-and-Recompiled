.class public Lcom/flurry/android/CatalogActivity;
.super Landroid/app/Activity;
.implements Landroid/view/View$OnClickListener;

.field private static bridge a:Ljava/lang/String;
.field private b:Landroid/webkit/WebView;
.field private c:Lcom/flurry/android/w;
.field private d:Ljava/util/List;
.field private e:Lcom/flurry/android/u;
.field private f:Lcom/flurry/android/p;

.method static constructor <clinit>()V
    .registers 1
    const-string v0, "<html><body><table height='100%' width='100%' border='0'><tr><td style='vertical-align:middle;text-align:center'>No recommendations available<p><button type='input' onClick='activity.finish()'>Back</button></td></tr></table></body></html>"
    sput-object v0, Lcom/flurry/android/CatalogActivity;->a Ljava/lang/String;
    return-void
.end method

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Landroid/app/Activity;-><init>()V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/CatalogActivity;->f Lcom/flurry/android/p;
    return-object v0
.end method

.method private a(Lcom/flurry/android/x;)V
    .registers 5
    iget-object v0, v3, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    iget-object v1, v4, Lcom/flurry/android/x;->b Ljava/lang/String;
    invoke-virtual v0, v1, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    iget-object v0, v3, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    iget-object v1, v4, Lcom/flurry/android/x;->c Ljava/util/List;
    invoke-virtual v0, v1, Lcom/flurry/android/w;->a(Ljava/util/List;)V
    return-void
    move-exception v0
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Error loading url: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v4, Lcom/flurry/android/x;->b Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -1ch
.end method

.method static synthetic b(Lcom/flurry/android/CatalogActivity;)J
    .registers 3
    iget-object v0, v2, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->k()J
    move-result-wide v0
    return-wide v0
.end method

.method static synthetic c(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/u;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    return-object v0
.end method

.method public finish()V
    .registers 1
    invoke-super v0, Landroid/app/Activity;->finish()V
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 9
    instance-of v0, v8, Lcom/flurry/android/y;
    if-eqz v0, +075h
    new-instance v0, Lcom/flurry/android/x;
    invoke-direct v0, Lcom/flurry/android/x;-><init>()V
    iget-object v1, v7, Lcom/flurry/android/CatalogActivity;->f Lcom/flurry/android/p;
    iput-object v1, v0, Lcom/flurry/android/x;->a Lcom/flurry/android/p;
    iget-object v1, v7, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v1, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;
    move-result-object v1
    iput-object v1, v0, Lcom/flurry/android/x;->b Ljava/lang/String;
    new-instance v1, Ljava/util/ArrayList;
    iget-object v2, v7, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    invoke-virtual v2, Lcom/flurry/android/w;->b()Ljava/util/List;
    move-result-object v2
    invoke-direct v1, v2, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    iput-object v1, v0, Lcom/flurry/android/x;->c Ljava/util/List;
    iget-object v1, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    invoke-interface v1, v0, Ljava/util/List;->add(Ljava/lang/Object;)Z
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    const/4 v1, 5
    if-le v0, v1, +008h
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    const/4 v1, 0
    invoke-interface v0, v1, Ljava/util/List;->remove(I)Ljava/lang/Object;
    new-instance v1, Lcom/flurry/android/x;
    invoke-direct v1, Lcom/flurry/android/x;-><init>()V
    move-object v0, v8
    check-cast v0, Lcom/flurry/android/y;
    iget-object v2, v7, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v2, Lcom/flurry/android/u;->j()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Lcom/flurry/android/y;->b(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, Lcom/flurry/android/y;->a()Lcom/flurry/android/p;
    move-result-object v3
    iput-object v3, v7, Lcom/flurry/android/CatalogActivity;->f Lcom/flurry/android/p;
    invoke-virtual v0, Lcom/flurry/android/y;->a()Lcom/flurry/android/p;
    move-result-object v0
    iput-object v0, v1, Lcom/flurry/android/x;->a Lcom/flurry/android/p;
    iget-object v0, v1, Lcom/flurry/android/x;->a Lcom/flurry/android/p;
    new-instance v3, Lcom/flurry/android/f;
    const/4 v4, 4
    iget-object v5, v7, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v5, Lcom/flurry/android/u;->k()J
    move-result-wide v5
    invoke-direct v3, v4, v5, v6, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v0, v3, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    iput-object v2, v1, Lcom/flurry/android/x;->b Ljava/lang/String;
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    invoke-virtual v8, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v2
    invoke-virtual v0, v2, Lcom/flurry/android/w;->a(Landroid/content/Context;)Ljava/util/List;
    move-result-object v0
    iput-object v0, v1, Lcom/flurry/android/x;->c Ljava/util/List;
    invoke-direct v7, v1, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/x;)V
    return-void
    invoke-virtual v8, Landroid/view/View;->getId()I
    move-result v0
    const/16 v1, 10000
    if-ne v0, v1, +006h
    invoke-virtual v7, Lcom/flurry/android/CatalogActivity;->finish()V
    goto -ch
    invoke-virtual v8, Landroid/view/View;->getId()I
    move-result v0
    const/16 v1, 10002
    if-ne v0, v1, +008h
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    invoke-virtual v0, Lcom/flurry/android/w;->a()V
    goto -1ah
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-eqz v0, +006h
    invoke-virtual v7, Lcom/flurry/android/CatalogActivity;->finish()V
    goto -26h
    iget-object v0, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    iget-object v1, v7, Lcom/flurry/android/CatalogActivity;->d Ljava/util/List;
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    add-int/lit8 v1, v1, -1
    invoke-interface v0, v1, Ljava/util/List;->remove(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/x;
    invoke-direct v7, v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/x;)V
    goto -3ah
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 11
    const/4 v8, 2
    const/4 v6, 1
    const/4 v1, 0
    const/4 v7, -2
    const/4 v5, -1
    const v0, 16973839
    invoke-virtual v9, v0, Lcom/flurry/android/CatalogActivity;->setTheme(I)V
    invoke-super v9, v10, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    invoke-static Lcom/flurry/android/FlurryAgent;->b()Lcom/flurry/android/u;
    move-result-object v0
    iput-object v0, v9, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v9, Lcom/flurry/android/CatalogActivity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v0, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v2
    if-eqz v2, +01eh
    invoke-virtual v0, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v0
    const-string v2, "o"
    invoke-virtual v0, v2, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J
    move-result-wide v2
    invoke-static v2, v3, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v0
    if-eqz v0, +00eh
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v3
    invoke-virtual v2, v3, v4, Lcom/flurry/android/u;->b(J)Lcom/flurry/android/p;
    move-result-object v0
    iput-object v0, v9, Lcom/flurry/android/CatalogActivity;->f Lcom/flurry/android/p;
    new-instance v0, Lcom/flurry/android/ab;
    invoke-direct v0, v9, v9, Lcom/flurry/android/ab;-><init>(Lcom/flurry/android/CatalogActivity; Landroid/content/Context;)V
    invoke-virtual v0, v6, Lcom/flurry/android/ab;->setId(I)V
    const/high16 v2, -16777216
    invoke-virtual v0, v2, Lcom/flurry/android/ab;->setBackgroundColor(I)V
    new-instance v2, Landroid/webkit/WebView;
    invoke-direct v2, v9, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    iput-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v2, v8, Landroid/webkit/WebView;->setId(I)V
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    const/4 v3, 0
    invoke-virtual v2, v3, Landroid/webkit/WebView;->setScrollBarStyle(I)V
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v2, v5, Landroid/webkit/WebView;->setBackgroundColor(I)V
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->f Lcom/flurry/android/p;
    if-eqz v2, +00ch
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    new-instance v3, Lcom/flurry/android/q;
    invoke-direct v3, v9, Lcom/flurry/android/q;-><init>(Lcom/flurry/android/CatalogActivity;)V
    invoke-virtual v2, v3, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v2, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v2
    invoke-virtual v2, v6, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    const-string v3, "activity"
    invoke-virtual v2, v9, v3, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object; Ljava/lang/String;)V
    new-instance v2, Lcom/flurry/android/w;
    invoke-direct v2, v9, v9, Lcom/flurry/android/w;-><init>(Lcom/flurry/android/CatalogActivity; Landroid/content/Context;)V
    iput-object v2, v9, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    iget-object v2, v9, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    const/4 v3, 3
    invoke-virtual v2, v3, Lcom/flurry/android/w;->setId(I)V
    new-instance v6, Landroid/widget/RelativeLayout;
    invoke-direct v6, v9, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V
    new-instance v2, Landroid/view/ViewGroup$LayoutParams;
    invoke-direct v2, v5, v5, Landroid/view/ViewGroup$LayoutParams;-><init>(I I)V
    invoke-virtual v6, v2, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v2, v5, v7, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/16 v3, 10
    invoke-virtual v0, Lcom/flurry/android/ab;->getId()I
    move-result v4
    invoke-virtual v2, v3, v4, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    invoke-virtual v6, v0, v2, Landroid/widget/RelativeLayout;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v2, v5, v7, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/4 v3, 3
    invoke-virtual v0, Lcom/flurry/android/ab;->getId()I
    move-result v4
    invoke-virtual v2, v3, v4, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    iget-object v3, v9, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    invoke-virtual v3, Lcom/flurry/android/w;->getId()I
    move-result v3
    invoke-virtual v2, v8, v3, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    iget-object v3, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v6, v3, v2, Landroid/widget/RelativeLayout;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v2, v5, v7, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    const/16 v3, 12
    invoke-virtual v0, Lcom/flurry/android/ab;->getId()I
    move-result v0
    invoke-virtual v2, v3, v0, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    iget-object v0, v9, Lcom/flurry/android/CatalogActivity;->c Lcom/flurry/android/w;
    invoke-virtual v6, v0, v2, Landroid/widget/RelativeLayout;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v9, Lcom/flurry/android/CatalogActivity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v0, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v0
    if-nez v0, +015h
    move-object v0, v1
    if-nez v0, +019h
    iget-object v0, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    sget-object v2, Lcom/flurry/android/CatalogActivity;->a Ljava/lang/String;
    const-string v3, "text/html"
    const-string v4, "utf-8"
    move-object v5, v1
    invoke-virtual/range v0 ... v5, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v9, v6, Lcom/flurry/android/CatalogActivity;->setContentView(Landroid/view/View;)V
    return-void
    const-string v2, "u"
    invoke-virtual v0, v2, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    goto -18h
    iget-object v1, v9, Lcom/flurry/android/CatalogActivity;->b Landroid/webkit/WebView;
    invoke-virtual v1, v0, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    goto -10h
.end method

.method protected onDestroy()V
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/CatalogActivity;->e Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->h()V
    invoke-super v1, Landroid/app/Activity;->onDestroy()V
    return-void
.end method
