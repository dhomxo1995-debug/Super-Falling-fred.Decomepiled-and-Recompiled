.class final Lcom/flurry/android/ac;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnFocusChangeListener;

.field private synthetic a:Landroid/widget/TextView;
.field private synthetic b:Lcom/flurry/android/ab;

.method constructor <init>(Lcom/flurry/android/ab; Landroid/widget/TextView;)V
    .registers 3
    iput-object v1, v0, Lcom/flurry/android/ac;->b Lcom/flurry/android/ab;
    iput-object v2, v0, Lcom/flurry/android/ac;->a Landroid/widget/TextView;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onFocusChange(Landroid/view/View; Z)V
    .registers 5
    if-eqz v4, +00eh
    iget-object v0, v2, Lcom/flurry/android/ac;->b Lcom/flurry/android/ab;
    invoke-static v0, Lcom/flurry/android/ab;->a(Lcom/flurry/android/ab;)Landroid/text/SpannedString;
    move-result-object v0
    iget-object v1, v2, Lcom/flurry/android/ac;->a Landroid/widget/TextView;
    invoke-virtual v1, v0, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    return-void
    iget-object v0, v2, Lcom/flurry/android/ac;->b Lcom/flurry/android/ab;
    invoke-static v0, Lcom/flurry/android/ab;->b(Lcom/flurry/android/ab;)Landroid/text/SpannedString;
    move-result-object v0
    goto -ch
.end method
