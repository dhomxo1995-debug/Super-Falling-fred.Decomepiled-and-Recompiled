.class final Lcom/flurry/android/u;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;

.field static a:Ljava/lang/String;
.field static b:Ljava/lang/String;
.field private static bridge c:Ljava/lang/String;
.field private static bridge d:Ljava/lang/String;
.field private static bridge e:Ljava/lang/String;
.field private static f:Ljava/lang/String;
.field private static g:I
.field private static bridge z:J
.field private h:Ljava/lang/String;
.field private i:Ljava/lang/String;
.field private j:Ljava/lang/String;
.field private k:J
.field private l:J
.field private m:J
.field private n:Lcom/flurry/android/z;
.field private o:Z
.field private bridge p:Z
.field private q:Ljava/lang/String;
.field private r:Ljava/util/Map;
.field private s:Landroid/os/Handler;
.field private t:Z
.field private varargs u:Ljava/util/Map;
.field private v:Lcom/flurry/android/ag;
.field private w:Ljava/util/List;
.field private x:Ljava/util/Map;
.field private y:Lcom/flurry/android/AppCircleCallback;

.method static constructor <clinit>()V
    .registers 3
    const-string v0, "market://"
    sput-object v0, Lcom/flurry/android/u;->c Ljava/lang/String;
    const-string v0, "market://details?id="
    sput-object v0, Lcom/flurry/android/u;->d Ljava/lang/String;
    const-string v0, "https://market.android.com/details?id="
    sput-object v0, Lcom/flurry/android/u;->e Ljava/lang/String;
    const-string v0, "com.flurry.android.ACTION_CATALOG"
    sput-object v0, Lcom/flurry/android/u;->f Ljava/lang/String;
    const-string v0, "FlurryAgent"
    sput-object v0, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v0, Ljava/util/Random;
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v1
    invoke-direct v0, v1, v2, Ljava/util/Random;-><init>(J)V
    const/16 v0, 5000
    sput v0, Lcom/flurry/android/u;->g I
    const-string v0, ""
    sput-object v0, Lcom/flurry/android/u;->b Ljava/lang/String;
    const-wide/16 v0, 0
    sput-wide v0, Lcom/flurry/android/u;->z J
    return-void
.end method

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/flurry/android/u;->o Z
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/u;->r Ljava/util/Map;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/u;->u Ljava/util/Map;
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/u;->w Ljava/util/List;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/u;->x Ljava/util/Map;
    new-instance v0, Lcom/flurry/android/z;
    invoke-direct v0, Lcom/flurry/android/z;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/u;)Lcom/flurry/android/AppCircleCallback;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/u;->y Lcom/flurry/android/AppCircleCallback;
    return-object v0
.end method

.method private a(Ljava/lang/String; Lcom/flurry/android/v;)Lcom/flurry/android/Offer;
    .registers 11
    new-instance v3, Lcom/flurry/android/p;
    const/4 v0, 3
    invoke-virtual v8, Lcom/flurry/android/u;->k()J
    move-result-wide v1
    invoke-direct v3, v9, v0, v1, v2, Lcom/flurry/android/p;-><init>(Ljava/lang/String; B J)V
    invoke-direct v8, v3, Lcom/flurry/android/u;->a(Lcom/flurry/android/p;)V
    new-instance v0, Lcom/flurry/android/f;
    const/4 v1, 2
    invoke-virtual v8, Lcom/flurry/android/u;->k()J
    move-result-wide v4
    invoke-direct v0, v1, v4, v5, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v3, v0, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    iput-object v10, v3, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iget-object v0, v8, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    iget-wide v1, v10, Lcom/flurry/android/v;->a J
    invoke-virtual v0, v1, v2, Lcom/flurry/android/z;->a(J)Lcom/flurry/android/al;
    move-result-object v0
    if-nez v0, +033h
    const-string v6, ""
    if-nez v0, +032h
    const/4 v7, 0
    new-instance v0, Lcom/flurry/android/OfferInSdk;
    sget-wide v1, Lcom/flurry/android/u;->z J
    const-wide/16 v4, 1
    add-long/2addr v1, v4
    sput-wide v1, Lcom/flurry/android/u;->z J
    iget-object v4, v10, Lcom/flurry/android/v;->h Lcom/flurry/android/AdImage;
    iget-object v5, v10, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-direct/range v0 ... v7, Lcom/flurry/android/OfferInSdk;-><init>(J Lcom/flurry/android/p; Lcom/flurry/android/AdImage; Ljava/lang/String; Ljava/lang/String; I)V
    iget-object v1, v8, Lcom/flurry/android/u;->x Ljava/util/Map;
    iget-wide v2, v0, Lcom/flurry/android/OfferInSdk;->a J
    invoke-static v2, v3, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v2
    invoke-interface v1, v2, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    new-instance v7, Lcom/flurry/android/Offer;
    iget-wide v1, v0, Lcom/flurry/android/OfferInSdk;->a J
    iget-object v3, v0, Lcom/flurry/android/OfferInSdk;->f Lcom/flurry/android/AdImage;
    iget-object v4, v0, Lcom/flurry/android/OfferInSdk;->c Ljava/lang/String;
    iget-object v5, v0, Lcom/flurry/android/OfferInSdk;->d Ljava/lang/String;
    iget v6, v0, Lcom/flurry/android/OfferInSdk;->e I
    move-object v0, v7
    invoke-direct/range v0 ... v6, Lcom/flurry/android/Offer;-><init>(J Lcom/flurry/android/AdImage; Ljava/lang/String; Ljava/lang/String; I)V
    return-object v7
    iget-object v6, v0, Lcom/flurry/android/al;->a Ljava/lang/String;
    goto -31h
    iget v7, v0, Lcom/flurry/android/al;->c I
    goto -31h
.end method

.method private a(Lcom/flurry/android/p; Ljava/lang/Long;)Ljava/lang/String;
    .registers 9
    iget-object v0, v7, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    invoke-virtual v7, Lcom/flurry/android/p;->a()J
    move-result-wide v1
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "?apik="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-object v4, v6, Lcom/flurry/android/u;->j Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&cid="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-wide v4, v0, Lcom/flurry/android/v;->e J
    invoke-virtual v3, v4, v5, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&adid="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-wide v4, v0, Lcom/flurry/android/v;->a J
    invoke-virtual v3, v4, v5, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&pid="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-object v4, v6, Lcom/flurry/android/u;->q Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&iid="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-wide v4, v6, Lcom/flurry/android/u;->k J
    invoke-virtual v3, v4, v5, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&sid="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-wide v4, v6, Lcom/flurry/android/u;->l J
    invoke-virtual v3, v4, v5, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "&its="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, v2, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, "&hid="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v7, Lcom/flurry/android/p;->a Ljava/lang/String;
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, "&ac="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v0, v0, Lcom/flurry/android/v;->g [B
    invoke-static v0, Lcom/flurry/android/u;->a([B)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    iget-object v0, v6, Lcom/flurry/android/u;->r Ljava/util/Map;
    if-eqz v0, +05bh
    iget-object v0, v6, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-nez v0, +053h
    iget-object v0, v6, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +043h
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "c_"
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-static v0, Lcom/flurry/android/r;->a(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    const-string v4, "&"
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v4, "="
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -46h
    const-string v0, "&ats="
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    if-eqz v8, +005h
    invoke-virtual v2, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method static synthetic a(Lcom/flurry/android/u; Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    invoke-direct v1, v2, Lcom/flurry/android/u;->d(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method private static a([B)Ljava/lang/String;
    .registers 5
    const/16 v3, 10
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const/4 v0, 0
    array-length v2, v4
    if-ge v0, v2, +031h
    aget-byte v2, v4, v0
    shr-int/lit8 v2, v2, 4
    and-int/lit8 v2, v2, 15
    if-ge v2, v3, +017h
    add-int/lit8 v2, v2, 48
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    aget-byte v2, v4, v0
    and-int/lit8 v2, v2, 15
    if-ge v2, v3, +014h
    add-int/lit8 v2, v2, 48
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    add-int/lit8 v0, v0, 1
    goto -1fh
    add-int/lit8 v2, v2, 65
    add-int/lit8 v2, v2, -10
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    goto -17h
    add-int/lit8 v2, v2, 65
    add-int/lit8 v2, v2, -10
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    goto -14h
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method private a(Ljava/util/List; Ljava/lang/Long;)Ljava/util/List;
    .registers 11
    const/4 v7, 0
    if-eqz v9, +010h
    invoke-interface v9, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-nez v0, +00ah
    iget-object v0, v8, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->b()Z
    move-result v0
    if-nez v0, +007h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    return-object v0
    iget-object v1, v8, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-interface v9, v7, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-virtual v1, v0, Lcom/flurry/android/z;->a(Ljava/lang/String;)[Lcom/flurry/android/v;
    move-result-object v0
    if-eqz v0, +041h
    array-length v1, v0
    if-lez v1, +03eh
    new-instance v1, Ljava/util/ArrayList;
    invoke-static v0, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    invoke-direct v1, v0, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    invoke-static v1, Ljava/util/Collections;->shuffle(Ljava/util/List;)V
    if-eqz v10, +01fh
    invoke-interface v1, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +015h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/v;
    iget-wide v3, v0, Lcom/flurry/android/v;->a J
    invoke-virtual v10, Ljava/lang/Long;->longValue()J
    move-result-wide v5
    cmp-long v0, v3, v5
    if-nez v0, -014h
    invoke-interface v2, Ljava/util/Iterator;->remove()V
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v0
    invoke-interface v9, Ljava/util/List;->size()I
    move-result v2
    invoke-static v0, v2, Ljava/lang/Math;->min(I I)I
    move-result v0
    invoke-interface v1, v7, v0, Ljava/util/List;->subList(I I)Ljava/util/List;
    move-result-object v0
    goto -4dh
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    goto -52h
.end method

.method private a(Lcom/flurry/android/p;)V
    .registers 5
    iget-object v0, v3, Lcom/flurry/android/u;->w Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    const/16 v1, 32767
    if-ge v0, v1, +014h
    iget-object v0, v3, Lcom/flurry/android/u;->w Ljava/util/List;
    invoke-interface v0, v4, Ljava/util/List;->add(Ljava/lang/Object;)Z
    iget-object v0, v3, Lcom/flurry/android/u;->u Ljava/util/Map;
    invoke-virtual v4, Lcom/flurry/android/p;->a()J
    move-result-wide v1
    invoke-static v1, v2, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-interface v0, v1, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/u; Landroid/content/Context; Ljava/lang/String;)V
    .registers 7
    sget-object v0, Lcom/flurry/android/u;->d Ljava/lang/String;
    invoke-virtual v6, v0, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +093h
    sget-object v0, Lcom/flurry/android/u;->d Ljava/lang/String;
    invoke-virtual v0, Ljava/lang/String;->length()I
    move-result v0
    invoke-virtual v6, v0, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v0
    iget-boolean v1, v4, Lcom/flurry/android/u;->o Z
    if-eqz v1, +047h
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Launching Android Market for app "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v0, Landroid/content/Intent;
    const-string v1, "android.intent.action.VIEW"
    invoke-direct v0, v1, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-static v6, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v1
    invoke-virtual v0, v1, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v5, v0, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    return-void
    move-exception v0
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Cannot launch Marketplace url "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Launching Android Market website for app "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    sget-object v2, Lcom/flurry/android/u;->e Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    new-instance v1, Landroid/content/Intent;
    const-string v2, "android.intent.action.VIEW"
    invoke-direct v1, v2, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-static v0, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v0
    invoke-virtual v1, v0, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v5, v0, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    goto -58h
    sget-object v0, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Unexpected android market url scheme: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    goto -71h
.end method

.method private static a(Ljava/lang/Runnable;)V
    .registers 2
    new-instance v0, Landroid/os/Handler;
    invoke-direct v0, Landroid/os/Handler;-><init>()V
    invoke-virtual v0, v1, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    return-void
.end method

.method private b(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    .registers 8
    new-instance v0, Landroid/content/Intent;
    invoke-static Lcom/flurry/android/u;->p()Ljava/lang/String;
    move-result-object v1
    invoke-direct v0, v1, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    const-string v1, "android.intent.category.DEFAULT"
    invoke-virtual v0, v1, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;
    const-string v1, "u"
    invoke-virtual v0, v1, v7, Landroid/content/Intent;->putExtra(Ljava/lang/String; Ljava/lang/String;)Landroid/content/Intent;
    if-eqz v6, +00bh
    const-string v1, "o"
    invoke-virtual v6, Lcom/flurry/android/p;->a()J
    move-result-wide v2
    invoke-virtual v0, v1, v2, v3, Landroid/content/Intent;->putExtra(Ljava/lang/String; J)Landroid/content/Intent;
    invoke-virtual v5, v0, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    return-void
.end method

.method static synthetic b(Lcom/flurry/android/u; Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, v1, Lcom/flurry/android/u;->e(Ljava/lang/String;)V
    return-void
.end method

.method private d(Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    const/4 v0, 0
    sget-object v1, Lcom/flurry/android/u;->c Ljava/lang/String;
    invoke-virtual v6, v1, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v1
    if-nez v1, +030h
    new-instance v1, Lorg/apache/http/client/methods/HttpGet;
    invoke-direct v1, v6, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/lang/String;)V
    new-instance v2, Lorg/apache/http/impl/client/DefaultHttpClient;
    invoke-direct v2, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>()V
    invoke-interface v2, v1, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    move-result-object v1
    invoke-interface v1, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;
    move-result-object v2
    invoke-interface v2, Lorg/apache/http/StatusLine;->getStatusCode()I
    move-result v2
    const/16 v3, 200
    if-ne v2, v3, +017h
    invoke-interface v1, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;
    move-result-object v1
    invoke-static v1, Lorg/apache/http/util/EntityUtils;->toString(Lorg/apache/http/HttpEntity;)Ljava/lang/String;
    move-result-object v6
    sget-object v1, Lcom/flurry/android/u;->c Ljava/lang/String;
    invoke-virtual v6, v1, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v1
    if-nez v1, +006h
    invoke-direct v5, v6, Lcom/flurry/android/u;->d(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    return-object v6
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Cannot process with responseCode "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v1, v3, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Error when fetching application's android market ID, responseCode "
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-direct v5, v1, Lcom/flurry/android/u;->e(Ljava/lang/String;)V
    goto -2fh
    move-exception v1
    sget-object v2, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Unknown host: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v1, Ljava/net/UnknownHostException;->getMessage()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v2, v5, Lcom/flurry/android/u;->y Lcom/flurry/android/AppCircleCallback;
    if-eqz v2, +01ch
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Unknown host: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v1, Ljava/net/UnknownHostException;->getMessage()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-direct v5, v1, Lcom/flurry/android/u;->e(Ljava/lang/String;)V
    move-object v6, v0
    goto -6ch
    move-exception v1
    sget-object v2, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Failed on url: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    move-object v6, v0
    goto/16 -087h
.end method

.method private e(Ljava/lang/String;)V
    .registers 3
    new-instance v0, Lcom/flurry/android/ae;
    invoke-direct v0, v1, v2, Lcom/flurry/android/ae;-><init>(Lcom/flurry/android/u; Ljava/lang/String;)V
    invoke-static v0, Lcom/flurry/android/u;->a(Ljava/lang/Runnable;)V
    return-void
.end method

.method private synchronized o()Lcom/flurry/android/AdImage;
    .registers 3
    monitor-enter v2
    invoke-direct v2, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v2
    return-object v0
    iget-object v0, v2, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    const/4 v1, 1
    invoke-virtual v0, v1, Lcom/flurry/android/z;->a(S)Lcom/flurry/android/AdImage;
    move-result-object v0
    goto -9h
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method private static p()Ljava/lang/String;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->a Ljava/lang/String;
    if-eqz v0, +005h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->a Ljava/lang/String;
    return-object v0
    sget-object v0, Lcom/flurry/android/u;->f Ljava/lang/String;
    goto -3h
.end method

.method private q()Z
    .registers 3
    iget-boolean v0, v2, Lcom/flurry/android/u;->p Z
    if-nez v0, +009h
    sget-object v0, Lcom/flurry/android/u;->a Ljava/lang/String;
    const-string v1, "AppCircle is not initialized"
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v2, Lcom/flurry/android/u;->q Ljava/lang/String;
    if-nez v0, +009h
    sget-object v0, Lcom/flurry/android/u;->a Ljava/lang/String;
    const-string v1, "Cannot identify UDID."
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    iget-boolean v0, v2, Lcom/flurry/android/u;->p Z
    return v0
.end method

.method final synchronized a(Landroid/content/Context; Ljava/lang/String; I)Landroid/view/View;
    .registers 6
    monitor-enter v2
    invoke-direct v2, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v2
    return-object v0
    new-instance v0, Lcom/flurry/android/o;
    invoke-direct v0, v2, v3, v4, v5, Lcom/flurry/android/o;-><init>(Lcom/flurry/android/u; Landroid/content/Context; Ljava/lang/String; I)V
    iget-object v1, v2, Lcom/flurry/android/u;->v Lcom/flurry/android/ag;
    invoke-virtual v1, v0, Lcom/flurry/android/ag;->a(Lcom/flurry/android/o;)V
    goto -ch
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized a(J)Lcom/flurry/android/AdImage;
    .registers 4
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v1
    return-object v0
    iget-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, v2, v3, Lcom/flurry/android/z;->b(J)Lcom/flurry/android/AdImage;
    move-result-object v0
    goto -8h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(Landroid/content/Context; Ljava/util/List; Ljava/lang/Long; I Z)Ljava/util/List;
    .registers 17
    monitor-enter v11
    invoke-direct v11, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +008h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    monitor-exit v11
    return-object v0
    iget-object v0, v11, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->b()Z
    move-result v0
    if-eqz v0, +091h
    if-eqz v13, +08fh
    invoke-direct v11, v13, v14, Lcom/flurry/android/u;->a(Ljava/util/List; Ljava/lang/Long;)Ljava/util/List;
    move-result-object v9
    invoke-interface v13, Ljava/util/List;->size()I
    move-result v0
    invoke-interface v9, Ljava/util/List;->size()I
    move-result v1
    invoke-static v0, v1, Ljava/lang/Math;->min(I I)I
    move-result v10
    new-instance v7, Ljava/util/ArrayList;
    invoke-direct v7, Ljava/util/ArrayList;-><init>()V
    const/4 v0, 0
    move v8, v0
    if-ge v8, v10, +073h
    invoke-interface v13, v8, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iget-object v1, v11, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v1, v0, Lcom/flurry/android/z;->b(Ljava/lang/String;)Lcom/flurry/android/e;
    move-result-object v4
    if-eqz v4, +049h
    new-instance v3, Lcom/flurry/android/p;
    invoke-interface v13, v8, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    const/4 v1, 1
    invoke-virtual v11, Lcom/flurry/android/u;->k()J
    move-result-wide v5
    invoke-direct v3, v0, v1, v5, v6, Lcom/flurry/android/p;-><init>(Ljava/lang/String; B J)V
    invoke-direct v11, v3, Lcom/flurry/android/u;->a(Lcom/flurry/android/p;)V
    invoke-interface v9, Ljava/util/List;->size()I
    move-result v0
    if-ge v8, v0, +02ch
    invoke-interface v9, v8, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/v;
    iput-object v0, v3, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    new-instance v0, Lcom/flurry/android/f;
    const/4 v1, 2
    invoke-virtual v11, Lcom/flurry/android/u;->k()J
    move-result-wide v5
    invoke-direct v0, v1, v5, v6, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v3, v0, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    new-instance v0, Lcom/flurry/android/y;
    move-object v1, v12
    move-object v2, v11
    move v5, v15
    move/from16 v6, v16
    invoke-direct/range v0 ... v6, Lcom/flurry/android/y;-><init>(Landroid/content/Context; Lcom/flurry/android/u; Lcom/flurry/android/p; Lcom/flurry/android/e; I Z)V
    const/4 v1, 0
    invoke-direct v11, v3, v1, Lcom/flurry/android/u;->a(Lcom/flurry/android/p; Ljava/lang/Long;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/flurry/android/y;->a(Ljava/lang/String;)V
    invoke-interface v7, v0, Ljava/util/List;->add(Ljava/lang/Object;)Z
    add-int/lit8 v0, v8, 1
    move v8, v0
    goto -56h
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Cannot find hook: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    goto -1ch
    move-exception v0
    monitor-exit v11
    throw v0
    move-object v0, v7
    goto/16 -097h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    goto/16 -09dh
.end method

.method final synchronized a()V
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->w Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->clear()V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(I)V
    .registers 3
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->y Lcom/flurry/android/AppCircleCallback;
    if-eqz v0, +00ah
    new-instance v0, Lcom/flurry/android/ad;
    invoke-direct v0, v1, v2, Lcom/flurry/android/ad;-><init>(Lcom/flurry/android/u; I)V
    invoke-static v0, Lcom/flurry/android/u;->a(Ljava/lang/Runnable;)V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(Landroid/content/Context; J)V
    .registers 11
    monitor-enter v7
    invoke-direct v7, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v7
    return-void
    iget-object v0, v7, Lcom/flurry/android/u;->x Ljava/util/Map;
    invoke-static v9, v10, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/OfferInSdk;
    if-nez v0, +01eh
    sget-object v0, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Cannot find offer "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v9, v10, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    goto -28h
    move-exception v0
    monitor-exit v7
    throw v0
    iget-object v1, v0, Lcom/flurry/android/OfferInSdk;->b Lcom/flurry/android/p;
    new-instance v2, Lcom/flurry/android/f;
    const/4 v3, 4
    invoke-virtual v7, Lcom/flurry/android/u;->k()J
    move-result-wide v4
    invoke-direct v2, v3, v4, v5, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v1, v2, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    invoke-static Lcom/flurry/android/FlurryAgent;->c()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v1, Lcom/flurry/android/p;->a()J
    move-result-wide v3
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v3
    invoke-direct v7, v1, v3, Lcom/flurry/android/u;->a(Lcom/flurry/android/p; Ljava/lang/Long;)Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    sget-object v3, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Offer "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    iget-wide v5, v0, Lcom/flurry/android/OfferInSdk;->a J
    invoke-virtual v4, v5, v6, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v4, " accepted. Sent with cookies: "
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v4, v7, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v3, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v7, v8, v1, v2, Lcom/flurry/android/u;->a(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    goto/16 -085h
.end method

.method final synchronized a(Landroid/content/Context; Lcom/flurry/android/a;)V
    .registers 8
    const/4 v0, 1
    monitor-enter v5
    iget-boolean v1, v5, Lcom/flurry/android/u;->p Z
    if-nez v1, +081h
    iget-object v1, v7, Lcom/flurry/android/a;->e Ljava/lang/String;
    iput-object v1, v5, Lcom/flurry/android/u;->h Ljava/lang/String;
    iget-object v1, v7, Lcom/flurry/android/a;->f Ljava/lang/String;
    iput-object v1, v5, Lcom/flurry/android/u;->i Ljava/lang/String;
    iget-object v1, v7, Lcom/flurry/android/a;->a Ljava/lang/String;
    iput-object v1, v5, Lcom/flurry/android/u;->j Ljava/lang/String;
    iget-wide v1, v7, Lcom/flurry/android/a;->b J
    iput-wide v1, v5, Lcom/flurry/android/u;->k J
    iget-wide v1, v7, Lcom/flurry/android/a;->c J
    iput-wide v1, v5, Lcom/flurry/android/u;->l J
    iget-wide v1, v7, Lcom/flurry/android/a;->d J
    iput-wide v1, v5, Lcom/flurry/android/u;->m J
    iget-object v1, v7, Lcom/flurry/android/a;->g Landroid/os/Handler;
    iput-object v1, v5, Lcom/flurry/android/u;->s Landroid/os/Handler;
    new-instance v1, Lcom/flurry/android/ag;
    iget-object v2, v5, Lcom/flurry/android/u;->s Landroid/os/Handler;
    sget v3, Lcom/flurry/android/u;->g I
    invoke-direct v1, v2, v3, Lcom/flurry/android/ag;-><init>(Landroid/os/Handler; I)V
    iput-object v1, v5, Lcom/flurry/android/u;->v Lcom/flurry/android/ag;
    invoke-virtual v6, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    move-result-object v1
    invoke-virtual v1, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    iget-object v1, v5, Lcom/flurry/android/u;->x Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->clear()V
    iget-object v1, v5, Lcom/flurry/android/u;->u Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->clear()V
    iget-object v1, v5, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v1, v6, v5, v7, Lcom/flurry/android/z;->a(Landroid/content/Context; Lcom/flurry/android/u; Lcom/flurry/android/a;)V
    iget-object v1, v5, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->clear()V
    invoke-virtual v6, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v1
    invoke-virtual v6, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v2
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    sget-object v4, Lcom/flurry/android/u;->d Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    new-instance v3, Landroid/content/Intent;
    const-string v4, "android.intent.action.VIEW"
    invoke-direct v3, v4, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-static v2, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v2
    invoke-virtual v3, v2, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;
    const/high16 v2, 65536
    invoke-virtual v1, v3, v2, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent; I)Ljava/util/List;
    move-result-object v1
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    if-lez v1, +00ch
    iput-boolean v0, v5, Lcom/flurry/android/u;->o Z
    invoke-virtual v5, Lcom/flurry/android/u;->a()V
    const/4 v0, 1
    iput-boolean v0, v5, Lcom/flurry/android/u;->p Z
    monitor-exit v5
    return-void
    const/4 v0, 0
    goto -bh
    move-exception v0
    monitor-exit v5
    throw v0
.end method

.method final synchronized a(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    .registers 6
    monitor-enter v2
    invoke-direct v2, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v2
    return-void
    iget-object v0, v2, Lcom/flurry/android/u;->s Landroid/os/Handler;
    new-instance v1, Lcom/flurry/android/ak;
    invoke-direct v1, v2, v5, v3, v4, Lcom/flurry/android/ak;-><init>(Lcom/flurry/android/u; Ljava/lang/String; Landroid/content/Context; Lcom/flurry/android/p;)V
    invoke-virtual v0, v1, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    goto -ch
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized a(Landroid/content/Context; Ljava/lang/String;)V
    .registers 8
    monitor-enter v5
    invoke-direct v5, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v5
    return-void
    const/4 v0, 1
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0
    aput-object v7, v0, v1
    invoke-static v0, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    const/4 v1, 0
    invoke-direct v5, v0, v1, Lcom/flurry/android/u;->a(Ljava/util/List; Ljava/lang/Long;)Ljava/util/List;
    move-result-object v0
    if-eqz v0, +061h
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v1
    if-nez v1, +05bh
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v1
    iget-wide v3, v5, Lcom/flurry/android/u;->m J
    sub-long/2addr v1, v3
    new-instance v3, Lcom/flurry/android/p;
    const/4 v4, 2
    invoke-direct v3, v7, v4, v1, v2, Lcom/flurry/android/p;-><init>(Ljava/lang/String; B J)V
    const/4 v1, 0
    invoke-interface v0, v1, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/v;
    iput-object v0, v3, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    invoke-direct v5, v3, Lcom/flurry/android/u;->a(Lcom/flurry/android/p;)V
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    iget-object v1, v5, Lcom/flurry/android/u;->h Ljava/lang/String;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v1
    invoke-static v1, v2, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-direct v5, v3, v1, Lcom/flurry/android/u;->a(Lcom/flurry/android/p; Ljava/lang/Long;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-direct v5, v6, v3, v0, Lcom/flurry/android/u;->b(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    goto -54h
    move-exception v0
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to launch promotional canvas for hook: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -6eh
    move-exception v0
    monitor-exit v5
    throw v0
    new-instance v0, Landroid/content/Intent;
    invoke-static Lcom/flurry/android/u;->p()Ljava/lang/String;
    move-result-object v1
    invoke-direct v0, v1, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    const-string v1, "android.intent.category.DEFAULT"
    invoke-virtual v0, v1, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;
    invoke-virtual v6, v0, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    goto/16 -083h
.end method

.method final a(Lcom/flurry/android/AppCircleCallback;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/u;->y Lcom/flurry/android/AppCircleCallback;
    return-void
.end method

.method final a(Ljava/lang/String;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/u;->q Ljava/lang/String;
    return-void
.end method

.method final synchronized a(Ljava/lang/String; Ljava/lang/String;)V
    .registers 4
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-interface v0, v2, v3, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(Ljava/util/List;)V
    .registers 5
    monitor-enter v3
    invoke-direct v3, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v3
    return-void
    invoke-interface v4, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, -00ah
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Long;
    iget-object v2, v3, Lcom/flurry/android/u;->x Ljava/util/Map;
    invoke-interface v2, v0, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    goto -11h
    move-exception v0
    monitor-exit v3
    throw v0
.end method

.method final synchronized a(Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map;)V
    .registers 14
    monitor-enter v7
    invoke-direct v7, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v7
    return-void
    iget-object v0, v7, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    move-object v1, v8
    move-object v2, v9
    move-object v3, v10
    move-object v4, v11
    move-object v5, v12
    move-object v6, v13
    invoke-virtual/range v0 ... v6, Lcom/flurry/android/z;->a(Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map;)V
    const-string v0, "FlurryAgent"
    iget-object v1, v7, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v1, Lcom/flurry/android/z;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    goto -18h
    move-exception v0
    monitor-exit v7
    throw v0
.end method

.method final a(Z)V
    .registers 2
    iput-boolean v1, v0, Lcom/flurry/android/u;->t Z
    return-void
.end method

.method final synchronized b(Ljava/lang/String;)Lcom/flurry/android/Offer;
    .registers 7
    const/4 v0, 0
    monitor-enter v5
    invoke-direct v5, Lcom/flurry/android/u;->q()Z
    move-result v1
    if-nez v1, +004h
    monitor-exit v5
    return-object v0
    const/4 v1, 1
    new-array v1, v1, [Ljava/lang/String;
    const/4 v2, 0
    aput-object v6, v1, v2
    invoke-static v1, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v1
    const/4 v2, 0
    invoke-direct v5, v1, v2, Lcom/flurry/android/u;->a(Ljava/util/List; Ljava/lang/Long;)Ljava/util/List;
    move-result-object v1
    if-eqz v1, -011h
    invoke-interface v1, Ljava/util/List;->isEmpty()Z
    move-result v2
    if-nez v2, -017h
    const/4 v0, 0
    invoke-interface v1, v0, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/v;
    invoke-direct v5, v6, v0, Lcom/flurry/android/u;->a(Ljava/lang/String; Lcom/flurry/android/v;)Lcom/flurry/android/Offer;
    move-result-object v0
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Impression for offer with ID "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v0, Lcom/flurry/android/Offer;->getId()J
    move-result-wide v3
    invoke-virtual v2, v3, v4, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -40h
    move-exception v0
    monitor-exit v5
    throw v0
.end method

.method final synchronized b(J)Lcom/flurry/android/p;
    .registers 5
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/u;->u Ljava/util/Map;
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/p;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final b()Z
    .registers 2
    iget-boolean v0, v1, Lcom/flurry/android/u;->p Z
    return v0
.end method

.method final synchronized c(Ljava/lang/String;)Ljava/util/List;
    .registers 7
    monitor-enter v5
    invoke-direct v5, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +008h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    monitor-exit v5
    return-object v0
    iget-object v0, v5, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->b()Z
    move-result v0
    if-nez v0, +007h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    goto -eh
    iget-object v0, v5, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, v6, Lcom/flurry/android/z;->a(Ljava/lang/String;)[Lcom/flurry/android/v;
    move-result-object v2
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    if-eqz v2, +015h
    array-length v1, v2
    if-lez v1, +012h
    array-length v3, v2
    const/4 v1, 0
    if-ge v1, v3, +00eh
    aget-object v4, v2, v1
    invoke-direct v5, v6, v4, Lcom/flurry/android/u;->a(Ljava/lang/String; Lcom/flurry/android/v;)Lcom/flurry/android/Offer;
    move-result-object v4
    invoke-interface v0, v4, Ljava/util/List;->add(Ljava/lang/Object;)Z
    add-int/lit8 v1, v1, 1
    goto -dh
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Impressions for "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v3
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, " offers."
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -51h
    move-exception v0
    monitor-exit v5
    throw v0
.end method

.method final synchronized c()V
    .registers 2
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v1
    return-void
    iget-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->d()V
    goto -7h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized d()V
    .registers 2
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v1
    return-void
    iget-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->e()V
    goto -7h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized e()J
    .registers 3
    monitor-enter v2
    invoke-direct v2, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +006h
    const-wide/16 v0, 0
    monitor-exit v2
    return-wide v0
    iget-object v0, v2, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->c()J
    move-result-wide v0
    goto -8h
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized f()Ljava/util/Set;
    .registers 2
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +008h
    invoke-static Ljava/util/Collections;->emptySet()Ljava/util/Set;
    move-result-object v0
    monitor-exit v1
    return-object v0
    iget-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->a()Ljava/util/Set;
    move-result-object v0
    goto -8h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized g()Ljava/util/List;
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->w Ljava/util/List;
    monitor-exit v1
    return-object v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized h()V
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->u Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->clear()V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final i()Z
    .registers 2
    iget-boolean v0, v1, Lcom/flurry/android/u;->t Z
    return v0
.end method

.method final j()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/u;->h Ljava/lang/String;
    return-object v0
.end method

.method final k()J
    .registers 5
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v0
    iget-wide v2, v4, Lcom/flurry/android/u;->m J
    sub-long/2addr v0, v2
    return-wide v0
.end method

.method final synchronized l()V
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/u;->r Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->clear()V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized m()Lcom/flurry/android/AdImage;
    .registers 2
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v1
    return-object v0
    invoke-direct v1, Lcom/flurry/android/u;->o()Lcom/flurry/android/AdImage;
    move-result-object v0
    goto -6h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized n()Z
    .registers 2
    monitor-enter v1
    invoke-direct v1, Lcom/flurry/android/u;->q()Z
    move-result v0
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v1
    return v0
    iget-object v0, v1, Lcom/flurry/android/u;->n Lcom/flurry/android/z;
    invoke-virtual v0, Lcom/flurry/android/z;->b()Z
    move-result v0
    goto -8h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public final synchronized onClick(Landroid/view/View;)V
    .registers 9
    monitor-enter v7
    move-object v0, v8
    check-cast v0, Lcom/flurry/android/y;
    move-object v1, v0
    invoke-virtual v1, Lcom/flurry/android/y;->a()Lcom/flurry/android/p;
    move-result-object v2
    new-instance v3, Lcom/flurry/android/f;
    const/4 v4, 4
    invoke-virtual v7, Lcom/flurry/android/u;->k()J
    move-result-wide v5
    invoke-direct v3, v4, v5, v6, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v2, v3, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    iget-boolean v3, v7, Lcom/flurry/android/u;->t Z
    if-eqz v3, +011h
    invoke-virtual v8, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v3
    iget-object v4, v7, Lcom/flurry/android/u;->h Ljava/lang/String;
    invoke-virtual v1, v4, Lcom/flurry/android/y;->b(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-direct v7, v3, v2, v1, Lcom/flurry/android/u;->b(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    monitor-exit v7
    return-void
    invoke-virtual v8, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v3
    iget-object v4, v7, Lcom/flurry/android/u;->i Ljava/lang/String;
    invoke-virtual v1, v4, Lcom/flurry/android/y;->b(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v7, v3, v2, v1, Lcom/flurry/android/u;->a(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    goto -fh
    move-exception v1
    monitor-exit v7
    throw v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 4
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "[adLogs="
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v3, Lcom/flurry/android/u;->w Ljava/util/List;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, "]"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
