package com.flurry.android;
final class x {
    com.flurry.android.p a;
    String b;
    java.util.List c;

    x()
    {
        return;
    }
}
