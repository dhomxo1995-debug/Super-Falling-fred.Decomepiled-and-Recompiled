package com.flurry.android;
final class a {
    String a;
    long b;
    long c;
    long d;
    String e;
    String f;
    android.os.Handler g;

    a()
    {
        return;
    }
}
