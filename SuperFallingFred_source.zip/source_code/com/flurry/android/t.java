package com.flurry.android;
final class t implements java.lang.Runnable {
    private synthetic java.util.Map a;
    private synthetic com.flurry.android.InstallReceiver b;

    t(com.flurry.android.InstallReceiver p1, java.util.Map p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }

    public final void run()
    {
        java.util.Map$Entry v2_0 = 0;
        try {
            String v1_17 = com.flurry.android.InstallReceiver.a(this.b).getParentFile();
        } catch (String v1_2) {
            com.flurry.android.ah.b("InstallReceiver", "", v1_2);
            com.flurry.android.r.a(v2_0);
            return;
        } catch (String v1_10) {
            com.flurry.android.r.a(v2_0);
            throw v1_10;
        }
        if ((v1_17.mkdirs()) || (v1_17.exists())) {
            String v3_4 = new java.io.DataOutputStream(new java.io.FileOutputStream(com.flurry.android.InstallReceiver.a(this.b)));
            try {
                java.util.Iterator v7 = this.a.entrySet().iterator();
                int v4_0 = 1;
            } catch (String v1_2) {
                v2_0 = v3_4;
            } catch (String v1_10) {
                v2_0 = v3_4;
            }
            while (v7.hasNext()) {
                java.util.Map$Entry v2_1 = ((java.util.Map$Entry) v7.next());
                if (v4_0 != 1) {
                    v3_4.writeUTF("&");
                } else {
                    v4_0 = 0;
                }
                v3_4.writeUTF(((String) v2_1.getKey()));
                v3_4.writeUTF("=");
                v3_4.writeUTF(((String) v2_1.getValue()));
            }
            v3_4.writeShort(0);
            com.flurry.android.r.a(v3_4);
            return;
        } else {
            com.flurry.android.ah.b("InstallReceiver", new StringBuilder().append("Unable to create persistent dir: ").append(v1_17).toString());
            com.flurry.android.r.a(0);
            return;
        }
    }
}
