.class final Lcom/flurry/android/o;
.super Landroid/widget/RelativeLayout;

.field private a:Lcom/flurry/android/u;
.field private b:Landroid/content/Context;
.field private c:Ljava/lang/String;
.field private d:I
.field private e:Z
.field private f:Z

.method constructor <init>(Lcom/flurry/android/u; Landroid/content/Context; Ljava/lang/String; I)V
    .registers 5
    invoke-direct v0, v2, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V
    iput-object v1, v0, Lcom/flurry/android/o;->a Lcom/flurry/android/u;
    iput-object v2, v0, Lcom/flurry/android/o;->b Landroid/content/Context;
    iput-object v3, v0, Lcom/flurry/android/o;->c Ljava/lang/String;
    iput v4, v0, Lcom/flurry/android/o;->d I
    return-void
.end method

.method private static b()Landroid/widget/RelativeLayout$LayoutParams;
    .registers 2
    const/4 v1, -1
    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v0, v1, v1, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    return-object v0
.end method

.method private synchronized c()Lcom/flurry/android/y;
    .registers 8
    const/4 v6, 0
    monitor-enter v7
    iget-object v0, v7, Lcom/flurry/android/o;->a Lcom/flurry/android/u;
    iget-object v1, v7, Lcom/flurry/android/o;->b Landroid/content/Context;
    const/4 v2, 1
    new-array v2, v2, [Ljava/lang/String;
    const/4 v3, 0
    iget-object v4, v7, Lcom/flurry/android/o;->c Ljava/lang/String;
    aput-object v4, v2, v3
    invoke-static v2, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v2
    const/4 v3, 0
    iget v4, v7, Lcom/flurry/android/o;->d I
    const/4 v5, 0
    invoke-virtual/range v0 ... v5, Lcom/flurry/android/u;->a(Landroid/content/Context; Ljava/util/List; Ljava/lang/Long; I Z)Ljava/util/List;
    move-result-object v0
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v1
    if-nez v1, +013h
    const/4 v1, 0
    invoke-interface v0, v1, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/y;
    iget-object v1, v7, Lcom/flurry/android/o;->a Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/y;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    monitor-exit v7
    return-object v0
    move-exception v0
    monitor-exit v7
    throw v0
    move-object v0, v6
    goto -6h
.end method

.method final a()V
    .registers 7
    const/4 v5, 1
    iget-boolean v0, v6, Lcom/flurry/android/o;->e Z
    if-nez v0, +029h
    invoke-direct v6, Lcom/flurry/android/o;->c()Lcom/flurry/android/y;
    move-result-object v0
    if-eqz v0, +024h
    invoke-virtual v6, Lcom/flurry/android/o;->removeAllViews()V
    invoke-static Lcom/flurry/android/o;->b()Landroid/widget/RelativeLayout$LayoutParams;
    move-result-object v1
    invoke-virtual v6, v0, v1, Lcom/flurry/android/o;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v0, Lcom/flurry/android/y;->a()Lcom/flurry/android/p;
    move-result-object v0
    new-instance v1, Lcom/flurry/android/f;
    const/4 v2, 3
    iget-object v3, v6, Lcom/flurry/android/o;->a Lcom/flurry/android/u;
    invoke-virtual v3, Lcom/flurry/android/u;->k()J
    move-result-wide v3
    invoke-direct v1, v2, v3, v4, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v0, v1, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    iput-boolean v5, v6, Lcom/flurry/android/o;->e Z
    iput-boolean v5, v6, Lcom/flurry/android/o;->f Z
    return-void
    iget-boolean v0, v6, Lcom/flurry/android/o;->f Z
    if-nez v0, -005h
    new-instance v0, Landroid/widget/TextView;
    iget-object v1, v6, Lcom/flurry/android/o;->b Landroid/content/Context;
    invoke-direct v0, v1, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    sget-object v1, Lcom/flurry/android/u;->b Ljava/lang/String;
    invoke-virtual v0, v1, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    const/high16 v1, 1101004800
    invoke-virtual v0, v5, v1, Landroid/widget/TextView;->setTextSize(I F)V
    invoke-static Lcom/flurry/android/o;->b()Landroid/widget/RelativeLayout$LayoutParams;
    move-result-object v1
    invoke-virtual v6, v0, v1, Lcom/flurry/android/o;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    goto -1fh
.end method
