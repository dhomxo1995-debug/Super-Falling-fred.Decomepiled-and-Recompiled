package com.flurry.android;
final class ak implements java.lang.Runnable {
    final synthetic String a;
    final synthetic android.content.Context b;
    final synthetic com.flurry.android.p c;
    final synthetic com.flurry.android.u d;

    ak(com.flurry.android.u p1, String p2, android.content.Context p3, com.flurry.android.p p4)
    {
        this.d = p1;
        this.a = p2;
        this.b = p3;
        this.c = p4;
        return;
    }

    public final void run()
    {
        new android.os.Handler().post(new com.flurry.android.m(this, com.flurry.android.u.a(this.d, this.a)));
        return;
    }
}
