.class final Lcom/flurry/android/v;
.super Lcom/flurry/android/aj;

.field  a:J
.field  b:J
.field  c:Ljava/lang/String;
.field  d:Ljava/lang/String;
.field  e:J
.field  f:Ljava/lang/Long;
.field  g:[B
.field  h:Lcom/flurry/android/AdImage;

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/aj;-><init>()V
    return-void
.end method

.method constructor <init>(Ljava/io/DataInput;)V
    .registers 2
    invoke-direct v0, Lcom/flurry/android/aj;-><init>()V
    invoke-direct v0, v1, Lcom/flurry/android/v;->b(Ljava/io/DataInput;)V
    return-void
.end method

.method private static a([B)Ljava/lang/String;
    .registers 5
    const/16 v3, 10
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const/4 v0, 0
    array-length v2, v4
    if-ge v0, v2, +031h
    aget-byte v2, v4, v0
    shr-int/lit8 v2, v2, 4
    and-int/lit8 v2, v2, 15
    if-ge v2, v3, +017h
    add-int/lit8 v2, v2, 48
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    aget-byte v2, v4, v0
    and-int/lit8 v2, v2, 15
    if-ge v2, v3, +014h
    add-int/lit8 v2, v2, 48
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    add-int/lit8 v0, v0, 1
    goto -1fh
    add-int/lit8 v2, v2, 65
    add-int/lit8 v2, v2, -10
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    goto -17h
    add-int/lit8 v2, v2, 65
    add-int/lit8 v2, v2, -10
    int-to-char v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    goto -14h
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method private b(Ljava/io/DataInput;)V
    .registers 4
    invoke-interface v3, Ljava/io/DataInput;->readLong()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/flurry/android/v;->a J
    invoke-interface v3, Ljava/io/DataInput;->readLong()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/flurry/android/v;->b J
    invoke-interface v3, Ljava/io/DataInput;->readUTF()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-interface v3, Ljava/io/DataInput;->readUTF()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/flurry/android/v;->c Ljava/lang/String;
    invoke-interface v3, Ljava/io/DataInput;->readLong()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/flurry/android/v;->e J
    invoke-interface v3, Ljava/io/DataInput;->readLong()J
    move-result-wide v0
    invoke-static v0, v1, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v0
    iput-object v0, v2, Lcom/flurry/android/v;->f Ljava/lang/Long;
    invoke-interface v3, Ljava/io/DataInput;->readUnsignedByte()I
    move-result v0
    new-array v0, v0, [B
    iput-object v0, v2, Lcom/flurry/android/v;->g [B
    iget-object v0, v2, Lcom/flurry/android/v;->g [B
    invoke-interface v3, v0, Ljava/io/DataInput;->readFully([B)V
    return-void
.end method

.method final a(Ljava/io/DataInput;)V
    .registers 2
    invoke-direct v0, v1, Lcom/flurry/android/v;->b(Ljava/io/DataInput;)V
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 4
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "ad {id="
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-wide v1, v3, Lcom/flurry/android/v;->a J
    invoke-virtual v0, v1, v2, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, ", name='"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v3, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "', cookie: '"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v3, Lcom/flurry/android/v;->g [B
    invoke-static v1, Lcom/flurry/android/v;->a([B)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "'}"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
