package com.flurry.android;
final class m implements java.lang.Runnable {
    private synthetic String a;
    private synthetic com.flurry.android.ak b;

    m(com.flurry.android.ak p1, String p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }

    public final void run()
    {
        if (this.a == null) {
            String v0_2 = new StringBuilder().append("Unable to launch in app market: ").append(this.b.a).toString();
            com.flurry.android.ah.d(com.flurry.android.u.a, v0_2);
            com.flurry.android.u.b(this.b.d, v0_2);
        } else {
            com.flurry.android.u.a(this.b.d, this.b.b, this.a);
            this.b.c.a(new com.flurry.android.f(8, this.b.d.k()));
        }
        return;
    }
}
