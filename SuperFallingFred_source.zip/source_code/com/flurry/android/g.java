package com.flurry.android;
final class g {
    int a;

    synthetic g()
    {
        this(0);
        return;
    }

    private g(byte p1)
    {
        return;
    }
}
