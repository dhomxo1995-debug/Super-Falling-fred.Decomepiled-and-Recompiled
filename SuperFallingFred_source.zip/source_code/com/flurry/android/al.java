package com.flurry.android;
final class al extends com.flurry.android.aj {
    String a;
    String b;
    int c;

    al()
    {
        return;
    }
}
