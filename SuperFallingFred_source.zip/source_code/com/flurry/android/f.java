package com.flurry.android;
final class f {
    final byte a;
    final long b;

    f(byte p1, long p2)
    {
        this.a = p1;
        this.b = p2;
        return;
    }

    public final String toString()
    {
        return new StringBuilder().append("[").append(this.b).append("] ").append(this.a).toString();
    }
}
