package com.flurry.android;
final class l implements java.lang.Runnable {
    private synthetic com.flurry.android.b a;

    l(com.flurry.android.b p1)
    {
        this.a = p1;
        return;
    }

    public final void run()
    {
        com.flurry.android.FlurryAgent.b(this.a.b, this.a.a);
        return;
    }
}
