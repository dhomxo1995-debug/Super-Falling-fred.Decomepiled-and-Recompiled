.class public Lcom/flurry/android/AppCircle;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public acceptOffer(Landroid/content/Context; J)V
    .registers 4
    invoke-static v1, v2, v3, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context; J)V
    return-void
.end method

.method public addUserCookie(Ljava/lang/String; Ljava/lang/String;)V
    .registers 3
    invoke-static v1, v2, Lcom/flurry/android/FlurryAgent;->addUserCookie(Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public clearUserCookies()V
    .registers 1
    invoke-static Lcom/flurry/android/FlurryAgent;->clearUserCookies()V
    return-void
.end method

.method public getAllOffers()Ljava/util/List;
    .registers 2
    const-string v0, ""
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->b(Ljava/lang/String;)Ljava/util/List;
    move-result-object v0
    return-object v0
.end method

.method public getAllOffers(Ljava/lang/String;)Ljava/util/List;
    .registers 3
    invoke-static v2, Lcom/flurry/android/FlurryAgent;->b(Ljava/lang/String;)Ljava/util/List;
    move-result-object v0
    return-object v0
.end method

.method public getHook(Landroid/content/Context; Ljava/lang/String; I)Landroid/view/View;
    .registers 5
    invoke-static v2, v3, v4, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context; Ljava/lang/String; I)Landroid/view/View;
    move-result-object v0
    return-object v0
.end method

.method public getOffer()Lcom/flurry/android/Offer;
    .registers 2
    const-string v0, ""
    invoke-virtual v1, v0, Lcom/flurry/android/AppCircle;->getOffer(Ljava/lang/String;)Lcom/flurry/android/Offer;
    move-result-object v0
    return-object v0
.end method

.method public getOffer(Ljava/lang/String;)Lcom/flurry/android/Offer;
    .registers 3
    invoke-static v2, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String;)Lcom/flurry/android/Offer;
    move-result-object v0
    return-object v0
.end method

.method public hasAds()Z
    .registers 2
    invoke-static Lcom/flurry/android/FlurryAgent;->d()Z
    move-result v0
    return v0
.end method

.method public isLaunchCanvasOnBannerClicked()Z
    .registers 2
    invoke-static Lcom/flurry/android/FlurryAgent;->a()Z
    move-result v0
    return v0
.end method

.method public isLaunchCatalogOnBannerClicked()Z
    .registers 2
    invoke-static Lcom/flurry/android/FlurryAgent;->a()Z
    move-result v0
    return v0
.end method

.method public launchCanvasOnBannerClicked(Z)V
    .registers 2
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->a(Z)V
    return-void
.end method

.method public launchCatalogOnBannerClicked(Z)V
    .registers 2
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->a(Z)V
    return-void
.end method

.method public openCatalog(Landroid/content/Context;)V
    .registers 3
    const-string v0, ""
    invoke-virtual v1, v2, v0, Lcom/flurry/android/AppCircle;->openCatalog(Landroid/content/Context; Ljava/lang/String;)V
    return-void
.end method

.method public openCatalog(Landroid/content/Context; Ljava/lang/String;)V
    .registers 3
    invoke-static v1, v2, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context; Ljava/lang/String;)V
    return-void
.end method

.method public removeOffers(Ljava/util/List;)V
    .registers 2
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->a(Ljava/util/List;)V
    return-void
.end method

.method public setAppCircleCallback(Lcom/flurry/android/AppCircleCallback;)V
    .registers 2
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->a(Lcom/flurry/android/AppCircleCallback;)V
    return-void
.end method

.method public setDefaultNoAdsMessage(Ljava/lang/String;)V
    .registers 2
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->setDefaultNoAdsMessage(Ljava/lang/String;)V
    return-void
.end method
