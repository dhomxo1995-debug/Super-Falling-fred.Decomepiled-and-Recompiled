package com.flurry.android;
final class s extends android.widget.LinearLayout {

    public s(com.flurry.android.CatalogActivity p7, android.content.Context p8)
    {
        super(p8);
        super.setBackgroundColor(-1);
        android.widget.LinearLayout$LayoutParams v0_6 = com.flurry.android.CatalogActivity.c(p7).m();
        if (v0_6 != null) {
            android.widget.ImageView v1_1 = new android.widget.ImageView(p8);
            v1_1.setId(10000);
            int v2_1 = v0_6.e;
            if (v2_1 != 0) {
                v1_1.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(v2_1, 0, v2_1.length));
            }
            com.flurry.android.r.a(p8, v1_1, com.flurry.android.r.a(p8, v0_6.b), com.flurry.android.r.a(p8, v0_6.c));
            android.widget.LinearLayout$LayoutParams v0_3 = new android.widget.LinearLayout$LayoutParams(-2, -2);
            v0_3.setMargins(0, 0, 0, -3);
            super.setGravity(3);
            super.addView(v1_1, v0_3);
        }
        return;
    }
}
