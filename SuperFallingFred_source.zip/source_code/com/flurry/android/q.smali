.class final Lcom/flurry/android/q;
.super Landroid/webkit/WebViewClient;

.field private synthetic a:Lcom/flurry/android/CatalogActivity;

.method constructor <init>(Lcom/flurry/android/CatalogActivity;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-direct v0, Landroid/webkit/WebViewClient;-><init>()V
    return-void
.end method

.method public final onPageFinished(Landroid/webkit/WebView; Ljava/lang/String;)V
    .registers 8
    iget-object v0, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v0
    new-instance v1, Lcom/flurry/android/f;
    const/4 v2, 5
    iget-object v3, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v3, Lcom/flurry/android/CatalogActivity;->b(Lcom/flurry/android/CatalogActivity;)J
    move-result-wide v3
    invoke-direct v1, v2, v3, v4, Lcom/flurry/android/f;-><init>(B J)V
    iget-object v2, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v2, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v2
    iget-wide v2, v2, Lcom/flurry/android/p;->c J
    iget-object v4, v0, Lcom/flurry/android/p;->d Ljava/util/List;
    invoke-interface v4, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    iput-wide v2, v0, Lcom/flurry/android/p;->c J
    return-void
    move-exception v0
    goto -2h
.end method

.method public final onReceivedError(Landroid/webkit/WebView; I Ljava/lang/String; Ljava/lang/String;)V
    .registers 8
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Failed to load url: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " with an errorCode of "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v5, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    const-string v0, "Cannot find Android Market information. <p>Please check your network"
    const-string v1, "text/html"
    const-string v2, "UTF-8"
    invoke-virtual v4, v0, v1, v2, Landroid/webkit/WebView;->loadData(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public final shouldOverrideUrlLoading(Landroid/webkit/WebView; Ljava/lang/String;)Z
    .registers 8
    if-nez v7, +004h
    const/4 v0, 0
    return v0
    iget-object v0, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v0
    if-eqz v0, +017h
    iget-object v0, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v0
    new-instance v1, Lcom/flurry/android/f;
    const/4 v2, 6
    iget-object v3, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v3, Lcom/flurry/android/CatalogActivity;->b(Lcom/flurry/android/CatalogActivity;)J
    move-result-wide v3
    invoke-direct v1, v2, v3, v4, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v0, v1, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    iget-object v0, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->c(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/u;
    move-result-object v0
    invoke-virtual v6, Landroid/webkit/WebView;->getContext()Landroid/content/Context;
    move-result-object v1
    iget-object v2, v5, Lcom/flurry/android/q;->a Lcom/flurry/android/CatalogActivity;
    invoke-static v2, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v2
    invoke-virtual v0, v1, v2, v7, Lcom/flurry/android/u;->a(Landroid/content/Context; Lcom/flurry/android/p; Ljava/lang/String;)V
    const/4 v0, 1
    goto -32h
.end method
