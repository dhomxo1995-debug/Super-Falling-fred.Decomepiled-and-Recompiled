package com.flurry.android;
public final class AdImage extends com.flurry.android.aj {
    long a;
    int b;
    int c;
    String d;
    byte[] e;

    AdImage()
    {
        return;
    }

    AdImage(java.io.DataInput p1)
    {
        this.a(p1);
        return;
    }

    final void a(java.io.DataInput p3)
    {
        this.a = p3.readLong();
        this.b = p3.readInt();
        this.c = p3.readInt();
        this.d = p3.readUTF();
        byte[] v0_3 = new byte[p3.readInt()];
        this.e = v0_3;
        p3.readFully(this.e);
        return;
    }

    public final int getHeight()
    {
        return this.c;
    }

    public final long getId()
    {
        return this.a;
    }

    public final byte[] getImageData()
    {
        return this.e;
    }

    public final String getMimeType()
    {
        return this.d;
    }

    public final int getWidth()
    {
        return this.b;
    }
}
