package com.flurry.android;
final class j implements java.lang.Runnable {
    private synthetic java.util.List a;

    j(java.util.List p1)
    {
        this.a = p1;
        return;
    }

    public final void run()
    {
        java.util.Iterator v1 = this.a.iterator();
        while (v1.hasNext()) {
            ((com.flurry.android.o) v1.next()).a();
        }
        return;
    }
}
