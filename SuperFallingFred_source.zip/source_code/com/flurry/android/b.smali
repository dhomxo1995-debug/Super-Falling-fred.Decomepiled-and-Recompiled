.class final Lcom/flurry/android/b;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field final synthetic a:Landroid/content/Context;
.field final synthetic b:Lcom/flurry/android/FlurryAgent;
.field private synthetic c:Z

.method constructor <init>(Lcom/flurry/android/FlurryAgent; Z Landroid/content/Context;)V
    .registers 4
    iput-object v1, v0, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    iput-boolean v2, v0, Lcom/flurry/android/b;->c Z
    iput-object v3, v0, Lcom/flurry/android/b;->a Landroid/content/Context;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 5
    iget-object v0, v4, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->b(Lcom/flurry/android/FlurryAgent;)V
    iget-object v0, v4, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->c(Lcom/flurry/android/FlurryAgent;)V
    iget-boolean v0, v4, Lcom/flurry/android/b;->c Z
    if-nez v0, +014h
    iget-object v0, v4, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->d(Lcom/flurry/android/FlurryAgent;)Landroid/os/Handler;
    move-result-object v0
    new-instance v1, Lcom/flurry/android/l;
    invoke-direct v1, v4, Lcom/flurry/android/l;-><init>(Lcom/flurry/android/b;)V
    invoke-static Lcom/flurry/android/FlurryAgent;->g()J
    move-result-wide v2
    invoke-virtual v0, v1, v2, v3, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable; J)Z
    invoke-static Lcom/flurry/android/FlurryAgent;->h()Z
    move-result v0
    if-eqz v0, +00bh
    iget-object v0, v4, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->e(Lcom/flurry/android/FlurryAgent;)Lcom/flurry/android/u;
    move-result-object v0
    invoke-virtual v0, Lcom/flurry/android/u;->d()V
    return-void
.end method
