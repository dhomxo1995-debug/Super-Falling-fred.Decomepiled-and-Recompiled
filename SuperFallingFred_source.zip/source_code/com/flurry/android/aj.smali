.class abstract Lcom/flurry/android/aj;
.super Ljava/lang/Object;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
