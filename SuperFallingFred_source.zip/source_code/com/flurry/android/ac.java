package com.flurry.android;
final class ac implements android.view.View$OnFocusChangeListener {
    private synthetic android.widget.TextView a;
    private synthetic com.flurry.android.ab b;

    ac(com.flurry.android.ab p1, android.widget.TextView p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }

    public final void onFocusChange(android.view.View p3, boolean p4)
    {
        android.text.SpannedString v0_1;
        if (!p4) {
            v0_1 = com.flurry.android.ab.b(this.b);
        } else {
            v0_1 = com.flurry.android.ab.a(this.b);
        }
        this.a.setText(v0_1);
        return;
    }
}
