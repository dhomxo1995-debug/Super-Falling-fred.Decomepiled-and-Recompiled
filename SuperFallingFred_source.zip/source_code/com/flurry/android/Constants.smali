.class public interface abstract Lcom/flurry/android/Constants;
.super Ljava/lang/Object;

.field public static final FEMALE:B
.field public static final MALE:B
.field public static final MODE_LANDSCAPE:I
.field public static final MODE_PORTRAIT:I
.field public static final UNKNOWN:B
