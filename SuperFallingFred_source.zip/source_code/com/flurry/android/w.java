package com.flurry.android;
final class w extends android.widget.LinearLayout {
    private android.view.View a;
    private java.util.List b;
    private boolean c;
    private synthetic com.flurry.android.CatalogActivity d;

    public w(com.flurry.android.CatalogActivity p3, android.content.Context p4)
    {
        this.d = p3;
        super(p4);
        super.b = new java.util.ArrayList();
        super.c = 1;
        super.setOrientation(1);
        super.setGravity(48);
        super.a = new com.flurry.android.s(p3, p4);
        super.a.setId(10002);
        super.a.setOnClickListener(p3);
        super.a(super.a(p4), super.c);
        return;
    }

    private void a(java.util.List p8, boolean p9)
    {
        this.removeAllViews();
        android.widget.LinearLayout$LayoutParams v1_1 = new android.widget.LinearLayout$LayoutParams(-1, -2);
        v1_1.setMargins(0, 0, 0, 0);
        this.addView(this.a, v1_1);
        if (p8 != null) {
            this.b.clear();
            this.b.addAll(p8);
        }
        if (p9) {
            java.util.Iterator v2_0 = this.b.iterator();
            while (v2_0.hasNext()) {
                com.flurry.android.p v0_5 = ((com.flurry.android.y) v2_0.next());
                this.addView(v0_5, v1_1);
                v0_5.a().a(new com.flurry.android.f(3, com.flurry.android.CatalogActivity.b(this.d)));
            }
        }
        this.refreshDrawableState();
        return;
    }

    final java.util.List a(android.content.Context p7)
    {
        com.flurry.android.CatalogActivity v3_0 = 0;
        java.util.Iterator v2_2 = new java.util.ArrayList();
        com.flurry.android.y v0_9 = 1;
        while (v0_9 <= 3) {
            v2_2.add(new StringBuilder().append("Flurry_Canvas_Hook_").append(v0_9).toString());
            v0_9++;
        }
        com.flurry.android.y v0_2;
        if (com.flurry.android.CatalogActivity.a(this.d) != null) {
            v0_2 = com.flurry.android.CatalogActivity.a(this.d).b;
        } else {
            v0_2 = 0;
        }
        if (v0_2 != null) {
            v3_0 = Long.valueOf(v0_2.a);
        }
        java.util.List v1_1 = com.flurry.android.CatalogActivity.c(this.d).a(p7, v2_2, v3_0, 1, 1);
        java.util.Iterator v2_1 = v1_1.iterator();
        while (v2_1.hasNext()) {
            ((com.flurry.android.y) v2_1.next()).setOnClickListener(this.d);
        }
        return v1_1;
    }

    final void a()
    {
        int v0_1;
        if (this.c) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        this.c = v0_1;
        this.a(0, this.c);
        return;
    }

    final void a(java.util.List p2)
    {
        this.a(p2, this.c);
        return;
    }

    final java.util.List b()
    {
        return this.b;
    }
}
