package com.flurry.android;
final class c extends com.flurry.android.aj {
    private int A;
    private int B;
    private int C;
    private int D;
    private int E;
    private int F;
    private int G;
    private int H;
    private int I;
    private int J;
    private int K;
    private int L;
    private int M;
    private int N;
    private int O;
    private int P;
    private int Q;
    private int R;
    private int S;
    private int T;
    private int U;
    private int V;
    private int W;
    private int X;
    private int Y;
    private int Z;
    byte a;
    private int aa;
    private int ab;
    private int ac;
    private int ad;
    private int ae;
    private int af;
    private boolean ag;
    String b;
    long c;
    String d;
    int e;
    int f;
    String g;
    int h;
    int i;
    String j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    private long r;
    private String s;
    private int t;
    private int u;
    private String v;
    private int w;
    private int x;
    private String y;
    private int z;

    c()
    {
        return;
    }

    c(java.io.DataInput p1)
    {
        this.c(p1);
        return;
    }

    private void c(java.io.DataInput p3)
    {
        this.a = p3.readByte();
        this.b = p3.readUTF();
        this.c = p3.readLong();
        this.r = p3.readLong();
        this.d = p3.readUTF();
        this.e = p3.readUnsignedShort();
        this.f = p3.readInt();
        this.g = p3.readUTF();
        this.h = p3.readUnsignedShort();
        this.i = p3.readInt();
        this.j = p3.readUTF();
        this.k = p3.readUnsignedShort();
        this.l = p3.readInt();
        return;
    }

    final void a(java.io.DataInput p2)
    {
        this.s = p2.readUTF();
        this.t = p2.readUnsignedShort();
        this.u = p2.readInt();
        this.v = p2.readUTF();
        this.w = p2.readUnsignedShort();
        this.x = p2.readInt();
        this.y = p2.readUTF();
        this.z = p2.readUnsignedShort();
        this.A = p2.readInt();
        this.B = p2.readInt();
        this.C = p2.readInt();
        this.m = p2.readInt();
        this.n = p2.readInt();
        this.o = p2.readInt();
        this.p = p2.readInt();
        this.D = p2.readInt();
        this.E = p2.readInt();
        this.F = p2.readInt();
        this.G = p2.readInt();
        this.H = p2.readInt();
        this.I = p2.readInt();
        this.J = p2.readInt();
        this.K = p2.readInt();
        this.q = p2.readInt();
        this.L = p2.readInt();
        this.M = p2.readInt();
        this.N = p2.readInt();
        this.O = p2.readInt();
        this.P = p2.readInt();
        this.Q = p2.readInt();
        this.R = p2.readInt();
        this.S = p2.readInt();
        this.T = p2.readInt();
        this.U = p2.readInt();
        this.V = p2.readInt();
        this.W = p2.readInt();
        this.X = p2.readInt();
        this.Y = p2.readInt();
        this.Z = p2.readInt();
        this.aa = p2.readInt();
        this.ab = p2.readInt();
        this.ac = p2.readInt();
        this.ad = p2.readInt();
        this.ae = p2.readInt();
        this.af = p2.readInt();
        this.ag = 1;
        return;
    }

    final void a(java.io.DataOutput p3)
    {
        p3.writeByte(this.a);
        p3.writeUTF(this.b);
        p3.writeLong(this.c);
        p3.writeLong(this.r);
        p3.writeUTF(this.d);
        p3.writeShort(this.e);
        p3.writeInt(this.f);
        p3.writeUTF(this.g);
        p3.writeShort(this.h);
        p3.writeInt(this.i);
        p3.writeUTF(this.j);
        p3.writeShort(this.k);
        p3.writeInt(this.l);
        p3.writeBoolean(this.ag);
        if (this.ag) {
            p3.writeUTF(this.s);
            p3.writeShort(this.t);
            p3.writeInt(this.u);
            p3.writeUTF(this.v);
            p3.writeShort(this.w);
            p3.writeInt(this.x);
            p3.writeUTF(this.y);
            p3.writeShort(this.z);
            p3.writeInt(this.A);
            p3.writeInt(this.B);
            p3.writeInt(this.C);
            p3.writeInt(this.m);
            p3.writeInt(this.n);
            p3.writeInt(this.o);
            p3.writeInt(this.p);
            p3.writeInt(this.D);
            p3.writeInt(this.E);
            p3.writeInt(this.F);
            p3.writeInt(this.G);
            p3.writeInt(this.H);
            p3.writeInt(this.I);
            p3.writeInt(this.J);
            p3.writeInt(this.K);
            p3.writeInt(this.q);
            p3.writeInt(this.L);
            p3.writeInt(this.M);
            p3.writeInt(this.N);
            p3.writeInt(this.O);
            p3.writeInt(this.P);
            p3.writeInt(this.Q);
            p3.writeInt(this.R);
            p3.writeInt(this.S);
            p3.writeInt(this.T);
            p3.writeInt(this.U);
            p3.writeInt(this.V);
            p3.writeInt(this.W);
            p3.writeInt(this.X);
            p3.writeInt(this.Y);
            p3.writeInt(this.Z);
            p3.writeInt(this.aa);
            p3.writeInt(this.ab);
            p3.writeInt(this.ac);
            p3.writeInt(this.ad);
            p3.writeInt(this.ae);
            p3.writeInt(this.af);
        }
        return;
    }

    final void b(java.io.DataInput p2)
    {
        this.c(p2);
        this.ag = p2.readBoolean();
        if (this.ag) {
            this.a(p2);
        }
        return;
    }
}
