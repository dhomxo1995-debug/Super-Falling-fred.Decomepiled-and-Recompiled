.class final Lcom/flurry/android/t;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/util/Map;
.field private synthetic b:Lcom/flurry/android/InstallReceiver;

.method constructor <init>(Lcom/flurry/android/InstallReceiver; Ljava/util/Map;)V
    .registers 3
    iput-object v1, v0, Lcom/flurry/android/t;->b Lcom/flurry/android/InstallReceiver;
    iput-object v2, v0, Lcom/flurry/android/t;->a Ljava/util/Map;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 9
    const/4 v2, 0
    const/4 v5, 1
    const/4 v6, 0
    iget-object v1, v8, Lcom/flurry/android/t;->b Lcom/flurry/android/InstallReceiver;
    invoke-static v1, Lcom/flurry/android/InstallReceiver;->a(Lcom/flurry/android/InstallReceiver;)Ljava/io/File;
    move-result-object v1
    invoke-virtual v1, Ljava/io/File;->getParentFile()Ljava/io/File;
    move-result-object v1
    invoke-virtual v1, Ljava/io/File;->mkdirs()Z
    move-result v3
    if-nez v3, +024h
    invoke-virtual v1, Ljava/io/File;->exists()Z
    move-result v3
    if-nez v3, +01eh
    const-string v3, "InstallReceiver"
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Unable to create persistent dir: "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v3, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    return-void
    new-instance v1, Ljava/io/FileOutputStream;
    iget-object v3, v8, Lcom/flurry/android/t;->b Lcom/flurry/android/InstallReceiver;
    invoke-static v3, Lcom/flurry/android/InstallReceiver;->a(Lcom/flurry/android/InstallReceiver;)Ljava/io/File;
    move-result-object v3
    invoke-direct v1, v3, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    new-instance v3, Ljava/io/DataOutputStream;
    invoke-direct v3, v1, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    iget-object v1, v8, Lcom/flurry/android/t;->a Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v1
    invoke-interface v1, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v7
    move v4, v5
    invoke-interface v7, Ljava/util/Iterator;->hasNext()Z
    move-result v1
    if-eqz v1, +03eh
    invoke-interface v7, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    move-object v0, v1
    check-cast v0, Ljava/util/Map$Entry;
    move-object v2, v0
    if-ne v4, v5, +028h
    move v4, v6
    invoke-interface v2, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v3, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v1, "="
    invoke-virtual v3, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-interface v2, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v3, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    goto -28h
    move-exception v1
    move-object v2, v3
    const-string v3, "InstallReceiver"
    const-string v4, ""
    invoke-static v3, v4, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -51h
    const-string v1, "&"
    invoke-virtual v3, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    goto -2ah
    move-exception v1
    move-object v2, v3
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v1
    const/4 v1, 0
    invoke-virtual v3, v1, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-static v3, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -65h
    move-exception v1
    goto -dh
    move-exception v1
    goto -22h
.end method
