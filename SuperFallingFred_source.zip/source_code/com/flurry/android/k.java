package com.flurry.android;
final class k implements java.lang.Runnable {
    private synthetic com.flurry.android.ag a;

    k(com.flurry.android.ag p1)
    {
        this.a = p1;
        return;
    }

    public final void run()
    {
        com.flurry.android.ag.a(this.a);
        return;
    }
}
