.class public final Lcom/flurry/android/AdImage;
.super Lcom/flurry/android/aj;

.field  a:J
.field  b:I
.field  c:I
.field  d:Ljava/lang/String;
.field  e:[B

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/aj;-><init>()V
    return-void
.end method

.method constructor <init>(Ljava/io/DataInput;)V
    .registers 2
    invoke-direct v0, Lcom/flurry/android/aj;-><init>()V
    invoke-virtual v0, v1, Lcom/flurry/android/AdImage;->a(Ljava/io/DataInput;)V
    return-void
.end method

.method final a(Ljava/io/DataInput;)V
    .registers 4
    invoke-interface v3, Ljava/io/DataInput;->readLong()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/flurry/android/AdImage;->a J
    invoke-interface v3, Ljava/io/DataInput;->readInt()I
    move-result v0
    iput v0, v2, Lcom/flurry/android/AdImage;->b I
    invoke-interface v3, Ljava/io/DataInput;->readInt()I
    move-result v0
    iput v0, v2, Lcom/flurry/android/AdImage;->c I
    invoke-interface v3, Ljava/io/DataInput;->readUTF()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/flurry/android/AdImage;->d Ljava/lang/String;
    invoke-interface v3, Ljava/io/DataInput;->readInt()I
    move-result v0
    new-array v0, v0, [B
    iput-object v0, v2, Lcom/flurry/android/AdImage;->e [B
    iget-object v0, v2, Lcom/flurry/android/AdImage;->e [B
    invoke-interface v3, v0, Ljava/io/DataInput;->readFully([B)V
    return-void
.end method

.method public final getHeight()I
    .registers 2
    iget v0, v1, Lcom/flurry/android/AdImage;->c I
    return v0
.end method

.method public final getId()J
    .registers 3
    iget-wide v0, v2, Lcom/flurry/android/AdImage;->a J
    return-wide v0
.end method

.method public final getImageData()[B
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/AdImage;->e [B
    return-object v0
.end method

.method public final getMimeType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/AdImage;->d Ljava/lang/String;
    return-object v0
.end method

.method public final getWidth()I
    .registers 2
    iget v0, v1, Lcom/flurry/android/AdImage;->b I
    return v0
.end method
