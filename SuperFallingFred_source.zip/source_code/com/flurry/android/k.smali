.class final Lcom/flurry/android/k;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/flurry/android/ag;

.method constructor <init>(Lcom/flurry/android/ag;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/k;->a Lcom/flurry/android/ag;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/k;->a Lcom/flurry/android/ag;
    invoke-static v0, Lcom/flurry/android/ag;->a(Lcom/flurry/android/ag;)V
    return-void
.end method
