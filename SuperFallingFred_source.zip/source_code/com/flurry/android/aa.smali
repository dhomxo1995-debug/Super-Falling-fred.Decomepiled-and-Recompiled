.class final Lcom/flurry/android/aa;
.super Ljava/lang/Object;

.field  a:J
.field  b:Ljava/lang/String;
.field  c:Ljava/lang/String;
.field  d:Ljava/lang/String;

.method synthetic constructor <init>()V
    .registers 2
    const/4 v0, 0
    invoke-direct v1, v0, Lcom/flurry/android/aa;-><init>(B)V
    return-void
.end method

.method private constructor <init>(B)V
    .registers 2
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
