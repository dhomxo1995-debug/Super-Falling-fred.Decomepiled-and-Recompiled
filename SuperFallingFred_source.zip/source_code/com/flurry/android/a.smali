.class final Lcom/flurry/android/a;
.super Ljava/lang/Object;

.field  a:Ljava/lang/String;
.field  b:J
.field  c:J
.field  d:J
.field  e:Ljava/lang/String;
.field  f:Ljava/lang/String;
.field  g:Landroid/os/Handler;

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
