.class final Lcom/flurry/android/l;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/flurry/android/b;

.method constructor <init>(Lcom/flurry/android/b;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/l;->a Lcom/flurry/android/b;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/flurry/android/l;->a Lcom/flurry/android/b;
    iget-object v0, v0, Lcom/flurry/android/b;->b Lcom/flurry/android/FlurryAgent;
    iget-object v1, v2, Lcom/flurry/android/l;->a Lcom/flurry/android/b;
    iget-object v1, v1, Lcom/flurry/android/b;->a Landroid/content/Context;
    invoke-static v0, v1, Lcom/flurry/android/FlurryAgent;->b(Lcom/flurry/android/FlurryAgent; Landroid/content/Context;)V
    return-void
.end method
