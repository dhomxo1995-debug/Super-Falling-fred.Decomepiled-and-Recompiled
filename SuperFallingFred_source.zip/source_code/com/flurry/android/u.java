package com.flurry.android;
final class u implements android.view.View$OnClickListener {
    static String a;
    static String b;
    private static volatile String c;
    private static volatile String d;
    private static volatile String e;
    private static String f;
    private static int g;
    private static volatile long z;
    private String h;
    private String i;
    private String j;
    private long k;
    private long l;
    private long m;
    private com.flurry.android.z n;
    private boolean o;
    private volatile boolean p;
    private String q;
    private java.util.Map r;
    private android.os.Handler s;
    private boolean t;
    private transient java.util.Map u;
    private com.flurry.android.ag v;
    private java.util.List w;
    private java.util.Map x;
    private com.flurry.android.AppCircleCallback y;

    static u()
    {
        com.flurry.android.u.c = "market://";
        com.flurry.android.u.d = "market://details?id=";
        com.flurry.android.u.e = "https://market.android.com/details?id=";
        com.flurry.android.u.f = "com.flurry.android.ACTION_CATALOG";
        com.flurry.android.u.a = "FlurryAgent";
        new java.util.Random(System.currentTimeMillis());
        com.flurry.android.u.g = 5000;
        com.flurry.android.u.b = "";
        com.flurry.android.u.z = 0;
        return;
    }

    public u()
    {
        this.o = 1;
        this.r = new java.util.HashMap();
        this.u = new java.util.HashMap();
        this.w = new java.util.ArrayList();
        this.x = new java.util.HashMap();
        this.n = new com.flurry.android.z();
        return;
    }

    static synthetic com.flurry.android.AppCircleCallback a(com.flurry.android.u p1)
    {
        return p1.y;
    }

    private com.flurry.android.Offer a(String p9, com.flurry.android.v p10)
    {
        int v6_0;
        com.flurry.android.AdImage v3_2 = new com.flurry.android.p(p9, 3, this.k());
        this.a(v3_2);
        v3_2.a(new com.flurry.android.f(2, this.k()));
        v3_2.b = p10;
        com.flurry.android.Offer v0_3 = this.n.a(p10.a);
        if (v0_3 != null) {
            v6_0 = v0_3.a;
        } else {
            v6_0 = "";
        }
        com.flurry.android.Offer v7_0;
        if (v0_3 != null) {
            v7_0 = v0_3.c;
        } else {
            v7_0 = 0;
        }
        long v1_2 = (com.flurry.android.u.z + 1);
        com.flurry.android.u.z = v1_2;
        com.flurry.android.Offer v0_5 = new com.flurry.android.OfferInSdk(v1_2, v3_2, p10.h, p10.d, v6_0, v7_0);
        this.x.put(Long.valueOf(v0_5.a), v0_5);
        com.flurry.android.Offer v7_1 = new com.flurry.android.Offer;
        v7_1(v0_5.a, v0_5.f, v0_5.c, v0_5.d, v0_5.e);
        return v7_1;
    }

    private String a(com.flurry.android.p p7, Long p8)
    {
        String v0_0 = p7.b;
        StringBuilder v2_4 = new StringBuilder().append("?apik=").append(this.j).append("&cid=").append(v0_0.e).append("&adid=").append(v0_0.a).append("&pid=").append(this.q).append("&iid=").append(this.k).append("&sid=").append(this.l).append("&its=").append(p7.a()).append("&hid=").append(com.flurry.android.r.a(p7.a)).append("&ac=").append(com.flurry.android.u.a(v0_0.g));
        if ((this.r != null) && (!this.r.isEmpty())) {
            java.util.Iterator v3_15 = this.r.entrySet().iterator();
            while (v3_15.hasNext()) {
                String v0_15 = ((java.util.Map$Entry) v3_15.next());
                v2_4.append("&").append(new StringBuilder().append("c_").append(com.flurry.android.r.a(((String) v0_15.getKey()))).toString()).append("=").append(com.flurry.android.r.a(((String) v0_15.getValue())));
            }
        }
        v2_4.append("&ats=");
        if (p8 != null) {
            v2_4.append(p8);
        }
        return v2_4.toString();
    }

    static synthetic String a(com.flurry.android.u p1, String p2)
    {
        return p1.d(p2);
    }

    private static String a(byte[] p4)
    {
        StringBuilder v1_1 = new StringBuilder();
        int v0_0 = 0;
        while (v0_0 < p4.length) {
            char v2_1 = ((p4[v0_0] >> 4) & 15);
            if (v2_1 >= 10) {
                v1_1.append(((char) ((v2_1 + 65) - 10)));
            } else {
                v1_1.append(((char) (v2_1 + 48)));
            }
            char v2_8 = (p4[v0_0] & 15);
            if (v2_8 >= 10) {
                v1_1.append(((char) ((v2_8 + 65) - 10)));
            } else {
                v1_1.append(((char) (v2_8 + 48)));
            }
            v0_0++;
        }
        return v1_1.toString();
    }

    private java.util.List a(java.util.List p9, Long p10)
    {
        if ((p9 != null) && ((!p9.isEmpty()) && (this.n.b()))) {
            long v0_2 = this.n.a(((String) p9.get(0)));
            if ((v0_2 == 0) || (v0_2.length <= 0)) {
                long v0_3 = java.util.Collections.emptyList();
            } else {
                java.util.ArrayList v1_2 = new java.util.ArrayList(java.util.Arrays.asList(v0_2));
                java.util.Collections.shuffle(v1_2);
                if (p10 != null) {
                    int v2_0 = v1_2.iterator();
                    while (v2_0.hasNext()) {
                        if (((com.flurry.android.v) v2_0.next()).a == p10.longValue()) {
                            v2_0.remove();
                            break;
                        }
                    }
                }
                v0_3 = v1_2.subList(0, Math.min(v1_2.size(), p9.size()));
            }
        } else {
            v0_3 = java.util.Collections.emptyList();
        }
        return v0_3;
    }

    private void a(com.flurry.android.p p4)
    {
        if (this.w.size() < 32767) {
            this.w.add(p4);
            this.u.put(Long.valueOf(p4.a()), p4);
        }
        return;
    }

    static synthetic void a(com.flurry.android.u p4, android.content.Context p5, String p6)
    {
        if (!p6.startsWith(com.flurry.android.u.d)) {
            com.flurry.android.ah.d(com.flurry.android.u.a, new StringBuilder().append("Unexpected android market url scheme: ").append(p6).toString());
        } else {
            Exception v0_3 = p6.substring(com.flurry.android.u.d.length());
            if (!p4.o) {
                com.flurry.android.ah.a(com.flurry.android.u.a, new StringBuilder().append("Launching Android Market website for app ").append(v0_3).toString());
                p5.startActivity(new android.content.Intent("android.intent.action.VIEW").setData(android.net.Uri.parse(new StringBuilder().append(com.flurry.android.u.e).append(v0_3).toString())));
            } else {
                try {
                    com.flurry.android.ah.a(com.flurry.android.u.a, new StringBuilder().append("Launching Android Market for app ").append(v0_3).toString());
                    p5.startActivity(new android.content.Intent("android.intent.action.VIEW").setData(android.net.Uri.parse(p6)));
                } catch (Exception v0_15) {
                    com.flurry.android.ah.c(com.flurry.android.u.a, new StringBuilder().append("Cannot launch Marketplace url ").append(p6).toString(), v0_15);
                }
            }
        }
        return;
    }

    private static void a(Runnable p1)
    {
        new android.os.Handler().post(p1);
        return;
    }

    private void b(android.content.Context p5, com.flurry.android.p p6, String p7)
    {
        android.content.Intent v0_1 = new android.content.Intent(com.flurry.android.u.p());
        v0_1.addCategory("android.intent.category.DEFAULT");
        v0_1.putExtra("u", p7);
        if (p6 != null) {
            v0_1.putExtra("o", p6.a());
        }
        p5.startActivity(v0_1);
        return;
    }

    static synthetic void b(com.flurry.android.u p0, String p1)
    {
        p0.e(p1);
        return;
    }

    private String d(String p6)
    {
        try {
            if (!p6.startsWith(com.flurry.android.u.c)) {
                String v1_1 = new org.apache.http.impl.client.DefaultHttpClient().execute(new org.apache.http.client.methods.HttpGet(p6));
                StringBuilder v2_1 = v1_1.getStatusLine().getStatusCode();
                if (v2_1 != 200) {
                    com.flurry.android.ah.c(com.flurry.android.u.a, new StringBuilder().append("Cannot process with responseCode ").append(v2_1).toString());
                    this.e(new StringBuilder().append("Error when fetching application\'s android market ID, responseCode ").append(v2_1).toString());
                } else {
                    p6 = org.apache.http.util.EntityUtils.toString(v1_1.getEntity());
                    if (!p6.startsWith(com.flurry.android.u.c)) {
                        p6 = this.d(p6);
                    }
                }
            }
        } catch (String v1_12) {
            com.flurry.android.ah.c(com.flurry.android.u.a, new StringBuilder().append("Failed on url: ").append(p6).toString(), v1_12);
            p6 = 0;
        } catch (String v1_15) {
            com.flurry.android.ah.c(com.flurry.android.u.a, new StringBuilder().append("Unknown host: ").append(v1_15.getMessage()).toString());
            if (this.y != null) {
                this.e(new StringBuilder().append("Unknown host: ").append(v1_15.getMessage()).toString());
            }
            p6 = 0;
        }
        return p6;
    }

    private void e(String p2)
    {
        com.flurry.android.u.a(new com.flurry.android.ae(this, p2));
        return;
    }

    private declared_synchronized com.flurry.android.AdImage o()
    {
        try {
            com.flurry.android.AdImage v0_2;
            if (this.q()) {
                v0_2 = this.n.a(1);
            } else {
                v0_2 = 0;
            }
        } catch (com.flurry.android.AdImage v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    private static String p()
    {
        String v0_1;
        if (com.flurry.android.FlurryAgent.a == null) {
            v0_1 = com.flurry.android.u.f;
        } else {
            v0_1 = com.flurry.android.FlurryAgent.a;
        }
        return v0_1;
    }

    private boolean q()
    {
        if (!this.p) {
            com.flurry.android.ah.d(com.flurry.android.u.a, "AppCircle is not initialized");
        }
        if (this.q == null) {
            com.flurry.android.ah.d(com.flurry.android.u.a, "Cannot identify UDID.");
        }
        return this.p;
    }

    final declared_synchronized android.view.View a(android.content.Context p3, String p4, int p5)
    {
        try {
            com.flurry.android.o v0_2;
            if (this.q()) {
                v0_2 = new com.flurry.android.o(this, p3, p4, p5);
                this.v.a(v0_2);
            } else {
                v0_2 = 0;
            }
        } catch (com.flurry.android.o v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    final declared_synchronized com.flurry.android.AdImage a(long p2)
    {
        try {
            com.flurry.android.AdImage v0_2;
            if (this.q()) {
                v0_2 = this.n.b(p2);
            } else {
                v0_2 = 0;
            }
        } catch (com.flurry.android.AdImage v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    final declared_synchronized java.util.List a(android.content.Context p12, java.util.List p13, Long p14, int p15, boolean p16)
    {
        try {
            int v0_3;
            if (this.q()) {
                if ((!this.n.b()) || (p13 == null)) {
                    v0_3 = java.util.Collections.emptyList();
                } else {
                    java.util.List v9 = this.a(p13, p14);
                    int v10 = Math.min(p13.size(), v9.size());
                    java.util.ArrayList v7_1 = new java.util.ArrayList();
                    int v8 = 0;
                    while (v8 < v10) {
                        int v0_5 = ((String) p13.get(v8));
                        com.flurry.android.e v4 = this.n.b(v0_5);
                        if (v4 == null) {
                            com.flurry.android.ah.d(com.flurry.android.u.a, new StringBuilder().append("Cannot find hook: ").append(v0_5).toString());
                        } else {
                            String v3_2 = new com.flurry.android.p(((String) p13.get(v8)), 1, this.k());
                            this.a(v3_2);
                            if (v8 < v9.size()) {
                                v3_2.b = ((com.flurry.android.v) v9.get(v8));
                                v3_2.a(new com.flurry.android.f(2, this.k()));
                                int v0_18 = new com.flurry.android.y(p12, this, v3_2, v4, p15, p16);
                                v0_18.a(this.a(v3_2, 0));
                                v7_1.add(v0_18);
                            }
                        }
                        v8++;
                    }
                    v0_3 = v7_1;
                }
            } else {
                v0_3 = java.util.Collections.emptyList();
            }
        } catch (int v0_20) {
            throw v0_20;
        }
        return v0_3;
    }

    final declared_synchronized void a()
    {
        try {
            this.w.clear();
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final declared_synchronized void a(int p2)
    {
        try {
            if (this.y != null) {
                com.flurry.android.u.a(new com.flurry.android.ad(this, p2));
            }
        } catch (com.flurry.android.ad v0_3) {
            throw v0_3;
        }
        return;
    }

    final declared_synchronized void a(android.content.Context p8, long p9)
    {
        try {
            if (this.q()) {
                String v0_9 = ((com.flurry.android.OfferInSdk) this.x.get(Long.valueOf(p9)));
                if (v0_9 != null) {
                    com.flurry.android.p v1_0 = v0_9.b;
                    v1_0.a(new com.flurry.android.f(4, this.k()));
                    String v2_6 = new StringBuilder().append(com.flurry.android.FlurryAgent.c()).append(this.a(v1_0, Long.valueOf(v1_0.a()))).toString();
                    com.flurry.android.ah.a(com.flurry.android.u.a, new StringBuilder().append("Offer ").append(v0_9.a).append(" accepted. Sent with cookies: ").append(this.r).toString());
                    this.a(p8, v1_0, v2_6);
                } else {
                    com.flurry.android.ah.b(com.flurry.android.u.a, new StringBuilder().append("Cannot find offer ").append(p9).toString());
                }
            }
        } catch (String v0_6) {
            throw v0_6;
        }
        return;
    }

    final declared_synchronized void a(android.content.Context p6, com.flurry.android.a p7)
    {
        int v0_0 = 1;
        try {
            if (!this.p) {
                this.h = p7.e;
                this.i = p7.f;
                this.j = p7.a;
                this.k = p7.b;
                this.l = p7.c;
                this.m = p7.d;
                this.s = p7.g;
                this.v = new com.flurry.android.ag(this.s, com.flurry.android.u.g);
                p6.getResources().getDisplayMetrics();
                this.x.clear();
                this.u.clear();
                this.n.a(p6, this, p7);
                this.r.clear();
                int v1_12 = p6.getPackageManager();
                int v2_3 = new StringBuilder().append(com.flurry.android.u.d).append(p6.getPackageName()).toString();
                android.content.Intent v3_5 = new android.content.Intent("android.intent.action.VIEW");
                v3_5.setData(android.net.Uri.parse(v2_3));
                if (v1_12.queryIntentActivities(v3_5, 65536).size() <= 0) {
                    v0_0 = 0;
                }
                this.o = v0_0;
                this.a();
                this.p = 1;
            }
        } catch (int v0_2) {
            throw v0_2;
        }
        return;
    }

    final declared_synchronized void a(android.content.Context p3, com.flurry.android.p p4, String p5)
    {
        try {
            if (this.q()) {
                this.s.post(new com.flurry.android.ak(this, p5, p3, p4));
            }
        } catch (android.os.Handler v0_2) {
            throw v0_2;
        }
        return;
    }

    final declared_synchronized void a(android.content.Context p6, String p7)
    {
        try {
            if (this.q()) {
                try {
                    String v0_7 = new String[1];
                    v0_7[0] = p7;
                    String v0_1 = this.a(java.util.Arrays.asList(v0_7), 0);
                } catch (String v0_4) {
                    com.flurry.android.ah.d(com.flurry.android.u.a, new StringBuilder().append("Failed to launch promotional canvas for hook: ").append(p7).toString(), v0_4);
                }
                if ((v0_1 == null) || (v0_1.isEmpty())) {
                    String v0_3 = new android.content.Intent(com.flurry.android.u.p());
                    v0_3.addCategory("android.intent.category.DEFAULT");
                    p6.startActivity(v0_3);
                } else {
                    com.flurry.android.p v3_3 = new com.flurry.android.p(p7, 2, (android.os.SystemClock.elapsedRealtime() - this.m));
                    v3_3.b = ((com.flurry.android.v) v0_1.get(0));
                    this.a(v3_3);
                    this.b(p6, v3_3, new StringBuilder().append(this.h).append(this.a(v3_3, Long.valueOf(System.currentTimeMillis()))).toString());
                }
            }
        } catch (String v0_6) {
            throw v0_6;
        }
        return;
    }

    final void a(com.flurry.android.AppCircleCallback p1)
    {
        this.y = p1;
        return;
    }

    final void a(String p1)
    {
        this.q = p1;
        return;
    }

    final declared_synchronized void a(String p2, String p3)
    {
        try {
            this.r.put(p2, p3);
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final declared_synchronized void a(java.util.List p4)
    {
        try {
            if (this.q()) {
                java.util.Iterator v1 = p4.iterator();
                while (v1.hasNext()) {
                    this.x.remove(((Long) v1.next()));
                }
            }
        } catch (Long v0_4) {
            throw v0_4;
        }
        return;
    }

    final declared_synchronized void a(java.util.Map p8, java.util.Map p9, java.util.Map p10, java.util.Map p11, java.util.Map p12, java.util.Map p13)
    {
        try {
            if (this.q()) {
                this.n.a(p8, p9, p10, p11, p12, p13);
                android.util.Log.i("FlurryAgent", this.n.toString());
            }
        } catch (String v0_2) {
            throw v0_2;
        }
        return;
    }

    final void a(boolean p1)
    {
        this.t = p1;
        return;
    }

    final declared_synchronized com.flurry.android.Offer b(String p6)
    {
        com.flurry.android.Offer v0_0 = 0;
        try {
            if (this.q()) {
                String v1_4 = new String[1];
                v1_4[0] = p6;
                String v1_0 = this.a(java.util.Arrays.asList(v1_4), 0);
                if ((v1_0 != null) && (!v1_0.isEmpty())) {
                    v0_0 = this.a(p6, ((com.flurry.android.v) v1_0.get(0)));
                    com.flurry.android.ah.a(com.flurry.android.u.a, new StringBuilder().append("Impression for offer with ID ").append(v0_0.getId()).toString());
                }
            }
        } catch (com.flurry.android.Offer v0_1) {
            throw v0_1;
        }
        return v0_0;
    }

    final declared_synchronized com.flurry.android.p b(long p3)
    {
        try {
            return ((com.flurry.android.p) this.u.get(Long.valueOf(p3)));
        } catch (Throwable v0_3) {
            throw v0_3;
        }
    }

    final boolean b()
    {
        return this.p;
    }

    final declared_synchronized java.util.List c(String p6)
    {
        try {
            java.util.ArrayList v0_2;
            if (this.q()) {
                if (this.n.b()) {
                    String v2_6 = this.n.a(p6);
                    v0_2 = new java.util.ArrayList();
                    if ((v2_6 != null) && (v2_6.length > 0)) {
                        int v3_0 = v2_6.length;
                        int v1_1 = 0;
                        while (v1_1 < v3_0) {
                            v0_2.add(this.a(p6, v2_6[v1_1]));
                            v1_1++;
                        }
                    }
                    com.flurry.android.ah.a(com.flurry.android.u.a, new StringBuilder().append("Impressions for ").append(v0_2.size()).append(" offers.").toString());
                } else {
                    v0_2 = java.util.Collections.emptyList();
                }
            } else {
                v0_2 = java.util.Collections.emptyList();
            }
        } catch (java.util.ArrayList v0_4) {
            throw v0_4;
        }
        return v0_2;
    }

    final declared_synchronized void c()
    {
        try {
            if (this.q()) {
                this.n.d();
            }
        } catch (com.flurry.android.z v0_2) {
            throw v0_2;
        }
        return;
    }

    final declared_synchronized void d()
    {
        try {
            if (this.q()) {
                this.n.e();
            }
        } catch (com.flurry.android.z v0_2) {
            throw v0_2;
        }
        return;
    }

    final declared_synchronized long e()
    {
        try {
            long v0_2;
            if (this.q()) {
                v0_2 = this.n.c();
            } else {
                v0_2 = 0;
            }
        } catch (long v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    final declared_synchronized java.util.Set f()
    {
        try {
            java.util.Set v0_2;
            if (this.q()) {
                v0_2 = this.n.a();
            } else {
                v0_2 = java.util.Collections.emptySet();
            }
        } catch (java.util.Set v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    final declared_synchronized java.util.List g()
    {
        try {
            return this.w;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final declared_synchronized void h()
    {
        try {
            this.u.clear();
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final boolean i()
    {
        return this.t;
    }

    final String j()
    {
        return this.h;
    }

    final long k()
    {
        return (android.os.SystemClock.elapsedRealtime() - this.m);
    }

    final declared_synchronized void l()
    {
        try {
            this.r.clear();
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final declared_synchronized com.flurry.android.AdImage m()
    {
        try {
            com.flurry.android.AdImage v0_1;
            if (this.q()) {
                v0_1 = this.o();
            } else {
                v0_1 = 0;
            }
        } catch (com.flurry.android.AdImage v0_2) {
            throw v0_2;
        }
        return v0_1;
    }

    final declared_synchronized boolean n()
    {
        try {
            boolean v0_2;
            if (this.q()) {
                v0_2 = this.n.b();
            } else {
                v0_2 = 0;
            }
        } catch (boolean v0_3) {
            throw v0_3;
        }
        return v0_2;
    }

    public final declared_synchronized void onClick(android.view.View p8)
    {
        try {
            com.flurry.android.p v2 = ((com.flurry.android.y) p8).a();
            v2.a(new com.flurry.android.f(4, this.k()));
        } catch (String v1_3) {
            throw v1_3;
        }
        if (!this.t) {
            this.a(p8.getContext(), v2, ((com.flurry.android.y) p8).b(this.i));
        } else {
            this.b(p8.getContext(), v2, ((com.flurry.android.y) p8).b(this.h));
        }
        return;
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder();
        v0_1.append("[adLogs=").append(this.w).append("]");
        return v0_1.toString();
    }
}
