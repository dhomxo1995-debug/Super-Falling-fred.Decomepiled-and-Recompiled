package com.flurry.android;
final class ab extends android.widget.RelativeLayout {
    private final android.text.SpannedString a;
    private final android.text.SpannedString b;

    public ab(com.flurry.android.CatalogActivity p8, android.content.Context p9)
    {
        super(p9);
        super.a = new android.text.SpannedString(android.text.Html.fromHtml("<html><div=\'style:font-size:7px\'>&lt; Previous</div></html>"));
        super.b = new android.text.SpannedString(android.text.Html.fromHtml("<html><div=\'style:font-size:7px;color:#ffA500\'>&lt; Previous</div></html>"));
        super.setBackgroundColor(-16777216);
        android.widget.TextView v0_5 = new android.widget.TextView(p9);
        v0_5.setTextColor(android.content.res.ColorStateList.valueOf(-1));
        v0_5.setId(10001);
        v0_5.setText(super.a);
        v0_5.setPadding(5, 2, 5, 2);
        v0_5.setFocusable(1);
        v0_5.setOnFocusChangeListener(new com.flurry.android.ac(super, v0_5));
        v0_5.setOnClickListener(p8);
        v0_5.setEnabled(1);
        android.widget.RelativeLayout$LayoutParams v1_9 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
        v1_9.setMargins(0, 0, 0, 0);
        super.setLayoutParams(v1_9);
        android.widget.RelativeLayout$LayoutParams v1_11 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
        v1_11.setMargins(2, 0, 0, 0);
        v1_11.addRule(4);
        super.addView(v0_5, v1_11);
        return;
    }

    static synthetic android.text.SpannedString a(com.flurry.android.ab p1)
    {
        return p1.b;
    }

    static synthetic android.text.SpannedString b(com.flurry.android.ab p1)
    {
        return p1.a;
    }
}
