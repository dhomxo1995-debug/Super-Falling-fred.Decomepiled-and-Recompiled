package com.flurry.android;
public final class CallbackEvent {
    public static final int ADS_LOADED_FROM_CACHE = 201;
    public static final int ADS_UPDATED = 202;
    public static final int ERROR_MARKET_LAUNCH = 101;
    private int a;
    private long b;
    private String c;

    CallbackEvent(int p3)
    {
        this.a = p3;
        this.b = System.currentTimeMillis();
        return;
    }

    public final String getMessage()
    {
        return this.c;
    }

    public final long getTimestamp()
    {
        return this.b;
    }

    public final int getType()
    {
        return this.a;
    }

    public final void setMessage(String p1)
    {
        this.c = p1;
        return;
    }

    public final void setTimestamp(long p1)
    {
        this.b = p1;
        return;
    }
}
