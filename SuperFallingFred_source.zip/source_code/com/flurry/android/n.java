package com.flurry.android;
final class n implements javax.net.ssl.X509TrustManager {

    n()
    {
        return;
    }

    public final void checkClientTrusted(java.security.cert.X509Certificate[] p1, String p2)
    {
        return;
    }

    public final void checkServerTrusted(java.security.cert.X509Certificate[] p1, String p2)
    {
        return;
    }

    public final java.security.cert.X509Certificate[] getAcceptedIssuers()
    {
        return 0;
    }
}
