.class public final Lcom/flurry/android/FlurryAgent;
.super Ljava/lang/Object;
.implements Landroid/location/LocationListener;

.field static a:Ljava/lang/String;
.field private static final b:[Ljava/lang/String;
.field private static bridge c:Ljava/lang/String;
.field private static bridge d:Ljava/lang/String;
.field private static bridge e:Ljava/lang/String;
.field private static bridge f:Ljava/lang/String;
.field private static bridge g:Ljava/lang/String;
.field private static final h:Lcom/flurry/android/FlurryAgent;
.field private static i:J
.field private static j:Z
.field private static k:Z
.field private static bridge kInsecureReportUrl:Ljava/lang/String;
.field private static bridge kSecureReportUrl:Ljava/lang/String;
.field private static l:Z
.field private static m:Z
.field private static n:Landroid/location/Criteria;
.field private static o:Z
.field private static p:Lcom/flurry/android/AppCircle;
.field private A:Z
.field private B:Ljava/util/List;
.field private C:Landroid/location/LocationManager;
.field private D:Ljava/lang/String;
.field private E:Z
.field private F:J
.field private G:Ljava/util/List;
.field private H:J
.field private I:J
.field private J:J
.field private K:Ljava/lang/String;
.field private L:Ljava/lang/String;
.field private M:B
.field private N:Ljava/lang/String;
.field private O:B
.field private P:Ljava/lang/Long;
.field private Q:I
.field private R:Landroid/location/Location;
.field private S:Ljava/util/Map;
.field private T:Ljava/util/List;
.field private U:Z
.field private V:I
.field private W:Ljava/util/List;
.field private X:I
.field private Y:Lcom/flurry/android/u;
.field private final q:Landroid/os/Handler;
.field private r:Ljava/io/File;
.field private s:Ljava/io/File;
.field private bridge t:Z
.field private bridge u:Z
.field private v:J
.field private w:Ljava/util/Map;
.field private x:Ljava/lang/String;
.field private y:Ljava/lang/String;
.field private z:Ljava/lang/String;

.method static constructor <clinit>()V
    .registers 5
    const/4 v4, 1
    const/4 v3, 0
    const/4 v2, 0
    const/4 v0, 2
    new-array v0, v0, [Ljava/lang/String;
    const-string v1, "9774d56d682e549c"
    aput-object v1, v0, v2
    const-string v1, "dead00beef"
    aput-object v1, v0, v4
    sput-object v0, Lcom/flurry/android/FlurryAgent;->b [Ljava/lang/String;
    sput-object v3, Lcom/flurry/android/FlurryAgent;->c Ljava/lang/String;
    const-string v0, "http://data.flurry.com/aap.do"
    sput-object v0, Lcom/flurry/android/FlurryAgent;->kInsecureReportUrl Ljava/lang/String;
    const-string v0, "https://data.flurry.com/aap.do"
    sput-object v0, Lcom/flurry/android/FlurryAgent;->kSecureReportUrl Ljava/lang/String;
    sput-object v3, Lcom/flurry/android/FlurryAgent;->d Ljava/lang/String;
    const-string v0, "http://ad.flurry.com/getCanvas.do"
    sput-object v0, Lcom/flurry/android/FlurryAgent;->e Ljava/lang/String;
    sput-object v3, Lcom/flurry/android/FlurryAgent;->f Ljava/lang/String;
    const-string v0, "http://ad.flurry.com/getAndroidApp.do"
    sput-object v0, Lcom/flurry/android/FlurryAgent;->g Ljava/lang/String;
    new-instance v0, Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, Lcom/flurry/android/FlurryAgent;-><init>()V
    sput-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const-wide/16 v0, 10000
    sput-wide v0, Lcom/flurry/android/FlurryAgent;->i J
    sput-boolean v4, Lcom/flurry/android/FlurryAgent;->j Z
    sput-boolean v2, Lcom/flurry/android/FlurryAgent;->k Z
    sput-boolean v2, Lcom/flurry/android/FlurryAgent;->l Z
    sput-boolean v4, Lcom/flurry/android/FlurryAgent;->m Z
    sput-object v3, Lcom/flurry/android/FlurryAgent;->n Landroid/location/Criteria;
    sput-boolean v2, Lcom/flurry/android/FlurryAgent;->o Z
    new-instance v0, Lcom/flurry/android/AppCircle;
    invoke-direct v0, Lcom/flurry/android/AppCircle;-><init>()V
    sput-object v0, Lcom/flurry/android/FlurryAgent;->p Lcom/flurry/android/AppCircle;
    return-void
.end method

.method private constructor <init>()V
    .registers 4
    const/4 v2, 0
    const/4 v1, -1
    invoke-direct v3, Ljava/lang/Object;-><init>()V
    const/4 v0, 0
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    iput-boolean v2, v3, Lcom/flurry/android/FlurryAgent;->t Z
    iput-boolean v2, v3, Lcom/flurry/android/FlurryAgent;->u Z
    new-instance v0, Ljava/util/WeakHashMap;
    invoke-direct v0, Ljava/util/WeakHashMap;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->w Ljava/util/Map;
    const/4 v0, 1
    iput-boolean v0, v3, Lcom/flurry/android/FlurryAgent;->A Z
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    const-string v0, ""
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->K Ljava/lang/String;
    const-string v0, ""
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->L Ljava/lang/String;
    iput-byte v1, v3, Lcom/flurry/android/FlurryAgent;->M B
    const-string v0, ""
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->N Ljava/lang/String;
    iput-byte v1, v3, Lcom/flurry/android/FlurryAgent;->O B
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    new-instance v0, Lcom/flurry/android/u;
    invoke-direct v0, Lcom/flurry/android/u;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    new-instance v0, Landroid/os/HandlerThread;
    const-string v1, "FlurryAgent"
    invoke-direct v0, v1, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, Landroid/os/HandlerThread;->start()V
    new-instance v1, Landroid/os/Handler;
    invoke-virtual v0, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;
    move-result-object v0
    invoke-direct v1, v0, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    iput-object v1, v3, Lcom/flurry/android/FlurryAgent;->q Landroid/os/Handler;
    return-void
.end method

.method private static a(D)D
    .registers 6
    const-wide v2, 4652007308841189376
    mul-double v0, v4, v2
    invoke-static v0, v1, Ljava/lang/Math;->round(D)J
    move-result-wide v0
    long-to-double v0, v0
    div-double/2addr v0, v2
    return-wide v0
.end method

.method static a(Landroid/content/Context; Ljava/lang/String; I)Landroid/view/View;
    .registers 7
    const/4 v0, 0
    sget-boolean v1, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v1, +003h
    return-object v0
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v1, v1, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v1, v4, v5, v6, Lcom/flurry/android/u;->a(Landroid/content/Context; Ljava/lang/String; I)Landroid/view/View;
    move-result-object v0
    goto -9h
    move-exception v1
    const-string v2, "FlurryAgent"
    const-string v3, ""
    invoke-static v2, v3, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -12h
.end method

.method static a(Ljava/lang/String;)Lcom/flurry/android/Offer;
    .registers 2
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +004h
    const/4 v0, 0
    return-object v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->b(Ljava/lang/String;)Lcom/flurry/android/Offer;
    move-result-object v0
    goto -9h
.end method

.method private a(Lorg/apache/http/params/HttpParams;)Lorg/apache/http/client/HttpClient;
    .registers 8
    invoke-static Ljava/security/KeyStore;->getDefaultType()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Ljava/security/KeyStore;->getInstance(Ljava/lang/String;)Ljava/security/KeyStore;
    move-result-object v0
    const/4 v1, 0
    const/4 v2, 0
    invoke-virtual v0, v1, v2, Ljava/security/KeyStore;->load(Ljava/io/InputStream; [C)V
    new-instance v1, Lcom/flurry/android/ai;
    invoke-direct v1, v6, v0, Lcom/flurry/android/ai;-><init>(Lcom/flurry/android/FlurryAgent; Ljava/security/KeyStore;)V
    new-instance v0, Lorg/apache/http/conn/scheme/SchemeRegistry;
    invoke-direct v0, Lorg/apache/http/conn/scheme/SchemeRegistry;-><init>()V
    new-instance v2, Lorg/apache/http/conn/scheme/Scheme;
    const-string v3, "http"
    invoke-static Lorg/apache/http/conn/scheme/PlainSocketFactory;->getSocketFactory()Lorg/apache/http/conn/scheme/PlainSocketFactory;
    move-result-object v4
    const/16 v5, 80
    invoke-direct v2, v3, v4, v5, Lorg/apache/http/conn/scheme/Scheme;-><init>(Ljava/lang/String; Lorg/apache/http/conn/scheme/SocketFactory; I)V
    invoke-virtual v0, v2, Lorg/apache/http/conn/scheme/SchemeRegistry;->register(Lorg/apache/http/conn/scheme/Scheme;)Lorg/apache/http/conn/scheme/Scheme;
    new-instance v2, Lorg/apache/http/conn/scheme/Scheme;
    const-string v3, "https"
    const/16 v4, 443
    invoke-direct v2, v3, v1, v4, Lorg/apache/http/conn/scheme/Scheme;-><init>(Ljava/lang/String; Lorg/apache/http/conn/scheme/SocketFactory; I)V
    invoke-virtual v0, v2, Lorg/apache/http/conn/scheme/SchemeRegistry;->register(Lorg/apache/http/conn/scheme/Scheme;)Lorg/apache/http/conn/scheme/Scheme;
    new-instance v1, Lorg/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager;
    invoke-direct v1, v7, v0, Lorg/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager;-><init>(Lorg/apache/http/params/HttpParams; Lorg/apache/http/conn/scheme/SchemeRegistry;)V
    new-instance v0, Lorg/apache/http/impl/client/DefaultHttpClient;
    invoke-direct v0, v1, v7, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>(Lorg/apache/http/conn/ClientConnectionManager; Lorg/apache/http/params/HttpParams;)V
    return-object v0
    move-exception v0
    new-instance v0, Lorg/apache/http/impl/client/DefaultHttpClient;
    invoke-direct v0, v7, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>(Lorg/apache/http/params/HttpParams;)V
    goto -7h
.end method

.method private synchronized a(Landroid/content/Context;)V
    .registers 10
    monitor-enter v8
    invoke-direct v8, v9, Lcom/flurry/android/FlurryAgent;->b(Landroid/content/Context;)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-virtual v0, Ljava/io/File;->exists()Z
    move-result v0
    if-eqz v0, +11ah
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "loading persistent data: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v8, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-virtual v2, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v2, 0
    new-instance v0, Ljava/io/FileInputStream;
    iget-object v1, v8, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-direct v0, v1, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    new-instance v1, Ljava/io/DataInputStream;
    invoke-direct v1, v0, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    invoke-virtual v1, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v0
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Magic: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    const v2, 46586
    if-ne v0, v2, +09ch
    invoke-direct v8, v1, Lcom/flurry/android/FlurryAgent;->b(Ljava/io/DataInputStream;)V
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    iget-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->u Z
    if-nez v0, +011h
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-virtual v0, Ljava/io/File;->delete()Z
    move-result v0
    if-eqz v0, +0a9h
    const-string v0, "FlurryAgent"
    const-string v1, "Deleted persistence file"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iget-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->u Z
    if-nez v0, +00ch
    const/4 v0, 0
    iput-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->E Z
    iget-wide v0, v8, Lcom/flurry/android/FlurryAgent;->H J
    iput-wide v0, v8, Lcom/flurry/android/FlurryAgent;->F J
    const/4 v0, 1
    iput-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->u Z
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    if-nez v0, +051h
    invoke-static Ljava/lang/Math;->random()D
    move-result-wide v0
    invoke-static v0, v1, Ljava/lang/Double;->doubleToLongBits(D)J
    move-result-wide v0
    const-wide/16 v2, 37
    invoke-static Ljava/lang/System;->nanoTime()J
    move-result-wide v4
    iget-object v6, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v6, Ljava/lang/String;->hashCode()I
    move-result v6
    mul-int/lit8 v6, v6, 37
    int-to-long v6, v6
    add-long/2addr v4, v6
    mul-long/2addr v2, v4
    add-long/2addr v0, v2
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "ID"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const/16 v3, 16
    invoke-static v0, v1, v3, Ljava/lang/Long;->toString(J I)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Generated phoneId: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    iget-object v1, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->a(Ljava/lang/String;)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    const-string v1, "AND"
    invoke-virtual v0, v1, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v0
    if-nez v0, +00fh
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->r Ljava/io/File;
    invoke-virtual v0, Ljava/io/File;->exists()Z
    move-result v0
    if-nez v0, +007h
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-direct v8, v9, v0, Lcom/flurry/android/FlurryAgent;->c(Landroid/content/Context; Ljava/lang/String;)V
    monitor-exit v8
    return-void
    const-string v0, "FlurryAgent"
    const-string v2, "Unexpected file type"
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto/16 -09eh
    move-exception v0
    const-string v2, "FlurryAgent"
    const-string v3, "Error when loading persistent file"
    invoke-static v2, v3, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto/16 -0a8h
    move-exception v0
    monitor-exit v8
    throw v0
    move-exception v0
    move-object v1, v2
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    const-string v0, "FlurryAgent"
    const-string v1, "Cannot delete persistence file"
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    goto/16 -0a7h
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto/16 -0b1h
    const-string v0, "FlurryAgent"
    const-string v1, "Agent cache file doesn't exist."
    invoke-static v0, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    goto/16 -0bah
    move-exception v0
    goto -21h
    move-exception v0
    move-object v1, v2
    goto -35h
.end method

.method static a(Landroid/content/Context; J)V
    .registers 5
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +009h
    const-string v0, "FlurryAgent"
    const-string v1, "Cannot accept Offer. AppCircle is not enabled"
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v2, v3, v4, Lcom/flurry/android/u;->a(Landroid/content/Context; J)V
    return-void
.end method

.method static a(Landroid/content/Context; Ljava/lang/String;)V
    .registers 3
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, v2, Lcom/flurry/android/u;->a(Landroid/content/Context; Ljava/lang/String;)V
    goto -8h
.end method

.method private synchronized a(Landroid/content/Context; Z)V
    .registers 8
    monitor-enter v5
    if-eqz v6, +013h
    iget-object v0, v5, Lcom/flurry/android/FlurryAgent;->w Ljava/util/Map;
    invoke-interface v0, v6, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/content/Context;
    if-nez v0, +009h
    const-string v0, "FlurryAgent"
    const-string v1, "onEndSession called without context from corresponding onStartSession"
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    iget-boolean v0, v5, Lcom/flurry/android/FlurryAgent;->t Z
    if-eqz v0, +06ah
    iget-object v0, v5, Lcom/flurry/android/FlurryAgent;->w Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-eqz v0, +062h
    const-string v0, "FlurryAgent"
    const-string v1, "Ending session"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-direct v5, Lcom/flurry/android/FlurryAgent;->m()V
    if-nez v6, +058h
    const/4 v0, 0
    if-eqz v6, +032h
    invoke-virtual v0, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v1
    iget-object v2, v5, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    invoke-virtual v2, v1, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +026h
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "onEndSession called from different application package, expected: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-object v4, v5, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, " actual: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v2, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v1
    iput-wide v1, v5, Lcom/flurry/android/FlurryAgent;->v J
    iget-wide v3, v5, Lcom/flurry/android/FlurryAgent;->I J
    sub-long/2addr v1, v3
    iput-wide v1, v5, Lcom/flurry/android/FlurryAgent;->J J
    iget-object v1, v5, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    if-nez v1, +009h
    const-string v1, "FlurryAgent"
    const-string v2, "Not creating report because of bad Android ID or generated ID is null"
    invoke-static v1, v2, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v1, Lcom/flurry/android/b;
    invoke-direct v1, v5, v7, v0, Lcom/flurry/android/b;-><init>(Lcom/flurry/android/FlurryAgent; Z Landroid/content/Context;)V
    invoke-direct v5, v1, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/Runnable;)V
    const/4 v0, 0
    iput-boolean v0, v5, Lcom/flurry/android/FlurryAgent;->t Z
    monitor-exit v5
    return-void
    invoke-virtual v6, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    move-result-object v0
    goto -59h
    move-exception v0
    monitor-exit v5
    throw v0
.end method

.method static a(Lcom/flurry/android/AppCircleCallback;)V
    .registers 2
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->a(Lcom/flurry/android/AppCircleCallback;)V
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/FlurryAgent; Landroid/content/Context;)V
    .registers 2
    invoke-direct v0, v1, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context;)V
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/FlurryAgent; Landroid/content/Context; Z)V
    .registers 6
    const/4 v0, 0
    if-eqz v5, +006h
    invoke-direct v3, v4, Lcom/flurry/android/FlurryAgent;->d(Landroid/content/Context;)Landroid/location/Location;
    move-result-object v0
    monitor-enter v3
    iput-object v0, v3, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    monitor-exit v3
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +007h
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->c()V
    const/4 v0, 1
    invoke-direct v3, v0, Lcom/flurry/android/FlurryAgent;->c(Z)V
    return-void
    move-exception v0
    monitor-exit v3
    throw v0
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -ch
.end method

.method private a(Ljava/io/DataInputStream;)V
    .registers 16
    new-instance v1, Ljava/util/HashMap;
    invoke-direct v1, Ljava/util/HashMap;-><init>()V
    new-instance v4, Ljava/util/HashMap;
    invoke-direct v4, Ljava/util/HashMap;-><init>()V
    new-instance v5, Ljava/util/HashMap;
    invoke-direct v5, Ljava/util/HashMap;-><init>()V
    new-instance v2, Ljava/util/HashMap;
    invoke-direct v2, Ljava/util/HashMap;-><init>()V
    new-instance v3, Ljava/util/HashMap;
    invoke-direct v3, Ljava/util/HashMap;-><init>()V
    new-instance v6, Ljava/util/HashMap;
    invoke-direct v6, Ljava/util/HashMap;-><init>()V
    invoke-virtual v15, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v8
    invoke-virtual v15, Ljava/io/DataInputStream;->readInt()I
    move-result v0
    packed-switch v8, +0000130h
    const-string v7, "FlurryAgent"
    new-instance v9, Ljava/lang/StringBuilder;
    invoke-direct v9, Ljava/lang/StringBuilder;-><init>()V
    const-string v10, "Unknown chunkType: "
    invoke-virtual v9, v10, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v9
    invoke-virtual v9, v8, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v9
    invoke-virtual v9, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v9
    invoke-static v7, v9, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v15, v0, Ljava/io/DataInputStream;->skipBytes(I)I
    const/16 v0, 264
    if-ne v8, v0, -028h
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +014h
    invoke-interface v1, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-eqz v0, +009h
    const-string v0, "FlurryAgent"
    const-string v7, "No ads from server"
    invoke-static v0, v7, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v14, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual/range v0 ... v6, Lcom/flurry/android/u;->a(Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map;)V
    return-void
    invoke-virtual v15, Ljava/io/DataInputStream;->readInt()I
    goto -1eh
    invoke-virtual v15, Ljava/io/DataInputStream;->readByte()B
    move-result v7
    invoke-virtual v15, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v9
    new-array v10, v9, [Lcom/flurry/android/v;
    const/4 v0, 0
    if-ge v0, v9, +00ch
    new-instance v11, Lcom/flurry/android/v;
    invoke-direct v11, v15, Lcom/flurry/android/v;-><init>(Ljava/io/DataInput;)V
    aput-object v11, v10, v0
    add-int/lit8 v0, v0, 1
    goto -bh
    invoke-static v7, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v0
    invoke-interface v1, v0, v10, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -3dh
    invoke-virtual v15, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v7
    const/4 v0, 0
    if-ge v0, v7, -043h
    new-instance v9, Lcom/flurry/android/AdImage;
    invoke-direct v9, v15, Lcom/flurry/android/AdImage;-><init>(Ljava/io/DataInput;)V
    iget-wide v10, v9, Lcom/flurry/android/AdImage;->a J
    invoke-static v10, v11, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v10
    invoke-interface v4, v10, v9, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    const-string v10, "FlurryAgent"
    new-instance v11, Ljava/lang/StringBuilder;
    invoke-direct v11, Ljava/lang/StringBuilder;-><init>()V
    const-string v12, "Parsed image: "
    invoke-virtual v11, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v11
    iget-wide v12, v9, Lcom/flurry/android/AdImage;->a J
    invoke-virtual v11, v12, v13, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v9
    invoke-virtual v9, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v9
    invoke-static v10, v9, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    add-int/lit8 v0, v0, 1
    goto -2ch
    invoke-virtual v15, Ljava/io/DataInputStream;->readInt()I
    move-result v7
    const/4 v0, 0
    if-ge v0, v7, -075h
    new-instance v9, Lcom/flurry/android/e;
    invoke-direct v9, v15, Lcom/flurry/android/e;-><init>(Ljava/io/DataInput;)V
    iget-object v10, v9, Lcom/flurry/android/e;->a Ljava/lang/String;
    invoke-interface v2, v10, v9, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v0, v0, 1
    goto -eh
    invoke-virtual v15, v0, Ljava/io/DataInputStream;->skipBytes(I)I
    goto/16 -087h
    invoke-virtual v15, Ljava/io/DataInputStream;->readByte()B
    move-result v7
    const/4 v0, 0
    if-ge v0, v7, -08eh
    new-instance v9, Lcom/flurry/android/c;
    invoke-direct v9, v15, Lcom/flurry/android/c;-><init>(Ljava/io/DataInput;)V
    iget-byte v10, v9, Lcom/flurry/android/c;->a B
    invoke-static v10, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v10
    invoke-interface v3, v10, v9, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v0, v0, 1
    goto -12h
    invoke-virtual v15, Ljava/io/DataInputStream;->readByte()B
    move-result v9
    const/4 v0, 0
    move v7, v0
    if-ge v7, v9, -0a7h
    invoke-virtual v15, Ljava/io/DataInputStream;->readByte()B
    move-result v0
    invoke-static v0, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v0
    invoke-interface v3, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/c;
    if-eqz v0, +005h
    invoke-virtual v0, v15, Lcom/flurry/android/c;->a(Ljava/io/DataInput;)V
    add-int/lit8 v0, v7, 1
    move v7, v0
    goto -18h
    invoke-virtual v15, Ljava/io/DataInputStream;->readInt()I
    move-result v7
    const/4 v0, 0
    if-ge v0, v7, -0c5h
    invoke-virtual v15, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v9
    invoke-virtual v15, Ljava/io/DataInputStream;->readShort()S
    move-result v11
    invoke-static v11, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;
    move-result-object v11
    invoke-static v9, v10, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v9
    invoke-interface v6, v11, v9, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v0, v0, 1
    goto -17h
    invoke-virtual v15, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v9
    invoke-static v9, v10, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v0
    invoke-interface v5, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/al;
    if-nez v0, +007h
    new-instance v0, Lcom/flurry/android/al;
    invoke-direct v0, Lcom/flurry/android/al;-><init>()V
    invoke-virtual v15, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v7
    iput-object v7, v0, Lcom/flurry/android/al;->a Ljava/lang/String;
    invoke-virtual v15, Ljava/io/DataInputStream;->readInt()I
    move-result v7
    iput v7, v0, Lcom/flurry/android/al;->c I
    invoke-static v9, v10, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v7
    invoke-interface v5, v7, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto/16 -105h
    invoke-virtual v15, v0, Ljava/io/DataInputStream;->skipBytes(I)I
    goto/16 -10ah
    invoke-virtual v15, v0, Ljava/io/DataInputStream;->skipBytes(I)I
    goto/16 -10fh
    nop
    packed-switch-payload 102 103 104 105 106 107 108 109 10a 10b 10c 10d 10e 10f 110 111
.end method

.method private a(Ljava/lang/Runnable;)V
    .registers 3
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->q Landroid/os/Handler;
    invoke-virtual v0, v2, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    return-void
.end method

.method private synchronized a(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 7
    monitor-enter v3
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    if-nez v0, +01ch
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "onError called before onStartSession.  Error: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    monitor-exit v3
    return-void
    iget v0, v3, Lcom/flurry/android/FlurryAgent;->Q I
    add-int/lit8 v0, v0, 1
    iput v0, v3, Lcom/flurry/android/FlurryAgent;->Q I
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    const/16 v1, 10
    if-ge v0, v1, -010h
    new-instance v0, Lcom/flurry/android/aa;
    invoke-direct v0, Lcom/flurry/android/aa;-><init>()V
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v1
    iput-wide v1, v0, Lcom/flurry/android/aa;->a J
    const/16 v1, 255
    invoke-static v4, v1, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v1
    iput-object v1, v0, Lcom/flurry/android/aa;->b Ljava/lang/String;
    const/16 v1, 512
    invoke-static v5, v1, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v1
    iput-object v1, v0, Lcom/flurry/android/aa;->c Ljava/lang/String;
    const/16 v1, 255
    invoke-static v6, v1, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v1
    iput-object v1, v0, Lcom/flurry/android/aa;->d Ljava/lang/String;
    iget-object v1, v3, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    invoke-interface v1, v0, Ljava/util/List;->add(Ljava/lang/Object;)Z
    goto -3ah
    move-exception v0
    monitor-exit v3
    throw v0
.end method

.method private synchronized a(Ljava/lang/String; Ljava/util/Map; Z)V
    .registers 11
    const/16 v6, 16000
    monitor-enter v7
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    if-nez v0, +01ch
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "onEvent called before onStartSession.  Event: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    monitor-exit v7
    return-void
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v0
    iget-wide v2, v7, Lcom/flurry/android/FlurryAgent;->I J
    sub-long v3, v0, v2
    const/16 v0, 255
    invoke-static v8, v0, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/String;->length()I
    move-result v0
    if-eqz v0, -014h
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/g;
    if-nez v0, +082h
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    const/16 v2, 100
    if-ge v0, v2, +057h
    new-instance v0, Lcom/flurry/android/g;
    invoke-direct v0, Lcom/flurry/android/g;-><init>()V
    const/4 v2, 1
    iput v2, v0, Lcom/flurry/android/g;->a I
    iget-object v2, v7, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    invoke-interface v2, v1, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->j Z
    if-eqz v0, +098h
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    const/16 v2, 200
    if-ge v0, v2, +08eh
    iget v0, v7, Lcom/flurry/android/FlurryAgent;->V I
    if-ge v0, v6, +08ah
    if-nez v9, +08dh
    invoke-static Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    move-result-object v2
    invoke-interface v2, Ljava/util/Map;->size()I
    move-result v0
    const/16 v5, 10
    if-le v0, v5, +052h
    const-string v0, "FlurryAgent"
    invoke-static v0, Lcom/flurry/android/ah;->a(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, -05dh
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "MaxEventParams exceeded: "
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-interface v2, Ljava/util/Map;->size()I
    move-result v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -7bh
    move-exception v0
    monitor-exit v7
    throw v0
    const-string v0, "FlurryAgent"
    invoke-static v0, Lcom/flurry/android/ah;->a(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, -04eh
    const-string v0, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "MaxEventIds exceeded: "
    invoke-virtual v2, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -68h
    iget v2, v0, Lcom/flurry/android/g;->a I
    add-int/lit8 v2, v2, 1
    iput v2, v0, Lcom/flurry/android/g;->a I
    goto -6fh
    new-instance v0, Lcom/flurry/android/i;
    move v5, v10
    invoke-direct/range v0 ... v5, Lcom/flurry/android/i;-><init>(Ljava/lang/String; Ljava/util/Map; J Z)V
    invoke-virtual v0, Lcom/flurry/android/i;->b()[B
    move-result-object v1
    array-length v1, v1
    iget v2, v7, Lcom/flurry/android/FlurryAgent;->V I
    add-int/2addr v1, v2
    if-gt v1, v6, +013h
    iget-object v1, v7, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    invoke-interface v1, v0, Ljava/util/List;->add(Ljava/lang/Object;)Z
    iget v1, v7, Lcom/flurry/android/FlurryAgent;->V I
    invoke-virtual v0, Lcom/flurry/android/i;->b()[B
    move-result-object v0
    array-length v0, v0
    add-int/2addr v0, v1
    iput v0, v7, Lcom/flurry/android/FlurryAgent;->V I
    goto/16 -0c6h
    const/16 v0, 16000
    iput v0, v7, Lcom/flurry/android/FlurryAgent;->V I
    const/4 v0, 0
    iput-boolean v0, v7, Lcom/flurry/android/FlurryAgent;->U Z
    goto/16 -0cfh
    const/4 v0, 0
    iput-boolean v0, v7, Lcom/flurry/android/FlurryAgent;->U Z
    goto/16 -0d4h
    move-object v2, v9
    goto/16 -088h
.end method

.method static a(Ljava/util/List;)V
    .registers 2
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->a(Ljava/util/List;)V
    goto -8h
.end method

.method static a(Z)V
    .registers 2
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->a(Z)V
    goto -8h
.end method

.method static a()Z
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->i()Z
    move-result v0
    return v0
.end method

.method static synthetic a(Lcom/flurry/android/FlurryAgent;)Z
    .registers 2
    iget-boolean v0, v1, Lcom/flurry/android/FlurryAgent;->u Z
    return v0
.end method

.method private static a(Ljava/io/File;)Z
    .registers 5
    invoke-virtual v4, Ljava/io/File;->getParentFile()Ljava/io/File;
    move-result-object v0
    invoke-virtual v0, Ljava/io/File;->mkdirs()Z
    move-result v1
    if-nez v1, +022h
    invoke-virtual v0, Ljava/io/File;->exists()Z
    move-result v1
    if-nez v1, +01ch
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Unable to create persistent dir: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 0
    return v0
    const/4 v0, 1
    goto -2h
.end method

.method private a([B)Z
    .registers 7
    const/4 v1, 0
    invoke-static Lcom/flurry/android/FlurryAgent;->k()Ljava/lang/String;
    move-result-object v0
    if-nez v0, +004h
    move v0, v1
    return v0
    invoke-direct v5, v6, v0, Lcom/flurry/android/FlurryAgent;->a([B Ljava/lang/String;)Z
    move-result v0
    if-nez v0, -005h
    sget-object v2, Lcom/flurry/android/FlurryAgent;->c Ljava/lang/String;
    if-nez v2, -009h
    sget-boolean v2, Lcom/flurry/android/FlurryAgent;->k Z
    if-eqz v2, -00dh
    sget-boolean v2, Lcom/flurry/android/FlurryAgent;->l Z
    if-nez v2, -011h
    sget-object v2, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v2
    const/4 v3, 1
    sput-boolean v3, Lcom/flurry/android/FlurryAgent;->l Z
    invoke-static Lcom/flurry/android/FlurryAgent;->k()Ljava/lang/String;
    move-result-object v3
    if-nez v3, +024h
    monitor-exit v2
    move v0, v1
    goto -21h
    move-exception v0
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Sending report exception: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v0, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    move v0, v1
    goto -3bh
    monitor-exit v2
    invoke-direct v5, v6, v3, Lcom/flurry/android/FlurryAgent;->a([B Ljava/lang/String;)Z
    move-result v0
    goto -46h
    move-exception v0
    monitor-exit v2
    throw v0
    move-exception v1
    goto -4bh
.end method

.method private a([B Ljava/lang/String;)Z
    .registers 9
    const/4 v1, 0
    const/4 v0, 1
    const-string v2, "local"
    invoke-virtual v2, v8, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +003h
    return v0
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Sending report to: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v2, Lorg/apache/http/entity/ByteArrayEntity;
    invoke-direct v2, v7, Lorg/apache/http/entity/ByteArrayEntity;-><init>([B)V
    const-string v3, "application/octet-stream"
    invoke-virtual v2, v3, Lorg/apache/http/entity/ByteArrayEntity;->setContentType(Ljava/lang/String;)V
    new-instance v3, Lorg/apache/http/client/methods/HttpPost;
    invoke-direct v3, v8, Lorg/apache/http/client/methods/HttpPost;-><init>(Ljava/lang/String;)V
    invoke-virtual v3, v2, Lorg/apache/http/client/methods/HttpPost;->setEntity(Lorg/apache/http/HttpEntity;)V
    new-instance v2, Lorg/apache/http/params/BasicHttpParams;
    invoke-direct v2, Lorg/apache/http/params/BasicHttpParams;-><init>()V
    const/16 v4, 10000
    invoke-static v2, v4, Lorg/apache/http/params/HttpConnectionParams;->setConnectionTimeout(Lorg/apache/http/params/HttpParams; I)V
    const/16 v4, 15000
    invoke-static v2, v4, Lorg/apache/http/params/HttpConnectionParams;->setSoTimeout(Lorg/apache/http/params/HttpParams; I)V
    invoke-virtual v3, Lorg/apache/http/client/methods/HttpPost;->getParams()Lorg/apache/http/params/HttpParams;
    move-result-object v4
    const-string v5, "http.protocol.expect-continue"
    invoke-interface v4, v5, v1, Lorg/apache/http/params/HttpParams;->setBooleanParameter(Ljava/lang/String; Z)Lorg/apache/http/params/HttpParams;
    invoke-direct v6, v2, Lcom/flurry/android/FlurryAgent;->a(Lorg/apache/http/params/HttpParams;)Lorg/apache/http/client/HttpClient;
    move-result-object v2
    invoke-interface v2, v3, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    move-result-object v2
    invoke-interface v2, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;
    move-result-object v3
    invoke-interface v3, Lorg/apache/http/StatusLine;->getStatusCode()I
    move-result v3
    monitor-enter v6
    const/16 v4, 200
    if-ne v3, v4, +047h
    const-string v1, "FlurryAgent"
    const-string v3, "Report successful"
    invoke-static v1, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v1, 1
    iput-boolean v1, v6, Lcom/flurry/android/FlurryAgent;->E Z
    iget-object v1, v6, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    iget-object v3, v6, Lcom/flurry/android/FlurryAgent;->B Ljava/util/List;
    invoke-interface v1, v3, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z
    invoke-interface v2, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;
    move-result-object v1
    const-string v2, "FlurryAgent"
    const-string v3, "Processing report response"
    invoke-static v2, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    if-eqz v1, +01bh
    invoke-interface v1, Lorg/apache/http/HttpEntity;->getContentLength()J
    move-result-wide v2
    const-wide/16 v4, 0
    cmp-long v2, v2, v4
    if-eqz v2, +011h
    invoke-interface v1, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;
    move-result-object v2
    new-instance v3, Ljava/io/DataInputStream;
    invoke-direct v3, v2, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    invoke-direct v6, v3, Lcom/flurry/android/FlurryAgent;->a(Ljava/io/DataInputStream;)V
    invoke-interface v1, Lorg/apache/http/HttpEntity;->consumeContent()V
    const/4 v1, 0
    iput-object v1, v6, Lcom/flurry/android/FlurryAgent;->B Ljava/util/List;
    monitor-exit v6
    goto/16 -093h
    move-exception v0
    monitor-exit v6
    throw v0
    move-exception v0
    invoke-interface v1, Lorg/apache/http/HttpEntity;->consumeContent()V
    throw v0
    const-string v0, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Report failed. HTTP response: "
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    move v0, v1
    goto -27h
.end method

.method public static addUserCookie(Ljava/lang/String; Ljava/lang/String;)V
    .registers 3
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, v2, Lcom/flurry/android/u;->a(Ljava/lang/String; Ljava/lang/String;)V
    goto -8h
.end method

.method static b()Lcom/flurry/android/u;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    return-object v0
.end method

.method private b(Landroid/content/Context;)Ljava/lang/String;
    .registers 9
    const/4 v0, 0
    const/4 v1, 0
    iget-object v2, v7, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    if-eqz v2, +005h
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    return-object v0
    invoke-virtual v8, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    move-result-object v2
    const-string v3, "android_id"
    invoke-static v2, v3, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    if-eqz v3, +010h
    invoke-virtual v3, Ljava/lang/String;->length()I
    move-result v2
    if-lez v2, +00ah
    const-string v2, "null"
    invoke-virtual v3, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +018h
    if-eqz v1, +029h
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "AND"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    goto -30h
    sget-object v4, Lcom/flurry/android/FlurryAgent;->b [Ljava/lang/String;
    array-length v5, v4
    move v2, v1
    if-ge v2, v5, +00dh
    aget-object v6, v4, v2
    invoke-virtual v3, v6, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v6
    if-nez v6, -022h
    add-int/lit8 v2, v2, 1
    goto -ch
    const/4 v1, 1
    goto -28h
    const-string v1, ".flurryb."
    invoke-virtual v8, v1, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v1
    invoke-virtual v1, Ljava/io/File;->exists()Z
    move-result v2
    if-eqz v2, -04eh
    new-instance v3, Ljava/io/FileInputStream;
    invoke-direct v3, v1, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    new-instance v2, Ljava/io/DataInputStream;
    invoke-direct v2, v3, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    invoke-virtual v2, Ljava/io/DataInputStream;->readInt()I
    invoke-virtual v2, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -64h
    move-exception v1
    move-object v2, v0
    const-string v3, "FlurryAgent"
    const-string v4, "Error when loading b file"
    invoke-static v3, v4, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -71h
    move-exception v1
    move-object v2, v0
    move-object v0, v1
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    goto -5h
    move-exception v1
    goto -15h
.end method

.method static b(Ljava/lang/String;)Ljava/util/List;
    .registers 2
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +004h
    const/4 v0, 0
    return-object v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v1, Lcom/flurry/android/u;->c(Ljava/lang/String;)Ljava/util/List;
    move-result-object v0
    goto -9h
.end method

.method private synchronized b(Landroid/content/Context; Ljava/lang/String;)V
    .registers 11
    monitor-enter v8
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    if-eqz v0, +02eh
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v0, v10, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-nez v0, +026h
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "onStartSession called with different api keys: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " and "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v10, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->w Ljava/util/Map;
    invoke-interface v0, v9, v9, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/content/Context;
    if-eqz v0, +009h
    const-string v0, "FlurryAgent"
    const-string v1, "onStartSession called with duplicate context, use a specific Activity or Service as context instead of using a global context"
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    iget-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->t Z
    if-nez v0, +15ch
    const-string v0, "FlurryAgent"
    const-string v1, "Initializing Flurry session"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iput-object v10, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, ".flurryagent."
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v1, Ljava/lang/String;->hashCode()I
    move-result v1
    const/16 v2, 16
    invoke-static v1, v2, Ljava/lang/Integer;->toString(I I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v9, v0, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    const-string v0, ".flurryb."
    invoke-virtual v9, v0, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->r Ljava/io/File;
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->m Z
    if-eqz v0, +00ah
    new-instance v0, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;
    invoke-direct v0, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;-><init>()V
    invoke-static v0, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V
    invoke-virtual v9, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    move-result-object v1
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->z Ljava/lang/String;
    if-nez v0, +008h
    invoke-static v1, Lcom/flurry/android/FlurryAgent;->c(Landroid/content/Context;)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->z Ljava/lang/String;
    invoke-virtual v1, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v0
    iget-object v2, v8, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    if-eqz v2, +02eh
    iget-object v2, v8, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +026h
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "onStartSession called from different application packages: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-object v4, v8, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, " and "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->y Ljava/lang/String;
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v2
    iget-wide v4, v8, Lcom/flurry/android/FlurryAgent;->v J
    sub-long v4, v2, v4
    sget-wide v6, Lcom/flurry/android/FlurryAgent;->i J
    cmp-long v0, v4, v6
    if-lez v0, +0cdh
    const-string v0, "FlurryAgent"
    const-string v4, "New session"
    invoke-static v0, v4, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v4
    iput-wide v4, v8, Lcom/flurry/android/FlurryAgent;->H J
    iput-wide v2, v8, Lcom/flurry/android/FlurryAgent;->I J
    const-wide/16 v2, -1
    iput-wide v2, v8, Lcom/flurry/android/FlurryAgent;->J J
    const-string v0, ""
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->N Ljava/lang/String;
    const/4 v0, 0
    iput v0, v8, Lcom/flurry/android/FlurryAgent;->Q I
    const/4 v0, 0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    invoke-static Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;
    move-result-object v0
    invoke-virtual v0, Ljava/util/TimeZone;->getID()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->L Ljava/lang/String;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    invoke-static Ljava/util/Locale;->getDefault()Ljava/util/Locale;
    move-result-object v2
    invoke-virtual v2, Ljava/util/Locale;->getLanguage()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, "_"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static Ljava/util/Locale;->getDefault()Ljava/util/Locale;
    move-result-object v2
    invoke-virtual v2, Ljava/util/Locale;->getCountry()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->K Ljava/lang/String;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    const/4 v0, 1
    iput-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->U Z
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    const/4 v0, 0
    iput v0, v8, Lcom/flurry/android/FlurryAgent;->V I
    const/4 v0, 0
    iput v0, v8, Lcom/flurry/android/FlurryAgent;->X I
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +049h
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->b()Z
    move-result v0
    if-nez v0, +03ch
    const-string v0, "FlurryAgent"
    const-string v2, "Initializing AppCircle"
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v2, Lcom/flurry/android/a;
    invoke-direct v2, Lcom/flurry/android/a;-><init>()V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    iput-object v0, v2, Lcom/flurry/android/a;->a Ljava/lang/String;
    iget-wide v3, v8, Lcom/flurry/android/FlurryAgent;->F J
    iput-wide v3, v2, Lcom/flurry/android/a;->b J
    iget-wide v3, v8, Lcom/flurry/android/FlurryAgent;->H J
    iput-wide v3, v2, Lcom/flurry/android/a;->c J
    iget-wide v3, v8, Lcom/flurry/android/FlurryAgent;->I J
    iput-wide v3, v2, Lcom/flurry/android/a;->d J
    sget-object v0, Lcom/flurry/android/FlurryAgent;->d Ljava/lang/String;
    if-eqz v0, +030h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->d Ljava/lang/String;
    iput-object v0, v2, Lcom/flurry/android/a;->e Ljava/lang/String;
    invoke-static Lcom/flurry/android/FlurryAgent;->c()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/flurry/android/a;->f Ljava/lang/String;
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->q Landroid/os/Handler;
    iput-object v0, v2, Lcom/flurry/android/a;->g Landroid/os/Handler;
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, v9, v2, Lcom/flurry/android/u;->a(Landroid/content/Context; Lcom/flurry/android/a;)V
    const-string v0, "FlurryAgent"
    const-string v2, "AppCircle initialized"
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->a()V
    iget-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->A Z
    new-instance v2, Lcom/flurry/android/d;
    invoke-direct v2, v8, v1, v0, Lcom/flurry/android/d;-><init>(Lcom/flurry/android/FlurryAgent; Landroid/content/Context; Z)V
    invoke-direct v8, v2, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/Runnable;)V
    const/4 v0, 1
    iput-boolean v0, v8, Lcom/flurry/android/FlurryAgent;->t Z
    monitor-exit v8
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->e Ljava/lang/String;
    goto -2eh
    const-string v0, "FlurryAgent"
    const-string v1, "Continuing previous session"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-nez v0, -015h
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    iget-object v1, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    add-int/lit8 v1, v1, -1
    invoke-interface v0, v1, Ljava/util/List;->remove(I)Ljava/lang/Object;
    goto -24h
    move-exception v0
    monitor-exit v8
    throw v0
.end method

.method static synthetic b(Lcom/flurry/android/FlurryAgent;)V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/FlurryAgent;->i()V
    return-void
.end method

.method static synthetic b(Lcom/flurry/android/FlurryAgent; Landroid/content/Context;)V
    .registers 7
    const/4 v0, 0
    monitor-enter v5
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v1
    iget-wide v3, v5, Lcom/flurry/android/FlurryAgent;->v J
    sub-long/2addr v1, v3
    iget-boolean v3, v5, Lcom/flurry/android/FlurryAgent;->t Z
    if-nez v3, +011h
    sget-wide v3, Lcom/flurry/android/FlurryAgent;->i J
    cmp-long v1, v1, v3
    if-lez v1, +00bh
    iget-object v1, v5, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    if-lez v1, +003h
    const/4 v0, 1
    monitor-exit v5
    if-eqz v0, +006h
    const/4 v0, 0
    invoke-direct v5, v0, Lcom/flurry/android/FlurryAgent;->c(Z)V
    return-void
    move-exception v0
    monitor-exit v5
    throw v0
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -ch
.end method

.method private synchronized b(Ljava/io/DataInputStream;)V
    .registers 8
    const/4 v5, 2
    const/4 v0, 0
    monitor-enter v6
    invoke-virtual v7, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v1
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "File version: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    if-le v1, v5, +036h
    const-string v0, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Unknown agent file version: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v0, Ljava/io/IOException;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Unknown agent file version: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-direct v0, v1, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    throw v0
    move-exception v0
    monitor-exit v6
    throw v0
    if-lt v1, v5, +0bah
    invoke-virtual v7, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v1
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Loading API key: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-object v4, v6, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v2, v6, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +06fh
    invoke-virtual v7, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v1
    iget-object v2, v6, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    if-nez v2, +01ah
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Loading phoneId: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    iput-object v1, v6, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-virtual v7, Ljava/io/DataInputStream;->readBoolean()Z
    move-result v1
    iput-boolean v1, v6, Lcom/flurry/android/FlurryAgent;->E Z
    invoke-virtual v7, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v1
    iput-wide v1, v6, Lcom/flurry/android/FlurryAgent;->F J
    const-string v1, "FlurryAgent"
    const-string v2, "Loading session reports"
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v7, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v1
    if-eqz v1, +028h
    new-array v1, v1, [B
    invoke-virtual v7, v1, Ljava/io/DataInputStream;->readFully([B)V
    iget-object v2, v6, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    const/4 v3, 0
    invoke-interface v2, v3, v1, Ljava/util/List;->add(I Ljava/lang/Object;)V
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Session report added: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    add-int/lit8 v0, v0, 1
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -2bh
    const-string v0, "FlurryAgent"
    const-string v1, "Persistent file loaded"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 1
    iput-boolean v0, v6, Lcom/flurry/android/FlurryAgent;->u Z
    monitor-exit v6
    return-void
    const-string v0, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Api keys do not match, old: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, ", new: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v6, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -26h
    const-string v0, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Deleting old file version: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    goto -3fh
.end method

.method private synchronized b(Z)[B
    .registers 10
    const/4 v1, 0
    const/4 v3, 0
    monitor-enter v8
    new-instance v4, Ljava/io/ByteArrayOutputStream;
    invoke-direct v4, Ljava/io/ByteArrayOutputStream;-><init>()V
    new-instance v2, Ljava/io/DataOutputStream;
    invoke-direct v2, v4, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    const/16 v0, 15
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +04ch
    if-eqz v9, +04ah
    const/4 v0, 1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +04fh
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->e()J
    move-result-wide v5
    invoke-virtual v2, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->f()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->size()I
    move-result v5
    invoke-virtual v2, v5, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v5
    invoke-interface v5, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +038h
    invoke-interface v5, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Long;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v6
    const/4 v0, 1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeByte(I)V
    invoke-virtual v2, v6, v7, Ljava/io/DataOutputStream;->writeLong(J)V
    goto -17h
    move-exception v0
    const-string v3, "FlurryAgent"
    const-string v4, "Error when generating report"
    invoke-static v3, v4, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    move-object v0, v1
    monitor-exit v8
    return-object v0
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    goto -48h
    move-exception v0
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    monitor-exit v8
    throw v0
    const-wide/16 v5, 0
    invoke-virtual v2, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    const/4 v0, 3
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    const/16 v0, 117
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v5
    invoke-virtual v2, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->z Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-wide v5, v8, Lcom/flurry/android/FlurryAgent;->F J
    invoke-virtual v2, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-wide v5, v8, Lcom/flurry/android/FlurryAgent;->H J
    invoke-virtual v2, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    const/4 v0, 6
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    const-string v0, "device.model"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build;->MODEL Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v0, "build.brand"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build;->BRAND Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v0, "build.id"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build;->ID Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v0, "version.release"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build$VERSION;->RELEASE Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v0, "build.device"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build;->DEVICE Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    const-string v0, "build.product"
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    sget-object v0, Landroid/os/Build;->PRODUCT Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v5
    invoke-virtual v2, v5, Ljava/io/DataOutputStream;->writeShort(I)V
    if-ge v3, v5, +011h
    iget-object v0, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v0, v3, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [B
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->write([B)V
    add-int/lit8 v0, v3, 1
    move v3, v0
    goto -10h
    new-instance v0, Ljava/util/ArrayList;
    iget-object v3, v8, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-direct v0, v3, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    iput-object v0, v8, Lcom/flurry/android/FlurryAgent;->B Ljava/util/List;
    invoke-virtual v2, Ljava/io/DataOutputStream;->close()V
    invoke-virtual v4, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v0
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto/16 -0b2h
    move-exception v0
    move-object v2, v1
    goto/16 -0aeh
    move-exception v0
    move-object v2, v1
    goto/16 -0c5h
.end method

.method static c()Ljava/lang/String;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->f Ljava/lang/String;
    if-eqz v0, +005h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->f Ljava/lang/String;
    return-object v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->g Ljava/lang/String;
    goto -3h
.end method

.method private static c(Landroid/content/Context;)Ljava/lang/String;
    .registers 4
    invoke-virtual v3, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v0
    invoke-virtual v3, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v1
    const/4 v2, 0
    invoke-virtual v0, v1, v2, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String; I)Landroid/content/pm/PackageInfo;
    move-result-object v0
    iget-object v1, v0, Landroid/content/pm/PackageInfo;->versionName Ljava/lang/String;
    if-eqz v1, +005h
    iget-object v0, v0, Landroid/content/pm/PackageInfo;->versionName Ljava/lang/String;
    return-object v0
    iget v1, v0, Landroid/content/pm/PackageInfo;->versionCode I
    if-eqz v1, +011h
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode I
    invoke-static v0, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v0
    goto -bh
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    const-string v0, "Unknown"
    goto -16h
.end method

.method private synchronized c(Landroid/content/Context; Ljava/lang/String;)V
    .registers 7
    monitor-enter v4
    const-string v0, ".flurryb."
    invoke-virtual v5, v0, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v0
    iput-object v0, v4, Lcom/flurry/android/FlurryAgent;->r Ljava/io/File;
    iget-object v0, v4, Lcom/flurry/android/FlurryAgent;->r Ljava/io/File;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->a(Ljava/io/File;)Z
    move-result v0
    if-nez v0, +004h
    monitor-exit v4
    return-void
    const/4 v2, 0
    new-instance v0, Ljava/io/FileOutputStream;
    iget-object v1, v4, Lcom/flurry/android/FlurryAgent;->r Ljava/io/File;
    invoke-direct v0, v1, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    new-instance v1, Ljava/io/DataOutputStream;
    invoke-direct v1, v0, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    const/4 v0, 1
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeInt(I)V
    invoke-virtual v1, v6, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -19h
    move-exception v0
    monitor-exit v4
    throw v0
    move-exception v0
    move-object v1, v2
    const-string v2, "FlurryAgent"
    const-string v3, "Error when saving b file"
    invoke-static v2, v3, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -29h
    move-exception v0
    move-object v1, v2
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    goto -5h
    move-exception v0
    goto -14h
.end method

.method static synthetic c(Lcom/flurry/android/FlurryAgent;)V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/FlurryAgent;->l()V
    return-void
.end method

.method private synchronized c(Ljava/lang/String;)V
    .registers 5
    monitor-enter v3
    iget-object v0, v3, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +011h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/i;
    invoke-virtual v0, v4, Lcom/flurry/android/i;->a(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, -010h
    invoke-virtual v0, Lcom/flurry/android/i;->a()V
    monitor-exit v3
    return-void
    move-exception v0
    monitor-exit v3
    throw v0
.end method

.method private c(Z)V
    .registers 5
    const-string v0, "FlurryAgent"
    const-string v1, "generating report"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-direct v3, v4, Lcom/flurry/android/FlurryAgent;->b(Z)[B
    move-result-object v0
    if-eqz v0, +033h
    invoke-direct v3, v0, Lcom/flurry/android/FlurryAgent;->a([B)Z
    move-result v0
    if-eqz v0, +029h
    const-string v1, "FlurryAgent"
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Done sending "
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    iget-boolean v0, v3, Lcom/flurry/android/FlurryAgent;->t Z
    if-eqz v0, +019h
    const-string v0, "initial "
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, "agent report"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-direct v3, Lcom/flurry/android/FlurryAgent;->l()V
    return-void
    const-string v0, ""
    goto -17h
    const-string v0, "FlurryAgent"
    const-string v1, "Error generating report"
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto -bh
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -14h
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1dh
.end method

.method public static clearUserCookies()V
    .registers 1
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->l()V
    goto -8h
.end method

.method private d(Landroid/content/Context;)Landroid/location/Location;
    .registers 9
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"
    invoke-virtual v8, v0, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    move-result v0
    if-eqz v0, +00ah
    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"
    invoke-virtual v8, v0, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    move-result v0
    if-nez v0, +038h
    const-string v0, "location"
    invoke-virtual v8, v0, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/location/LocationManager;
    monitor-enter v7
    iget-object v1, v7, Lcom/flurry/android/FlurryAgent;->C Landroid/location/LocationManager;
    if-nez v1, +025h
    iput-object v0, v7, Lcom/flurry/android/FlurryAgent;->C Landroid/location/LocationManager;
    monitor-exit v7
    sget-object v1, Lcom/flurry/android/FlurryAgent;->n Landroid/location/Criteria;
    if-nez v1, +007h
    new-instance v1, Landroid/location/Criteria;
    invoke-direct v1, Landroid/location/Criteria;-><init>()V
    const/4 v2, 1
    invoke-virtual v0, v1, v2, Landroid/location/LocationManager;->getBestProvider(Landroid/location/Criteria; Z)Ljava/lang/String;
    move-result-object v1
    if-eqz v1, +018h
    const-wide/16 v2, 0
    const/4 v4, 0
    invoke-static Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    move-result-object v6
    move-object v5, v7
    invoke-virtual/range v0 ... v6, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String; J F Landroid/location/LocationListener; Landroid/os/Looper;)V
    invoke-virtual v0, v1, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;
    move-result-object v0
    return-object v0
    iget-object v0, v7, Lcom/flurry/android/FlurryAgent;->C Landroid/location/LocationManager;
    goto -23h
    move-exception v0
    monitor-exit v7
    throw v0
    const/4 v0, 0
    goto -8h
.end method

.method static synthetic d(Lcom/flurry/android/FlurryAgent;)Landroid/os/Handler;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->q Landroid/os/Handler;
    return-object v0
.end method

.method static d()Z
    .registers 1
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->n()Z
    move-result v0
    goto -9h
.end method

.method static synthetic e(Lcom/flurry/android/FlurryAgent;)Lcom/flurry/android/u;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    return-object v0
.end method

.method static e()Ljava/lang/String;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-object v0, v0, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    return-object v0
.end method

.method public static enableAppCircle()V
    .registers 1
    const/4 v0, 1
    sput-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    return-void
.end method

.method public static endTimedEvent(Ljava/lang/String;)V
    .registers 5
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, v4, Lcom/flurry/android/FlurryAgent;->c(Ljava/lang/String;)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to signify the end of event: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
.end method

.method static synthetic f()Lcom/flurry/android/FlurryAgent;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    return-object v0
.end method

.method static synthetic g()J
    .registers 2
    sget-wide v0, Lcom/flurry/android/FlurryAgent;->i J
    return-wide v0
.end method

.method public static getAgentVersion()I
    .registers 1
    const/16 v0, 117
    return v0
.end method

.method public static getAppCircle()Lcom/flurry/android/AppCircle;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->p Lcom/flurry/android/AppCircle;
    return-object v0
.end method

.method public static getForbidPlaintextFallback()Z
    .registers 1
    const/4 v0, 0
    return v0
.end method

.method public static getPhoneId()Ljava/lang/String;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, Lcom/flurry/android/FlurryAgent;->n()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method static synthetic h()Z
    .registers 1
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    return v0
.end method

.method private synchronized i()V
    .registers 7
    monitor-enter v6
    const/4 v1, 0
    new-instance v3, Ljava/io/ByteArrayOutputStream;
    invoke-direct v3, Ljava/io/ByteArrayOutputStream;-><init>()V
    new-instance v2, Ljava/io/DataOutputStream;
    invoke-direct v2, v3, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    const/4 v0, 1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->z Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-wide v0, v6, Lcom/flurry/android/FlurryAgent;->H J
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-wide v0, v6, Lcom/flurry/android/FlurryAgent;->J J
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    const-wide/16 v0, 0
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->K Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->L Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-byte v0, v6, Lcom/flurry/android/FlurryAgent;->M B
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeByte(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->N Ljava/lang/String;
    if-nez v0, +06bh
    const-string v0, ""
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    if-nez v0, +065h
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget v0, v6, Lcom/flurry/android/FlurryAgent;->X I
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeInt(I)V
    const/4 v0, -1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeByte(I)V
    const/4 v0, -1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeByte(I)V
    iget-byte v0, v6, Lcom/flurry/android/FlurryAgent;->O B
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeByte(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->P Ljava/lang/Long;
    if-nez v0, +07ch
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->S Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +06eh
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v2, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/g;
    iget v0, v0, Lcom/flurry/android/g;->a I
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeInt(I)V
    goto -20h
    move-exception v0
    move-object v1, v2
    const-string v2, "FlurryAgent"
    const-string v3, ""
    invoke-static v2, v3, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    monitor-exit v6
    return-void
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->N Ljava/lang/String;
    goto -69h
    const/4 v0, 1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    invoke-virtual v0, Landroid/location/Location;->getLatitude()D
    move-result-wide v0
    invoke-static v0, v1, Lcom/flurry/android/FlurryAgent;->a(D)D
    move-result-wide v0
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeDouble(D)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    invoke-virtual v0, Landroid/location/Location;->getLongitude()D
    move-result-wide v0
    invoke-static v0, v1, Lcom/flurry/android/FlurryAgent;->a(D)D
    move-result-wide v0
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeDouble(D)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    invoke-virtual v0, Landroid/location/Location;->getAccuracy()F
    move-result v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeFloat(F)V
    goto/16 -086h
    move-exception v0
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    monitor-exit v6
    throw v0
    const/4 v0, 1
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->P Ljava/lang/Long;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v0
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    goto/16 -083h
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->T Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +010h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/i;
    invoke-virtual v0, Lcom/flurry/android/i;->b()[B
    move-result-object v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->write([B)V
    goto -13h
    iget-boolean v0, v6, Lcom/flurry/android/FlurryAgent;->U Z
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget v0, v6, Lcom/flurry/android/FlurryAgent;->Q I
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeInt(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->W Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01dh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/aa;
    iget-wide v4, v0, Lcom/flurry/android/aa;->a J
    invoke-virtual v2, v4, v5, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v4, v0, Lcom/flurry/android/aa;->b Ljava/lang/String;
    invoke-virtual v2, v4, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v4, v0, Lcom/flurry/android/aa;->c Ljava/lang/String;
    invoke-virtual v2, v4, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v0, Lcom/flurry/android/aa;->d Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    goto -20h
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-eqz v0, +023h
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->Y Lcom/flurry/android/u;
    invoke-virtual v0, Lcom/flurry/android/u;->g()Ljava/util/List;
    move-result-object v0
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v1
    invoke-virtual v2, v1, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +010h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/p;
    invoke-virtual v0, v2, Lcom/flurry/android/p;->a(Ljava/io/DataOutput;)V
    goto -fh
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-virtual v3, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto/16 -0d7h
    move-exception v0
    move-object v2, v1
    goto/16 -0ach
    move-exception v0
    move-object v2, v1
    goto/16 -0b0h
    move-exception v0
    goto/16 -0ech
.end method

.method protected static isCaptureUncaughtExceptions()Z
    .registers 1
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->m Z
    return v0
.end method

.method private synchronized j()V
    .registers 2
    monitor-enter v1
    iget v0, v1, Lcom/flurry/android/FlurryAgent;->X I
    add-int/lit8 v0, v0, 1
    iput v0, v1, Lcom/flurry/android/FlurryAgent;->X I
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method private static k()Ljava/lang/String;
    .registers 1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->c Ljava/lang/String;
    if-eqz v0, +005h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->c Ljava/lang/String;
    return-object v0
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->l Z
    if-eqz v0, +005h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->kInsecureReportUrl Ljava/lang/String;
    goto -7h
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->k Z
    if-eqz v0, +005h
    sget-object v0, Lcom/flurry/android/FlurryAgent;->kSecureReportUrl Ljava/lang/String;
    goto -eh
    sget-object v0, Lcom/flurry/android/FlurryAgent;->kInsecureReportUrl Ljava/lang/String;
    goto -11h
.end method

.method private synchronized l()V
    .registers 7
    const/4 v2, 0
    monitor-enter v6
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->a(Ljava/io/File;)Z
    move-result v0
    if-nez v0, +008h
    const/4 v0, 0
    invoke-static v0, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    monitor-exit v6
    return-void
    new-instance v0, Ljava/io/FileOutputStream;
    iget-object v1, v6, Lcom/flurry/android/FlurryAgent;->s Ljava/io/File;
    invoke-direct v0, v1, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    new-instance v1, Ljava/io/DataOutputStream;
    invoke-direct v1, v0, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    const v0, 46586
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    const/4 v0, 2
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->x Ljava/lang/String;
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-boolean v0, v6, Lcom/flurry/android/FlurryAgent;->E Z
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    iget-wide v2, v6, Lcom/flurry/android/FlurryAgent;->F J
    invoke-virtual v1, v2, v3, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    add-int/lit8 v0, v0, -1
    move v2, v0
    if-ltz v2, +02fh
    iget-object v0, v6, Lcom/flurry/android/FlurryAgent;->G Ljava/util/List;
    invoke-interface v0, v2, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [B
    array-length v3, v0
    add-int/lit8 v4, v3, 2
    invoke-virtual v1, Ljava/io/DataOutputStream;->size()I
    move-result v5
    add-int/2addr v4, v5
    const v5, 50000
    if-le v4, v5, +025h
    const-string v0, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "discarded sessions: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 0
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -6bh
    move-exception v0
    monitor-exit v6
    throw v0
    invoke-virtual v1, v3, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-virtual v1, v0, Ljava/io/DataOutputStream;->write([B)V
    add-int/lit8 v0, v2, -1
    move v2, v0
    goto -43h
    move-exception v0
    move-object v1, v2
    const-string v2, "FlurryAgent"
    const-string v3, ""
    invoke-static v2, v3, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto/16 -085h
    move-exception v0
    move-object v1, v2
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    goto -5h
    move-exception v0
    goto -15h
.end method

.method public static logEvent(Ljava/lang/String;)V
    .registers 5
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    const/4 v2, 0
    invoke-direct v0, v4, v1, v2, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to log event: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
.end method

.method public static logEvent(Ljava/lang/String; Ljava/util/Map;)V
    .registers 6
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    invoke-direct v0, v4, v5, v1, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to log event: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
.end method

.method public static logEvent(Ljava/lang/String; Ljava/util/Map; Z)V
    .registers 7
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, v4, v5, v6, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to log event: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
.end method

.method public static logEvent(Ljava/lang/String; Z)V
    .registers 6
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    invoke-direct v0, v4, v1, v5, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Failed to log event: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -1ah
.end method

.method private synchronized m()V
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->C Landroid/location/LocationManager;
    if-eqz v0, +007h
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->C Landroid/location/LocationManager;
    invoke-virtual v0, v1, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method private synchronized n()Ljava/lang/String;
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/FlurryAgent;->D Ljava/lang/String;
    monitor-exit v1
    return-object v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static onEndSession(Landroid/content/Context;)V
    .registers 4
    if-nez v3, +00ah
    new-instance v0, Ljava/lang/NullPointerException;
    const-string v1, "Null context"
    invoke-direct v0, v1, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    throw v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    invoke-direct v0, v3, v1, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static onError(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 6
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, v3, v4, v5, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static onEvent(Ljava/lang/String;)V
    .registers 4
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    const/4 v2, 0
    invoke-direct v0, v3, v1, v2, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static onEvent(Ljava/lang/String; Ljava/util/Map;)V
    .registers 5
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, 0
    invoke-direct v0, v3, v4, v1, Lcom/flurry/android/FlurryAgent;->a(Ljava/lang/String; Ljava/util/Map; Z)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static onPageView()V
    .registers 3
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, Lcom/flurry/android/FlurryAgent;->j()V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static onStartSession(Landroid/content/Context; Ljava/lang/String;)V
    .registers 5
    if-nez v3, +00ah
    new-instance v0, Ljava/lang/NullPointerException;
    const-string v1, "Null context"
    invoke-direct v0, v1, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    throw v0
    if-eqz v4, +008h
    invoke-virtual v4, Ljava/lang/String;->length()I
    move-result v0
    if-nez v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "Api key not specified"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-direct v0, v3, v4, Lcom/flurry/android/FlurryAgent;->b(Landroid/content/Context; Ljava/lang/String;)V
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -9h
.end method

.method public static setAge(I)V
    .registers 8
    const/4 v6, 1
    if-lez v7, +02ch
    const/16 v0, 110
    if-ge v7, v0, +028h
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    int-to-long v2, v7
    const-wide v4, 31449600000
    mul-long/2addr v2, v4
    sub-long/2addr v0, v2
    new-instance v2, Ljava/util/Date;
    invoke-direct v2, v0, v1, Ljava/util/Date;-><init>(J)V
    invoke-virtual v2, Ljava/util/Date;->getYear()I
    move-result v0
    new-instance v1, Ljava/util/Date;
    invoke-direct v1, v0, v6, v6, Ljava/util/Date;-><init>(I I I)V
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    invoke-virtual v1, Ljava/util/Date;->getTime()J
    move-result-wide v1
    invoke-static v1, v2, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    iput-object v1, v0, Lcom/flurry/android/FlurryAgent;->P Ljava/lang/Long;
    return-void
.end method

.method public static setCanvasUrl(Ljava/lang/String;)V
    .registers 1
    sput-object v0, Lcom/flurry/android/FlurryAgent;->d Ljava/lang/String;
    return-void
.end method

.method public static setCaptureUncaughtExceptions(Z)V
    .registers 4
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iget-boolean v0, v0, Lcom/flurry/android/FlurryAgent;->t Z
    if-eqz v0, +00bh
    const-string v0, "FlurryAgent"
    const-string v2, "Cannot setCaptureUncaughtExceptions after onSessionStart"
    invoke-static v0, v2, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    monitor-exit v1
    return-void
    sput-boolean v3, Lcom/flurry/android/FlurryAgent;->m Z
    monitor-exit v1
    goto -4h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setCatalogIntentName(Ljava/lang/String;)V
    .registers 1
    sput-object v0, Lcom/flurry/android/FlurryAgent;->a Ljava/lang/String;
    return-void
.end method

.method public static setContinueSessionMillis(J)V
    .registers 5
    const-wide/16 v0, 5000
    cmp-long v0, v3, v0
    if-gez v0, +01bh
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Invalid time set for session resumption: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v3, v4, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    return-void
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sput-wide v3, Lcom/flurry/android/FlurryAgent;->i J
    monitor-exit v1
    goto -7h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setDefaultNoAdsMessage(Ljava/lang/String;)V
    .registers 2
    sget-boolean v0, Lcom/flurry/android/FlurryAgent;->o Z
    if-nez v0, +003h
    return-void
    if-nez v1, +004h
    const-string v1, ""
    sput-object v1, Lcom/flurry/android/u;->b Ljava/lang/String;
    goto -7h
.end method

.method public static setGender(B)V
    .registers 3
    packed-switch v2, +000000eh
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/4 v1, -1
    iput-byte v1, v0, Lcom/flurry/android/FlurryAgent;->O B
    return-void
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iput-byte v2, v0, Lcom/flurry/android/FlurryAgent;->O B
    goto -5h
    packed-switch-payload 0 1
.end method

.method public static setGetAppUrl(Ljava/lang/String;)V
    .registers 1
    sput-object v0, Lcom/flurry/android/FlurryAgent;->f Ljava/lang/String;
    return-void
.end method

.method public static setLocationCriteria(Landroid/location/Criteria;)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sput-object v2, Lcom/flurry/android/FlurryAgent;->n Landroid/location/Criteria;
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setLogEnabled(Z)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    if-eqz v2, +007h
    invoke-static Lcom/flurry/android/ah;->b()V
    monitor-exit v1
    return-void
    invoke-static Lcom/flurry/android/ah;->a()V
    goto -5h
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setLogEvents(Z)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sput-boolean v2, Lcom/flurry/android/FlurryAgent;->j Z
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setLogLevel(I)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    invoke-static v2, Lcom/flurry/android/ah;->a(I)V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setReportLocation(Z)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iput-boolean v2, v0, Lcom/flurry/android/FlurryAgent;->A Z
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setReportUrl(Ljava/lang/String;)V
    .registers 1
    sput-object v0, Lcom/flurry/android/FlurryAgent;->c Ljava/lang/String;
    return-void
.end method

.method public static setUseHttps(Z)V
    .registers 1
    sput-boolean v0, Lcom/flurry/android/FlurryAgent;->k Z
    return-void
.end method

.method public static setUserId(Ljava/lang/String;)V
    .registers 4
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    const/16 v2, 255
    invoke-static v3, v2, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v2
    iput-object v2, v0, Lcom/flurry/android/FlurryAgent;->N Ljava/lang/String;
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public static setVersionName(Ljava/lang/String;)V
    .registers 3
    sget-object v1, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    monitor-enter v1
    sget-object v0, Lcom/flurry/android/FlurryAgent;->h Lcom/flurry/android/FlurryAgent;
    iput-object v2, v0, Lcom/flurry/android/FlurryAgent;->z Ljava/lang/String;
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final a(Ljava/lang/Throwable;)V
    .registers 6
    invoke-virtual v5, Ljava/lang/Throwable;->printStackTrace()V
    const-string v0, ""
    invoke-virtual v5, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;
    move-result-object v1
    if-eqz v1, +072h
    array-length v2, v1
    if-lez v2, +06fh
    const/4 v0, 0
    aget-object v0, v1, v0
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v0, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "."
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v0, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ":"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v0, Ljava/lang/StackTraceElement;->getLineNumber()I
    move-result v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    invoke-virtual v5, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +022h
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, " ("
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v5, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, ")"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v5, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Class;->toString()Ljava/lang/String;
    move-result-object v1
    const-string v2, "uncaught"
    invoke-static v2, v0, v1, Lcom/flurry/android/FlurryAgent;->onError(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v4, Lcom/flurry/android/FlurryAgent;->w Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->clear()V
    const/4 v0, 0
    const/4 v1, 1
    invoke-direct v4, v0, v1, Lcom/flurry/android/FlurryAgent;->a(Landroid/content/Context; Z)V
    return-void
    invoke-virtual v5, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    move-result-object v1
    if-eqz v1, -01ch
    invoke-virtual v5, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    move-result-object v0
    goto -22h
.end method

.method public final synchronized onLocationChanged(Landroid/location/Location;)V
    .registers 5
    monitor-enter v3
    iput-object v4, v3, Lcom/flurry/android/FlurryAgent;->R Landroid/location/Location;
    invoke-direct v3, Lcom/flurry/android/FlurryAgent;->m()V
    monitor-exit v3
    return-void
    move-exception v0
    const-string v1, "FlurryAgent"
    const-string v2, ""
    invoke-static v1, v2, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    goto -ah
    move-exception v0
    monitor-exit v3
    throw v0
.end method

.method public final onProviderDisabled(Ljava/lang/String;)V
    .registers 2
    return-void
.end method

.method public final onProviderEnabled(Ljava/lang/String;)V
    .registers 2
    return-void
.end method

.method public final onStatusChanged(Ljava/lang/String; I Landroid/os/Bundle;)V
    .registers 4
    return-void
.end method
