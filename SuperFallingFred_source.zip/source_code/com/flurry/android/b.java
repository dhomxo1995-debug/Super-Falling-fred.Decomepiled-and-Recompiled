package com.flurry.android;
final class b implements java.lang.Runnable {
    final synthetic android.content.Context a;
    final synthetic com.flurry.android.FlurryAgent b;
    private synthetic boolean c;

    b(com.flurry.android.FlurryAgent p1, boolean p2, android.content.Context p3)
    {
        this.b = p1;
        this.c = p2;
        this.a = p3;
        return;
    }

    public final void run()
    {
        com.flurry.android.FlurryAgent.b(this.b);
        com.flurry.android.FlurryAgent.c(this.b);
        if (!this.c) {
            com.flurry.android.FlurryAgent.d(this.b).postDelayed(new com.flurry.android.l(this), com.flurry.android.FlurryAgent.g());
        }
        if (com.flurry.android.FlurryAgent.h()) {
            com.flurry.android.FlurryAgent.e(this.b).d();
        }
        return;
    }
}
