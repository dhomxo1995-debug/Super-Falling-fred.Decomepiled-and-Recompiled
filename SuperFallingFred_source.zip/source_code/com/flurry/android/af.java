package com.flurry.android;
final class af {
    private java.util.LinkedHashMap a;
    private int b;

    af(int p4)
    {
        this.b = 50;
        this.a = new com.flurry.android.h(this, (((int) Math.ceil(((double) (((float) 50) / 1061158912)))) + 1), 1061158912);
        return;
    }

    static synthetic int a(com.flurry.android.af p1)
    {
        return p1.b;
    }

    final declared_synchronized int a()
    {
        try {
            return this.a.size();
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    final declared_synchronized Object a(Object p2)
    {
        try {
            return this.a.get(p2);
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    final declared_synchronized void a(Object p2, Object p3)
    {
        try {
            this.a.put(p2, p3);
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final declared_synchronized java.util.List b()
    {
        try {
            return new java.util.ArrayList(this.a.entrySet());
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    final declared_synchronized java.util.Set c()
    {
        try {
            return this.a.keySet();
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }
}
