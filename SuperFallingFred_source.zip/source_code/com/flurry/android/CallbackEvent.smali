.class public final Lcom/flurry/android/CallbackEvent;
.super Ljava/lang/Object;

.field public static final ADS_LOADED_FROM_CACHE:I
.field public static final ADS_UPDATED:I
.field public static final ERROR_MARKET_LAUNCH:I
.field private a:I
.field private b:J
.field private c:Ljava/lang/String;

.method constructor <init>(I)V
    .registers 4
    invoke-direct v2, Ljava/lang/Object;-><init>()V
    iput v3, v2, Lcom/flurry/android/CallbackEvent;->a I
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/flurry/android/CallbackEvent;->b J
    return-void
.end method

.method public final getMessage()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/CallbackEvent;->c Ljava/lang/String;
    return-object v0
.end method

.method public final getTimestamp()J
    .registers 3
    iget-wide v0, v2, Lcom/flurry/android/CallbackEvent;->b J
    return-wide v0
.end method

.method public final getType()I
    .registers 2
    iget v0, v1, Lcom/flurry/android/CallbackEvent;->a I
    return v0
.end method

.method public final setMessage(Ljava/lang/String;)V
    .registers 2
    iput-object v1, v0, Lcom/flurry/android/CallbackEvent;->c Ljava/lang/String;
    return-void
.end method

.method public final setTimestamp(J)V
    .registers 3
    iput-wide v1, v0, Lcom/flurry/android/CallbackEvent;->b J
    return-void
.end method
