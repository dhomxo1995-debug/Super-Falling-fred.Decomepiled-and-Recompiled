.class public interface abstract Lcom/flurry/android/AppCircleCallback;
.super Ljava/lang/Object;


.method public abstract onAdsUpdated(Lcom/flurry/android/CallbackEvent;)V
    # abstract or native method
.end method

.method public abstract onMarketAppLaunchError(Lcom/flurry/android/CallbackEvent;)V
    # abstract or native method
.end method
