.class final Lcom/flurry/android/al;
.super Lcom/flurry/android/aj;

.field  a:Ljava/lang/String;
.field  b:Ljava/lang/String;
.field  c:I

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/aj;-><init>()V
    return-void
.end method
