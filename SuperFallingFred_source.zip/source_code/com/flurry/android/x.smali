.class final Lcom/flurry/android/x;
.super Ljava/lang/Object;

.field  a:Lcom/flurry/android/p;
.field  b:Ljava/lang/String;
.field  c:Ljava/util/List;

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
