package com.flurry.android;
final class ae implements java.lang.Runnable {
    private synthetic String a;
    private synthetic com.flurry.android.u b;

    ae(com.flurry.android.u p1, String p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }

    public final void run()
    {
        com.flurry.android.CallbackEvent v0_1 = new com.flurry.android.CallbackEvent(101);
        v0_1.setMessage(this.a);
        com.flurry.android.u.a(this.b).onMarketAppLaunchError(v0_1);
        return;
    }
}
