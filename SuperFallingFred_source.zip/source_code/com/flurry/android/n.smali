.class final Lcom/flurry/android/n;
.super Ljava/lang/Object;
.implements Ljavax/net/ssl/X509TrustManager;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final checkClientTrusted([Ljava/security/cert/X509Certificate; Ljava/lang/String;)V
    .registers 3
    return-void
.end method

.method public final checkServerTrusted([Ljava/security/cert/X509Certificate; Ljava/lang/String;)V
    .registers 3
    return-void
.end method

.method public final getAcceptedIssuers()[Ljava/security/cert/X509Certificate;
    .registers 2
    const/4 v0, 0
    return-object v0
.end method
