package com.flurry.android;
final class e extends com.flurry.android.aj {
    String a;
    byte b;
    byte c;
    com.flurry.android.c d;

    e()
    {
        return;
    }

    e(java.io.DataInput p2)
    {
        this.a = p2.readUTF();
        this.b = p2.readByte();
        this.c = p2.readByte();
        return;
    }

    public final String toString()
    {
        return new StringBuilder().append("{name: ").append(this.a).append(", blockId: ").append(this.b).append(", themeId: ").append(this.c).toString();
    }
}
