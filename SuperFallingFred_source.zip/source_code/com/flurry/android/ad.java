package com.flurry.android;
final class ad implements java.lang.Runnable {
    private synthetic int a;
    private synthetic com.flurry.android.u b;

    ad(com.flurry.android.u p1, int p2)
    {
        this.b = p1;
        this.a = p2;
        return;
    }

    public final void run()
    {
        com.flurry.android.u.a(this.b).onAdsUpdated(new com.flurry.android.CallbackEvent(this.a));
        return;
    }
}
