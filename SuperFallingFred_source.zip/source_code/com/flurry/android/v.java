package com.flurry.android;
final class v extends com.flurry.android.aj {
    long a;
    long b;
    String c;
    String d;
    long e;
    Long f;
    byte[] g;
    com.flurry.android.AdImage h;

    v()
    {
        return;
    }

    v(java.io.DataInput p1)
    {
        this.b(p1);
        return;
    }

    private static String a(byte[] p4)
    {
        StringBuilder v1_1 = new StringBuilder();
        int v0_0 = 0;
        while (v0_0 < p4.length) {
            char v2_1 = ((p4[v0_0] >> 4) & 15);
            if (v2_1 >= 10) {
                v1_1.append(((char) ((v2_1 + 65) - 10)));
            } else {
                v1_1.append(((char) (v2_1 + 48)));
            }
            char v2_8 = (p4[v0_0] & 15);
            if (v2_8 >= 10) {
                v1_1.append(((char) ((v2_8 + 65) - 10)));
            } else {
                v1_1.append(((char) (v2_8 + 48)));
            }
            v0_0++;
        }
        return v1_1.toString();
    }

    private void b(java.io.DataInput p3)
    {
        this.a = p3.readLong();
        this.b = p3.readLong();
        this.d = p3.readUTF();
        this.c = p3.readUTF();
        this.e = p3.readLong();
        this.f = Long.valueOf(p3.readLong());
        byte[] v0_6 = new byte[p3.readUnsignedByte()];
        this.g = v0_6;
        p3.readFully(this.g);
        return;
    }

    final void a(java.io.DataInput p1)
    {
        this.b(p1);
        return;
    }

    public final String toString()
    {
        return new StringBuilder().append("ad {id=").append(this.a).append(", name=\'").append(this.d).append("\', cookie: \'").append(com.flurry.android.v.a(this.g)).append("\'}").toString();
    }
}
