.class final Lcom/flurry/android/d;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Landroid/content/Context;
.field private synthetic b:Z
.field private synthetic c:Lcom/flurry/android/FlurryAgent;

.method constructor <init>(Lcom/flurry/android/FlurryAgent; Landroid/content/Context; Z)V
    .registers 4
    iput-object v1, v0, Lcom/flurry/android/d;->c Lcom/flurry/android/FlurryAgent;
    iput-object v2, v0, Lcom/flurry/android/d;->a Landroid/content/Context;
    iput-boolean v3, v0, Lcom/flurry/android/d;->b Z
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    iget-object v0, v3, Lcom/flurry/android/d;->c Lcom/flurry/android/FlurryAgent;
    invoke-static v0, Lcom/flurry/android/FlurryAgent;->a(Lcom/flurry/android/FlurryAgent;)Z
    move-result v0
    if-nez v0, +009h
    iget-object v0, v3, Lcom/flurry/android/d;->c Lcom/flurry/android/FlurryAgent;
    iget-object v1, v3, Lcom/flurry/android/d;->a Landroid/content/Context;
    invoke-static v0, v1, Lcom/flurry/android/FlurryAgent;->a(Lcom/flurry/android/FlurryAgent; Landroid/content/Context;)V
    iget-object v0, v3, Lcom/flurry/android/d;->c Lcom/flurry/android/FlurryAgent;
    iget-object v1, v3, Lcom/flurry/android/d;->a Landroid/content/Context;
    iget-boolean v2, v3, Lcom/flurry/android/d;->b Z
    invoke-static v0, v1, v2, Lcom/flurry/android/FlurryAgent;->a(Lcom/flurry/android/FlurryAgent; Landroid/content/Context; Z)V
    return-void
.end method
