package com.flurry.android;
public final class InstallReceiver extends android.content.BroadcastReceiver {
    private final android.os.Handler a;
    private java.io.File b;

    private InstallReceiver()
    {
        this.b = 0;
        android.os.Looper v0_2 = new android.os.HandlerThread("InstallReceiver");
        v0_2.start();
        this.a = new android.os.Handler(v0_2.getLooper());
        return;
    }

    static synthetic java.io.File a(com.flurry.android.InstallReceiver p1)
    {
        return p1.b;
    }

    private static java.util.Map a(String p8)
    {
        if ((p8 != null) && (!p8.trim().equals(""))) {
            java.util.HashMap v2_2 = new java.util.HashMap();
            String[] v3 = p8.split("&");
            int v4 = v3.length;
            String v0_1 = 0;
            while (v0_1 < v4) {
                String v5_1 = v3[v0_1].split("=");
                if (v5_1.length == 2) {
                    v2_2.put(v5_1[0], v5_1[1]);
                } else {
                    com.flurry.android.ah.a("InstallReceiver", new StringBuilder().append("Invalid referrer Element: ").append(v3[v0_1]).append(" in referrer tag ").append(p8).toString());
                }
                v0_1++;
            }
            String v0_3 = new StringBuilder();
            if (v2_2.get("utm_source") == null) {
                v0_3.append("Campaign Source is missing.\n");
            }
            if (v2_2.get("utm_medium") == null) {
                v0_3.append("Campaign Medium is missing.\n");
            }
            if (v2_2.get("utm_campaign") == null) {
                v0_3.append("Campaign Name is missing.\n");
            }
            if (v0_3.length() <= 0) {
                return v2_2;
            } else {
                throw new IllegalArgumentException(v0_3.toString());
            }
        } else {
            throw new IllegalArgumentException("Referrer is null or empty");
        }
    }

    private declared_synchronized void a(java.util.Map p3)
    {
        try {
            this.a.post(new com.flurry.android.t(this, p3));
            return;
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    public final void onReceive(android.content.Context p5, android.content.Intent p6)
    {
        this.b = p5.getFileStreamPath(new StringBuilder().append(".flurryinstallreceiver.").append(Integer.toString(com.flurry.android.FlurryAgent.e().hashCode(), 16)).toString());
        if (com.flurry.android.FlurryAgent.isCaptureUncaughtExceptions()) {
            Thread.setDefaultUncaughtExceptionHandler(new com.flurry.android.FlurryAgent$FlurryDefaultExceptionHandler());
        }
        String v0_9 = p6.getStringExtra("referrer");
        if ((v0_9 != null) && ("com.android.vending.INSTALL_REFERRER".equals(p6.getAction()))) {
            try {
                this.a(com.flurry.android.InstallReceiver.a(v0_9));
            } catch (String v0_11) {
                com.flurry.android.ah.c("InstallReceiver", new StringBuilder().append("Invalid referrer Tag: ").append(v0_11.getMessage()).toString());
            }
        }
        return;
    }
}
