package com.flurry.android;
final class y extends android.widget.RelativeLayout {
    private com.flurry.android.u a;
    private com.flurry.android.p b;
    private String c;
    private int d;

    public y(android.content.Context p5, com.flurry.android.u p6, com.flurry.android.p p7, com.flurry.android.e p8, int p9, boolean p10)
    {
        super(p5);
        super.a = p6;
        super.b = p7;
        com.flurry.android.v v0 = p7.b;
        super.d = p9;
        switch (super.d) {
            case 1:
                if (!p10) {
                    super.a(p5, p8, v0, 1);
                } else {
                    super.a(p5, p8, v0, 0);
                }
                break;
            case 2:
                if (!p10) {
                    super.a(p5, p8, v0, 1);
                } else {
                    super.a(p5, p8, v0, 0);
                }
                break;
        }
        super.setFocusable(1);
        return;
    }

    private void a(android.content.Context p15, com.flurry.android.e p16, com.flurry.android.v p17, boolean p18)
    {
        this.setLayoutParams(new android.widget.RelativeLayout$LayoutParams(-1, -1));
        android.widget.RelativeLayout$LayoutParams v3_6 = p16.d;
        int v4_4 = new android.widget.ImageView(p15);
        v4_4.setId(1);
        android.widget.ImageView$ScaleType v1_3 = p17.h;
        if (v1_3 != null) {
            android.widget.ImageView$ScaleType v1_13 = v1_3.e;
            int v5_14 = android.graphics.BitmapFactory.decodeByteArray(v1_13, 0, v1_13.length);
            if (v5_14 == 0) {
                com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Ad with bad image: ").append(p17.d).append(", data: ").append(v1_13).toString());
            }
            if (v5_14 != 0) {
                android.widget.ImageView$ScaleType v1_26;
                int v2_12 = android.graphics.Bitmap.createBitmap(v5_14.getWidth(), v5_14.getHeight(), android.graphics.Bitmap$Config.ARGB_8888);
                android.widget.ImageView$ScaleType v1_23 = new android.graphics.Canvas(v2_12);
                int v6_38 = new android.graphics.Paint();
                int v7_20 = new android.graphics.Rect(0, 0, v5_14.getWidth(), v5_14.getHeight());
                int v8_9 = new android.graphics.RectF(v7_20);
                int v9_4 = ((float) com.flurry.android.r.a(p15, 8));
                v6_38.setAntiAlias(1);
                v1_23.drawARGB(0, 0, 0, 0);
                v6_38.setColor(-16777216);
                v1_23.drawRoundRect(v8_9, v9_4, v9_4, v6_38);
                v6_38.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff$Mode.SRC_IN));
                v1_23.drawBitmap(v5_14, v7_20, v7_20, v6_38);
                if (Integer.parseInt(android.os.Build$VERSION.SDK) <= 4) {
                    v1_26 = v2_12;
                } else {
                    android.widget.ImageView$ScaleType v1_28 = new android.graphics.BlurMaskFilter(1077936128, android.graphics.BlurMaskFilter$Blur.OUTER);
                    int v5_54 = new android.graphics.Paint();
                    v5_54.setMaskFilter(v1_28);
                    int v6_40 = new int[2];
                    v1_26 = v2_12.extractAlpha(v5_54, v6_40).copy(android.graphics.Bitmap$Config.ARGB_8888, 1);
                    new android.graphics.Canvas(v1_26).drawBitmap(v2_12, ((float) (- v6_40[0])), ((float) (- v6_40[1])), 0);
                }
                v4_4.setImageBitmap(v1_26);
                com.flurry.android.r.a(p15, v4_4, com.flurry.android.r.a(p15, v3_6.m), com.flurry.android.r.a(p15, v3_6.n));
                v4_4.setScaleType(android.widget.ImageView$ScaleType.FIT_XY);
            }
        }
        android.widget.ImageView$ScaleType v1_6 = this.a.a(v3_6.c);
        if (v1_6 != null) {
            android.widget.ImageView$ScaleType v1_11;
            android.widget.ImageView$ScaleType v1_7 = v1_6.e;
            int v2_4 = android.graphics.BitmapFactory.decodeByteArray(v1_7, 0, v1_7.length);
            if (!android.graphics.NinePatch.isNinePatchChunk(v2_4.getNinePatchChunk())) {
                v1_11 = new android.graphics.drawable.BitmapDrawable(v2_4);
            } else {
                v1_11 = new android.graphics.drawable.NinePatchDrawable(v2_4, v2_4.getNinePatchChunk(), new android.graphics.Rect(0, 0, 0, 0), 0);
            }
            this.setBackgroundDrawable(v1_11);
        }
        android.widget.ImageView$ScaleType v1_15 = new android.widget.TextView(p15);
        v1_15.setId(5);
        v1_15.setPadding(0, 0, 0, 0);
        int v2_9 = new android.widget.TextView(p15);
        v2_9.setId(3);
        v2_9.setPadding(0, 0, 0, 0);
        if (!p18) {
            v1_15.setId(3);
            v1_15.setText(p17.d);
            v1_15.setTextColor(v3_6.i);
            v1_15.setTextSize(((float) v3_6.h));
            v1_15.setTypeface(android.graphics.Typeface.create(v3_6.g, 0));
            v2_9.setId(4);
            v2_9.setText(p17.c);
            v2_9.setTextColor(v3_6.l);
            v2_9.setTextSize(((float) v3_6.k));
            v2_9.setTypeface(android.graphics.Typeface.create(v3_6.j, 0));
        } else {
            v1_15.setTextColor(v3_6.f);
            v1_15.setTextSize(((float) v3_6.e));
            v1_15.setText(new String(new StringBuilder().append("\u2022 ").append(v3_6.b).toString()));
            v1_15.setTypeface(android.graphics.Typeface.create(v3_6.d, 0));
            v2_9.setTextColor(v3_6.i);
            v2_9.setTextSize(((float) v3_6.h));
            v2_9.setTypeface(android.graphics.Typeface.create(v3_6.g, 0));
            v2_9.setText(p17.d);
        }
        this.setLayoutParams(new android.view.ViewGroup$LayoutParams(-2, -2));
        this.addView(new android.widget.ImageView(p15), new android.widget.RelativeLayout$LayoutParams(-1, -2));
        int v5_43 = ((v3_6.q - (v3_6.o << 1)) - v3_6.m);
        int v6_27 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
        v6_27.addRule(9);
        v6_27.setMargins(v3_6.o, v3_6.p, v5_43, 0);
        this.addView(v4_4, v6_27);
        android.widget.RelativeLayout$LayoutParams v3_3 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
        v3_3.addRule(6, v4_4.getId());
        v3_3.addRule(1, v4_4.getId());
        v3_3.setMargins(0, 0, 0, 0);
        this.addView(v1_15, v3_3);
        android.widget.RelativeLayout$LayoutParams v3_5 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
        v3_5.addRule(1, v4_4.getId());
        v3_5.addRule(3, v1_15.getId());
        v3_5.setMargins(0, -2, 0, 0);
        this.addView(v2_9, v3_5);
        return;
    }

    final com.flurry.android.p a()
    {
        return this.b;
    }

    final void a(String p1)
    {
        this.c = p1;
        return;
    }

    final String b(String p4)
    {
        return new StringBuilder().append(p4).append(this.c).append(System.currentTimeMillis()).toString();
    }
}
