.class final Lcom/flurry/android/ah;
.super Ljava/lang/Object;

.field private static a:Z
.field private static b:I

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/flurry/android/ah;->a Z
    const/4 v0, 5
    sput v0, Lcom/flurry/android/ah;->b I
    return-void
.end method

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method static a(Ljava/lang/String; Ljava/lang/String;)I
    .registers 4
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 3
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    move-result v0
    goto -5h
.end method

.method static a(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    .registers 5
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 3
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, v4, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    move-result v0
    goto -5h
.end method

.method static a()V
    .registers 1
    const/4 v0, 1
    sput-boolean v0, Lcom/flurry/android/ah;->a Z
    return-void
.end method

.method static a(I)V
    .registers 1
    sput v0, Lcom/flurry/android/ah;->b I
    return-void
.end method

.method static a(Ljava/lang/String;)Z
    .registers 2
    const/4 v0, 3
    invoke-static v1, v0, Landroid/util/Log;->isLoggable(Ljava/lang/String; I)Z
    move-result v0
    return v0
.end method

.method static b(Ljava/lang/String; Ljava/lang/String;)I
    .registers 4
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 6
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String;)I
    move-result v0
    goto -5h
.end method

.method static b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    .registers 5
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 6
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, v4, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    move-result v0
    goto -5h
.end method

.method static b()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/flurry/android/ah;->a Z
    return-void
.end method

.method static c(Ljava/lang/String; Ljava/lang/String;)I
    .registers 4
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 4
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    move-result v0
    goto -5h
.end method

.method static c(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    .registers 5
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 4
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, v4, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    move-result v0
    goto -5h
.end method

.method static d(Ljava/lang/String; Ljava/lang/String;)I
    .registers 4
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 5
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, Landroid/util/Log;->w(Ljava/lang/String; Ljava/lang/String;)I
    move-result v0
    goto -5h
.end method

.method static d(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    .registers 5
    sget-boolean v0, Lcom/flurry/android/ah;->a Z
    if-nez v0, +007h
    sget v0, Lcom/flurry/android/ah;->b I
    const/4 v1, 5
    if-gt v0, v1, +004h
    const/4 v0, 0
    return v0
    invoke-static v2, v3, v4, Landroid/util/Log;->w(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    move-result v0
    goto -5h
.end method
