.class final Lcom/flurry/android/i;
.super Ljava/lang/Object;

.field private a:Ljava/lang/String;
.field private b:Ljava/util/Map;
.field private c:J
.field private d:Z
.field private e:J
.field private f:[B

.method public constructor <init>(Ljava/lang/String; Ljava/util/Map; J Z)V
    .registers 6
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-object v1, v0, Lcom/flurry/android/i;->a Ljava/lang/String;
    iput-object v2, v0, Lcom/flurry/android/i;->b Ljava/util/Map;
    iput-wide v3, v0, Lcom/flurry/android/i;->c J
    iput-boolean v5, v0, Lcom/flurry/android/i;->d Z
    return-void
.end method

.method public final a()V
    .registers 5
    invoke-static Landroid/os/SystemClock;->elapsedRealtime()J
    move-result-wide v0
    iget-wide v2, v4, Lcom/flurry/android/i;->c J
    sub-long/2addr v0, v2
    iput-wide v0, v4, Lcom/flurry/android/i;->e J
    return-void
.end method

.method public final a(Ljava/lang/String;)Z
    .registers 6
    iget-boolean v0, v4, Lcom/flurry/android/i;->d Z
    if-eqz v0, +014h
    iget-wide v0, v4, Lcom/flurry/android/i;->e J
    const-wide/16 v2, 0
    cmp-long v0, v0, v2
    if-nez v0, +00ch
    iget-object v0, v4, Lcom/flurry/android/i;->a Ljava/lang/String;
    invoke-virtual v0, v5, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public final b()[B
    .registers 7
    iget-object v0, v6, Lcom/flurry/android/i;->f [B
    if-nez v0, +030h
    const/4 v0, 0
    new-instance v3, Ljava/io/ByteArrayOutputStream;
    invoke-direct v3, Ljava/io/ByteArrayOutputStream;-><init>()V
    new-instance v2, Ljava/io/DataOutputStream;
    invoke-direct v2, v3, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    iget-object v0, v6, Lcom/flurry/android/i;->a Ljava/lang/String;
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    iget-object v0, v6, Lcom/flurry/android/i;->b Ljava/util/Map;
    if-nez v0, +01fh
    const/4 v0, 0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-wide v0, v6, Lcom/flurry/android/i;->c J
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-wide v0, v6, Lcom/flurry/android/i;->e J
    invoke-virtual v2, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    invoke-virtual v2, Ljava/io/DataOutputStream;->flush()V
    invoke-virtual v3, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v0
    iput-object v0, v6, Lcom/flurry/android/i;->f [B
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    iget-object v0, v6, Lcom/flurry/android/i;->f [B
    return-object v0
    iget-object v0, v6, Lcom/flurry/android/i;->b Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v6, Lcom/flurry/android/i;->b Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, -030h
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    const/16 v5, 255
    invoke-static v1, v5, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v2, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    const/16 v1, 255
    invoke-static v0, v1, Lcom/flurry/android/r;->a(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    goto -2ah
    move-exception v0
    move-object v0, v2
    const/4 v1, 0
    new-array v1, v1, [B
    iput-object v1, v6, Lcom/flurry/android/i;->f [B
    invoke-static v0, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -4bh
    move-exception v1
    move-object v2, v0
    move-object v0, v1
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    goto -5h
    move-exception v1
    move-object v2, v0
    move-object v0, v1
    goto -9h
    move-exception v1
    goto -17h
.end method
