package com.flurry.android;
public final class Offer {
    private long a;
    private String b;
    private String c;
    private int d;
    private com.flurry.android.AdImage e;

    Offer(long p1, com.flurry.android.AdImage p3, String p4, String p5, int p6)
    {
        this.a = p1;
        this.b = p4;
        this.e = p3;
        this.c = p5;
        this.d = p6;
        return;
    }

    public final String getDescription()
    {
        return this.c;
    }

    public final long getId()
    {
        return this.a;
    }

    public final com.flurry.android.AdImage getImage()
    {
        return this.e;
    }

    public final String getName()
    {
        return this.b;
    }

    public final int getPrice()
    {
        return this.d;
    }

    public final String getUrl()
    {
        return "";
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder();
        v0_1.append(new StringBuilder().append("[id=").append(this.a).append(",name=").append(this.b).append(",price=").append(this.d).append(", image size: ").append(this.e.e.length).toString());
        return v0_1.toString();
    }
}
