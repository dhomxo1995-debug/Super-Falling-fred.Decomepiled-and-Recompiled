.class public final Lcom/flurry/android/InstallReceiver;
.super Landroid/content/BroadcastReceiver;

.field private final a:Landroid/os/Handler;
.field private b:Ljava/io/File;

.method private constructor <init>()V
    .registers 3
    invoke-direct v2, Landroid/content/BroadcastReceiver;-><init>()V
    const/4 v0, 0
    iput-object v0, v2, Lcom/flurry/android/InstallReceiver;->b Ljava/io/File;
    new-instance v0, Landroid/os/HandlerThread;
    const-string v1, "InstallReceiver"
    invoke-direct v0, v1, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, Landroid/os/HandlerThread;->start()V
    new-instance v1, Landroid/os/Handler;
    invoke-virtual v0, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;
    move-result-object v0
    invoke-direct v1, v0, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    iput-object v1, v2, Lcom/flurry/android/InstallReceiver;->a Landroid/os/Handler;
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/InstallReceiver;)Ljava/io/File;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/InstallReceiver;->b Ljava/io/File;
    return-object v0
.end method

.method private static a(Ljava/lang/String;)Ljava/util/Map;
    .registers 9
    const/4 v1, 0
    if-eqz v8, +00eh
    invoke-virtual v8, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object v0
    const-string v2, ""
    invoke-virtual v0, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "Referrer is null or empty"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    new-instance v2, Ljava/util/HashMap;
    invoke-direct v2, Ljava/util/HashMap;-><init>()V
    const-string v0, "&"
    invoke-virtual v8, v0, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    move-result-object v3
    array-length v4, v3
    move v0, v1
    if-ge v0, v4, +03eh
    aget-object v5, v3, v0
    const-string v6, "="
    invoke-virtual v5, v6, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    move-result-object v5
    array-length v6, v5
    const/4 v7, 2
    if-eq v6, v7, +029h
    const-string v5, "InstallReceiver"
    new-instance v6, Ljava/lang/StringBuilder;
    invoke-direct v6, Ljava/lang/StringBuilder;-><init>()V
    const-string v7, "Invalid referrer Element: "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    aget-object v7, v3, v0
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    const-string v7, " in referrer tag "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v6
    invoke-static v5, v6, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    add-int/lit8 v0, v0, 1
    goto -34h
    aget-object v6, v5, v1
    const/4 v7, 1
    aget-object v5, v5, v7
    invoke-interface v2, v6, v5, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -bh
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "utm_source"
    invoke-interface v2, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    if-nez v1, +007h
    const-string v1, "Campaign Source is missing.
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, "utm_medium"
    invoke-interface v2, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    if-nez v1, +007h
    const-string v1, "Campaign Medium is missing.
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, "utm_campaign"
    invoke-interface v2, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    if-nez v1, +007h
    const-string v1, "Campaign Name is missing.
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v0, Ljava/lang/StringBuilder;->length()I
    move-result v1
    if-lez v1, +00ch
    new-instance v1, Ljava/lang/IllegalArgumentException;
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-direct v1, v0, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v1
    return-object v2
.end method

.method private synchronized a(Ljava/util/Map;)V
    .registers 4
    monitor-enter v2
    new-instance v0, Lcom/flurry/android/t;
    invoke-direct v0, v2, v3, Lcom/flurry/android/t;-><init>(Lcom/flurry/android/InstallReceiver; Ljava/util/Map;)V
    iget-object v1, v2, Lcom/flurry/android/InstallReceiver;->a Landroid/os/Handler;
    invoke-virtual v1, v0, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    monitor-exit v2
    return-void
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method public final onReceive(Landroid/content/Context; Landroid/content/Intent;)V
    .registers 7
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, ".flurryinstallreceiver."
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static Lcom/flurry/android/FlurryAgent;->e()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/String;->hashCode()I
    move-result v1
    const/16 v2, 16
    invoke-static v1, v2, Ljava/lang/Integer;->toString(I I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v5, v0, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v0
    iput-object v0, v4, Lcom/flurry/android/InstallReceiver;->b Ljava/io/File;
    invoke-static Lcom/flurry/android/FlurryAgent;->isCaptureUncaughtExceptions()Z
    move-result v0
    if-eqz v0, +00ah
    new-instance v0, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;
    invoke-direct v0, Lcom/flurry/android/FlurryAgent$FlurryDefaultExceptionHandler;-><init>()V
    invoke-static v0, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V
    const-string v0, "referrer"
    invoke-virtual v6, v0, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +00eh
    const-string v1, "com.android.vending.INSTALL_REFERRER"
    invoke-virtual v6, Landroid/content/Intent;->getAction()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v1
    if-nez v1, +003h
    return-void
    invoke-static v0, Lcom/flurry/android/InstallReceiver;->a(Ljava/lang/String;)Ljava/util/Map;
    move-result-object v0
    invoke-direct v4, v0, Lcom/flurry/android/InstallReceiver;->a(Ljava/util/Map;)V
    goto -8h
    move-exception v0
    const-string v1, "InstallReceiver"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Invalid referrer Tag: "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v0, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    goto -26h
.end method
