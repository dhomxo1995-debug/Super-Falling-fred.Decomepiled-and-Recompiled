.class final Lcom/flurry/android/ad;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:Lcom/flurry/android/u;

.method constructor <init>(Lcom/flurry/android/u; I)V
    .registers 3
    iput-object v1, v0, Lcom/flurry/android/ad;->b Lcom/flurry/android/u;
    iput v2, v0, Lcom/flurry/android/ad;->a I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    new-instance v0, Lcom/flurry/android/CallbackEvent;
    iget v1, v2, Lcom/flurry/android/ad;->a I
    invoke-direct v0, v1, Lcom/flurry/android/CallbackEvent;-><init>(I)V
    iget-object v1, v2, Lcom/flurry/android/ad;->b Lcom/flurry/android/u;
    invoke-static v1, Lcom/flurry/android/u;->a(Lcom/flurry/android/u;)Lcom/flurry/android/AppCircleCallback;
    move-result-object v1
    invoke-interface v1, v0, Lcom/flurry/android/AppCircleCallback;->onAdsUpdated(Lcom/flurry/android/CallbackEvent;)V
    return-void
.end method
