package com.flurry.android;
final class z {
    private android.content.Context a;
    private com.flurry.android.u b;
    private com.flurry.android.a c;
    private volatile long d;
    private com.flurry.android.af e;
    private com.flurry.android.af f;
    private java.util.Map g;
    private java.util.Map h;
    private java.util.Map i;
    private java.util.Map j;
    private volatile boolean k;

    z()
    {
        this.e = new com.flurry.android.af(50);
        this.f = new com.flurry.android.af(50);
        this.g = new java.util.HashMap();
        this.h = new java.util.HashMap();
        this.i = new java.util.HashMap();
        this.j = new java.util.HashMap();
        return;
    }

    private declared_synchronized com.flurry.android.c a(byte p3)
    {
        try {
            return ((com.flurry.android.c) this.i.get(Byte.valueOf(p3)));
        } catch (Throwable v0_3) {
            throw v0_3;
        }
    }

    private void a(int p2)
    {
        com.flurry.android.u v0_2;
        if (this.g.isEmpty()) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        this.k = v0_2;
        if (this.k) {
            this.b.a(p2);
        }
        return;
    }

    private void a(java.io.DataInputStream p9)
    {
        String v0_0 = 0;
        com.flurry.android.ah.a("FlurryAgent", "Reading cache");
        if (p9.readUnsignedShort() == 2) {
            this.d = p9.readLong();
            int v2_0 = p9.readUnsignedShort();
            this.e = new com.flurry.android.af(50);
            String v1_5 = 0;
            while (v1_5 < v2_0) {
                Long v3_3 = p9.readLong();
                java.util.Map v5_4 = new com.flurry.android.AdImage();
                v5_4.a(p9);
                this.e.a(Long.valueOf(v3_3), v5_4);
                v1_5++;
            }
            int v2_1 = p9.readUnsignedShort();
            this.f = new com.flurry.android.af(50);
            String v1_3 = 0;
            while (v1_3 < v2_1) {
                Long v3_1 = p9.readLong();
                java.util.Map v5_2 = new com.flurry.android.al();
                if (p9.readBoolean()) {
                    v5_2.a = p9.readUTF();
                }
                if (p9.readBoolean()) {
                    v5_2.b = p9.readUTF();
                }
                v5_2.c = p9.readInt();
                this.f.a(Long.valueOf(v3_1), v5_2);
                v1_3++;
            }
            int v2_2 = p9.readUnsignedShort();
            this.h = new java.util.HashMap(v2_2);
            String v1_2 = 0;
            while (v1_2 < v2_2) {
                this.h.put(p9.readUTF(), new com.flurry.android.e(p9));
                v1_2++;
            }
            Long v3_5 = p9.readUnsignedShort();
            this.g = new java.util.HashMap(v3_5);
            int v2_4 = 0;
            while (v2_4 < v3_5) {
                com.flurry.android.c v4_4 = p9.readUTF();
                java.util.Map v5_7 = p9.readUnsignedShort();
                com.flurry.android.v[] v6_7 = new com.flurry.android.v[v5_7];
                String v1_1 = 0;
                while (v1_1 < v5_7) {
                    com.flurry.android.v v7_2 = new com.flurry.android.v();
                    v7_2.a(p9);
                    v6_7[v1_1] = v7_2;
                    v1_1++;
                }
                this.g.put(v4_4, v6_7);
                v2_4++;
            }
            int v2_5 = p9.readUnsignedShort();
            this.i = new java.util.HashMap();
            String v1_16 = 0;
            while (v1_16 < v2_5) {
                Long v3_8 = p9.readByte();
                com.flurry.android.c v4_3 = new com.flurry.android.c();
                v4_3.b(p9);
                this.i.put(Byte.valueOf(v3_8), v4_3);
                v1_16++;
            }
            String v1_17 = p9.readUnsignedShort();
            this.j = new java.util.HashMap(v1_17);
            while (v0_0 < v1_17) {
                this.j.put(Short.valueOf(p9.readShort()), Long.valueOf(p9.readLong()));
                v0_0++;
            }
            this.f();
            com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Cache read, num images: ").append(this.e.a()).toString());
        }
        return;
    }

    private void a(java.io.DataOutputStream p9)
    {
        p9.writeShort(2);
        p9.writeLong(this.d);
        long v0_51 = this.e.b();
        p9.writeShort(v0_51.size());
        java.util.Iterator v4_0 = v0_51.iterator();
        while (v4_0.hasNext()) {
            long v0_22 = ((java.util.Map$Entry) v4_0.next());
            p9.writeLong(((Long) v0_22.getKey()).longValue());
            long v0_25 = ((com.flurry.android.AdImage) v0_22.getValue());
            p9.writeLong(v0_25.a);
            p9.writeInt(v0_25.b);
            p9.writeInt(v0_25.c);
            p9.writeUTF(v0_25.d);
            p9.writeInt(v0_25.e.length);
            p9.write(v0_25.e);
        }
        long v0_20 = this.f.b();
        p9.writeShort(v0_20.size());
        java.util.Iterator v4_1 = v0_20.iterator();
        while (v4_1.hasNext()) {
            java.util.Map$Entry v1_12;
            java.util.Map$Entry v1_10 = ((java.util.Map$Entry) v4_1.next());
            p9.writeLong(((Long) v1_10.getKey()).longValue());
            long v0_18 = ((com.flurry.android.al) v1_10.getValue());
            if (v0_18.a == null) {
                v1_12 = 0;
            } else {
                v1_12 = 1;
            }
            p9.writeBoolean(v1_12);
            if (v1_12 != null) {
                p9.writeUTF(v0_18.a);
            }
            java.util.Map$Entry v1_15;
            if (v0_18.b == null) {
                v1_15 = 0;
            } else {
                v1_15 = 1;
            }
            p9.writeBoolean(v1_15);
            if (v1_15 != null) {
                p9.writeUTF(v0_18.b);
            }
            p9.writeInt(v0_18.c);
        }
        p9.writeShort(this.h.size());
        int v2_2 = this.h.entrySet().iterator();
        while (v2_2.hasNext()) {
            java.util.Map$Entry v1_6 = ((java.util.Map$Entry) v2_2.next());
            p9.writeUTF(((String) v1_6.getKey()));
            long v0_11 = ((com.flurry.android.e) v1_6.getValue());
            p9.writeUTF(v0_11.a);
            p9.writeByte(v0_11.b);
            p9.writeByte(v0_11.c);
        }
        p9.writeShort(this.g.size());
        java.util.Iterator v4_2 = this.g.entrySet().iterator();
        while (v4_2.hasNext()) {
            java.util.Map$Entry v1_4;
            long v0_3 = ((java.util.Map$Entry) v4_2.next());
            p9.writeUTF(((String) v0_3.getKey()));
            long v0_5 = ((com.flurry.android.v[]) v0_3.getValue());
            if (v0_5 != 0) {
                v1_4 = v0_5.length;
            } else {
                v1_4 = 0;
            }
            p9.writeShort(v1_4);
            int v2_1 = 0;
            while (v2_1 < v1_4) {
                byte[] v5_0 = v0_5[v2_1];
                p9.writeLong(v5_0.a);
                p9.writeLong(v5_0.b);
                p9.writeUTF(v5_0.d);
                p9.writeUTF(v5_0.c);
                p9.writeLong(v5_0.e);
                p9.writeLong(v5_0.f.longValue());
                p9.writeByte(v5_0.g.length);
                p9.write(v5_0.g);
                v2_1++;
            }
        }
        p9.writeShort(this.i.size());
        int v2_3 = this.i.entrySet().iterator();
        while (v2_3.hasNext()) {
            long v0_59 = ((java.util.Map$Entry) v2_3.next());
            p9.writeByte(((Byte) v0_59.getKey()).byteValue());
            ((com.flurry.android.c) v0_59.getValue()).a(p9);
        }
        p9.writeShort(this.j.size());
        int v2_4 = this.j.entrySet().iterator();
        while (v2_4.hasNext()) {
            java.util.Map$Entry v1_26 = ((java.util.Map$Entry) v2_4.next());
            p9.writeShort(((Short) v1_26.getKey()).shortValue());
            p9.writeLong(((Long) v1_26.getValue()).longValue());
        }
        return;
    }

    private static void a(java.io.File p2)
    {
        if (!p2.delete()) {
            com.flurry.android.ah.b("FlurryAgent", "Cannot delete cached ads");
        }
        return;
    }

    private void f()
    {
        String v0_9 = this.i.values().iterator();
        while (v0_9.hasNext()) {
            v0_9.next();
        }
        String v2_0 = this.g.values().iterator();
        while (v2_0.hasNext()) {
            String v0_14 = ((com.flurry.android.v[]) v2_0.next());
            if (v0_14 != null) {
                StringBuilder v3_3 = v0_14.length;
                int v1_1 = 0;
                while (v1_1 < v3_3) {
                    String v4_1 = v0_14[v1_1];
                    v4_1.h = this.b(v4_1.f.longValue());
                    if (v4_1.h == null) {
                        com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Ad ").append(v4_1.d).append(" has no image").toString());
                    }
                    if (this.a(v4_1.a) == null) {
                        com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Ad ").append(v4_1.d).append(" has no pricing").toString());
                    }
                    v1_1++;
                }
            }
        }
        int v1_0 = this.h.values().iterator();
        while (v1_0.hasNext()) {
            String v0_8 = ((com.flurry.android.e) v1_0.next());
            v0_8.d = this.a(v0_8.c);
            if (v0_8.d == null) {
                com.flurry.android.ah.d("FlurryAgent", new StringBuilder().append("No ad theme found for ").append(v0_8.c).toString());
            }
        }
        return;
    }

    private String g()
    {
        return new StringBuilder().append(".flurryappcircle.").append(Integer.toString(this.c.a.hashCode(), 16)).toString();
    }

    final declared_synchronized com.flurry.android.AdImage a(short p3)
    {
        try {
            com.flurry.android.AdImage v0_1;
            com.flurry.android.AdImage v0_4 = ((Long) this.j.get(Short.valueOf(1)));
        } catch (com.flurry.android.AdImage v0_2) {
            throw v0_2;
        }
        if (v0_4 != null) {
            v0_1 = this.b(v0_4.longValue());
        } else {
            v0_1 = 0;
        }
        return v0_1;
    }

    final declared_synchronized com.flurry.android.al a(long p3)
    {
        try {
            return ((com.flurry.android.al) this.f.a(Long.valueOf(p3)));
        } catch (Throwable v0_3) {
            throw v0_3;
        }
    }

    final declared_synchronized java.util.Set a()
    {
        try {
            return this.e.c();
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    final void a(android.content.Context p1, com.flurry.android.u p2, com.flurry.android.a p3)
    {
        this.a = p1;
        this.b = p2;
        this.c = p3;
        return;
    }

    final declared_synchronized void a(java.util.Map p6, java.util.Map p7, java.util.Map p8, java.util.Map p9, java.util.Map p10, java.util.Map p11)
    {
        try {
            this.d = System.currentTimeMillis();
            com.flurry.android.e v1_3 = p9.entrySet().iterator();
        } catch (com.flurry.android.c v0_25) {
            throw v0_25;
        }
        while (v1_3.hasNext()) {
            com.flurry.android.c v0_24 = ((java.util.Map$Entry) v1_3.next());
            if (v0_24.getValue() != null) {
                this.e.a(v0_24.getKey(), v0_24.getValue());
            }
        }
        com.flurry.android.e v1_0 = p10.entrySet().iterator();
        while (v1_0.hasNext()) {
            com.flurry.android.c v0_20 = ((java.util.Map$Entry) v1_0.next());
            if (v0_20.getValue() != null) {
                this.f.a(v0_20.getKey(), v0_20.getValue());
            }
        }
        if ((p7 != null) && (!p7.isEmpty())) {
            this.h = p7;
        }
        if ((p8 != null) && (!p8.isEmpty())) {
            this.i = p8;
        }
        if ((p11 != null) && (!p11.isEmpty())) {
            this.j = p11;
        }
        this.g = new java.util.HashMap();
        java.util.Iterator v3_0 = p7.entrySet().iterator();
        while (v3_0.hasNext()) {
            com.flurry.android.c v0_13 = ((java.util.Map$Entry) v3_0.next());
            com.flurry.android.e v1_2 = ((com.flurry.android.e) v0_13.getValue());
            com.flurry.android.v[] v2_3 = ((com.flurry.android.v[]) p6.get(Byte.valueOf(v1_2.b)));
            if (v2_3 != null) {
                this.g.put(v0_13.getKey(), v2_3);
            }
            com.flurry.android.c v0_18 = ((com.flurry.android.c) p8.get(Byte.valueOf(v1_2.c)));
            if (v0_18 != null) {
                v1_2.d = v0_18;
            }
        }
        this.f();
        this.a(202);
        return;
    }

    final declared_synchronized com.flurry.android.v[] a(String p3)
    {
        try {
            com.flurry.android.v[] v0_3 = ((com.flurry.android.v[]) this.g.get(p3));
        } catch (com.flurry.android.v[] v0_1) {
            throw v0_1;
        }
        if (v0_3 == null) {
            v0_3 = ((com.flurry.android.v[]) this.g.get(""));
        }
        return v0_3;
    }

    final declared_synchronized com.flurry.android.AdImage b(long p3)
    {
        try {
            return ((com.flurry.android.AdImage) this.e.a(Long.valueOf(p3)));
        } catch (Throwable v0_3) {
            throw v0_3;
        }
    }

    final declared_synchronized com.flurry.android.e b(String p3)
    {
        try {
            com.flurry.android.e v0_3 = ((com.flurry.android.e) this.h.get(p3));
        } catch (com.flurry.android.e v0_1) {
            throw v0_1;
        }
        if (v0_3 == null) {
            v0_3 = ((com.flurry.android.e) this.h.get(""));
        }
        return v0_3;
    }

    final boolean b()
    {
        return this.k;
    }

    final long c()
    {
        return this.d;
    }

    final declared_synchronized void d()
    {
        try {
            java.io.File v3 = this.a.getFileStreamPath(this.g());
        } catch (int v0_7) {
            throw v0_7;
        }
        if (!v3.exists()) {
            com.flurry.android.ah.c("FlurryAgent", new StringBuilder().append("cache file does not exist, path=").append(v3.getAbsolutePath()).toString());
        } else {
            try {
                String v1_6 = new java.io.DataInputStream(new java.io.FileInputStream(v3));
                try {
                    if (v1_6.readUnsignedShort() != 46587) {
                        com.flurry.android.z.a(v3);
                    } else {
                        this.a(v1_6);
                        this.a(201);
                    }
                } catch (int v0_4) {
                    com.flurry.android.ah.a("FlurryAgent", "Discarding cache", v0_4);
                    com.flurry.android.z.a(v3);
                    com.flurry.android.r.a(v1_6);
                }
                com.flurry.android.r.a(v1_6);
            } catch (int v0_4) {
                v1_6 = 0;
            } catch (int v0_3) {
                v1_6 = 0;
                com.flurry.android.r.a(v1_6);
                throw v0_3;
            } catch (int v0_3) {
            }
        }
        return;
    }

    final declared_synchronized void e()
    {
        String v1 = 0;
        try {
            Throwable v0_7 = this.a.getFileStreamPath(this.g());
            String v2_6 = v0_7.getParentFile();
        } catch (Throwable v0_2) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_2);
            com.flurry.android.r.a(v1);
            return;
        } catch (Throwable v0_6) {
            throw v0_6;
        }
        if ((v2_6.mkdirs()) || (v2_6.exists())) {
            String v2_1 = new java.io.DataOutputStream(new java.io.FileOutputStream(v0_7));
            try {
                v2_1.writeShort(46587);
                this.a(v2_1);
            } catch (Throwable v0_2) {
                v1 = v2_1;
            } catch (Throwable v0_3) {
                v1 = v2_1;
                com.flurry.android.r.a(v1);
                throw v0_3;
            }
            com.flurry.android.r.a(v2_1);
            return;
        } else {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Unable to create persistent dir: ").append(v2_6).toString());
            com.flurry.android.r.a(0);
            return;
        }
    }

    public final String toString()
    {
        StringBuilder v2_1 = new StringBuilder();
        v2_1.append("{");
        v2_1.append(new StringBuilder().append("adImages (").append(this.e.b().size()).append("),\n").toString());
        v2_1.append(new StringBuilder().append("adBlock (").append(this.g.size()).append("):").toString()).append(",\n");
        java.util.Iterator v3 = this.g.entrySet().iterator();
        while (v3.hasNext()) {
            String v0_8 = ((java.util.Map$Entry) v3.next());
            v2_1.append(new StringBuilder().append("\t").append(((String) v0_8.getKey())).append(": ").append(java.util.Arrays.toString(((Object[]) v0_8.getValue()))).toString());
        }
        v2_1.append(new StringBuilder().append("adHooks (").append(this.h.size()).append("):").append(this.h).toString()).append(",\n");
        v2_1.append(new StringBuilder().append("adThemes (").append(this.i.size()).append("):").append(this.i).toString()).append(",\n");
        v2_1.append(new StringBuilder().append("auxMap (").append(this.j.size()).append("):").append(this.j).toString()).append(",\n");
        v2_1.append("}");
        return v2_1.toString();
    }
}
