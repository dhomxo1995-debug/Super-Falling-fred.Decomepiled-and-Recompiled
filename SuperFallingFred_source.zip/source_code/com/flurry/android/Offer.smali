.class public final Lcom/flurry/android/Offer;
.super Ljava/lang/Object;

.field private a:J
.field private b:Ljava/lang/String;
.field private c:Ljava/lang/String;
.field private d:I
.field private e:Lcom/flurry/android/AdImage;

.method constructor <init>(J Lcom/flurry/android/AdImage; Ljava/lang/String; Ljava/lang/String; I)V
    .registers 7
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-wide v1, v0, Lcom/flurry/android/Offer;->a J
    iput-object v4, v0, Lcom/flurry/android/Offer;->b Ljava/lang/String;
    iput-object v3, v0, Lcom/flurry/android/Offer;->e Lcom/flurry/android/AdImage;
    iput-object v5, v0, Lcom/flurry/android/Offer;->c Ljava/lang/String;
    iput v6, v0, Lcom/flurry/android/Offer;->d I
    return-void
.end method

.method public final getDescription()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/Offer;->c Ljava/lang/String;
    return-object v0
.end method

.method public final getId()J
    .registers 3
    iget-wide v0, v2, Lcom/flurry/android/Offer;->a J
    return-wide v0
.end method

.method public final getImage()Lcom/flurry/android/AdImage;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/Offer;->e Lcom/flurry/android/AdImage;
    return-object v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/Offer;->b Ljava/lang/String;
    return-object v0
.end method

.method public final getPrice()I
    .registers 2
    iget v0, v1, Lcom/flurry/android/Offer;->d I
    return v0
.end method

.method public final getUrl()Ljava/lang/String;
    .registers 2
    const-string v0, ""
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "[id="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-wide v2, v4, Lcom/flurry/android/Offer;->a J
    invoke-virtual v1, v2, v3, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, ",name="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v4, Lcom/flurry/android/Offer;->b Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, ",price="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget v2, v4, Lcom/flurry/android/Offer;->d I
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, ", image size: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v4, Lcom/flurry/android/Offer;->e Lcom/flurry/android/AdImage;
    iget-object v2, v2, Lcom/flurry/android/AdImage;->e [B
    array-length v2, v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
