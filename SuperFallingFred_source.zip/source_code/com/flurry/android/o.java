package com.flurry.android;
final class o extends android.widget.RelativeLayout {
    private com.flurry.android.u a;
    private android.content.Context b;
    private String c;
    private int d;
    private boolean e;
    private boolean f;

    o(com.flurry.android.u p1, android.content.Context p2, String p3, int p4)
    {
        super(p2);
        super.a = p1;
        super.b = p2;
        super.c = p3;
        super.d = p4;
        return;
    }

    private static android.widget.RelativeLayout$LayoutParams b()
    {
        return new android.widget.RelativeLayout$LayoutParams(-1, -1);
    }

    private declared_synchronized com.flurry.android.y c()
    {
        try {
            int v0_2;
            int v0_0 = this.a;
            com.flurry.android.u v1_2 = this.b;
            java.util.List v2_1 = new String[1];
            v2_1[0] = this.c;
            int v0_1 = v0_0.a(v1_2, java.util.Arrays.asList(v2_1), 0, this.d, 0);
        } catch (int v0_4) {
            throw v0_4;
        }
        if (v0_1.isEmpty()) {
            v0_2 = 0;
        } else {
            v0_2 = ((com.flurry.android.y) v0_1.get(0));
            v0_2.setOnClickListener(this.a);
        }
        return v0_2;
    }

    final void a()
    {
        if (!this.e) {
            android.widget.TextView v0_3 = this.c();
            if (v0_3 == null) {
                if (!this.f) {
                    android.widget.TextView v0_1 = new android.widget.TextView(this.b);
                    v0_1.setText(com.flurry.android.u.b);
                    v0_1.setTextSize(1, 1101004800);
                    this.addView(v0_1, com.flurry.android.o.b());
                }
            } else {
                this.removeAllViews();
                this.addView(v0_3, com.flurry.android.o.b());
                v0_3.a().a(new com.flurry.android.f(3, this.a.k()));
                this.e = 1;
            }
            this.f = 1;
        }
        return;
    }
}
