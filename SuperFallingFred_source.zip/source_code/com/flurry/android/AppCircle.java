package com.flurry.android;
public class AppCircle {

    public AppCircle()
    {
        return;
    }

    public void acceptOffer(android.content.Context p1, long p2)
    {
        com.flurry.android.FlurryAgent.a(p1, p2);
        return;
    }

    public void addUserCookie(String p1, String p2)
    {
        com.flurry.android.FlurryAgent.addUserCookie(p1, p2);
        return;
    }

    public void clearUserCookies()
    {
        com.flurry.android.FlurryAgent.clearUserCookies();
        return;
    }

    public java.util.List getAllOffers()
    {
        return com.flurry.android.FlurryAgent.b("");
    }

    public java.util.List getAllOffers(String p2)
    {
        return com.flurry.android.FlurryAgent.b(p2);
    }

    public android.view.View getHook(android.content.Context p2, String p3, int p4)
    {
        return com.flurry.android.FlurryAgent.a(p2, p3, p4);
    }

    public com.flurry.android.Offer getOffer()
    {
        return this.getOffer("");
    }

    public com.flurry.android.Offer getOffer(String p2)
    {
        return com.flurry.android.FlurryAgent.a(p2);
    }

    public boolean hasAds()
    {
        return com.flurry.android.FlurryAgent.d();
    }

    public boolean isLaunchCanvasOnBannerClicked()
    {
        return com.flurry.android.FlurryAgent.a();
    }

    public boolean isLaunchCatalogOnBannerClicked()
    {
        return com.flurry.android.FlurryAgent.a();
    }

    public void launchCanvasOnBannerClicked(boolean p1)
    {
        com.flurry.android.FlurryAgent.a(p1);
        return;
    }

    public void launchCatalogOnBannerClicked(boolean p1)
    {
        com.flurry.android.FlurryAgent.a(p1);
        return;
    }

    public void openCatalog(android.content.Context p2)
    {
        this.openCatalog(p2, "");
        return;
    }

    public void openCatalog(android.content.Context p1, String p2)
    {
        com.flurry.android.FlurryAgent.a(p1, p2);
        return;
    }

    public void removeOffers(java.util.List p1)
    {
        com.flurry.android.FlurryAgent.a(p1);
        return;
    }

    public void setAppCircleCallback(com.flurry.android.AppCircleCallback p1)
    {
        com.flurry.android.FlurryAgent.a(p1);
        return;
    }

    public void setDefaultNoAdsMessage(String p1)
    {
        com.flurry.android.FlurryAgent.setDefaultNoAdsMessage(p1);
        return;
    }
}
