package com.flurry.android;
final class p {
    final String a;
    com.flurry.android.v b;
    long c;
    java.util.List d;
    private byte e;

    p(String p4, byte p5, long p6)
    {
        this.d = new java.util.ArrayList();
        this.a = p4;
        this.e = p5;
        this.d.add(new com.flurry.android.f(1, p6));
        return;
    }

    final long a()
    {
        return ((com.flurry.android.f) this.d.get(0)).b;
    }

    final void a(com.flurry.android.f p2)
    {
        this.d.add(p2);
        return;
    }

    final void a(java.io.DataOutput p5)
    {
        p5.writeUTF(this.a);
        p5.writeByte(this.e);
        if (this.b != null) {
            p5.writeLong(this.b.a);
            p5.writeLong(this.b.e);
            com.flurry.android.f v0_4 = this.b.g;
            p5.writeByte(v0_4.length);
            p5.write(v0_4);
        } else {
            p5.writeLong(0);
            p5.writeLong(0);
            p5.writeByte(0);
        }
        p5.writeShort(this.d.size());
        java.util.Iterator v1_2 = this.d.iterator();
        while (v1_2.hasNext()) {
            com.flurry.android.f v0_12 = ((com.flurry.android.f) v1_2.next());
            p5.writeByte(v0_12.a);
            p5.writeLong(v0_12.b);
        }
        return;
    }

    public final String toString()
    {
        StringBuilder v1_1 = new StringBuilder();
        v1_1.append(new StringBuilder().append("{hook: ").append(this.a).append(", ad: ").append(this.b.d).append(", transitions: [").toString());
        java.util.Iterator v2_4 = this.d.iterator();
        while (v2_4.hasNext()) {
            v1_1.append(((com.flurry.android.f) v2_4.next()));
            v1_1.append(",");
        }
        v1_1.append("]}");
        return v1_1.toString();
    }
}
