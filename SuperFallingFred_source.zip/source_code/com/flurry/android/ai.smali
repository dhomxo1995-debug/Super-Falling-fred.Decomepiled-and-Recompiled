.class final Lcom/flurry/android/ai;
.super Lorg/apache/http/conn/ssl/SSLSocketFactory;

.field private a:Ljavax/net/ssl/SSLContext;

.method public constructor <init>(Lcom/flurry/android/FlurryAgent; Ljava/security/KeyStore;)V
    .registers 8
    const/4 v4, 0
    invoke-direct v5, v7, Lorg/apache/http/conn/ssl/SSLSocketFactory;-><init>(Ljava/security/KeyStore;)V
    const-string v0, "TLS"
    invoke-static v0, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;
    move-result-object v0
    iput-object v0, v5, Lcom/flurry/android/ai;->a Ljavax/net/ssl/SSLContext;
    new-instance v0, Lcom/flurry/android/n;
    invoke-direct v0, Lcom/flurry/android/n;-><init>()V
    iget-object v1, v5, Lcom/flurry/android/ai;->a Ljavax/net/ssl/SSLContext;
    const/4 v2, 1
    new-array v2, v2, [Ljavax/net/ssl/TrustManager;
    const/4 v3, 0
    aput-object v0, v2, v3
    invoke-virtual v1, v4, v2, v4, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager; [Ljavax/net/ssl/TrustManager; Ljava/security/SecureRandom;)V
    return-void
.end method

.method public final createSocket()Ljava/net/Socket;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/ai;->a Ljavax/net/ssl/SSLContext;
    invoke-virtual v0, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;
    move-result-object v0
    invoke-virtual v0, Ljavax/net/ssl/SSLSocketFactory;->createSocket()Ljava/net/Socket;
    move-result-object v0
    return-object v0
.end method

.method public final createSocket(Ljava/net/Socket; Ljava/lang/String; I Z)Ljava/net/Socket;
    .registers 6
    iget-object v0, v1, Lcom/flurry/android/ai;->a Ljavax/net/ssl/SSLContext;
    invoke-virtual v0, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;
    move-result-object v0
    invoke-virtual v0, v2, v3, v4, v5, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket; Ljava/lang/String; I Z)Ljava/net/Socket;
    move-result-object v0
    return-object v0
.end method
