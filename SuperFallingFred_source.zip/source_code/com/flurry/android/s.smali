.class final Lcom/flurry/android/s;
.super Landroid/widget/LinearLayout;


.method public constructor <init>(Lcom/flurry/android/CatalogActivity; Landroid/content/Context;)V
    .registers 9
    const/4 v5, -2
    const/4 v4, 0
    invoke-direct v6, v8, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    const/4 v0, -1
    invoke-virtual v6, v0, Lcom/flurry/android/s;->setBackgroundColor(I)V
    invoke-static v7, Lcom/flurry/android/CatalogActivity;->c(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/u;
    move-result-object v0
    invoke-virtual v0, Lcom/flurry/android/u;->m()Lcom/flurry/android/AdImage;
    move-result-object v0
    if-eqz v0, +037h
    new-instance v1, Landroid/widget/ImageView;
    invoke-direct v1, v8, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    const/16 v2, 10000
    invoke-virtual v1, v2, Landroid/widget/ImageView;->setId(I)V
    iget-object v2, v0, Lcom/flurry/android/AdImage;->e [B
    if-eqz v2, +00ah
    array-length v3, v2
    invoke-static v2, v4, v3, Landroid/graphics/BitmapFactory;->decodeByteArray([B I I)Landroid/graphics/Bitmap;
    move-result-object v2
    invoke-virtual v1, v2, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    iget v2, v0, Lcom/flurry/android/AdImage;->b I
    invoke-static v8, v2, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v2
    iget v0, v0, Lcom/flurry/android/AdImage;->c I
    invoke-static v8, v0, Lcom/flurry/android/r;->a(Landroid/content/Context; I)I
    move-result v0
    invoke-static v8, v1, v2, v0, Lcom/flurry/android/r;->a(Landroid/content/Context; Landroid/widget/ImageView; I I)V
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct v0, v5, v5, Landroid/widget/LinearLayout$LayoutParams;-><init>(I I)V
    const/4 v2, -3
    invoke-virtual v0, v4, v4, v4, v2, Landroid/widget/LinearLayout$LayoutParams;->setMargins(I I I I)V
    const/4 v2, 3
    invoke-virtual v6, v2, Lcom/flurry/android/s;->setGravity(I)V
    invoke-virtual v6, v1, v0, Lcom/flurry/android/s;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    return-void
.end method
