.class final Lcom/flurry/android/af;
.super Ljava/lang/Object;

.field private a:Ljava/util/LinkedHashMap;
.field private b:I

.method constructor <init>(I)V
    .registers 5
    const/16 v0, 50
    const/high16 v2, 1061158912
    invoke-direct v3, Ljava/lang/Object;-><init>()V
    iput v0, v3, Lcom/flurry/android/af;->b I
    int-to-float v0, v0
    div-float/2addr v0, v2
    float-to-double v0, v0
    invoke-static v0, v1, Ljava/lang/Math;->ceil(D)D
    move-result-wide v0
    double-to-int v0, v0
    add-int/lit8 v0, v0, 1
    new-instance v1, Lcom/flurry/android/h;
    invoke-direct v1, v3, v0, v2, Lcom/flurry/android/h;-><init>(Lcom/flurry/android/af; I F)V
    iput-object v1, v3, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/af;)I
    .registers 2
    iget v0, v1, Lcom/flurry/android/af;->b I
    return v0
.end method

.method final synchronized a()I
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    invoke-virtual v0, Ljava/util/LinkedHashMap;->size()I
    move-result v0
    monitor-exit v1
    return v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    invoke-virtual v0, v2, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    monitor-exit v1
    return-object v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized a(Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 4
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    invoke-virtual v0, v2, v3, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final synchronized b()Ljava/util/List;
    .registers 3
    monitor-enter v2
    new-instance v0, Ljava/util/ArrayList;
    iget-object v1, v2, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    invoke-virtual v1, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    move-result-object v1
    invoke-direct v0, v1, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized c()Ljava/util/Set;
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/af;->a Ljava/util/LinkedHashMap;
    invoke-virtual v0, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;
    move-result-object v0
    monitor-exit v1
    return-object v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method
