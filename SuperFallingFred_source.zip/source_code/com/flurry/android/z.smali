.class final Lcom/flurry/android/z;
.super Ljava/lang/Object;

.field private a:Landroid/content/Context;
.field private b:Lcom/flurry/android/u;
.field private c:Lcom/flurry/android/a;
.field private bridge d:J
.field private e:Lcom/flurry/android/af;
.field private f:Lcom/flurry/android/af;
.field private g:Ljava/util/Map;
.field private h:Ljava/util/Map;
.field private i:Ljava/util/Map;
.field private j:Ljava/util/Map;
.field private bridge k:Z

.method constructor <init>()V
    .registers 3
    const/16 v1, 50
    invoke-direct v2, Ljava/lang/Object;-><init>()V
    new-instance v0, Lcom/flurry/android/af;
    invoke-direct v0, v1, Lcom/flurry/android/af;-><init>(I)V
    iput-object v0, v2, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    new-instance v0, Lcom/flurry/android/af;
    invoke-direct v0, v1, Lcom/flurry/android/af;-><init>(I)V
    iput-object v0, v2, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v2, Lcom/flurry/android/z;->g Ljava/util/Map;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v2, Lcom/flurry/android/z;->h Ljava/util/Map;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v2, Lcom/flurry/android/z;->i Ljava/util/Map;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v2, Lcom/flurry/android/z;->j Ljava/util/Map;
    return-void
.end method

.method private synchronized a(B)Lcom/flurry/android/c;
    .registers 4
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-static v3, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/c;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method private a(I)V
    .registers 3
    iget-object v0, v1, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-nez v0, +00fh
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/flurry/android/z;->k Z
    iget-boolean v0, v1, Lcom/flurry/android/z;->k Z
    if-eqz v0, +007h
    iget-object v0, v1, Lcom/flurry/android/z;->b Lcom/flurry/android/u;
    invoke-virtual v0, v2, Lcom/flurry/android/u;->a(I)V
    return-void
    const/4 v0, 0
    goto -dh
.end method

.method private a(Ljava/io/DataInputStream;)V
    .registers 10
    const/16 v7, 50
    const/4 v0, 0
    const-string v1, "FlurryAgent"
    const-string v2, "Reading cache"
    invoke-static v1, v2, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v1
    const/4 v2, 2
    if-eq v1, v2, +003h
    return-void
    invoke-virtual v9, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v1
    iput-wide v1, v8, Lcom/flurry/android/z;->d J
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v2
    new-instance v1, Lcom/flurry/android/af;
    invoke-direct v1, v7, Lcom/flurry/android/af;-><init>(I)V
    iput-object v1, v8, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    move v1, v0
    if-ge v1, v2, +01ah
    invoke-virtual v9, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v3
    new-instance v5, Lcom/flurry/android/AdImage;
    invoke-direct v5, Lcom/flurry/android/AdImage;-><init>()V
    invoke-virtual v5, v9, Lcom/flurry/android/AdImage;->a(Ljava/io/DataInput;)V
    iget-object v6, v8, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v3
    invoke-virtual v6, v3, v5, Lcom/flurry/android/af;->a(Ljava/lang/Object; Ljava/lang/Object;)V
    add-int/lit8 v1, v1, 1
    goto -19h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v2
    new-instance v1, Lcom/flurry/android/af;
    invoke-direct v1, v7, Lcom/flurry/android/af;-><init>(I)V
    iput-object v1, v8, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    move v1, v0
    if-ge v1, v2, +035h
    invoke-virtual v9, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v3
    new-instance v5, Lcom/flurry/android/al;
    invoke-direct v5, Lcom/flurry/android/al;-><init>()V
    invoke-interface v9, Ljava/io/DataInput;->readBoolean()Z
    move-result v6
    if-eqz v6, +008h
    invoke-interface v9, Ljava/io/DataInput;->readUTF()Ljava/lang/String;
    move-result-object v6
    iput-object v6, v5, Lcom/flurry/android/al;->a Ljava/lang/String;
    invoke-interface v9, Ljava/io/DataInput;->readBoolean()Z
    move-result v6
    if-eqz v6, +008h
    invoke-interface v9, Ljava/io/DataInput;->readUTF()Ljava/lang/String;
    move-result-object v6
    iput-object v6, v5, Lcom/flurry/android/al;->b Ljava/lang/String;
    invoke-interface v9, Ljava/io/DataInput;->readInt()I
    move-result v6
    iput v6, v5, Lcom/flurry/android/al;->c I
    iget-object v6, v8, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v3
    invoke-virtual v6, v3, v5, Lcom/flurry/android/af;->a(Ljava/lang/Object; Ljava/lang/Object;)V
    add-int/lit8 v1, v1, 1
    goto -34h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v2
    new-instance v1, Ljava/util/HashMap;
    invoke-direct v1, v2, Ljava/util/HashMap;-><init>(I)V
    iput-object v1, v8, Lcom/flurry/android/z;->h Ljava/util/Map;
    move v1, v0
    if-ge v1, v2, +013h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v3
    new-instance v4, Lcom/flurry/android/e;
    invoke-direct v4, v9, Lcom/flurry/android/e;-><init>(Ljava/io/DataInput;)V
    iget-object v5, v8, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v5, v3, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v1, v1, 1
    goto -12h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v3
    new-instance v1, Ljava/util/HashMap;
    invoke-direct v1, v3, Ljava/util/HashMap;-><init>(I)V
    iput-object v1, v8, Lcom/flurry/android/z;->g Ljava/util/Map;
    move v2, v0
    if-ge v2, v3, +025h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v5
    new-array v6, v5, [Lcom/flurry/android/v;
    move v1, v0
    if-ge v1, v5, +00fh
    new-instance v7, Lcom/flurry/android/v;
    invoke-direct v7, Lcom/flurry/android/v;-><init>()V
    invoke-virtual v7, v9, Lcom/flurry/android/v;->a(Ljava/io/DataInput;)V
    aput-object v7, v6, v1
    add-int/lit8 v1, v1, 1
    goto -eh
    iget-object v1, v8, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v1, v4, v6, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v1, v2, 1
    move v2, v1
    goto -24h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v2
    new-instance v1, Ljava/util/HashMap;
    invoke-direct v1, Ljava/util/HashMap;-><init>()V
    iput-object v1, v8, Lcom/flurry/android/z;->i Ljava/util/Map;
    move v1, v0
    if-ge v1, v2, +01ah
    invoke-virtual v9, Ljava/io/DataInputStream;->readByte()B
    move-result v3
    new-instance v4, Lcom/flurry/android/c;
    invoke-direct v4, Lcom/flurry/android/c;-><init>()V
    invoke-virtual v4, v9, Lcom/flurry/android/c;->b(Ljava/io/DataInput;)V
    iget-object v5, v8, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-static v3, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v3
    invoke-interface v5, v3, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v1, v1, 1
    goto -19h
    invoke-virtual v9, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v1
    new-instance v2, Ljava/util/HashMap;
    invoke-direct v2, v1, Ljava/util/HashMap;-><init>(I)V
    iput-object v2, v8, Lcom/flurry/android/z;->j Ljava/util/Map;
    if-ge v0, v1, +01ah
    invoke-virtual v9, Ljava/io/DataInputStream;->readShort()S
    move-result v2
    invoke-virtual v9, Ljava/io/DataInputStream;->readLong()J
    move-result-wide v3
    iget-object v5, v8, Lcom/flurry/android/z;->j Ljava/util/Map;
    invoke-static v2, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;
    move-result-object v2
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v3
    invoke-interface v5, v2, v3, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v0, v0, 1
    goto -19h
    invoke-direct v8, Lcom/flurry/android/z;->f()V
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Cache read, num images: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v8, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-virtual v2, Lcom/flurry/android/af;->a()I
    move-result v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String;)I
    goto/16 -12ah
.end method

.method private a(Ljava/io/DataOutputStream;)V
    .registers 10
    const/4 v2, 1
    const/4 v3, 0
    const/4 v0, 2
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-wide v0, v8, Lcom/flurry/android/z;->d J
    invoke-virtual v9, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    iget-object v0, v8, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-virtual v0, Lcom/flurry/android/af;->b()Ljava/util/List;
    move-result-object v0
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v1
    invoke-virtual v9, v1, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +03bh
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/Long;
    invoke-virtual v1, Ljava/lang/Long;->longValue()J
    move-result-wide v5
    invoke-virtual v9, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/AdImage;
    iget-wide v5, v0, Lcom/flurry/android/AdImage;->a J
    invoke-interface v9, v5, v6, Ljava/io/DataOutput;->writeLong(J)V
    iget v1, v0, Lcom/flurry/android/AdImage;->b I
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeInt(I)V
    iget v1, v0, Lcom/flurry/android/AdImage;->c I
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeInt(I)V
    iget-object v1, v0, Lcom/flurry/android/AdImage;->d Ljava/lang/String;
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-object v1, v0, Lcom/flurry/android/AdImage;->e [B
    array-length v1, v1
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeInt(I)V
    iget-object v0, v0, Lcom/flurry/android/AdImage;->e [B
    invoke-interface v9, v0, Ljava/io/DataOutput;->write([B)V
    goto -3eh
    iget-object v0, v8, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    invoke-virtual v0, Lcom/flurry/android/af;->b()Ljava/util/List;
    move-result-object v0
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v1
    invoke-virtual v9, v1, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +044h
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    move-object v1, v0
    check-cast v1, Ljava/util/Map$Entry;
    invoke-interface v1, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Long;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v5
    invoke-virtual v9, v5, v6, Ljava/io/DataOutputStream;->writeLong(J)V
    invoke-interface v1, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/al;
    iget-object v1, v0, Lcom/flurry/android/al;->a Ljava/lang/String;
    if-eqz v1, +022h
    move v1, v2
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeBoolean(Z)V
    if-eqz v1, +007h
    iget-object v1, v0, Lcom/flurry/android/al;->a Ljava/lang/String;
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-object v1, v0, Lcom/flurry/android/al;->b Ljava/lang/String;
    if-eqz v1, +015h
    move v1, v2
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeBoolean(Z)V
    if-eqz v1, +007h
    iget-object v1, v0, Lcom/flurry/android/al;->b Ljava/lang/String;
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget v0, v0, Lcom/flurry/android/al;->c I
    invoke-interface v9, v0, Ljava/io/DataOutput;->writeInt(I)V
    goto -43h
    move v1, v3
    goto -20h
    move v1, v3
    goto -13h
    iget-object v0, v8, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v8, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +028h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    move-object v1, v0
    check-cast v1, Ljava/util/Map$Entry;
    invoke-interface v1, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-interface v1, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/e;
    iget-object v1, v0, Lcom/flurry/android/e;->a Ljava/lang/String;
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-byte v1, v0, Lcom/flurry/android/e;->b B
    invoke-interface v9, v1, Ljava/io/DataOutput;->writeByte(I)V
    iget-byte v0, v0, Lcom/flurry/android/e;->c B
    invoke-interface v9, v0, Ljava/io/DataOutput;->writeByte(I)V
    goto -2bh
    iget-object v0, v8, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v8, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +054h
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v9, v1, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/flurry/android/v;
    if-nez v0, +03bh
    move v1, v3
    invoke-virtual v9, v1, Ljava/io/DataOutputStream;->writeShort(I)V
    move v2, v3
    if-ge v2, v1, -022h
    aget-object v5, v0, v2
    iget-wide v6, v5, Lcom/flurry/android/v;->a J
    invoke-interface v9, v6, v7, Ljava/io/DataOutput;->writeLong(J)V
    iget-wide v6, v5, Lcom/flurry/android/v;->b J
    invoke-interface v9, v6, v7, Ljava/io/DataOutput;->writeLong(J)V
    iget-object v6, v5, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-interface v9, v6, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-object v6, v5, Lcom/flurry/android/v;->c Ljava/lang/String;
    invoke-interface v9, v6, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-wide v6, v5, Lcom/flurry/android/v;->e J
    invoke-interface v9, v6, v7, Ljava/io/DataOutput;->writeLong(J)V
    iget-object v6, v5, Lcom/flurry/android/v;->f Ljava/lang/Long;
    invoke-virtual v6, Ljava/lang/Long;->longValue()J
    move-result-wide v6
    invoke-interface v9, v6, v7, Ljava/io/DataOutput;->writeLong(J)V
    iget-object v6, v5, Lcom/flurry/android/v;->g [B
    array-length v6, v6
    invoke-interface v9, v6, Ljava/io/DataOutput;->writeByte(I)V
    iget-object v5, v5, Lcom/flurry/android/v;->g [B
    invoke-interface v9, v5, Ljava/io/DataOutput;->write([B)V
    add-int/lit8 v2, v2, 1
    goto -33h
    array-length v1, v0
    goto -39h
    iget-object v0, v8, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v8, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01fh
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/Byte;
    invoke-virtual v1, Ljava/lang/Byte;->byteValue()B
    move-result v1
    invoke-virtual v9, v1, Ljava/io/DataOutputStream;->writeByte(I)V
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/c;
    invoke-virtual v0, v9, Lcom/flurry/android/c;->a(Ljava/io/DataOutput;)V
    goto -22h
    iget-object v0, v8, Lcom/flurry/android/z;->j Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    iget-object v0, v8, Lcom/flurry/android/z;->j Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +024h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    move-object v1, v0
    check-cast v1, Ljava/util/Map$Entry;
    invoke-interface v1, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Short;
    invoke-virtual v0, Ljava/lang/Short;->shortValue()S
    move-result v0
    invoke-virtual v9, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-interface v1, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Long;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v0
    invoke-virtual v9, v0, v1, Ljava/io/DataOutputStream;->writeLong(J)V
    goto -27h
    return-void
.end method

.method private static a(Ljava/io/File;)V
    .registers 3
    invoke-virtual v2, Ljava/io/File;->delete()Z
    move-result v0
    if-nez v0, +009h
    const-string v0, "FlurryAgent"
    const-string v1, "Cannot delete cached ads"
    invoke-static v0, v1, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method

.method private f()V
    .registers 9
    iget-object v0, v8, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->values()Ljava/util/Collection;
    move-result-object v0
    invoke-interface v0, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v0
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v1
    if-eqz v1, +006h
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    goto -9h
    iget-object v0, v8, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->values()Ljava/util/Collection;
    move-result-object v0
    invoke-interface v0, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +06bh
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/flurry/android/v;
    if-eqz v0, -00ch
    array-length v3, v0
    const/4 v1, 0
    if-ge v1, v3, -010h
    aget-object v4, v0, v1
    iget-object v5, v4, Lcom/flurry/android/v;->f Ljava/lang/Long;
    invoke-virtual v5, Ljava/lang/Long;->longValue()J
    move-result-wide v5
    invoke-virtual v8, v5, v6, Lcom/flurry/android/z;->b(J)Lcom/flurry/android/AdImage;
    move-result-object v5
    iput-object v5, v4, Lcom/flurry/android/v;->h Lcom/flurry/android/AdImage;
    iget-object v5, v4, Lcom/flurry/android/v;->h Lcom/flurry/android/AdImage;
    if-nez v5, +022h
    const-string v5, "FlurryAgent"
    new-instance v6, Ljava/lang/StringBuilder;
    invoke-direct v6, Ljava/lang/StringBuilder;-><init>()V
    const-string v7, "Ad "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    iget-object v7, v4, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    const-string v7, " has no image"
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v6
    invoke-static v5, v6, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    iget-wide v5, v4, Lcom/flurry/android/v;->a J
    invoke-virtual v8, v5, v6, Lcom/flurry/android/z;->a(J)Lcom/flurry/android/al;
    move-result-object v5
    if-nez v5, +022h
    const-string v5, "FlurryAgent"
    new-instance v6, Ljava/lang/StringBuilder;
    invoke-direct v6, Ljava/lang/StringBuilder;-><init>()V
    const-string v7, "Ad "
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    iget-object v4, v4, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v6, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v6, " has no pricing"
    invoke-virtual v4, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-static v5, v4, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    add-int/lit8 v1, v1, 1
    goto -5eh
    iget-object v0, v8, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->values()Ljava/util/Collection;
    move-result-object v0
    invoke-interface v0, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +02fh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/e;
    iget-byte v2, v0, Lcom/flurry/android/e;->c B
    invoke-direct v8, v2, Lcom/flurry/android/z;->a(B)Lcom/flurry/android/c;
    move-result-object v2
    iput-object v2, v0, Lcom/flurry/android/e;->d Lcom/flurry/android/c;
    iget-object v2, v0, Lcom/flurry/android/e;->d Lcom/flurry/android/c;
    if-nez v2, -016h
    const-string v2, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "No ad theme found for "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    iget-byte v0, v0, Lcom/flurry/android/e;->c B
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, v0, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    goto -32h
    return-void
.end method

.method private g()Ljava/lang/String;
    .registers 4
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, ".flurryappcircle."
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v3, Lcom/flurry/android/z;->c Lcom/flurry/android/a;
    iget-object v1, v1, Lcom/flurry/android/a;->a Ljava/lang/String;
    invoke-virtual v1, Ljava/lang/String;->hashCode()I
    move-result v1
    const/16 v2, 16
    invoke-static v1, v2, Ljava/lang/Integer;->toString(I I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method final synchronized a(S)Lcom/flurry/android/AdImage;
    .registers 4
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->j Ljava/util/Map;
    const/4 v1, 1
    invoke-static v1, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Long;
    if-nez v0, +005h
    const/4 v0, 0
    monitor-exit v2
    return-object v0
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v0
    invoke-virtual v2, v0, v1, Lcom/flurry/android/z;->b(J)Lcom/flurry/android/AdImage;
    move-result-object v0
    goto -ah
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized a(J)Lcom/flurry/android/al;
    .registers 5
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/flurry/android/af;->a(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/al;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized a()Ljava/util/Set;
    .registers 2
    monitor-enter v1
    iget-object v0, v1, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-virtual v0, Lcom/flurry/android/af;->c()Ljava/util/Set;
    move-result-object v0
    monitor-exit v1
    return-object v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method final a(Landroid/content/Context; Lcom/flurry/android/u; Lcom/flurry/android/a;)V
    .registers 4
    iput-object v1, v0, Lcom/flurry/android/z;->a Landroid/content/Context;
    iput-object v2, v0, Lcom/flurry/android/z;->b Lcom/flurry/android/u;
    iput-object v3, v0, Lcom/flurry/android/z;->c Lcom/flurry/android/a;
    return-void
.end method

.method final synchronized a(Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map; Ljava/util/Map;)V
    .registers 12
    monitor-enter v5
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    iput-wide v0, v5, Lcom/flurry/android/z;->d J
    invoke-interface v9, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01fh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v2
    if-eqz v2, -010h
    iget-object v2, v5, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    invoke-virtual v2, v3, v0, Lcom/flurry/android/af;->a(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -1fh
    move-exception v0
    monitor-exit v5
    throw v0
    invoke-interface v10, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01ch
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v2
    if-eqz v2, -010h
    iget-object v2, v5, Lcom/flurry/android/z;->f Lcom/flurry/android/af;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    invoke-virtual v2, v3, v0, Lcom/flurry/android/af;->a(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -1fh
    if-eqz v7, +00ah
    invoke-interface v7, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-nez v0, +004h
    iput-object v7, v5, Lcom/flurry/android/z;->h Ljava/util/Map;
    if-eqz v8, +00ah
    invoke-interface v8, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-nez v0, +004h
    iput-object v8, v5, Lcom/flurry/android/z;->i Ljava/util/Map;
    if-eqz v11, +00ah
    invoke-interface v11, Ljava/util/Map;->isEmpty()Z
    move-result v0
    if-nez v0, +004h
    iput-object v11, v5, Lcom/flurry/android/z;->j Ljava/util/Map;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v5, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v7, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +036h
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Lcom/flurry/android/e;
    iget-byte v2, v1, Lcom/flurry/android/e;->b B
    invoke-static v2, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v2
    invoke-interface v6, v2, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, [Lcom/flurry/android/v;
    if-eqz v2, +00bh
    iget-object v4, v5, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    invoke-interface v4, v0, v2, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    iget-byte v0, v1, Lcom/flurry/android/e;->c B
    invoke-static v0, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v0
    invoke-interface v8, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/c;
    if-eqz v0, -035h
    iput-object v0, v1, Lcom/flurry/android/e;->d Lcom/flurry/android/c;
    goto -39h
    invoke-direct v5, Lcom/flurry/android/z;->f()V
    const/16 v0, 202
    invoke-direct v5, v0, Lcom/flurry/android/z;->a(I)V
    monitor-exit v5
    return-void
.end method

.method final synchronized a(Ljava/lang/String;)[Lcom/flurry/android/v;
    .registers 4
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, v3, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/flurry/android/v;
    if-nez v0, +00ch
    iget-object v0, v2, Lcom/flurry/android/z;->g Ljava/util/Map;
    const-string v1, ""
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/flurry/android/v;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized b(J)Lcom/flurry/android/AdImage;
    .registers 5
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-static v3, v4, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/flurry/android/af;->a(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/AdImage;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final synchronized b(Ljava/lang/String;)Lcom/flurry/android/e;
    .registers 4
    monitor-enter v2
    iget-object v0, v2, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v0, v3, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/e;
    if-nez v0, +00ch
    iget-object v0, v2, Lcom/flurry/android/z;->h Ljava/util/Map;
    const-string v1, ""
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/e;
    monitor-exit v2
    return-object v0
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method final b()Z
    .registers 2
    iget-boolean v0, v1, Lcom/flurry/android/z;->k Z
    return v0
.end method

.method final c()J
    .registers 3
    iget-wide v0, v2, Lcom/flurry/android/z;->d J
    return-wide v0
.end method

.method final synchronized d()V
    .registers 6
    monitor-enter v5
    iget-object v0, v5, Lcom/flurry/android/z;->a Landroid/content/Context;
    invoke-direct v5, Lcom/flurry/android/z;->g()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v3
    invoke-virtual v3, Ljava/io/File;->exists()Z
    move-result v0
    if-eqz v0, +03fh
    const/4 v2, 0
    new-instance v0, Ljava/io/FileInputStream;
    invoke-direct v0, v3, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    new-instance v1, Ljava/io/DataInputStream;
    invoke-direct v1, v0, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    invoke-virtual v1, Ljava/io/DataInputStream;->readUnsignedShort()I
    move-result v0
    const v2, 46587
    if-ne v0, v2, +00fh
    invoke-direct v5, v1, Lcom/flurry/android/z;->a(Ljava/io/DataInputStream;)V
    const/16 v0, 201
    invoke-direct v5, v0, Lcom/flurry/android/z;->a(I)V
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    monitor-exit v5
    return-void
    invoke-static v3, Lcom/flurry/android/z;->a(Ljava/io/File;)V
    goto -8h
    move-exception v0
    const-string v2, "FlurryAgent"
    const-string v4, "Discarding cache"
    invoke-static v2, v4, v0, Lcom/flurry/android/ah;->a(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v3, Lcom/flurry/android/z;->a(Ljava/io/File;)V
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -14h
    move-exception v0
    monitor-exit v5
    throw v0
    move-exception v0
    move-object v1, v2
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    const-string v0, "FlurryAgent"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "cache file does not exist, path="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v3, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/flurry/android/ah;->c(Ljava/lang/String; Ljava/lang/String;)I
    goto -3ah
    move-exception v0
    goto -22h
    move-exception v0
    move-object v1, v2
    goto -38h
.end method

.method final synchronized e()V
    .registers 6
    const/4 v1, 0
    monitor-enter v5
    iget-object v0, v5, Lcom/flurry/android/z;->a Landroid/content/Context;
    invoke-direct v5, Lcom/flurry/android/z;->g()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;
    move-result-object v0
    invoke-virtual v0, Ljava/io/File;->getParentFile()Ljava/io/File;
    move-result-object v2
    invoke-virtual v2, Ljava/io/File;->mkdirs()Z
    move-result v3
    if-nez v3, +026h
    invoke-virtual v2, Ljava/io/File;->exists()Z
    move-result v3
    if-nez v3, +020h
    const-string v0, "FlurryAgent"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Unable to create persistent dir: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 0
    invoke-static v0, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    monitor-exit v5
    return-void
    new-instance v3, Ljava/io/FileOutputStream;
    invoke-direct v3, v0, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    new-instance v2, Ljava/io/DataOutputStream;
    invoke-direct v2, v3, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    const v0, 46587
    invoke-virtual v2, v0, Ljava/io/DataOutputStream;->writeShort(I)V
    invoke-direct v5, v2, Lcom/flurry/android/z;->a(Ljava/io/DataOutputStream;)V
    invoke-static v2, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -18h
    move-exception v0
    monitor-exit v5
    throw v0
    move-exception v0
    const-string v2, "FlurryAgent"
    const-string v3, ""
    invoke-static v2, v3, v0, Lcom/flurry/android/ah;->b(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Throwable;)I
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    goto -27h
    move-exception v0
    invoke-static v1, Lcom/flurry/android/r;->a(Ljava/io/Closeable;)V
    throw v0
    move-exception v0
    move-object v1, v2
    goto -6h
    move-exception v0
    move-object v1, v2
    goto -15h
.end method

.method public final toString()Ljava/lang/String;
    .registers 6
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v0, "{"
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "adImages ("
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->e Lcom/flurry/android/af;
    invoke-virtual v1, Lcom/flurry/android/af;->b()Ljava/util/List;
    move-result-object v1
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "),
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "adBlock ("
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->size()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "):"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, ",
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget-object v0, v5, Lcom/flurry/android/z;->g Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +039h
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "	"
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v4, ": "
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Ljava/lang/Object;
    invoke-static v0, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -3ch
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "adHooks ("
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->size()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "):"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->h Ljava/util/Map;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, ",
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "adThemes ("
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->size()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "):"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->i Ljava/util/Map;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, ",
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "auxMap ("
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->j Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map;->size()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "):"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/z;->j Ljava/util/Map;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, ",
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0, "}"
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
