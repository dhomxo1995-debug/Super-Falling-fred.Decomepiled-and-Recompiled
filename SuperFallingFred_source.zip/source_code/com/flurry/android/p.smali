.class final Lcom/flurry/android/p;
.super Ljava/lang/Object;

.field final a:Ljava/lang/String;
.field  b:Lcom/flurry/android/v;
.field  c:J
.field  d:Ljava/util/List;
.field private e:B

.method constructor <init>(Ljava/lang/String; B J)V
    .registers 8
    invoke-direct v3, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v3, Lcom/flurry/android/p;->d Ljava/util/List;
    iput-object v4, v3, Lcom/flurry/android/p;->a Ljava/lang/String;
    iput-byte v5, v3, Lcom/flurry/android/p;->e B
    iget-object v0, v3, Lcom/flurry/android/p;->d Ljava/util/List;
    new-instance v1, Lcom/flurry/android/f;
    const/4 v2, 1
    invoke-direct v1, v2, v6, v7, Lcom/flurry/android/f;-><init>(B J)V
    invoke-interface v0, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    return-void
.end method

.method final a()J
    .registers 3
    iget-object v0, v2, Lcom/flurry/android/p;->d Ljava/util/List;
    const/4 v1, 0
    invoke-interface v0, v1, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/f;
    iget-wide v0, v0, Lcom/flurry/android/f;->b J
    return-wide v0
.end method

.method final a(Lcom/flurry/android/f;)V
    .registers 3
    iget-object v0, v1, Lcom/flurry/android/p;->d Ljava/util/List;
    invoke-interface v0, v2, Ljava/util/List;->add(Ljava/lang/Object;)Z
    return-void
.end method

.method final a(Ljava/io/DataOutput;)V
    .registers 6
    const-wide/16 v1, 0
    iget-object v0, v4, Lcom/flurry/android/p;->a Ljava/lang/String;
    invoke-interface v5, v0, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V
    iget-byte v0, v4, Lcom/flurry/android/p;->e B
    invoke-interface v5, v0, Ljava/io/DataOutput;->writeByte(I)V
    iget-object v0, v4, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    if-nez v0, +032h
    invoke-interface v5, v1, v2, Ljava/io/DataOutput;->writeLong(J)V
    invoke-interface v5, v1, v2, Ljava/io/DataOutput;->writeLong(J)V
    const/4 v0, 0
    invoke-interface v5, v0, Ljava/io/DataOutput;->writeByte(I)V
    iget-object v0, v4, Lcom/flurry/android/p;->d Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->size()I
    move-result v0
    invoke-interface v5, v0, Ljava/io/DataOutput;->writeShort(I)V
    iget-object v0, v4, Lcom/flurry/android/p;->d Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +02dh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/f;
    iget-byte v2, v0, Lcom/flurry/android/f;->a B
    invoke-interface v5, v2, Ljava/io/DataOutput;->writeByte(I)V
    iget-wide v2, v0, Lcom/flurry/android/f;->b J
    invoke-interface v5, v2, v3, Ljava/io/DataOutput;->writeLong(J)V
    goto -16h
    iget-object v0, v4, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iget-wide v0, v0, Lcom/flurry/android/v;->a J
    invoke-interface v5, v0, v1, Ljava/io/DataOutput;->writeLong(J)V
    iget-object v0, v4, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iget-wide v0, v0, Lcom/flurry/android/v;->e J
    invoke-interface v5, v0, v1, Ljava/io/DataOutput;->writeLong(J)V
    iget-object v0, v4, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iget-object v0, v0, Lcom/flurry/android/v;->g [B
    array-length v1, v0
    invoke-interface v5, v1, Ljava/io/DataOutput;->writeByte(I)V
    invoke-interface v5, v0, Ljava/io/DataOutput;->write([B)V
    goto -3fh
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 4
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "{hook: "
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v2, v3, Lcom/flurry/android/p;->a Ljava/lang/String;
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, ", ad: "
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v2, v3, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    iget-object v2, v2, Lcom/flurry/android/v;->d Ljava/lang/String;
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, ", transitions: ["
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget-object v0, v3, Lcom/flurry/android/p;->d Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +011h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/f;
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    const-string v0, ","
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -14h
    const-string v0, "]}"
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
