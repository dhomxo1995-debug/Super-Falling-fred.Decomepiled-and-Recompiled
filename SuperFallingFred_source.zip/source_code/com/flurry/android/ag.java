package com.flurry.android;
final class ag {
    private java.util.List a;
    private android.os.Handler b;
    private android.os.Handler c;
    private int d;
    private Runnable e;

    ag(android.os.Handler p2, int p3)
    {
        this.a = new java.util.ArrayList();
        this.b = p2;
        this.c = new android.os.Handler();
        this.d = p3;
        this.e = new com.flurry.android.k(this);
        this.b();
        return;
    }

    private declared_synchronized void a()
    {
        try {
            java.util.ArrayList v1_1 = new java.util.ArrayList();
            com.flurry.android.j v2_1 = this.a.iterator();
        } catch (android.os.Handler v0_5) {
            throw v0_5;
        }
        while (v2_1.hasNext()) {
            android.os.Handler v0_3 = ((com.flurry.android.o) ((ref.WeakReference) v2_1.next()).get());
            if (v0_3 != null) {
                v1_1.add(v0_3);
            }
        }
        this.c.post(new com.flurry.android.j(v1_1));
        this.b();
        return;
    }

    static synthetic void a(com.flurry.android.ag p0)
    {
        p0.a();
        return;
    }

    private declared_synchronized void b()
    {
        try {
            Runnable v1_1 = this.a.iterator();
        } catch (android.os.Handler v0_4) {
            throw v0_4;
        }
        while (v1_1.hasNext()) {
            if (((ref.WeakReference) v1_1.next()).get() == null) {
                v1_1.remove();
            }
        }
        this.b.removeCallbacks(this.e);
        this.b.postDelayed(this.e, ((long) this.d));
        return;
    }

    final declared_synchronized void a(com.flurry.android.o p3)
    {
        try {
            p3.a();
            this.a.add(new ref.WeakReference(p3));
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }
}
