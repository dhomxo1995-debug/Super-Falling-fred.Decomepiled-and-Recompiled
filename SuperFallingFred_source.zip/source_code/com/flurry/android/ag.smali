.class final Lcom/flurry/android/ag;
.super Ljava/lang/Object;

.field private a:Ljava/util/List;
.field private b:Landroid/os/Handler;
.field private c:Landroid/os/Handler;
.field private d:I
.field private e:Ljava/lang/Runnable;

.method constructor <init>(Landroid/os/Handler; I)V
    .registers 4
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/ag;->a Ljava/util/List;
    iput-object v2, v1, Lcom/flurry/android/ag;->b Landroid/os/Handler;
    new-instance v0, Landroid/os/Handler;
    invoke-direct v0, Landroid/os/Handler;-><init>()V
    iput-object v0, v1, Lcom/flurry/android/ag;->c Landroid/os/Handler;
    iput v3, v1, Lcom/flurry/android/ag;->d I
    new-instance v0, Lcom/flurry/android/k;
    invoke-direct v0, v1, Lcom/flurry/android/k;-><init>(Lcom/flurry/android/ag;)V
    iput-object v0, v1, Lcom/flurry/android/ag;->e Ljava/lang/Runnable;
    invoke-direct v1, Lcom/flurry/android/ag;->b()V
    return-void
.end method

.method private synchronized a()V
    .registers 4
    monitor-enter v3
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct v1, Ljava/util/ArrayList;-><init>()V
    iget-object v0, v3, Lcom/flurry/android/ag;->a Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +017h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/ref/WeakReference;
    invoke-virtual v0, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/o;
    if-eqz v0, -012h
    invoke-interface v1, v0, Ljava/util/List;->add(Ljava/lang/Object;)Z
    goto -17h
    move-exception v0
    monitor-exit v3
    throw v0
    iget-object v0, v3, Lcom/flurry/android/ag;->c Landroid/os/Handler;
    new-instance v2, Lcom/flurry/android/j;
    invoke-direct v2, v1, Lcom/flurry/android/j;-><init>(Ljava/util/List;)V
    invoke-virtual v0, v2, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    invoke-direct v3, Lcom/flurry/android/ag;->b()V
    monitor-exit v3
    return-void
.end method

.method static synthetic a(Lcom/flurry/android/ag;)V
    .registers 1
    invoke-direct v0, Lcom/flurry/android/ag;->a()V
    return-void
.end method

.method private synchronized b()V
    .registers 5
    monitor-enter v4
    iget-object v0, v4, Lcom/flurry/android/ag;->a Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +015h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/ref/WeakReference;
    invoke-virtual v0, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;
    move-result-object v0
    if-nez v0, -010h
    invoke-interface v1, Ljava/util/Iterator;->remove()V
    goto -15h
    move-exception v0
    monitor-exit v4
    throw v0
    iget-object v0, v4, Lcom/flurry/android/ag;->b Landroid/os/Handler;
    iget-object v1, v4, Lcom/flurry/android/ag;->e Ljava/lang/Runnable;
    invoke-virtual v0, v1, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    iget-object v0, v4, Lcom/flurry/android/ag;->b Landroid/os/Handler;
    iget-object v1, v4, Lcom/flurry/android/ag;->e Ljava/lang/Runnable;
    iget v2, v4, Lcom/flurry/android/ag;->d I
    int-to-long v2, v2
    invoke-virtual v0, v1, v2, v3, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable; J)Z
    monitor-exit v4
    return-void
.end method

.method final synchronized a(Lcom/flurry/android/o;)V
    .registers 4
    monitor-enter v2
    invoke-virtual v3, Lcom/flurry/android/o;->a()V
    iget-object v0, v2, Lcom/flurry/android/ag;->a Ljava/util/List;
    new-instance v1, Ljava/lang/ref/WeakReference;
    invoke-direct v1, v3, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    invoke-interface v0, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    monitor-exit v2
    return-void
    move-exception v0
    monitor-exit v2
    throw v0
.end method
