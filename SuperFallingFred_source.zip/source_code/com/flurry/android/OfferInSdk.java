package com.flurry.android;
public final class OfferInSdk {
    long a;
    com.flurry.android.p b;
    String c;
    String d;
    int e;
    com.flurry.android.AdImage f;

    OfferInSdk(long p1, com.flurry.android.p p3, com.flurry.android.AdImage p4, String p5, String p6, int p7)
    {
        this.a = p1;
        this.b = p3;
        this.c = p5;
        this.f = p4;
        this.d = p6;
        this.e = p7;
        return;
    }

    public final String toString()
    {
        String v0_1 = new StringBuilder();
        v0_1.append(new StringBuilder().append("[id=").append(this.a).toString()).append(new StringBuilder().append(",name=").append(this.c).append("]").toString());
        return v0_1.toString();
    }
}
