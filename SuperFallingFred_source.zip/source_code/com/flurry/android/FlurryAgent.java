package com.flurry.android;
public final class FlurryAgent implements android.location.LocationListener {
    static String a;
    private static final String[] b;
    private static volatile String c;
    private static volatile String d;
    private static volatile String e;
    private static volatile String f;
    private static volatile String g;
    private static final com.flurry.android.FlurryAgent h;
    private static long i;
    private static boolean j;
    private static boolean k;
    private static volatile String kInsecureReportUrl;
    private static volatile String kSecureReportUrl;
    private static boolean l;
    private static boolean m;
    private static android.location.Criteria n;
    private static boolean o;
    private static com.flurry.android.AppCircle p;
    private boolean A;
    private java.util.List B;
    private android.location.LocationManager C;
    private String D;
    private boolean E;
    private long F;
    private java.util.List G;
    private long H;
    private long I;
    private long J;
    private String K;
    private String L;
    private byte M;
    private String N;
    private byte O;
    private Long P;
    private int Q;
    private android.location.Location R;
    private java.util.Map S;
    private java.util.List T;
    private boolean U;
    private int V;
    private java.util.List W;
    private int X;
    private com.flurry.android.u Y;
    private final android.os.Handler q;
    private java.io.File r;
    private java.io.File s;
    private volatile boolean t;
    private volatile boolean u;
    private long v;
    private java.util.Map w;
    private String x;
    private String y;
    private String z;

    static FlurryAgent()
    {
        com.flurry.android.AppCircle v0_10 = new String[2];
        v0_10[0] = "9774d56d682e549c";
        v0_10[1] = "dead00beef";
        com.flurry.android.FlurryAgent.b = v0_10;
        com.flurry.android.FlurryAgent.c = 0;
        com.flurry.android.FlurryAgent.kInsecureReportUrl = "http://data.flurry.com/aap.do";
        com.flurry.android.FlurryAgent.kSecureReportUrl = "https://data.flurry.com/aap.do";
        com.flurry.android.FlurryAgent.d = 0;
        com.flurry.android.FlurryAgent.e = "http://ad.flurry.com/getCanvas.do";
        com.flurry.android.FlurryAgent.f = 0;
        com.flurry.android.FlurryAgent.g = "http://ad.flurry.com/getAndroidApp.do";
        com.flurry.android.FlurryAgent.h = new com.flurry.android.FlurryAgent();
        com.flurry.android.FlurryAgent.i = 10000;
        com.flurry.android.FlurryAgent.j = 1;
        com.flurry.android.FlurryAgent.k = 0;
        com.flurry.android.FlurryAgent.l = 0;
        com.flurry.android.FlurryAgent.m = 1;
        com.flurry.android.FlurryAgent.n = 0;
        com.flurry.android.FlurryAgent.o = 0;
        com.flurry.android.FlurryAgent.p = new com.flurry.android.AppCircle();
        return;
    }

    private FlurryAgent()
    {
        this.s = 0;
        this.t = 0;
        this.u = 0;
        this.w = new java.util.WeakHashMap();
        this.A = 1;
        this.G = new java.util.ArrayList();
        this.K = "";
        this.L = "";
        this.M = -1;
        this.N = "";
        this.O = -1;
        this.S = new java.util.HashMap();
        this.T = new java.util.ArrayList();
        this.W = new java.util.ArrayList();
        this.Y = new com.flurry.android.u();
        android.os.Looper v0_16 = new android.os.HandlerThread("FlurryAgent");
        v0_16.start();
        this.q = new android.os.Handler(v0_16.getLooper());
        return;
    }

    private static double a(double p4)
    {
        return (((double) Math.round((p4 * 4652007308841189376))) / 4652007308841189376);
    }

    static android.view.View a(android.content.Context p4, String p5, int p6)
    {
        android.view.View v0 = 0;
        if (com.flurry.android.FlurryAgent.o) {
            try {
                v0 = com.flurry.android.FlurryAgent.h.Y.a(p4, p5, p6);
            } catch (Throwable v1_3) {
                com.flurry.android.ah.b("FlurryAgent", "", v1_3);
            }
        }
        return v0;
    }

    static com.flurry.android.Offer a(String p1)
    {
        com.flurry.android.Offer v0_3;
        if (com.flurry.android.FlurryAgent.o) {
            v0_3 = com.flurry.android.FlurryAgent.h.Y.b(p1);
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }

    private org.apache.http.client.HttpClient a(org.apache.http.params.HttpParams p7)
    {
        try {
            org.apache.http.impl.client.DefaultHttpClient v0_5 = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType());
            v0_5.load(0, 0);
            org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager v1_4 = new com.flurry.android.ai(this, v0_5);
            org.apache.http.impl.client.DefaultHttpClient v0_1 = new org.apache.http.conn.scheme.SchemeRegistry();
            v0_1.register(new org.apache.http.conn.scheme.Scheme("http", org.apache.http.conn.scheme.PlainSocketFactory.getSocketFactory(), 80));
            v0_1.register(new org.apache.http.conn.scheme.Scheme("https", v1_4, 443));
            org.apache.http.impl.client.DefaultHttpClient v0_3 = new org.apache.http.impl.client.DefaultHttpClient(new org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager(p7, v0_1), p7);
        } catch (org.apache.http.impl.client.DefaultHttpClient v0) {
            v0_3 = new org.apache.http.impl.client.DefaultHttpClient(p7);
        }
        return v0_3;
    }

    private declared_synchronized void a(android.content.Context p9)
    {
        try {
            this.D = this.b(p9);
        } catch (String v0_13) {
            throw v0_13;
        }
        if (!this.s.exists()) {
            com.flurry.android.ah.c("FlurryAgent", "Agent cache file doesn\'t exist.");
        } else {
            com.flurry.android.ah.c("FlurryAgent", new StringBuilder().append("loading persistent data: ").append(this.s.getAbsolutePath()).toString());
            try {
                String v1_14 = new java.io.DataInputStream(new java.io.FileInputStream(this.s));
                try {
                    String v0_19 = v1_14.readUnsignedShort();
                    com.flurry.android.ah.c("FlurryAgent", new StringBuilder().append("Magic: ").append(v0_19).toString());
                } catch (String v0_18) {
                    com.flurry.android.ah.b("FlurryAgent", "Error when loading persistent file", v0_18);
                    com.flurry.android.r.a(v1_14);
                    try {
                        if (!this.u) {
                            if (!this.s.delete()) {
                                com.flurry.android.ah.b("FlurryAgent", "Cannot delete persistence file");
                            } else {
                                com.flurry.android.ah.a("FlurryAgent", "Deleted persistence file");
                            }
                        }
                    } catch (String v0_28) {
                        com.flurry.android.ah.b("FlurryAgent", "", v0_28);
                    }
                }
                if (v0_19 != 46586) {
                    com.flurry.android.ah.a("FlurryAgent", "Unexpected file type");
                } else {
                    this.b(v1_14);
                }
                com.flurry.android.r.a(v1_14);
            } catch (String v0_18) {
                v1_14 = 0;
            } catch (String v0_17) {
                v1_14 = 0;
                com.flurry.android.r.a(v1_14);
                throw v0_17;
            } catch (String v0_17) {
            }
        }
        if (!this.u) {
            this.E = 0;
            this.F = this.H;
            this.u = 1;
        }
        if (this.D == null) {
            this.D = new StringBuilder().append("ID").append(Long.toString((Double.doubleToLongBits(Math.random()) + (37 * (System.nanoTime() + ((long) (this.x.hashCode() * 37))))), 16)).toString();
            com.flurry.android.ah.c("FlurryAgent", new StringBuilder().append("Generated phoneId: ").append(this.D).toString());
        }
        this.Y.a(this.D);
        if ((!this.D.startsWith("AND")) && (!this.r.exists())) {
            this.c(p9, this.D);
        }
        return;
    }

    static void a(android.content.Context p2, long p3)
    {
        if (!com.flurry.android.FlurryAgent.o) {
            com.flurry.android.ah.d("FlurryAgent", "Cannot accept Offer. AppCircle is not enabled");
        }
        com.flurry.android.FlurryAgent.h.Y.a(p2, p3);
        return;
    }

    static void a(android.content.Context p1, String p2)
    {
        if (com.flurry.android.FlurryAgent.o) {
            com.flurry.android.FlurryAgent.h.Y.a(p1, p2);
        }
        return;
    }

    private declared_synchronized void a(android.content.Context p6, boolean p7)
    {
        try {
            if ((p6 != null) && (((android.content.Context) this.w.remove(p6)) == null)) {
                com.flurry.android.ah.d("FlurryAgent", "onEndSession called without context from corresponding onStartSession");
            }
        } catch (int v0_9) {
            throw v0_9;
        }
        if ((this.t) && (this.w.isEmpty())) {
            int v0_4;
            com.flurry.android.ah.a("FlurryAgent", "Ending session");
            this.m();
            if (p6 != null) {
                v0_4 = p6.getApplicationContext();
            } else {
                v0_4 = 0;
            }
            if (p6 != null) {
                com.flurry.android.b v1_1 = v0_4.getPackageName();
                if (!this.y.equals(v1_1)) {
                    com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("onEndSession called from different application package, expected: ").append(this.y).append(" actual: ").append(v1_1).toString());
                }
            }
            com.flurry.android.b v1_4 = android.os.SystemClock.elapsedRealtime();
            this.v = v1_4;
            this.J = (v1_4 - this.I);
            if (this.D == null) {
                com.flurry.android.ah.b("FlurryAgent", "Not creating report because of bad Android ID or generated ID is null");
            }
            this.a(new com.flurry.android.b(this, p7, v0_4));
            this.t = 0;
        }
        return;
    }

    static void a(com.flurry.android.AppCircleCallback p1)
    {
        com.flurry.android.FlurryAgent.h.Y.a(p1);
        return;
    }

    static synthetic void a(com.flurry.android.FlurryAgent p0, android.content.Context p1)
    {
        p0.a(p1);
        return;
    }

    static synthetic void a(com.flurry.android.FlurryAgent p3, android.content.Context p4, boolean p5)
    {
        int v0_0 = 0;
        try {
            if (!p5) {
                p3.R = v0_0;
                if (com.flurry.android.FlurryAgent.o) {
                    p3.Y.c();
                }
                p3.c(1);
            } else {
                v0_0 = p3.d(p4);
            }
        } catch (int v0_2) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_2);
        }
        return;
    }

    private void a(java.io.DataInputStream p15)
    {
        java.util.HashMap v1_1 = new java.util.HashMap();
        java.util.HashMap v4_1 = new java.util.HashMap();
        java.util.HashMap v5_1 = new java.util.HashMap();
        java.util.HashMap v2_1 = new java.util.HashMap();
        java.util.HashMap v3_1 = new java.util.HashMap();
        java.util.HashMap v6_1 = new java.util.HashMap();
        do {
            int v8 = p15.readUnsignedShort();
            int v0_8 = p15.readInt();
            switch (v8) {
                case 258:
                    p15.readInt();
                    break;
                case 259:
                    int v7_0 = p15.readByte();
                    Long v9_2 = p15.readUnsignedShort();
                    Byte v10_0 = new com.flurry.android.v[v9_2];
                    int v0_1 = 0;
                    while (v0_1 < v9_2) {
                        v10_0[v0_1] = new com.flurry.android.v(p15);
                        v0_1++;
                    }
                    v1_1.put(Byte.valueOf(v7_0), v10_0);
                    break;
                case 260:
                case 261:
                case 265:
                case 267:
                default:
                    com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Unknown chunkType: ").append(v8).toString());
                    p15.skipBytes(v0_8);
                    break;
                case 262:
                    int v7_10 = p15.readUnsignedShort();
                    int v0_0 = 0;
                    while (v0_0 < v7_10) {
                        Long v9_17 = new com.flurry.android.AdImage(p15);
                        v4_1.put(Long.valueOf(v9_17.a), v9_17);
                        com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Parsed image: ").append(v9_17.a).toString());
                        v0_0++;
                    }
                    break;
                case 263:
                    int v7_9 = p15.readInt();
                    int v0_21 = 0;
                    while (v0_21 < v7_9) {
                        Long v9_15 = new com.flurry.android.e(p15);
                        v2_1.put(v9_15.a, v9_15);
                        v0_21++;
                    }
                    break;
                case 264:
                    break;
                case 266:
                    int v7_8 = p15.readByte();
                    int v0_20 = 0;
                    while (v0_20 < v7_8) {
                        Long v9_13 = new com.flurry.android.c(p15);
                        v3_1.put(Byte.valueOf(v9_13.a), v9_13);
                        v0_20++;
                    }
                    break;
                case 268:
                    int v7_7 = p15.readInt();
                    int v0_19 = 0;
                    while (v0_19 < v7_7) {
                        v6_1.put(Short.valueOf(p15.readShort()), Long.valueOf(p15.readLong()));
                        v0_19++;
                    }
                    break;
                case 269:
                    p15.skipBytes(v0_8);
                    break;
                case 270:
                    p15.skipBytes(v0_8);
                    break;
                case 271:
                    Long v9_9 = p15.readByte();
                    int v7_6 = 0;
                    while (v7_6 < v9_9) {
                        int v0_17 = ((com.flurry.android.c) v3_1.get(Byte.valueOf(p15.readByte())));
                        if (v0_17 != 0) {
                            v0_17.a(p15);
                        }
                        v7_6++;
                    }
                    break;
                case 272:
                    Long v9_8 = p15.readLong();
                    int v0_11 = ((com.flurry.android.al) v5_1.get(Long.valueOf(v9_8)));
                    if (v0_11 == 0) {
                        v0_11 = new com.flurry.android.al();
                    }
                    v0_11.a = p15.readUTF();
                    v0_11.c = p15.readInt();
                    v5_1.put(Long.valueOf(v9_8), v0_11);
                    break;
                case 273:
                    p15.skipBytes(v0_8);
                    break;
            }
        } while(v8 != 264);
        if (com.flurry.android.FlurryAgent.o) {
            if (v1_1.isEmpty()) {
                com.flurry.android.ah.a("FlurryAgent", "No ads from server");
            }
            this.Y.a(v1_1, v2_1, v3_1, v4_1, v5_1, v6_1);
        }
        return;
    }

    private void a(Runnable p2)
    {
        this.q.post(p2);
        return;
    }

    private declared_synchronized void a(String p4, String p5, String p6)
    {
        try {
            if (this.W != null) {
                this.Q = (this.Q + 1);
                if (this.W.size() < 10) {
                    com.flurry.android.aa v0_2 = new com.flurry.android.aa();
                    v0_2.a = System.currentTimeMillis();
                    v0_2.b = com.flurry.android.r.a(p4, 255);
                    v0_2.c = com.flurry.android.r.a(p5, 512);
                    v0_2.d = com.flurry.android.r.a(p6, 255);
                    this.W.add(v0_2);
                }
            } else {
                com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("onError called before onStartSession.  Error: ").append(p4).toString());
            }
        } catch (com.flurry.android.aa v0_6) {
            throw v0_6;
        }
        return;
    }

    private declared_synchronized void a(String p8, java.util.Map p9, boolean p10)
    {
        try {
            if (this.T != null) {
                String v3_0 = (android.os.SystemClock.elapsedRealtime() - this.I);
                int v1_12 = com.flurry.android.r.a(p8, 255);
                if (v1_12.length() != 0) {
                    int v0_6 = ((com.flurry.android.g) this.S.get(v1_12));
                    if (v0_6 != 0) {
                        v0_6.a = (v0_6.a + 1);
                    } else {
                        if (this.S.size() >= 100) {
                            if (com.flurry.android.ah.a("FlurryAgent")) {
                                com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("MaxEventIds exceeded: ").append(v1_12).toString());
                            }
                        } else {
                            int v0_14 = new com.flurry.android.g();
                            v0_14.a = 1;
                            this.S.put(v1_12, v0_14);
                        }
                    }
                    if ((!com.flurry.android.FlurryAgent.j) || ((this.T.size() >= 200) || (this.V >= 16000))) {
                        this.U = 0;
                    } else {
                        int v2_13;
                        if (p9 != null) {
                            v2_13 = p9;
                        } else {
                            v2_13 = java.util.Collections.emptyMap();
                        }
                        if (v2_13.size() <= 10) {
                            int v0_22 = new com.flurry.android.i(v1_12, v2_13, v3_0, p10);
                            if ((v0_22.b().length + this.V) > 16000) {
                                this.V = 16000;
                                this.U = 0;
                            } else {
                                this.T.add(v0_22);
                                this.V = (v0_22.b().length + this.V);
                            }
                        } else {
                            if (com.flurry.android.ah.a("FlurryAgent")) {
                                com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("MaxEventParams exceeded: ").append(v2_13.size()).toString());
                            }
                        }
                    }
                }
            } else {
                com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("onEvent called before onStartSession.  Event: ").append(p8).toString());
            }
        } catch (int v0_3) {
            throw v0_3;
        }
        return;
    }

    static void a(java.util.List p1)
    {
        if (com.flurry.android.FlurryAgent.o) {
            com.flurry.android.FlurryAgent.h.Y.a(p1);
        }
        return;
    }

    static void a(boolean p1)
    {
        if (com.flurry.android.FlurryAgent.o) {
            com.flurry.android.FlurryAgent.h.Y.a(p1);
        }
        return;
    }

    static boolean a()
    {
        return com.flurry.android.FlurryAgent.h.Y.i();
    }

    static synthetic boolean a(com.flurry.android.FlurryAgent p1)
    {
        return p1.u;
    }

    private static boolean a(java.io.File p4)
    {
        int v0_3;
        int v0_0 = p4.getParentFile();
        if ((v0_0.mkdirs()) || (v0_0.exists())) {
            v0_3 = 1;
        } else {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Unable to create persistent dir: ").append(v0_0).toString());
            v0_3 = 0;
        }
        return v0_3;
    }

    private boolean a(byte[] p6)
    {
        boolean v0_4;
        boolean v0_3 = com.flurry.android.FlurryAgent.k();
        if (v0_3) {
            try {
                v0_4 = this.a(p6, v0_3);
            } catch (boolean v0_6) {
                com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Sending report exception: ").append(v0_6.getMessage()).toString());
                v0_4 = 0;
            }
            if ((!v0_4) && ((com.flurry.android.FlurryAgent.c == null) && ((com.flurry.android.FlurryAgent.k) && (!com.flurry.android.FlurryAgent.l)))) {
                com.flurry.android.FlurryAgent.l = 1;
                String v3_2 = com.flurry.android.FlurryAgent.k();
                if (v3_2 != null) {
                    try {
                        v0_4 = this.a(p6, v3_2);
                    } catch (Exception v1) {
                    }
                } else {
                    v0_4 = 0;
                }
            }
        } else {
            v0_4 = 0;
        }
        return v0_4;
    }

    private boolean a(byte[] p7, String p8)
    {
        Throwable v0_0 = 1;
        if (!"local".equals(p8)) {
            com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Sending report to: ").append(p8).toString());
            java.io.InputStream v2_1 = new org.apache.http.entity.ByteArrayEntity(p7);
            v2_1.setContentType("application/octet-stream");
            java.io.DataInputStream v3_5 = new org.apache.http.client.methods.HttpPost(p8);
            v3_5.setEntity(v2_1);
            java.io.InputStream v2_4 = new org.apache.http.params.BasicHttpParams();
            org.apache.http.params.HttpConnectionParams.setConnectionTimeout(v2_4, 10000);
            org.apache.http.params.HttpConnectionParams.setSoTimeout(v2_4, 15000);
            v3_5.getParams().setBooleanParameter("http.protocol.expect-continue", 0);
            java.io.InputStream v2_6 = this.a(v2_4).execute(v3_5);
            java.io.DataInputStream v3_7 = v2_6.getStatusLine().getStatusCode();
            try {
                if (v3_7 != 200) {
                    com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Report failed. HTTP response: ").append(v3_7).toString());
                    v0_0 = 0;
                } else {
                    com.flurry.android.ah.a("FlurryAgent", "Report successful");
                    this.E = 1;
                    this.G.removeAll(this.B);
                    int v1_4 = v2_6.getEntity();
                    com.flurry.android.ah.a("FlurryAgent", "Processing report response");
                    if ((v1_4 != 0) && (v1_4.getContentLength() != 0)) {
                        try {
                            this.a(new java.io.DataInputStream(v1_4.getContent()));
                        } catch (Throwable v0_2) {
                            v1_4.consumeContent();
                            throw v0_2;
                        }
                        v1_4.consumeContent();
                    }
                }
            } catch (Throwable v0_3) {
                throw v0_3;
            }
            this.B = 0;
        }
        return v0_0;
    }

    public static void addUserCookie(String p1, String p2)
    {
        if (com.flurry.android.FlurryAgent.o) {
            com.flurry.android.FlurryAgent.h.Y.a(p1, p2);
        }
        return;
    }

    static com.flurry.android.u b()
    {
        return com.flurry.android.FlurryAgent.h.Y;
    }

    private String b(android.content.Context p8)
    {
        Throwable v0_0 = 0;
        Throwable v1_0 = 0;
        if (this.D == null) {
            String v3_4 = android.provider.Settings$System.getString(p8.getContentResolver(), "android_id");
            if ((v3_4 != null) && ((v3_4.length() > 0) && (!v3_4.equals("null")))) {
                String v4_0 = com.flurry.android.FlurryAgent.b;
                int v2_3 = 0;
                while (v2_3 < v4_0.length) {
                    if (!v3_4.equals(v4_0[v2_3])) {
                        v2_3++;
                    }
                }
                v1_0 = 1;
            }
            if (v1_0 == null) {
                Throwable v1_2 = p8.getFileStreamPath(".flurryb.");
                if (v1_2.exists()) {
                    try {
                        int v2_7 = new java.io.DataInputStream(new java.io.FileInputStream(v1_2));
                        try {
                            v2_7.readInt();
                            v0_0 = v2_7.readUTF();
                            com.flurry.android.r.a(v2_7);
                        } catch (Throwable v1_4) {
                            com.flurry.android.ah.b("FlurryAgent", "Error when loading b file", v1_4);
                            com.flurry.android.r.a(v2_7);
                        }
                    } catch (Throwable v1_4) {
                        v2_7 = 0;
                    } catch (Throwable v1_3) {
                        v2_7 = 0;
                        Throwable v0_1 = v1_3;
                        com.flurry.android.r.a(v2_7);
                        throw v0_1;
                    } catch (Throwable v0_1) {
                    }
                }
            } else {
                v0_0 = new StringBuilder().append("AND").append(v3_4).toString();
            }
        } else {
            v0_0 = this.D;
        }
        return v0_0;
    }

    static java.util.List b(String p1)
    {
        java.util.List v0_3;
        if (com.flurry.android.FlurryAgent.o) {
            v0_3 = com.flurry.android.FlurryAgent.h.Y.c(p1);
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }

    private declared_synchronized void b(android.content.Context p9, String p10)
    {
        try {
            if ((this.x != null) && (!this.x.equals(p10))) {
                com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("onStartSession called with different api keys: ").append(this.x).append(" and ").append(p10).toString());
            }
        } catch (String v0_42) {
            throw v0_42;
        }
        if (((android.content.Context) this.w.put(p9, p9)) != null) {
            com.flurry.android.ah.d("FlurryAgent", "onStartSession called with duplicate context, use a specific Activity or Service as context instead of using a global context");
        }
        if (!this.t) {
            com.flurry.android.ah.a("FlurryAgent", "Initializing Flurry session");
            this.x = p10;
            this.s = p9.getFileStreamPath(new StringBuilder().append(".flurryagent.").append(Integer.toString(this.x.hashCode(), 16)).toString());
            this.r = p9.getFileStreamPath(".flurryb.");
            if (com.flurry.android.FlurryAgent.m) {
                Thread.setDefaultUncaughtExceptionHandler(new com.flurry.android.FlurryAgent$FlurryDefaultExceptionHandler());
            }
            int v1_15 = p9.getApplicationContext();
            if (this.z == null) {
                this.z = com.flurry.android.FlurryAgent.c(v1_15);
            }
            String v0_64 = v1_15.getPackageName();
            if ((this.y != null) && (!this.y.equals(v0_64))) {
                com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("onStartSession called from different application packages: ").append(this.y).append(" and ").append(v0_64).toString());
            }
            this.y = v0_64;
            String v2_20 = android.os.SystemClock.elapsedRealtime();
            if ((v2_20 - this.v) <= com.flurry.android.FlurryAgent.i) {
                com.flurry.android.ah.a("FlurryAgent", "Continuing previous session");
                if (!this.G.isEmpty()) {
                    this.G.remove((this.G.size() - 1));
                }
            } else {
                com.flurry.android.ah.a("FlurryAgent", "New session");
                this.H = System.currentTimeMillis();
                this.I = v2_20;
                this.J = -1;
                this.N = "";
                this.Q = 0;
                this.R = 0;
                this.L = java.util.TimeZone.getDefault().getID();
                this.K = new StringBuilder().append(java.util.Locale.getDefault().getLanguage()).append("_").append(java.util.Locale.getDefault().getCountry()).toString();
                this.S = new java.util.HashMap();
                this.T = new java.util.ArrayList();
                this.U = 1;
                this.W = new java.util.ArrayList();
                this.V = 0;
                this.X = 0;
                if (com.flurry.android.FlurryAgent.o) {
                    if (!this.Y.b()) {
                        String v0_33;
                        com.flurry.android.ah.a("FlurryAgent", "Initializing AppCircle");
                        String v2_10 = new com.flurry.android.a();
                        v2_10.a = this.x;
                        v2_10.b = this.F;
                        v2_10.c = this.H;
                        v2_10.d = this.I;
                        if (com.flurry.android.FlurryAgent.d == null) {
                            v0_33 = com.flurry.android.FlurryAgent.e;
                        } else {
                            v0_33 = com.flurry.android.FlurryAgent.d;
                        }
                        v2_10.e = v0_33;
                        v2_10.f = com.flurry.android.FlurryAgent.c();
                        v2_10.g = this.q;
                        this.Y.a(p9, v2_10);
                        com.flurry.android.ah.a("FlurryAgent", "AppCircle initialized");
                    }
                    this.Y.a();
                }
                this.a(new com.flurry.android.d(this, v1_15, this.A));
            }
            this.t = 1;
        }
        return;
    }

    static synthetic void b(com.flurry.android.FlurryAgent p0)
    {
        p0.i();
        return;
    }

    static synthetic void b(com.flurry.android.FlurryAgent p5, android.content.Context p6)
    {
        int v0_0 = 0;
        try {
        } catch (int v0_3) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_3);
            return;
        }
        int v1_4 = (android.os.SystemClock.elapsedRealtime() - p5.v);
        if ((!p5.t) && ((v1_4 > com.flurry.android.FlurryAgent.i) && (p5.G.size() > 0))) {
            v0_0 = 1;
        }
        if (v0_0 == 0) {
            return;
        } else {
            p5.c(0);
            return;
        }
    }

    private declared_synchronized void b(java.io.DataInputStream p7)
    {
        int v0_0 = 0;
        try {
            String v1_6 = p7.readUnsignedShort();
            com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("File version: ").append(v1_6).toString());
        } catch (int v0_4) {
            throw v0_4;
        }
        if (v1_6 <= 2) {
            if (v1_6 < 2) {
                com.flurry.android.ah.d("FlurryAgent", new StringBuilder().append("Deleting old file version: ").append(v1_6).toString());
            } else {
                String v1_5 = p7.readUTF();
                com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Loading API key: ").append(this.x).toString());
                if (!v1_5.equals(this.x)) {
                    com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Api keys do not match, old: ").append(v1_5).append(", new: ").append(this.x).toString());
                } else {
                    String v1_11 = p7.readUTF();
                    if (this.D == null) {
                        com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Loading phoneId: ").append(v1_11).toString());
                    }
                    this.D = v1_11;
                    this.E = p7.readBoolean();
                    this.F = p7.readLong();
                    com.flurry.android.ah.a("FlurryAgent", "Loading session reports");
                    while(true) {
                        String v1_15 = p7.readUnsignedShort();
                        if (v1_15 == null) {
                            break;
                        }
                        String v1_17 = new byte[v1_15];
                        p7.readFully(v1_17);
                        this.G.add(0, v1_17);
                        v0_0++;
                        com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Session report added: ").append(v0_0).toString());
                    }
                    com.flurry.android.ah.a("FlurryAgent", "Persistent file loaded");
                    this.u = 1;
                }
            }
            return;
        } else {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Unknown agent file version: ").append(v1_6).toString());
            throw new java.io.IOException(new StringBuilder().append("Unknown agent file version: ").append(v1_6).toString());
        }
    }

    private declared_synchronized byte[] b(boolean p9)
    {
        java.util.List v3_0 = 0;
        try {
            String v4_2 = new java.io.ByteArrayOutputStream();
            int v2_0 = new java.io.DataOutputStream(v4_2);
            try {
                v2_0.writeShort(15);
            } catch (byte[] v0_3) {
                com.flurry.android.ah.b("FlurryAgent", "Error when generating report", v0_3);
                com.flurry.android.r.a(v2_0);
                byte[] v0_5 = 0;
                return v0_5;
            }
            if ((!com.flurry.android.FlurryAgent.o) || (!p9)) {
                v2_0.writeShort(0);
            } else {
                v2_0.writeShort(1);
            }
            if (!com.flurry.android.FlurryAgent.o) {
                v2_0.writeLong(0);
                v2_0.writeShort(0);
            } else {
                v2_0.writeLong(this.Y.e());
                byte[] v0_17 = this.Y.f();
                v2_0.writeShort(v0_17.size());
                int v5_3 = v0_17.iterator();
                while (v5_3.hasNext()) {
                    long v6 = ((Long) v5_3.next()).longValue();
                    v2_0.writeByte(1);
                    v2_0.writeLong(v6);
                }
            }
            v2_0.writeShort(3);
            v2_0.writeShort(117);
            v2_0.writeLong(System.currentTimeMillis());
            v2_0.writeUTF(this.x);
            v2_0.writeUTF(this.z);
            v2_0.writeShort(0);
            v2_0.writeUTF(this.D);
            v2_0.writeLong(this.F);
            v2_0.writeLong(this.H);
            v2_0.writeShort(6);
            v2_0.writeUTF("device.model");
            v2_0.writeUTF(android.os.Build.MODEL);
            v2_0.writeUTF("build.brand");
            v2_0.writeUTF(android.os.Build.BRAND);
            v2_0.writeUTF("build.id");
            v2_0.writeUTF(android.os.Build.ID);
            v2_0.writeUTF("version.release");
            v2_0.writeUTF(android.os.Build$VERSION.RELEASE);
            v2_0.writeUTF("build.device");
            v2_0.writeUTF(android.os.Build.DEVICE);
            v2_0.writeUTF("build.product");
            v2_0.writeUTF(android.os.Build.PRODUCT);
            int v5_7 = this.G.size();
            v2_0.writeShort(v5_7);
            while (v3_0 < v5_7) {
                v2_0.write(((byte[]) this.G.get(v3_0)));
                v3_0++;
            }
            this.B = new java.util.ArrayList(this.G);
            v2_0.close();
            v0_5 = v4_2.toByteArray();
            com.flurry.android.r.a(v2_0);
            return v0_5;
        } catch (byte[] v0_3) {
            v2_0 = 0;
        } catch (byte[] v0_4) {
            v2_0 = 0;
            com.flurry.android.r.a(v2_0);
            throw v0_4;
        } catch (byte[] v0_4) {
        } catch (byte[] v0_6) {
            throw v0_6;
        }
    }

    static String c()
    {
        String v0_1;
        if (com.flurry.android.FlurryAgent.f == null) {
            v0_1 = com.flurry.android.FlurryAgent.g;
        } else {
            v0_1 = com.flurry.android.FlurryAgent.f;
        }
        return v0_1;
    }

    private static String c(android.content.Context p3)
    {
        try {
            String v0_2;
            String v0_4 = p3.getPackageManager().getPackageInfo(p3.getPackageName(), 0);
        } catch (String v0_3) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_3);
            v0_2 = "Unknown";
            return v0_2;
        }
        if (v0_4.versionName == null) {
            if (v0_4.versionCode == 0) {
            } else {
                v0_2 = Integer.toString(v0_4.versionCode);
                return v0_2;
            }
        } else {
            v0_2 = v0_4.versionName;
            return v0_2;
        }
    }

    private declared_synchronized void c(android.content.Context p5, String p6)
    {
        try {
            this.r = p5.getFileStreamPath(".flurryb.");
        } catch (Throwable v0_6) {
            throw v0_6;
        }
        if (com.flurry.android.FlurryAgent.a(this.r)) {
            try {
                int v1_2 = new java.io.DataOutputStream(new java.io.FileOutputStream(this.r));
                try {
                    v1_2.writeInt(1);
                    v1_2.writeUTF(p6);
                } catch (Throwable v0_4) {
                    com.flurry.android.ah.b("FlurryAgent", "Error when saving b file", v0_4);
                    com.flurry.android.r.a(v1_2);
                }
                com.flurry.android.r.a(v1_2);
            } catch (Throwable v0_4) {
                v1_2 = 0;
            } catch (Throwable v0_3) {
                com.flurry.android.r.a(v1_2);
                throw v0_3;
            }
        }
        return;
    }

    static synthetic void c(com.flurry.android.FlurryAgent p0)
    {
        p0.l();
        return;
    }

    private declared_synchronized void c(String p4)
    {
        try {
            java.util.Iterator v1 = this.T.iterator();
        } catch (com.flurry.android.i v0_1) {
            throw v0_1;
        }
        while (v1.hasNext()) {
            com.flurry.android.i v0_4 = ((com.flurry.android.i) v1.next());
            if (v0_4.a(p4)) {
                v0_4.a();
                break;
            }
        }
        return;
    }

    private void c(boolean p4)
    {
        try {
            com.flurry.android.ah.a("FlurryAgent", "generating report");
            String v0_11 = this.b(p4);
        } catch (String v0_10) {
            com.flurry.android.ah.a("FlurryAgent", "", v0_10);
            return;
        } catch (String v0_9) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_9);
            return;
        }
        if (v0_11 == null) {
            com.flurry.android.ah.a("FlurryAgent", "Error generating report");
            return;
        } else {
            if (!this.a(v0_11)) {
                return;
            } else {
                String v0_5;
                StringBuilder vtmp7 = new StringBuilder().append("Done sending ");
                if (!this.t) {
                    v0_5 = "";
                } else {
                    v0_5 = "initial ";
                }
                com.flurry.android.ah.a("FlurryAgent", vtmp7.append(v0_5).append("agent report").toString());
                this.l();
                return;
            }
        }
    }

    public static void clearUserCookies()
    {
        if (com.flurry.android.FlurryAgent.o) {
            com.flurry.android.FlurryAgent.h.Y.l();
        }
        return;
    }

    private android.location.Location d(android.content.Context p8)
    {
        if ((p8.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") != 0) && (p8.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0)) {
            android.location.Location v0_5 = 0;
        } else {
            android.location.Location v0_2 = ((android.location.LocationManager) p8.getSystemService("location"));
            try {
                if (this.C != null) {
                    v0_2 = this.C;
                } else {
                    this.C = v0_2;
                }
            } catch (android.location.Location v0_3) {
                throw v0_3;
            }
            String v1_1 = com.flurry.android.FlurryAgent.n;
            if (v1_1 == null) {
                v1_1 = new android.location.Criteria();
            }
            String v1_3 = v0_2.getBestProvider(v1_1, 1);
            if (v1_3 == null) {
            } else {
                v0_2.requestLocationUpdates(v1_3, 0, 0, this, android.os.Looper.getMainLooper());
                v0_5 = v0_2.getLastKnownLocation(v1_3);
            }
        }
        return v0_5;
    }

    static synthetic android.os.Handler d(com.flurry.android.FlurryAgent p1)
    {
        return p1.q;
    }

    static boolean d()
    {
        boolean v0_3;
        if (com.flurry.android.FlurryAgent.o) {
            v0_3 = com.flurry.android.FlurryAgent.h.Y.n();
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }

    static synthetic com.flurry.android.u e(com.flurry.android.FlurryAgent p1)
    {
        return p1.Y;
    }

    static String e()
    {
        return com.flurry.android.FlurryAgent.h.x;
    }

    public static void enableAppCircle()
    {
        com.flurry.android.FlurryAgent.o = 1;
        return;
    }

    public static void endTimedEvent(String p4)
    {
        try {
            com.flurry.android.FlurryAgent.h.c(p4);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Failed to signify the end of event: ").append(p4).toString(), v0_1);
        }
        return;
    }

    static synthetic com.flurry.android.FlurryAgent f()
    {
        return com.flurry.android.FlurryAgent.h;
    }

    static synthetic long g()
    {
        return com.flurry.android.FlurryAgent.i;
    }

    public static int getAgentVersion()
    {
        return 117;
    }

    public static com.flurry.android.AppCircle getAppCircle()
    {
        return com.flurry.android.FlurryAgent.p;
    }

    public static boolean getForbidPlaintextFallback()
    {
        return 0;
    }

    public static String getPhoneId()
    {
        return com.flurry.android.FlurryAgent.h.n();
    }

    static synthetic boolean h()
    {
        return com.flurry.android.FlurryAgent.o;
    }

    private declared_synchronized void i()
    {
        byte[] v1_0 = 0;
        try {
            String v3_2 = new java.io.ByteArrayOutputStream();
            String v2_1 = new java.io.DataOutputStream(v3_2);
            try {
                com.flurry.android.p v0_31;
                v2_1.writeShort(1);
                v2_1.writeUTF(this.z);
                v2_1.writeLong(this.H);
                v2_1.writeLong(this.J);
                v2_1.writeLong(0);
                v2_1.writeUTF(this.K);
                v2_1.writeUTF(this.L);
                v2_1.writeByte(this.M);
            } catch (com.flurry.android.p v0_19) {
                v1_0 = v2_1;
                try {
                    com.flurry.android.ah.b("FlurryAgent", "", v0_19);
                } catch (com.flurry.android.p v0_18) {
                    v2_1 = v1_0;
                    com.flurry.android.r.a(v2_1);
                    throw v0_18;
                }
                com.flurry.android.r.a(v1_0);
                return;
            } catch (com.flurry.android.p v0_18) {
            }
            if (this.N != null) {
                v0_31 = this.N;
            } else {
                v0_31 = "";
            }
            v2_1.writeUTF(v0_31);
            if (this.R != null) {
                v2_1.writeBoolean(1);
                v2_1.writeDouble(com.flurry.android.FlurryAgent.a(this.R.getLatitude()));
                v2_1.writeDouble(com.flurry.android.FlurryAgent.a(this.R.getLongitude()));
                v2_1.writeFloat(this.R.getAccuracy());
            } else {
                v2_1.writeBoolean(0);
            }
            v2_1.writeInt(this.X);
            v2_1.writeByte(-1);
            v2_1.writeByte(-1);
            v2_1.writeByte(this.O);
            if (this.P != null) {
                v2_1.writeBoolean(1);
                v2_1.writeLong(this.P.longValue());
            } else {
                v2_1.writeBoolean(0);
            }
            v2_1.writeShort(this.S.size());
            String v4_3 = this.S.entrySet().iterator();
            while (v4_3.hasNext()) {
                com.flurry.android.p v0_23 = ((java.util.Map$Entry) v4_3.next());
                v2_1.writeUTF(((String) v0_23.getKey()));
                v2_1.writeInt(((com.flurry.android.g) v0_23.getValue()).a);
            }
            v2_1.writeShort(this.T.size());
            byte[] v1_7 = this.T.iterator();
            while (v1_7.hasNext()) {
                v2_1.write(((com.flurry.android.i) v1_7.next()).b());
            }
            v2_1.writeBoolean(this.U);
            v2_1.writeInt(this.Q);
            v2_1.writeShort(this.W.size());
            byte[] v1_1 = this.W.iterator();
            while (v1_1.hasNext()) {
                com.flurry.android.p v0_12 = ((com.flurry.android.aa) v1_1.next());
                v2_1.writeLong(v0_12.a);
                v2_1.writeUTF(v0_12.b);
                v2_1.writeUTF(v0_12.c);
                v2_1.writeUTF(v0_12.d);
            }
            if (!com.flurry.android.FlurryAgent.o) {
                v2_1.writeShort(0);
            } else {
                com.flurry.android.p v0_5 = this.Y.g();
                v2_1.writeShort(v0_5.size());
                byte[] v1_3 = v0_5.iterator();
                while (v1_3.hasNext()) {
                    ((com.flurry.android.p) v1_3.next()).a(v2_1);
                }
            }
            this.G.add(v3_2.toByteArray());
            com.flurry.android.r.a(v2_1);
            return;
        } catch (com.flurry.android.p v0_19) {
        } catch (com.flurry.android.p v0_18) {
            v2_1 = 0;
        } catch (com.flurry.android.p v0_20) {
            throw v0_20;
        }
    }

    protected static boolean isCaptureUncaughtExceptions()
    {
        return com.flurry.android.FlurryAgent.m;
    }

    private declared_synchronized void j()
    {
        try {
            this.X = (this.X + 1);
            return;
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    private static String k()
    {
        String v0_3;
        if (com.flurry.android.FlurryAgent.c == null) {
            if (!com.flurry.android.FlurryAgent.l) {
                if (!com.flurry.android.FlurryAgent.k) {
                    v0_3 = com.flurry.android.FlurryAgent.kInsecureReportUrl;
                } else {
                    v0_3 = com.flurry.android.FlurryAgent.kSecureReportUrl;
                }
            } else {
                v0_3 = com.flurry.android.FlurryAgent.kInsecureReportUrl;
            }
        } else {
            v0_3 = com.flurry.android.FlurryAgent.c;
        }
        return v0_3;
    }

    private declared_synchronized void l()
    {
        try {
            if (com.flurry.android.FlurryAgent.a(this.s)) {
                java.io.DataOutputStream v1_0 = new java.io.DataOutputStream(new java.io.FileOutputStream(this.s));
                try {
                    v1_0.writeShort(46586);
                    v1_0.writeShort(2);
                    v1_0.writeUTF(this.x);
                    v1_0.writeUTF(this.D);
                    v1_0.writeBoolean(this.E);
                    v1_0.writeLong(this.F);
                    int v2_2 = (this.G.size() - 1);
                } catch (int v0_3) {
                    com.flurry.android.ah.b("FlurryAgent", "", v0_3);
                    com.flurry.android.r.a(v1_0);
                }
                while (v2_2 >= 0) {
                    int v0_14 = ((byte[]) this.G.get(v2_2));
                    StringBuilder v3_0 = v0_14.length;
                    if (((v3_0 + 2) + v1_0.size()) <= 50000) {
                        v1_0.writeShort(v3_0);
                        v1_0.write(v0_14);
                        v2_2--;
                    } else {
                        com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("discarded sessions: ").append(v2_2).toString());
                        break;
                    }
                }
                v1_0.writeShort(0);
                com.flurry.android.r.a(v1_0);
            } else {
                com.flurry.android.r.a(0);
            }
        } catch (int v0_3) {
            v1_0 = 0;
        } catch (int v0_21) {
            throw v0_21;
        } catch (int v0_2) {
            com.flurry.android.r.a(v1_0);
            throw v0_2;
        }
        return;
    }

    public static void logEvent(String p4)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p4, 0, 0);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Failed to log event: ").append(p4).toString(), v0_1);
        }
        return;
    }

    public static void logEvent(String p4, java.util.Map p5)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p4, p5, 0);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Failed to log event: ").append(p4).toString(), v0_1);
        }
        return;
    }

    public static void logEvent(String p4, java.util.Map p5, boolean p6)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p4, p5, p6);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Failed to log event: ").append(p4).toString(), v0_1);
        }
        return;
    }

    public static void logEvent(String p4, boolean p5)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p4, 0, p5);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Failed to log event: ").append(p4).toString(), v0_1);
        }
        return;
    }

    private declared_synchronized void m()
    {
        try {
            if (this.C != null) {
                this.C.removeUpdates(this);
            }
        } catch (android.location.LocationManager v0_2) {
            throw v0_2;
        }
        return;
    }

    private declared_synchronized String n()
    {
        try {
            return this.D;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    public static void onEndSession(android.content.Context p3)
    {
        if (p3 != null) {
            try {
                com.flurry.android.FlurryAgent.h.a(p3, 0);
            } catch (Throwable v0_2) {
                com.flurry.android.ah.b("FlurryAgent", "", v0_2);
            }
            return;
        } else {
            throw new NullPointerException("Null context");
        }
    }

    public static void onError(String p3, String p4, String p5)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p3, p4, p5);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_1);
        }
        return;
    }

    public static void onEvent(String p3)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p3, 0, 0);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_1);
        }
        return;
    }

    public static void onEvent(String p3, java.util.Map p4)
    {
        try {
            com.flurry.android.FlurryAgent.h.a(p3, p4, 0);
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_1);
        }
        return;
    }

    public static void onPageView()
    {
        try {
            com.flurry.android.FlurryAgent.h.j();
        } catch (Throwable v0_1) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_1);
        }
        return;
    }

    public static void onStartSession(android.content.Context p3, String p4)
    {
        if (p3 != null) {
            if ((p4 != null) && (p4.length() != 0)) {
                try {
                    com.flurry.android.FlurryAgent.h.b(p3, p4);
                } catch (Throwable v0_6) {
                    com.flurry.android.ah.b("FlurryAgent", "", v0_6);
                }
                return;
            } else {
                throw new IllegalArgumentException("Api key not specified");
            }
        } else {
            throw new NullPointerException("Null context");
        }
    }

    public static void setAge(int p7)
    {
        if ((p7 > 0) && (p7 < 110)) {
            com.flurry.android.FlurryAgent.h.P = Long.valueOf(new java.util.Date(new java.util.Date((System.currentTimeMillis() - (((long) p7) * 31449600000))).getYear(), 1, 1).getTime());
        }
        return;
    }

    public static void setCanvasUrl(String p0)
    {
        com.flurry.android.FlurryAgent.d = p0;
        return;
    }

    public static void setCaptureUncaughtExceptions(boolean p3)
    {
        try {
            if (!com.flurry.android.FlurryAgent.h.t) {
                com.flurry.android.FlurryAgent.m = p3;
            } else {
                com.flurry.android.ah.b("FlurryAgent", "Cannot setCaptureUncaughtExceptions after onSessionStart");
            }
        } catch (String v0_3) {
            throw v0_3;
        }
        return;
    }

    public static void setCatalogIntentName(String p0)
    {
        com.flurry.android.FlurryAgent.a = p0;
        return;
    }

    public static void setContinueSessionMillis(long p3)
    {
        if (p3 >= 5000) {
            try {
                com.flurry.android.FlurryAgent.i = p3;
            } catch (Throwable v0_2) {
                throw v0_2;
            }
        } else {
            com.flurry.android.ah.b("FlurryAgent", new StringBuilder().append("Invalid time set for session resumption: ").append(p3).toString());
        }
        return;
    }

    public static void setDefaultNoAdsMessage(String p1)
    {
        if (com.flurry.android.FlurryAgent.o) {
            if (p1 == null) {
                p1 = "";
            }
            com.flurry.android.u.b = p1;
        }
        return;
    }

    public static void setGender(byte p2)
    {
        switch (p2) {
            case 0:
            case 1:
                com.flurry.android.FlurryAgent.h.O = p2;
                break;
            default:
                com.flurry.android.FlurryAgent.h.O = -1;
        }
        return;
    }

    public static void setGetAppUrl(String p0)
    {
        com.flurry.android.FlurryAgent.f = p0;
        return;
    }

    public static void setLocationCriteria(android.location.Criteria p2)
    {
        try {
            com.flurry.android.FlurryAgent.n = p2;
            return;
        } catch (Throwable v0) {
            throw v0;
        }
    }

    public static void setLogEnabled(boolean p2)
    {
        try {
            if (!p2) {
                com.flurry.android.ah.a();
            } else {
                com.flurry.android.ah.b();
            }
        } catch (Throwable v0) {
            throw v0;
        }
        return;
    }

    public static void setLogEvents(boolean p2)
    {
        try {
            com.flurry.android.FlurryAgent.j = p2;
            return;
        } catch (Throwable v0) {
            throw v0;
        }
    }

    public static void setLogLevel(int p2)
    {
        try {
            com.flurry.android.ah.a(p2);
            return;
        } catch (Throwable v0) {
            throw v0;
        }
    }

    public static void setReportLocation(boolean p2)
    {
        try {
            com.flurry.android.FlurryAgent.h.A = p2;
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    public static void setReportUrl(String p0)
    {
        com.flurry.android.FlurryAgent.c = p0;
        return;
    }

    public static void setUseHttps(boolean p0)
    {
        com.flurry.android.FlurryAgent.k = p0;
        return;
    }

    public static void setUserId(String p3)
    {
        try {
            com.flurry.android.FlurryAgent.h.N = com.flurry.android.r.a(p3, 255);
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    public static void setVersionName(String p2)
    {
        try {
            com.flurry.android.FlurryAgent.h.z = p2;
            return;
        } catch (Throwable v0_1) {
            throw v0_1;
        }
    }

    final void a(Throwable p5)
    {
        p5.printStackTrace();
        String v0_0 = "";
        int v1_2 = p5.getStackTrace();
        if ((v1_2 == 0) || (v1_2.length <= 0)) {
            if (p5.getMessage() != null) {
                v0_0 = p5.getMessage();
            }
        } else {
            String v0_2 = v1_2[0];
            int v1_1 = new StringBuilder();
            v1_1.append(v0_2.getClassName()).append(".").append(v0_2.getMethodName()).append(":").append(v0_2.getLineNumber());
            if (p5.getMessage() != null) {
                v1_1.append(new StringBuilder().append(" (").append(p5.getMessage()).append(")").toString());
            }
            v0_0 = v1_1.toString();
        }
        com.flurry.android.FlurryAgent.onError("uncaught", v0_0, p5.getClass().toString());
        this.w.clear();
        this.a(0, 1);
        return;
    }

    public final declared_synchronized void onLocationChanged(android.location.Location p4)
    {
        try {
            this.R = p4;
            this.m();
        } catch (Throwable v0_0) {
            com.flurry.android.ah.b("FlurryAgent", "", v0_0);
        } catch (Throwable v0_1) {
            throw v0_1;
        }
        return;
    }

    public final void onProviderDisabled(String p1)
    {
        return;
    }

    public final void onProviderEnabled(String p1)
    {
        return;
    }

    public final void onStatusChanged(String p1, int p2, android.os.Bundle p3)
    {
        return;
    }
}
