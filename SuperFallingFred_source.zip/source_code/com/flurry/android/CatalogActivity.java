package com.flurry.android;
public class CatalogActivity extends android.app.Activity implements android.view.View$OnClickListener {
    private static volatile String a;
    private android.webkit.WebView b;
    private com.flurry.android.w c;
    private java.util.List d;
    private com.flurry.android.u e;
    private com.flurry.android.p f;

    static CatalogActivity()
    {
        com.flurry.android.CatalogActivity.a = "<html><body><table height=\'100%\' width=\'100%\' border=\'0\'><tr><td style=\'vertical-align:middle;text-align:center\'>No recommendations available<p><button type=\'input\' onClick=\'activity.finish()\'>Back</button></td></tr></table></body></html>";
        return;
    }

    public CatalogActivity()
    {
        this.d = new java.util.ArrayList();
        return;
    }

    static synthetic com.flurry.android.p a(com.flurry.android.CatalogActivity p1)
    {
        return p1.f;
    }

    private void a(com.flurry.android.x p4)
    {
        try {
            this.b.loadUrl(p4.b);
            this.c.a(p4.c);
        } catch (String v0) {
            com.flurry.android.ah.a("FlurryAgent", new StringBuilder().append("Error loading url: ").append(p4.b).toString());
        }
        return;
    }

    static synthetic long b(com.flurry.android.CatalogActivity p2)
    {
        return p2.e.k();
    }

    static synthetic com.flurry.android.u c(com.flurry.android.CatalogActivity p1)
    {
        return p1.e;
    }

    public void finish()
    {
        super.finish();
        return;
    }

    public void onClick(android.view.View p8)
    {
        if (!(p8 instanceof com.flurry.android.y)) {
            if (p8.getId() != 10000) {
                if (p8.getId() != 10002) {
                    if (!this.d.isEmpty()) {
                        this.a(((com.flurry.android.x) this.d.remove((this.d.size() - 1))));
                    } else {
                        this.finish();
                    }
                } else {
                    this.c.a();
                }
            } else {
                this.finish();
            }
        } else {
            com.flurry.android.x v0_8 = new com.flurry.android.x();
            v0_8.a = this.f;
            v0_8.b = this.b.getUrl();
            v0_8.c = new java.util.ArrayList(this.c.b());
            this.d.add(v0_8);
            if (this.d.size() > 5) {
                this.d.remove(0);
            }
            int v1_13 = new com.flurry.android.x();
            android.content.Context v2_4 = ((com.flurry.android.y) p8).b(this.e.j());
            this.f = ((com.flurry.android.y) p8).a();
            v1_13.a = ((com.flurry.android.y) p8).a();
            v1_13.a.a(new com.flurry.android.f(4, this.e.k()));
            v1_13.b = v2_4;
            v1_13.c = this.c.a(p8.getContext());
            this.a(v1_13);
        }
        return;
    }

    protected void onCreate(android.os.Bundle p10)
    {
        this.setTheme(16973839);
        super.onCreate(p10);
        this.e = com.flurry.android.FlurryAgent.b();
        android.webkit.WebView v0_2 = this.getIntent();
        if (v0_2.getExtras() != null) {
            android.webkit.WebView v0_4 = Long.valueOf(v0_2.getExtras().getLong("o"));
            if (v0_4 != null) {
                this.f = this.e.b(v0_4.longValue());
            }
        }
        android.webkit.WebView v0_7 = new com.flurry.android.ab(this, this);
        v0_7.setId(1);
        v0_7.setBackgroundColor(-16777216);
        this.b = new android.webkit.WebView(this);
        this.b.setId(2);
        this.b.setScrollBarStyle(0);
        this.b.setBackgroundColor(-1);
        if (this.f != null) {
            this.b.setWebViewClient(new com.flurry.android.q(this));
        }
        android.webkit.WebView v0_0;
        this.b.getSettings().setJavaScriptEnabled(1);
        this.b.addJavascriptInterface(this, "activity");
        this.c = new com.flurry.android.w(this, this);
        this.c.setId(3);
        android.widget.RelativeLayout v6_2 = new android.widget.RelativeLayout(this);
        v6_2.setLayoutParams(new android.view.ViewGroup$LayoutParams(-1, -1));
        String v2_23 = new android.widget.RelativeLayout$LayoutParams(-1, -2);
        v2_23.addRule(10, v0_7.getId());
        v6_2.addView(v0_7, v2_23);
        String v2_25 = new android.widget.RelativeLayout$LayoutParams(-1, -2);
        v2_25.addRule(3, v0_7.getId());
        v2_25.addRule(2, this.c.getId());
        v6_2.addView(this.b, v2_25);
        String v2_27 = new android.widget.RelativeLayout$LayoutParams(-1, -2);
        v2_27.addRule(12, v0_7.getId());
        v6_2.addView(this.c, v2_27);
        android.webkit.WebView v0_13 = this.getIntent().getExtras();
        if (v0_13 != null) {
            v0_0 = v0_13.getString("u");
        } else {
            v0_0 = 0;
        }
        if (v0_0 != null) {
            this.b.loadUrl(v0_0);
        } else {
            this.b.loadDataWithBaseURL(0, com.flurry.android.CatalogActivity.a, "text/html", "utf-8", 0);
        }
        this.setContentView(v6_2);
        return;
    }

    protected void onDestroy()
    {
        this.e.h();
        super.onDestroy();
        return;
    }
}
