.class final Lcom/flurry/android/f;
.super Ljava/lang/Object;

.field final a:B
.field final b:J

.method constructor <init>(B J)V
    .registers 4
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-byte v1, v0, Lcom/flurry/android/f;->a B
    iput-wide v2, v0, Lcom/flurry/android/f;->b J
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 4
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "["
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-wide v1, v3, Lcom/flurry/android/f;->b J
    invoke-virtual v0, v1, v2, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "] "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-byte v1, v3, Lcom/flurry/android/f;->a B
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
