.class final Lcom/flurry/android/w;
.super Landroid/widget/LinearLayout;

.field private a:Landroid/view/View;
.field private b:Ljava/util/List;
.field private c:Z
.field private synthetic d:Lcom/flurry/android/CatalogActivity;

.method public constructor <init>(Lcom/flurry/android/CatalogActivity; Landroid/content/Context;)V
    .registers 5
    const/4 v1, 1
    iput-object v3, v2, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-direct v2, v4, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v2, Lcom/flurry/android/w;->b Ljava/util/List;
    iput-boolean v1, v2, Lcom/flurry/android/w;->c Z
    invoke-virtual v2, v1, Lcom/flurry/android/w;->setOrientation(I)V
    const/16 v0, 48
    invoke-virtual v2, v0, Lcom/flurry/android/w;->setGravity(I)V
    new-instance v0, Lcom/flurry/android/s;
    invoke-direct v0, v3, v4, Lcom/flurry/android/s;-><init>(Lcom/flurry/android/CatalogActivity; Landroid/content/Context;)V
    iput-object v0, v2, Lcom/flurry/android/w;->a Landroid/view/View;
    iget-object v0, v2, Lcom/flurry/android/w;->a Landroid/view/View;
    const/16 v1, 10002
    invoke-virtual v0, v1, Landroid/view/View;->setId(I)V
    iget-object v0, v2, Lcom/flurry/android/w;->a Landroid/view/View;
    invoke-virtual v0, v3, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    invoke-virtual v2, v4, Lcom/flurry/android/w;->a(Landroid/content/Context;)Ljava/util/List;
    move-result-object v0
    iget-boolean v1, v2, Lcom/flurry/android/w;->c Z
    invoke-direct v2, v0, v1, Lcom/flurry/android/w;->a(Ljava/util/List; Z)V
    return-void
.end method

.method private a(Ljava/util/List; Z)V
    .registers 10
    const/4 v3, 0
    invoke-virtual v7, Lcom/flurry/android/w;->removeAllViews()V
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;
    const/4 v0, -1
    const/4 v2, -2
    invoke-direct v1, v0, v2, Landroid/widget/LinearLayout$LayoutParams;-><init>(I I)V
    invoke-virtual v1, v3, v3, v3, v3, Landroid/widget/LinearLayout$LayoutParams;->setMargins(I I I I)V
    iget-object v0, v7, Lcom/flurry/android/w;->a Landroid/view/View;
    invoke-virtual v7, v0, v1, Lcom/flurry/android/w;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    if-eqz v8, +00ch
    iget-object v0, v7, Lcom/flurry/android/w;->b Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->clear()V
    iget-object v0, v7, Lcom/flurry/android/w;->b Ljava/util/List;
    invoke-interface v0, v8, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    if-eqz v9, +02bh
    iget-object v0, v7, Lcom/flurry/android/w;->b Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01fh
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/y;
    invoke-virtual v7, v0, v1, Lcom/flurry/android/w;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v0, Lcom/flurry/android/y;->a()Lcom/flurry/android/p;
    move-result-object v0
    new-instance v3, Lcom/flurry/android/f;
    const/4 v4, 3
    iget-object v5, v7, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-static v5, Lcom/flurry/android/CatalogActivity;->b(Lcom/flurry/android/CatalogActivity;)J
    move-result-wide v5
    invoke-direct v3, v4, v5, v6, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v0, v3, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    goto -22h
    invoke-virtual v7, Lcom/flurry/android/w;->refreshDrawableState()V
    return-void
.end method

.method final a(Landroid/content/Context;)Ljava/util/List;
    .registers 8
    const/4 v3, 0
    const/4 v4, 1
    new-instance v2, Ljava/util/ArrayList;
    invoke-direct v2, Ljava/util/ArrayList;-><init>()V
    move v0, v4
    const/4 v1, 3
    if-gt v0, v1, +01bh
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Flurry_Canvas_Hook_"
    invoke-virtual v1, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-interface v2, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    add-int/lit8 v0, v0, 1
    goto -1bh
    iget-object v0, v6, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v0
    if-nez v0, +027h
    move-object v0, v3
    if-nez v0, +02dh
    iget-object v0, v6, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->c(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/u;
    move-result-object v0
    move-object v1, v7
    move v5, v4
    invoke-virtual/range v0 ... v5, Lcom/flurry/android/u;->a(Landroid/content/Context; Ljava/util/List; Ljava/lang/Long; I Z)Ljava/util/List;
    move-result-object v1
    invoke-interface v1, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01eh
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/flurry/android/y;
    iget-object v3, v6, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-virtual v0, v3, Lcom/flurry/android/y;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    goto -11h
    iget-object v0, v6, Lcom/flurry/android/w;->d Lcom/flurry/android/CatalogActivity;
    invoke-static v0, Lcom/flurry/android/CatalogActivity;->a(Lcom/flurry/android/CatalogActivity;)Lcom/flurry/android/p;
    move-result-object v0
    iget-object v0, v0, Lcom/flurry/android/p;->b Lcom/flurry/android/v;
    goto -2ch
    iget-wide v0, v0, Lcom/flurry/android/v;->a J
    invoke-static v0, v1, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v3
    goto -31h
    return-object v1
.end method

.method final a()V
    .registers 3
    iget-boolean v0, v2, Lcom/flurry/android/w;->c Z
    if-nez v0, +00ch
    const/4 v0, 1
    iput-boolean v0, v2, Lcom/flurry/android/w;->c Z
    const/4 v0, 0
    iget-boolean v1, v2, Lcom/flurry/android/w;->c Z
    invoke-direct v2, v0, v1, Lcom/flurry/android/w;->a(Ljava/util/List; Z)V
    return-void
    const/4 v0, 0
    goto -ah
.end method

.method final a(Ljava/util/List;)V
    .registers 3
    iget-boolean v0, v1, Lcom/flurry/android/w;->c Z
    invoke-direct v1, v2, v0, Lcom/flurry/android/w;->a(Ljava/util/List; Z)V
    return-void
.end method

.method final b()Ljava/util/List;
    .registers 2
    iget-object v0, v1, Lcom/flurry/android/w;->b Ljava/util/List;
    return-object v0
.end method
