.class final Lcom/flurry/android/m;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/lang/String;
.field private synthetic b:Lcom/flurry/android/ak;

.method constructor <init>(Lcom/flurry/android/ak; Ljava/lang/String;)V
    .registers 3
    iput-object v1, v0, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iput-object v2, v0, Lcom/flurry/android/m;->a Ljava/lang/String;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 6
    iget-object v0, v5, Lcom/flurry/android/m;->a Ljava/lang/String;
    if-eqz v0, +026h
    iget-object v0, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v0, v0, Lcom/flurry/android/ak;->d Lcom/flurry/android/u;
    iget-object v1, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v1, v1, Lcom/flurry/android/ak;->b Landroid/content/Context;
    iget-object v2, v5, Lcom/flurry/android/m;->a Ljava/lang/String;
    invoke-static v0, v1, v2, Lcom/flurry/android/u;->a(Lcom/flurry/android/u; Landroid/content/Context; Ljava/lang/String;)V
    iget-object v0, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v0, v0, Lcom/flurry/android/ak;->c Lcom/flurry/android/p;
    new-instance v1, Lcom/flurry/android/f;
    const/16 v2, 8
    iget-object v3, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v3, v3, Lcom/flurry/android/ak;->d Lcom/flurry/android/u;
    invoke-virtual v3, Lcom/flurry/android/u;->k()J
    move-result-wide v3
    invoke-direct v1, v2, v3, v4, Lcom/flurry/android/f;-><init>(B J)V
    invoke-virtual v0, v1, Lcom/flurry/android/p;->a(Lcom/flurry/android/f;)V
    return-void
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    const-string v1, "Unable to launch in app market: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v1, v1, Lcom/flurry/android/ak;->a Ljava/lang/String;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    sget-object v1, Lcom/flurry/android/u;->a Ljava/lang/String;
    invoke-static v1, v0, Lcom/flurry/android/ah;->d(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v1, v5, Lcom/flurry/android/m;->b Lcom/flurry/android/ak;
    iget-object v1, v1, Lcom/flurry/android/ak;->d Lcom/flurry/android/u;
    invoke-static v1, v0, Lcom/flurry/android/u;->b(Lcom/flurry/android/u; Ljava/lang/String;)V
    goto -24h
.end method
