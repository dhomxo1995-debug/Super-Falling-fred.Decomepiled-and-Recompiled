package com.flurry.android;
final class q extends android.webkit.WebViewClient {
    private synthetic com.flurry.android.CatalogActivity a;

    q(com.flurry.android.CatalogActivity p1)
    {
        this.a = p1;
        return;
    }

    public final void onPageFinished(android.webkit.WebView p6, String p7)
    {
        try {
            Exception v0_1 = com.flurry.android.CatalogActivity.a(this.a);
            long v2_1 = com.flurry.android.CatalogActivity.a(this.a).c;
            v0_1.d.add(new com.flurry.android.f(5, com.flurry.android.CatalogActivity.b(this.a)));
            v0_1.c = v2_1;
        } catch (Exception v0) {
        }
        return;
    }

    public final void onReceivedError(android.webkit.WebView p4, int p5, String p6, String p7)
    {
        com.flurry.android.ah.c("FlurryAgent", new StringBuilder().append("Failed to load url: ").append(p7).append(" with an errorCode of ").append(p5).toString());
        p4.loadData("Cannot find Android Market information. <p>Please check your network", "text/html", "UTF-8");
        return;
    }

    public final boolean shouldOverrideUrlLoading(android.webkit.WebView p6, String p7)
    {
        int v0_3;
        if (p7 != null) {
            if (com.flurry.android.CatalogActivity.a(this.a) != null) {
                com.flurry.android.CatalogActivity.a(this.a).a(new com.flurry.android.f(6, com.flurry.android.CatalogActivity.b(this.a)));
            }
            com.flurry.android.CatalogActivity.c(this.a).a(p6.getContext(), com.flurry.android.CatalogActivity.a(this.a), p7);
            v0_3 = 1;
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }
}
