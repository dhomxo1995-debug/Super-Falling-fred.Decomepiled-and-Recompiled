package com.flurry.android;
final class aa {
    long a;
    String b;
    String c;
    String d;

    synthetic aa()
    {
        this(0);
        return;
    }

    private aa(byte p1)
    {
        return;
    }
}
