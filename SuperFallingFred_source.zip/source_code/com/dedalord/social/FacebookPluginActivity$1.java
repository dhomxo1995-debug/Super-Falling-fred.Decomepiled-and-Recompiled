package com.dedalord.social;
 class FacebookPluginActivity$1 implements com.facebook.android.Facebook$DialogListener {
    final synthetic com.dedalord.social.FacebookPluginActivity this$0;

    FacebookPluginActivity$1(com.dedalord.social.FacebookPluginActivity p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onCancel()
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidFail", "Login cancelled...");
        return;
    }

    public void onComplete(android.os.Bundle p5)
    {
        android.content.SharedPreferences$Editor v0 = com.dedalord.social.FacebookPluginActivity.access$000().edit();
        v0.putString("access_token", com.dedalord.social.FacebookPluginActivity.access$100().getAccessToken());
        v0.putLong("access_expires", com.dedalord.social.FacebookPluginActivity.access$100().getAccessExpires());
        v0.commit();
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidSucceed", "");
        return;
    }

    public void onError(com.facebook.android.DialogError p4)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidFail", p4.getMessage());
        return;
    }

    public void onFacebookError(com.facebook.android.FacebookError p4)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidFail", p4.getMessage());
        return;
    }
}
