package com.dedalord.social;
public class Constants {
    public static final String ACCESS_URL = "http://api.twitter.com/oauth/access_token";
    public static final String AUTHORIZE_URL = "http://api.twitter.com/oauth/authorize";
    public static String CONSUMER_KEY = "";
    public static String CONSUMER_SECRET = "";
    public static final String OAUTH_CALLBACK_URL = "http://localhost";
    public static final String REQUEST_URL = "http://api.twitter.com/oauth/request_token";

    static Constants()
    {
        com.dedalord.social.Constants.CONSUMER_KEY = "PUT YOUR TWITTER OAUTH CONSUMER KEY HERE";
        com.dedalord.social.Constants.CONSUMER_SECRET = "PUT YOUR TWITTER OAUTH CONSUMER SECRET HERE";
        return;
    }

    public Constants()
    {
        return;
    }
}
