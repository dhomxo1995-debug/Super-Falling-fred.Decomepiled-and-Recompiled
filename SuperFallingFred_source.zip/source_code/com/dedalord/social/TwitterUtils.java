package com.dedalord.social;
public class TwitterUtils {
    static final String TAG = "Dedalord";

    public TwitterUtils()
    {
        return;
    }

    public static boolean isAuthenticated(android.content.SharedPreferences p8)
    {
        int v4_0 = 1;
        String[] v2 = new com.dedalord.social.SharedPreferencesCredentialStore(p8).read();
        twitter4j.http.AccessToken v0_1 = new twitter4j.http.AccessToken(v2[0], v2[1]);
        twitter4j.Twitter v3 = new twitter4j.TwitterFactory().getInstance();
        v3.setOAuthConsumer(com.dedalord.social.Constants.CONSUMER_KEY, com.dedalord.social.Constants.CONSUMER_SECRET);
        v3.setOAuthAccessToken(v0_1);
        try {
            v3.getAccountSettings();
        } catch (twitter4j.TwitterException v1) {
            android.util.Log.d("Dedalord", v1.getMessage());
            v4_0 = 0;
        }
        return v4_0;
    }

    public static void sendTweet(android.content.SharedPreferences p5, String p6)
    {
        String[] v1 = new com.dedalord.social.SharedPreferencesCredentialStore(p5).read();
        twitter4j.http.AccessToken v0_1 = new twitter4j.http.AccessToken(v1[0], v1[1]);
        twitter4j.Twitter v2 = new twitter4j.TwitterFactory().getInstance();
        v2.setOAuthConsumer(com.dedalord.social.Constants.CONSUMER_KEY, com.dedalord.social.Constants.CONSUMER_SECRET);
        v2.setOAuthAccessToken(v0_1);
        v2.updateStatus(p6);
        return;
    }
}
