package com.dedalord.social;
public class TwitterPluginActivity extends com.unity3d.player.UnityPlayerActivity {
    static final String TAG = "Dedalord";
    private static android.content.Intent intent;
    private static android.content.SharedPreferences prefs;

    public TwitterPluginActivity()
    {
        return;
    }

    public static void Init(String p1, String p2)
    {
        com.dedalord.social.TwitterPluginActivity.prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(com.unity3d.player.UnityPlayer.currentActivity);
        com.dedalord.social.Constants.CONSUMER_KEY = p1;
        com.dedalord.social.Constants.CONSUMER_SECRET = p2;
        return;
    }

    public static boolean IsLoggedIn()
    {
        android.util.Log.d("Dedalord", "IsLoggedIn()");
        return com.dedalord.social.TwitterUtils.isAuthenticated(com.dedalord.social.TwitterPluginActivity.prefs);
    }

    public static void Login()
    {
        android.util.Log.d("Dedalord", "Login()");
        if (com.dedalord.social.TwitterPluginActivity.intent == null) {
            com.dedalord.social.TwitterPluginActivity.intent = new android.content.Intent().setClass(com.unity3d.player.UnityPlayer.currentActivity, com.dedalord.social.OAuthAccessTokenActivity);
        }
        com.unity3d.player.UnityPlayer.currentActivity.startActivity(com.dedalord.social.TwitterPluginActivity.intent);
        return;
    }

    public static void Logout()
    {
        android.util.Log.d("Dedalord", "Logout()");
        new com.dedalord.social.SharedPreferencesCredentialStore(com.dedalord.social.TwitterPluginActivity.prefs).clearCredentials();
        return;
    }

    public static void UpdateStatus(String p4)
    {
        try {
            android.util.Log.d("Dedalord", "UpdateStatus()");
            com.dedalord.social.TwitterUtils.sendTweet(com.dedalord.social.TwitterPluginActivity.prefs, p4);
            com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "requestSucceeded", "");
        } catch (Exception v0) {
            android.util.Log.d("Dedalord", "Couldn\'t send tweet...");
            com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "requestFailed", v0.getMessage());
        }
        return;
    }

    public void onCreate(android.os.Bundle p1)
    {
        super.onCreate(p1);
        return;
    }
}
