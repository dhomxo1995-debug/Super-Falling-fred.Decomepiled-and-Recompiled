package com.dedalord.social;
public interface CredentialStore {

    public abstract void clearCredentials();

    public abstract String[] read();

    public abstract void write(String[] p0);
}
