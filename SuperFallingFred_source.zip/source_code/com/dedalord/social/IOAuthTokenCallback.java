package com.dedalord.social;
public interface IOAuthTokenCallback {

    public abstract void OnTokenError(String p0);

    public abstract void OnTokenSuccess(com.google.api.client.auth.oauth.OAuthHmacSigner p0, String p1);
}
