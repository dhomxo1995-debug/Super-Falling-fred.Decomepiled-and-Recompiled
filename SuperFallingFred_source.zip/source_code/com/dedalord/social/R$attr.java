package com.dedalord.social;
public final class R$attr {

    public R$attr()
    {
        return;
    }
}
