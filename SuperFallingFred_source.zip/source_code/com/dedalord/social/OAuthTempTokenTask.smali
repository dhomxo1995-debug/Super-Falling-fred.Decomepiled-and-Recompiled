.class public Lcom/dedalord/social/OAuthTempTokenTask;
.super Landroid/os/AsyncTask;

.field final TAG:Ljava/lang/String;
.field private authorizationUrl:Ljava/lang/String;
.field private callback:Lcom/dedalord/social/OAuthAccessTokenActivity;
.field private context:Landroid/content/Context;
.field private mProgressDialog:Landroid/app/ProgressDialog;
.field private message:Ljava/lang/String;
.field private res:Z
.field private signer:Lcom/google/api/client/auth/oauth/OAuthHmacSigner;

.method public constructor <init>(Lcom/dedalord/social/OAuthAccessTokenActivity; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/content/Context;)V
    .registers 5
    invoke-direct v1, Landroid/os/AsyncTask;-><init>()V
    const-string v0, "Dedalord"
    iput-object v0, v1, Lcom/dedalord/social/OAuthTempTokenTask;->TAG Ljava/lang/String;
    const/4 v0, 0
    iput-boolean v0, v1, Lcom/dedalord/social/OAuthTempTokenTask;->res Z
    iput-object v4, v1, Lcom/dedalord/social/OAuthTempTokenTask;->context Landroid/content/Context;
    iput-object v2, v1, Lcom/dedalord/social/OAuthTempTokenTask;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    iput-object v3, v1, Lcom/dedalord/social/OAuthTempTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    check-cast v2, [Ljava/lang/Void;
    invoke-virtual v1, v2, Lcom/dedalord/social/OAuthTempTokenTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    move-result-object v0
    return-object v0
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    .registers 8
    const-string v4, "Dedalord"
    const-string v5, "OAuthTempTokenTask.doInBackground()"
    invoke-static v4, v5, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    sget-object v5, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    iput-object v5, v4, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->clientSharedSecret Ljava/lang/String;
    new-instance v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;
    const-string v4, "http://api.twitter.com/oauth/request_token"
    invoke-direct v3, v4, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;-><init>(Ljava/lang/String;)V
    new-instance v4, Lcom/google/api/client/http/apache/ApacheHttpTransport;
    invoke-direct v4, Lcom/google/api/client/http/apache/ApacheHttpTransport;-><init>()V
    iput-object v4, v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iput-object v4, v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;->signer Lcom/google/api/client/auth/oauth/OAuthSigner;
    sget-object v4, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    iput-object v4, v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;->consumerKey Ljava/lang/String;
    const-string v4, "http://localhost"
    iput-object v4, v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;->callback Ljava/lang/String;
    invoke-virtual v3, Lcom/google/api/client/auth/oauth/OAuthGetTemporaryToken;->execute()Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    move-result-object v2
    iget-object v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iget-object v5, v2, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;->tokenSecret Ljava/lang/String;
    iput-object v5, v4, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->tokenSharedSecret Ljava/lang/String;
    new-instance v0, Lcom/google/api/client/auth/oauth/OAuthAuthorizeTemporaryTokenUrl;
    const-string v4, "http://api.twitter.com/oauth/authorize"
    invoke-direct v0, v4, Lcom/google/api/client/auth/oauth/OAuthAuthorizeTemporaryTokenUrl;-><init>(Ljava/lang/String;)V
    iget-object v4, v2, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;->token Ljava/lang/String;
    iput-object v4, v0, Lcom/google/api/client/auth/oauth/OAuthAuthorizeTemporaryTokenUrl;->temporaryToken Ljava/lang/String;
    invoke-virtual v0, Lcom/google/api/client/auth/oauth/OAuthAuthorizeTemporaryTokenUrl;->build()Ljava/lang/String;
    move-result-object v4
    iput-object v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->authorizationUrl Ljava/lang/String;
    const/4 v4, 1
    iput-boolean v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->res Z
    const/4 v4, 0
    return-object v4
    move-exception v1
    invoke-virtual v1, Ljava/lang/Exception;->printStackTrace()V
    const/4 v4, 0
    iput-boolean v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->res Z
    invoke-virtual v1, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v4
    iput-object v4, v6, Lcom/dedalord/social/OAuthTempTokenTask;->message Ljava/lang/String;
    goto -fh
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2
    check-cast v1, Ljava/lang/Void;
    invoke-virtual v0, v1, Lcom/dedalord/social/OAuthTempTokenTask;->onPostExecute(Ljava/lang/Void;)V
    return-void
.end method

.method protected onPostExecute(Ljava/lang/Void;)V
    .registers 5
    iget-object v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->mProgressDialog Landroid/app/ProgressDialog;
    invoke-virtual v0, Landroid/app/ProgressDialog;->dismiss()V
    iget-boolean v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->res Z
    if-eqz v0, +00ch
    iget-object v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    iget-object v1, v3, Lcom/dedalord/social/OAuthTempTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iget-object v2, v3, Lcom/dedalord/social/OAuthTempTokenTask;->authorizationUrl Ljava/lang/String;
    invoke-virtual v0, v1, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->OnTokenSuccess(Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Ljava/lang/String;)V
    return-void
    iget-object v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    iget-object v1, v3, Lcom/dedalord/social/OAuthTempTokenTask;->message Ljava/lang/String;
    invoke-virtual v0, v1, Lcom/dedalord/social/OAuthAccessTokenActivity;->OnTokenError(Ljava/lang/String;)V
    goto -8h
.end method

.method protected onPreExecute()V
    .registers 4
    iget-object v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->context Landroid/content/Context;
    const-string v1, "Loading..."
    const-string v2, "Data is Loading..."
    invoke-static v0, v1, v2, Landroid/app/ProgressDialog;->show(Landroid/content/Context; Ljava/lang/CharSequence; Ljava/lang/CharSequence;)Landroid/app/ProgressDialog;
    move-result-object v0
    iput-object v0, v3, Lcom/dedalord/social/OAuthTempTokenTask;->mProgressDialog Landroid/app/ProgressDialog;
    return-void
.end method
