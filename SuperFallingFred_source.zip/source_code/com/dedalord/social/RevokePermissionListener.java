package com.dedalord.social;
public class RevokePermissionListener implements com.facebook.android.AsyncFacebookRunner$RequestListener {

    public RevokePermissionListener()
    {
        return;
    }

    public void onComplete(String p1, Object p2)
    {
        return;
    }

    public void onFacebookError(com.facebook.android.FacebookError p1, Object p2)
    {
        return;
    }

    public void onFileNotFoundException(java.io.FileNotFoundException p1, Object p2)
    {
        return;
    }

    public void onIOException(java.io.IOException p1, Object p2)
    {
        return;
    }

    public void onMalformedURLException(java.net.MalformedURLException p1, Object p2)
    {
        return;
    }
}
