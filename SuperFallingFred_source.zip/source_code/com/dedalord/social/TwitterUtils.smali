.class public Lcom/dedalord/social/TwitterUtils;
.super Ljava/lang/Object;

.field static final TAG:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static isAuthenticated(Landroid/content/SharedPreferences;)Z
    .registers 9
    const/4 v4, 1
    const/4 v5, 0
    new-instance v6, Lcom/dedalord/social/SharedPreferencesCredentialStore;
    invoke-direct v6, v8, Lcom/dedalord/social/SharedPreferencesCredentialStore;-><init>(Landroid/content/SharedPreferences;)V
    invoke-virtual v6, Lcom/dedalord/social/SharedPreferencesCredentialStore;->read()[Ljava/lang/String;
    move-result-object v2
    new-instance v0, Ltwitter4j/http/AccessToken;
    aget-object v6, v2, v5
    aget-object v7, v2, v4
    invoke-direct v0, v6, v7, Ltwitter4j/http/AccessToken;-><init>(Ljava/lang/String; Ljava/lang/String;)V
    new-instance v6, Ltwitter4j/TwitterFactory;
    invoke-direct v6, Ltwitter4j/TwitterFactory;-><init>()V
    invoke-virtual v6, Ltwitter4j/TwitterFactory;->getInstance()Ltwitter4j/Twitter;
    move-result-object v3
    sget-object v6, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    sget-object v7, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    invoke-virtual v3, v6, v7, Ltwitter4j/Twitter;->setOAuthConsumer(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v3, v0, Ltwitter4j/Twitter;->setOAuthAccessToken(Ltwitter4j/http/AccessToken;)V
    invoke-virtual v3, Ltwitter4j/Twitter;->getAccountSettings()Ltwitter4j/AccountSettings;
    return v4
    move-exception v1
    const-string v4, "Dedalord"
    invoke-virtual v1, Ltwitter4j/TwitterException;->getMessage()Ljava/lang/String;
    move-result-object v6
    invoke-static v4, v6, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    move v4, v5
    goto -ch
.end method

.method public static sendTweet(Landroid/content/SharedPreferences; Ljava/lang/String;)V
    .registers 7
    new-instance v3, Lcom/dedalord/social/SharedPreferencesCredentialStore;
    invoke-direct v3, v5, Lcom/dedalord/social/SharedPreferencesCredentialStore;-><init>(Landroid/content/SharedPreferences;)V
    invoke-virtual v3, Lcom/dedalord/social/SharedPreferencesCredentialStore;->read()[Ljava/lang/String;
    move-result-object v1
    new-instance v0, Ltwitter4j/http/AccessToken;
    const/4 v3, 0
    aget-object v3, v1, v3
    const/4 v4, 1
    aget-object v4, v1, v4
    invoke-direct v0, v3, v4, Ltwitter4j/http/AccessToken;-><init>(Ljava/lang/String; Ljava/lang/String;)V
    new-instance v3, Ltwitter4j/TwitterFactory;
    invoke-direct v3, Ltwitter4j/TwitterFactory;-><init>()V
    invoke-virtual v3, Ltwitter4j/TwitterFactory;->getInstance()Ltwitter4j/Twitter;
    move-result-object v2
    sget-object v3, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    sget-object v4, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    invoke-virtual v2, v3, v4, Ltwitter4j/Twitter;->setOAuthConsumer(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v2, v0, Ltwitter4j/Twitter;->setOAuthAccessToken(Ltwitter4j/http/AccessToken;)V
    invoke-virtual v2, v6, Ltwitter4j/Twitter;->updateStatus(Ljava/lang/String;)Ltwitter4j/Status;
    return-void
.end method
