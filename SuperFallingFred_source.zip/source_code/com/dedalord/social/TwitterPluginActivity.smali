.class public Lcom/dedalord/social/TwitterPluginActivity;
.super Lcom/unity3d/player/UnityPlayerActivity;

.field static final TAG:Ljava/lang/String;
.field private static intent:Landroid/content/Intent;
.field private static prefs:Landroid/content/SharedPreferences;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayerActivity;-><init>()V
    return-void
.end method

.method public static Init(Ljava/lang/String; Ljava/lang/String;)V
    .registers 3
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    invoke-static v0, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;
    move-result-object v0
    sput-object v0, Lcom/dedalord/social/TwitterPluginActivity;->prefs Landroid/content/SharedPreferences;
    sput-object v1, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    sput-object v2, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    return-void
.end method

.method public static IsLoggedIn()Z
    .registers 2
    const-string v0, "Dedalord"
    const-string v1, "IsLoggedIn()"
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    sget-object v0, Lcom/dedalord/social/TwitterPluginActivity;->prefs Landroid/content/SharedPreferences;
    invoke-static v0, Lcom/dedalord/social/TwitterUtils;->isAuthenticated(Landroid/content/SharedPreferences;)Z
    move-result v0
    return v0
.end method

.method public static Login()V
    .registers 3
    const-string v0, "Dedalord"
    const-string v1, "Login()"
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    sget-object v0, Lcom/dedalord/social/TwitterPluginActivity;->intent Landroid/content/Intent;
    if-nez v0, +011h
    new-instance v0, Landroid/content/Intent;
    invoke-direct v0, Landroid/content/Intent;-><init>()V
    sget-object v1, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    const-class v2, Lcom/dedalord/social/OAuthAccessTokenActivity;
    invoke-virtual v0, v1, v2, Landroid/content/Intent;->setClass(Landroid/content/Context; Ljava/lang/Class;)Landroid/content/Intent;
    move-result-object v0
    sput-object v0, Lcom/dedalord/social/TwitterPluginActivity;->intent Landroid/content/Intent;
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    sget-object v1, Lcom/dedalord/social/TwitterPluginActivity;->intent Landroid/content/Intent;
    invoke-virtual v0, v1, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    return-void
.end method

.method public static Logout()V
    .registers 2
    const-string v0, "Dedalord"
    const-string v1, "Logout()"
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;
    sget-object v1, Lcom/dedalord/social/TwitterPluginActivity;->prefs Landroid/content/SharedPreferences;
    invoke-direct v0, v1, Lcom/dedalord/social/SharedPreferencesCredentialStore;-><init>(Landroid/content/SharedPreferences;)V
    invoke-virtual v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;->clearCredentials()V
    return-void
.end method

.method public static UpdateStatus(Ljava/lang/String;)V
    .registers 5
    const-string v1, "Dedalord"
    const-string v2, "UpdateStatus()"
    invoke-static v1, v2, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    sget-object v1, Lcom/dedalord/social/TwitterPluginActivity;->prefs Landroid/content/SharedPreferences;
    invoke-static v1, v4, Lcom/dedalord/social/TwitterUtils;->sendTweet(Landroid/content/SharedPreferences; Ljava/lang/String;)V
    const-string v1, "TwitterManager"
    const-string v2, "requestSucceeded"
    const-string v3, ""
    invoke-static v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    move-exception v0
    const-string v1, "Dedalord"
    const-string v2, "Couldn't send tweet..."
    invoke-static v1, v2, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    const-string v1, "TwitterManager"
    const-string v2, "requestFailed"
    invoke-virtual v0, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v3
    invoke-static v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    goto -14h
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 2
    invoke-super v0, v1, Lcom/unity3d/player/UnityPlayerActivity;->onCreate(Landroid/os/Bundle;)V
    return-void
.end method
