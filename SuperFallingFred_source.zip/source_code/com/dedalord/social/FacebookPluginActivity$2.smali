.class final Lcom/dedalord/social/FacebookPluginActivity$2;
.super Ljava/lang/Object;
.implements Lcom/facebook/android/AsyncFacebookRunner$RequestListener;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onComplete(Ljava/lang/String; Ljava/lang/Object;)V
    .registers 6
    invoke-static Lcom/dedalord/social/FacebookPluginActivity;->access$000()Landroid/content/SharedPreferences;
    move-result-object v1
    invoke-interface v1, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->commit()Z
    const-string v1, "FacebookManager"
    const-string v2, "requestSucceeded"
    invoke-static v1, v2, v4, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onFacebookError(Lcom/facebook/android/FacebookError; Ljava/lang/Object;)V
    .registers 6
    const-string v0, "FacebookManager"
    const-string v1, "requestFailed"
    invoke-virtual v4, Lcom/facebook/android/FacebookError;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onFileNotFoundException(Ljava/io/FileNotFoundException; Ljava/lang/Object;)V
    .registers 6
    const-string v0, "FacebookManager"
    const-string v1, "requestFailed"
    invoke-virtual v4, Ljava/io/FileNotFoundException;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onIOException(Ljava/io/IOException; Ljava/lang/Object;)V
    .registers 6
    const-string v0, "FacebookManager"
    const-string v1, "requestFailed"
    invoke-virtual v4, Ljava/io/IOException;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onMalformedURLException(Ljava/net/MalformedURLException; Ljava/lang/Object;)V
    .registers 6
    const-string v0, "FacebookManager"
    const-string v1, "requestFailed"
    invoke-virtual v4, Ljava/net/MalformedURLException;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method
