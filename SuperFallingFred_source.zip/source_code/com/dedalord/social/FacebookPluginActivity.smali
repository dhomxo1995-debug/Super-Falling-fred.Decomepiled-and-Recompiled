.class public Lcom/dedalord/social/FacebookPluginActivity;
.super Lcom/unity3d/player/UnityPlayerActivity;

.field private static facebook:Lcom/facebook/android/Facebook;
.field private static intent:Landroid/content/Intent;
.field private static mPrefs:Landroid/content/SharedPreferences;

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayerActivity;-><init>()V
    return-void
.end method

.method public static Init(Ljava/lang/String;)V
    .registers 9
    const-wide/16 v6, 0
    new-instance v3, Lcom/facebook/android/Facebook;
    invoke-direct v3, v8, Lcom/facebook/android/Facebook;-><init>(Ljava/lang/String;)V
    sput-object v3, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    sget-object v3, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    const/4 v4, 0
    invoke-virtual v3, v4, Landroid/app/Activity;->getPreferences(I)Landroid/content/SharedPreferences;
    move-result-object v3
    sput-object v3, Lcom/dedalord/social/FacebookPluginActivity;->mPrefs Landroid/content/SharedPreferences;
    sget-object v3, Lcom/dedalord/social/FacebookPluginActivity;->mPrefs Landroid/content/SharedPreferences;
    const-string v4, "access_token"
    const/4 v5, 0
    invoke-interface v3, v4, v5, Landroid/content/SharedPreferences;->getString(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    sget-object v3, Lcom/dedalord/social/FacebookPluginActivity;->mPrefs Landroid/content/SharedPreferences;
    const-string v4, "access_expires"
    invoke-interface v3, v4, v6, v7, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String; J)J
    move-result-wide v1
    if-eqz v0, +007h
    sget-object v3, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-virtual v3, v0, Lcom/facebook/android/Facebook;->setAccessToken(Ljava/lang/String;)V
    cmp-long v3, v1, v6
    if-eqz v3, +007h
    sget-object v3, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-virtual v3, v1, v2, Lcom/facebook/android/Facebook;->setAccessExpires(J)V
    return-void
.end method

.method public static IsLoggedIn()Z
    .registers 1
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-eqz v0, +009h
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-virtual v0, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v0
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static Login()V
    .registers 3
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-nez v0, +00ch
    const-string v0, "FacebookManager"
    const-string v1, "loginDidFail"
    const-string v2, "Must call Init() method first!"
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-virtual v0, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v0
    if-nez v0, +01dh
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->intent Landroid/content/Intent;
    if-nez v0, +011h
    new-instance v0, Landroid/content/Intent;
    invoke-direct v0, Landroid/content/Intent;-><init>()V
    sget-object v1, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    const-class v2, Lcom/dedalord/social/FacebookPluginActivity;
    invoke-virtual v0, v1, v2, Landroid/content/Intent;->setClass(Landroid/content/Context; Ljava/lang/Class;)Landroid/content/Intent;
    move-result-object v0
    sput-object v0, Lcom/dedalord/social/FacebookPluginActivity;->intent Landroid/content/Intent;
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->intent Landroid/content/Intent;
    invoke-virtual v0, v1, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    goto -23h
    const-string v0, "FacebookManager"
    const-string v1, "loginDidSucceed"
    const-string v2, ""
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    goto -2dh
.end method

.method public static Logout()V
    .registers 4
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-nez v1, +00ch
    const-string v1, "FacebookManager"
    const-string v2, "requestFailed"
    const-string v3, "Must call Init() method first!"
    invoke-static v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    const/4 v0, 0
    new-instance v0, Lcom/facebook/android/AsyncFacebookRunner;
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-direct v0, v1, Lcom/facebook/android/AsyncFacebookRunner;-><init>(Lcom/facebook/android/Facebook;)V
    sget-object v1, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    invoke-virtual v1, Landroid/app/Activity;->getBaseContext()Landroid/content/Context;
    move-result-object v1
    new-instance v2, Lcom/dedalord/social/FacebookPluginActivity$2;
    invoke-direct v2, Lcom/dedalord/social/FacebookPluginActivity$2;-><init>()V
    invoke-virtual v0, v1, v2, Lcom/facebook/android/AsyncFacebookRunner;->logout(Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    goto -17h
.end method

.method public static PostMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 12
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-nez v1, +00ch
    const-string v1, "FacebookManager"
    const-string v3, "requestFailed"
    const-string v4, "Must call Init() method first!"
    invoke-static v1, v3, v4, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    const/4 v0, 0
    new-instance v0, Lcom/facebook/android/AsyncFacebookRunner;
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-direct v0, v1, Lcom/facebook/android/AsyncFacebookRunner;-><init>(Lcom/facebook/android/Facebook;)V
    new-instance v2, Landroid/os/Bundle;
    invoke-direct v2, Landroid/os/Bundle;-><init>()V
    if-eqz v6, +00bh
    const-string v1, ""
    if-eq v6, v1, +007h
    const-string v1, "message"
    invoke-virtual v2, v1, v6, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v7, +00bh
    const-string v1, ""
    if-eq v7, v1, +007h
    const-string v1, "caption"
    invoke-virtual v2, v1, v7, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v8, +00bh
    const-string v1, ""
    if-eq v9, v1, +007h
    const-string v1, "description"
    invoke-virtual v2, v1, v8, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v9, +00bh
    const-string v1, ""
    if-eq v9, v1, +007h
    const-string v1, "name"
    invoke-virtual v2, v1, v9, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v10, +00bh
    const-string v1, ""
    if-eq v10, v1, +007h
    const-string v1, "picture"
    invoke-virtual v2, v1, v10, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v11, +00bh
    const-string v1, ""
    if-eq v11, v1, +007h
    const-string v1, "link"
    invoke-virtual v2, v1, v11, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "me/feed"
    const-string v3, "POST"
    new-instance v4, Lcom/dedalord/social/WallPostListener;
    invoke-direct v4, Lcom/dedalord/social/WallPostListener;-><init>()V
    const/4 v5, 0
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    goto -5dh
.end method

.method public static RetrieveUserBasicInfo()V
    .registers 4
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-nez v1, +00ch
    const-string v1, "FacebookManager"
    const-string v2, "requestFailed"
    const-string v3, "Must call Init() method first!"
    invoke-static v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    const/4 v0, 0
    new-instance v0, Lcom/facebook/android/AsyncFacebookRunner;
    sget-object v1, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-direct v0, v1, Lcom/facebook/android/AsyncFacebookRunner;-><init>(Lcom/facebook/android/Facebook;)V
    const-string v1, "me"
    new-instance v2, Lcom/dedalord/social/UserDataRequestListener;
    invoke-direct v2, Lcom/dedalord/social/UserDataRequestListener;-><init>()V
    invoke-virtual v0, v1, v2, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    goto -13h
.end method

.method public static RetrieveUserFriends()V
    .registers 5
    sget-object v2, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    if-nez v2, +00ch
    const-string v2, "FacebookManager"
    const-string v3, "requestFailed"
    const-string v4, "Must call Init() method first!"
    invoke-static v2, v3, v4, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    const/4 v1, 0
    new-instance v1, Lcom/facebook/android/AsyncFacebookRunner;
    sget-object v2, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-direct v1, v2, Lcom/facebook/android/AsyncFacebookRunner;-><init>(Lcom/facebook/android/Facebook;)V
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    const-string v2, "method"
    const-string v3, "fql.query"
    invoke-virtual v0, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v2, "query"
    const-string v3, "SELECT name, uid, pic_small FROM user WHERE is_app_user = 1 AND uid IN (SELECT uid2 FROM friend WHERE uid1 = me()) ORDER BY concat(first_name,last_name) ASC"
    invoke-virtual v0, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    new-instance v2, Lcom/dedalord/social/UserFriendsRequestListener;
    invoke-direct v2, Lcom/dedalord/social/UserFriendsRequestListener;-><init>()V
    invoke-virtual v1, v0, v2, Lcom/facebook/android/AsyncFacebookRunner;->request(Landroid/os/Bundle; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    goto -24h
.end method

.method static synthetic access$000()Landroid/content/SharedPreferences;
    .registers 1
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->mPrefs Landroid/content/SharedPreferences;
    return-object v0
.end method

.method static synthetic access$100()Lcom/facebook/android/Facebook;
    .registers 1
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    return-object v0
.end method

.method public onActivityResult(I I Landroid/content/Intent;)V
    .registers 5
    invoke-super v1, v2, v3, v4, Lcom/unity3d/player/UnityPlayerActivity;->onActivityResult(I I Landroid/content/Intent;)V
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    invoke-virtual v0, v2, v3, v4, Lcom/facebook/android/Facebook;->authorizeCallback(I I Landroid/content/Intent;)V
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 6
    invoke-super v4, v5, Lcom/unity3d/player/UnityPlayerActivity;->onCreate(Landroid/os/Bundle;)V
    sget-object v0, Lcom/dedalord/social/FacebookPluginActivity;->facebook Lcom/facebook/android/Facebook;
    const/4 v1, 6
    new-array v1, v1, [Ljava/lang/String;
    const/4 v2, 0
    const-string v3, "publish_actions"
    aput-object v3, v1, v2
    const/4 v2, 1
    const-string v3, "user_games_activity"
    aput-object v3, v1, v2
    const/4 v2, 2
    const-string v3, "user_location"
    aput-object v3, v1, v2
    const/4 v2, 3
    const-string v3, "user_interests"
    aput-object v3, v1, v2
    const/4 v2, 4
    const-string v3, "user_birthday"
    aput-object v3, v1, v2
    const/4 v2, 5
    const-string v3, "email"
    aput-object v3, v1, v2
    new-instance v2, Lcom/dedalord/social/FacebookPluginActivity$1;
    invoke-direct v2, v4, Lcom/dedalord/social/FacebookPluginActivity$1;-><init>(Lcom/dedalord/social/FacebookPluginActivity;)V
    invoke-virtual v0, v4, v1, v2, Lcom/facebook/android/Facebook;->authorize(Landroid/app/Activity; [Ljava/lang/String; Lcom/facebook/android/Facebook$DialogListener;)V
    return-void
.end method
