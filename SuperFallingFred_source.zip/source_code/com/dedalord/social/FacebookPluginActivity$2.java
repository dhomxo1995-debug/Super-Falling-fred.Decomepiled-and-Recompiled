package com.dedalord.social;
final class FacebookPluginActivity$2 implements com.facebook.android.AsyncFacebookRunner$RequestListener {

    FacebookPluginActivity$2()
    {
        return;
    }

    public void onComplete(String p4, Object p5)
    {
        android.content.SharedPreferences$Editor v0 = com.dedalord.social.FacebookPluginActivity.access$000().edit();
        v0.clear();
        v0.commit();
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestSucceeded", p4);
        return;
    }

    public void onFacebookError(com.facebook.android.FacebookError p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", p4.getMessage());
        return;
    }

    public void onFileNotFoundException(java.io.FileNotFoundException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", p4.getMessage());
        return;
    }

    public void onIOException(java.io.IOException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", p4.getMessage());
        return;
    }

    public void onMalformedURLException(java.net.MalformedURLException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", p4.getMessage());
        return;
    }
}
