package com.dedalord.social;
public class FacebookPluginActivity extends com.unity3d.player.UnityPlayerActivity {
    private static com.facebook.android.Facebook facebook;
    private static android.content.Intent intent;
    private static android.content.SharedPreferences mPrefs;

    static FacebookPluginActivity()
    {
        com.dedalord.social.FacebookPluginActivity.facebook = 0;
        return;
    }

    public FacebookPluginActivity()
    {
        return;
    }

    public static void Init(String p8)
    {
        com.dedalord.social.FacebookPluginActivity.facebook = new com.facebook.android.Facebook(p8);
        com.dedalord.social.FacebookPluginActivity.mPrefs = com.unity3d.player.UnityPlayer.currentActivity.getPreferences(0);
        String v0 = com.dedalord.social.FacebookPluginActivity.mPrefs.getString("access_token", 0);
        long v1 = com.dedalord.social.FacebookPluginActivity.mPrefs.getLong("access_expires", 0);
        if (v0 != null) {
            com.dedalord.social.FacebookPluginActivity.facebook.setAccessToken(v0);
        }
        if (v1 != 0) {
            com.dedalord.social.FacebookPluginActivity.facebook.setAccessExpires(v1);
        }
        return;
    }

    public static boolean IsLoggedIn()
    {
        int v0_1;
        if (com.dedalord.social.FacebookPluginActivity.facebook == null) {
            v0_1 = 0;
        } else {
            v0_1 = com.dedalord.social.FacebookPluginActivity.facebook.isSessionValid();
        }
        return v0_1;
    }

    public static void Login()
    {
        if (com.dedalord.social.FacebookPluginActivity.facebook != null) {
            if (com.dedalord.social.FacebookPluginActivity.facebook.isSessionValid()) {
                com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidSucceed", "");
            } else {
                if (com.dedalord.social.FacebookPluginActivity.intent == null) {
                    com.dedalord.social.FacebookPluginActivity.intent = new android.content.Intent().setClass(com.unity3d.player.UnityPlayer.currentActivity, com.dedalord.social.FacebookPluginActivity);
                }
                com.unity3d.player.UnityPlayer.currentActivity.startActivity(com.dedalord.social.FacebookPluginActivity.intent);
            }
        } else {
            com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "loginDidFail", "Must call Init() method first!");
        }
        return;
    }

    public static void Logout()
    {
        if (com.dedalord.social.FacebookPluginActivity.facebook != null) {
            new com.facebook.android.AsyncFacebookRunner(com.dedalord.social.FacebookPluginActivity.facebook).logout(com.unity3d.player.UnityPlayer.currentActivity.getBaseContext(), new com.dedalord.social.FacebookPluginActivity$2());
        } else {
            com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", "Must call Init() method first!");
        }
        return;
    }

    public static void PostMessage(String p6, String p7, String p8, String p9, String p10, String p11)
    {
        if (com.dedalord.social.FacebookPluginActivity.facebook != null) {
            com.facebook.android.AsyncFacebookRunner v0_1 = new com.facebook.android.AsyncFacebookRunner(com.dedalord.social.FacebookPluginActivity.facebook);
            android.os.Bundle v2_1 = new android.os.Bundle();
            if ((p6 != null) && (p6 != "")) {
                v2_1.putString("message", p6);
            }
            if ((p7 != null) && (p7 != "")) {
                v2_1.putString("caption", p7);
            }
            if ((p8 != null) && (p9 != "")) {
                v2_1.putString("description", p8);
            }
            if ((p9 != null) && (p9 != "")) {
                v2_1.putString("name", p9);
            }
            if ((p10 != null) && (p10 != "")) {
                v2_1.putString("picture", p10);
            }
            if ((p11 != null) && (p11 != "")) {
                v2_1.putString("link", p11);
            }
            v0_1.request("me/feed", v2_1, "POST", new com.dedalord.social.WallPostListener(), 0);
        } else {
            com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", "Must call Init() method first!");
        }
        return;
    }

    public static void RetrieveUserBasicInfo()
    {
        if (com.dedalord.social.FacebookPluginActivity.facebook != null) {
            new com.facebook.android.AsyncFacebookRunner(com.dedalord.social.FacebookPluginActivity.facebook).request("me", new com.dedalord.social.UserDataRequestListener());
        } else {
            com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", "Must call Init() method first!");
        }
        return;
    }

    public static void RetrieveUserFriends()
    {
        if (com.dedalord.social.FacebookPluginActivity.facebook != null) {
            com.facebook.android.AsyncFacebookRunner v1_1 = new com.facebook.android.AsyncFacebookRunner(com.dedalord.social.FacebookPluginActivity.facebook);
            android.os.Bundle v0_1 = new android.os.Bundle();
            v0_1.putString("method", "fql.query");
            v0_1.putString("query", "SELECT name, uid, pic_small FROM user WHERE is_app_user = 1 AND uid IN (SELECT uid2 FROM friend WHERE uid1 = me()) ORDER BY concat(first_name,last_name) ASC");
            v1_1.request(v0_1, new com.dedalord.social.UserFriendsRequestListener());
        } else {
            com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFailed", "Must call Init() method first!");
        }
        return;
    }

    static synthetic android.content.SharedPreferences access$000()
    {
        return com.dedalord.social.FacebookPluginActivity.mPrefs;
    }

    static synthetic com.facebook.android.Facebook access$100()
    {
        return com.dedalord.social.FacebookPluginActivity.facebook;
    }

    public void onActivityResult(int p2, int p3, android.content.Intent p4)
    {
        super.onActivityResult(p2, p3, p4);
        com.dedalord.social.FacebookPluginActivity.facebook.authorizeCallback(p2, p3, p4);
        return;
    }

    public void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        String[] v1_1 = new String[6];
        v1_1[0] = "publish_actions";
        v1_1[1] = "user_games_activity";
        v1_1[2] = "user_location";
        v1_1[3] = "user_interests";
        v1_1[4] = "user_birthday";
        v1_1[5] = "email";
        com.dedalord.social.FacebookPluginActivity.facebook.authorize(this, v1_1, new com.dedalord.social.FacebookPluginActivity$1(this));
        return;
    }
}
