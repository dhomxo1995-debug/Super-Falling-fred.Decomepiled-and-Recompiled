package com.dedalord.social;
public final class R$string {
    public static final int app_name = 2130968577;
    public static final int hello = 2130968576;

    public R$string()
    {
        return;
    }
}
