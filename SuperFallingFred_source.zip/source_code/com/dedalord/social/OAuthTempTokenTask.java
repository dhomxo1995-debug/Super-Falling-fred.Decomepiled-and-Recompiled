package com.dedalord.social;
public class OAuthTempTokenTask extends android.os.AsyncTask {
    final String TAG;
    private String authorizationUrl;
    private com.dedalord.social.OAuthAccessTokenActivity callback;
    private android.content.Context context;
    private android.app.ProgressDialog mProgressDialog;
    private String message;
    private boolean res;
    private com.google.api.client.auth.oauth.OAuthHmacSigner signer;

    public OAuthTempTokenTask(com.dedalord.social.OAuthAccessTokenActivity p2, com.google.api.client.auth.oauth.OAuthHmacSigner p3, android.content.Context p4)
    {
        this.TAG = "Dedalord";
        this.res = 0;
        this.context = p4;
        this.callback = p2;
        this.signer = p3;
        return;
    }

    protected bridge synthetic Object doInBackground(Object[] p2)
    {
        return this.doInBackground(((Void[]) p2));
    }

    protected varargs Void doInBackground(Void[] p7)
    {
        android.util.Log.i("Dedalord", "OAuthTempTokenTask.doInBackground()");
        try {
            this.signer.clientSharedSecret = com.dedalord.social.Constants.CONSUMER_SECRET;
            com.google.api.client.auth.oauth.OAuthGetTemporaryToken v3_1 = new com.google.api.client.auth.oauth.OAuthGetTemporaryToken("http://api.twitter.com/oauth/request_token");
            v3_1.transport = new com.google.api.client.http.apache.ApacheHttpTransport();
            v3_1.signer = this.signer;
            v3_1.consumerKey = com.dedalord.social.Constants.CONSUMER_KEY;
            v3_1.callback = "http://localhost";
            com.google.api.client.auth.oauth.OAuthCredentialsResponse v2 = v3_1.execute();
            this.signer.tokenSharedSecret = v2.tokenSecret;
            com.google.api.client.auth.oauth.OAuthAuthorizeTemporaryTokenUrl v0_1 = new com.google.api.client.auth.oauth.OAuthAuthorizeTemporaryTokenUrl("http://api.twitter.com/oauth/authorize");
            v0_1.temporaryToken = v2.token;
            this.authorizationUrl = v0_1.build();
            this.res = 1;
        } catch (Exception v1) {
            v1.printStackTrace();
            this.res = 0;
            this.message = v1.getMessage();
        }
        return 0;
    }

    protected bridge synthetic void onPostExecute(Object p1)
    {
        this.onPostExecute(((Void) p1));
        return;
    }

    protected void onPostExecute(Void p4)
    {
        this.mProgressDialog.dismiss();
        if (!this.res) {
            this.callback.OnTokenError(this.message);
        } else {
            this.callback.OnTokenSuccess(this.signer, this.authorizationUrl);
        }
        return;
    }

    protected void onPreExecute()
    {
        this.mProgressDialog = android.app.ProgressDialog.show(this.context, "Loading...", "Data is Loading...");
        return;
    }
}
