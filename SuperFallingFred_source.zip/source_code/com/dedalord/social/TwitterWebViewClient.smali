.class public Lcom/dedalord/social/TwitterWebViewClient;
.super Landroid/webkit/WebViewClient;

.field final TAG:Ljava/lang/String;
.field private callback:Lcom/dedalord/social/OAuthAccessTokenActivity;
.field private context:Landroid/content/Context;
.field private prefs:Landroid/content/SharedPreferences;
.field private signer:Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
.field private tokenTask:Lcom/dedalord/social/OAuthTokenTask;

.method public constructor <init>(Lcom/dedalord/social/OAuthAccessTokenActivity; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/content/Context; Landroid/content/SharedPreferences;)V
    .registers 6
    invoke-direct v1, Landroid/webkit/WebViewClient;-><init>()V
    const-string v0, "Dedalord"
    iput-object v0, v1, Lcom/dedalord/social/TwitterWebViewClient;->TAG Ljava/lang/String;
    iput-object v3, v1, Lcom/dedalord/social/TwitterWebViewClient;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iput-object v5, v1, Lcom/dedalord/social/TwitterWebViewClient;->prefs Landroid/content/SharedPreferences;
    iput-object v2, v1, Lcom/dedalord/social/TwitterWebViewClient;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    iput-object v4, v1, Lcom/dedalord/social/TwitterWebViewClient;->context Landroid/content/Context;
    return-void
.end method

.method public OnError(Landroid/webkit/WebView; Ljava/lang/String;)V
    .registers 5
    const-string v0, "Dedalord"
    const-string v1, "OnError()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 4
    invoke-virtual v3, v0, Landroid/webkit/WebView;->setVisibility(I)V
    new-instance v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;
    iget-object v1, v2, Lcom/dedalord/social/TwitterWebViewClient;->prefs Landroid/content/SharedPreferences;
    invoke-direct v0, v1, Lcom/dedalord/social/SharedPreferencesCredentialStore;-><init>(Landroid/content/SharedPreferences;)V
    invoke-virtual v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;->clearCredentials()V
    iget-object v0, v2, Lcom/dedalord/social/TwitterWebViewClient;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    invoke-virtual v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->OnWebViewError(Ljava/lang/String;)V
    return-void
.end method

.method public OnSuccess(Landroid/webkit/WebView; Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;)V
    .registers 7
    const-string v1, "Dedalord"
    const-string v2, "OnSuccess()"
    invoke-static v1, v2, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;
    iget-object v1, v4, Lcom/dedalord/social/TwitterWebViewClient;->prefs Landroid/content/SharedPreferences;
    invoke-direct v0, v1, Lcom/dedalord/social/SharedPreferencesCredentialStore;-><init>(Landroid/content/SharedPreferences;)V
    const/4 v1, 2
    new-array v1, v1, [Ljava/lang/String;
    const/4 v2, 0
    iget-object v3, v6, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;->token Ljava/lang/String;
    aput-object v3, v1, v2
    const/4 v2, 1
    iget-object v3, v6, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;->tokenSecret Ljava/lang/String;
    aput-object v3, v1, v2
    invoke-interface v0, v1, Lcom/dedalord/social/CredentialStore;->write([Ljava/lang/String;)V
    const/4 v1, 4
    invoke-virtual v5, v1, Landroid/webkit/WebView;->setVisibility(I)V
    iget-object v1, v4, Lcom/dedalord/social/TwitterWebViewClient;->callback Lcom/dedalord/social/OAuthAccessTokenActivity;
    invoke-virtual v1, Lcom/dedalord/social/OAuthAccessTokenActivity;->OnWebViewSuccess()V
    return-void
.end method

.method public onPageFinished(Landroid/webkit/WebView; Ljava/lang/String;)V
    .registers 9
    const-string v0, "http://localhost"
    invoke-virtual v8, v0, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +01ch
    iget-object v0, v6, Lcom/dedalord/social/TwitterWebViewClient;->tokenTask Lcom/dedalord/social/OAuthTokenTask;
    if-nez v0, +018h
    new-instance v0, Lcom/dedalord/social/OAuthTokenTask;
    iget-object v2, v6, Lcom/dedalord/social/TwitterWebViewClient;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iget-object v4, v6, Lcom/dedalord/social/TwitterWebViewClient;->context Landroid/content/Context;
    move-object v1, v6
    move-object v3, v7
    move-object v5, v8
    invoke-direct/range v0 ... v5, Lcom/dedalord/social/OAuthTokenTask;-><init>(Lcom/dedalord/social/TwitterWebViewClient; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/webkit/WebView; Landroid/content/Context; Ljava/lang/String;)V
    iput-object v0, v6, Lcom/dedalord/social/TwitterWebViewClient;->tokenTask Lcom/dedalord/social/OAuthTokenTask;
    iget-object v0, v6, Lcom/dedalord/social/TwitterWebViewClient;->tokenTask Lcom/dedalord/social/OAuthTokenTask;
    const/4 v1, 0
    new-array v1, v1, [Ljava/lang/Void;
    invoke-virtual v0, v1, Lcom/dedalord/social/OAuthTokenTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    const-string v0, "Dedalord"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "onPageFinished : "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView; Ljava/lang/String; Landroid/graphics/Bitmap;)V
    .registers 7
    const-string v0, "Dedalord"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "onPageStarted : "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method
