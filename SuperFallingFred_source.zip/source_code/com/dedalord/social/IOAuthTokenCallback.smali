.class public interface abstract Lcom/dedalord/social/IOAuthTokenCallback;
.super Ljava/lang/Object;


.method public abstract OnTokenError(Ljava/lang/String;)V
    # abstract or native method
.end method

.method public abstract OnTokenSuccess(Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Ljava/lang/String;)V
    # abstract or native method
.end method
