package com.dedalord.social;
public class QueryStringParser {
    private int paramBegin;
    private int paramEnd;
    private String paramName;
    private int paramNameEnd;
    private java.util.Map paramPairs;
    private String paramValue;
    private final String queryString;

    public QueryStringParser(String p4)
    {
        this.paramEnd = -1;
        this.paramPairs = new java.util.HashMap();
        this.queryString = p4;
        while (this.next()) {
            this.paramPairs.put(this.getName(), this.getValue());
        }
        return;
    }

    private String getName()
    {
        if (this.paramName == null) {
            this.paramName = this.queryString.substring(this.paramBegin, this.paramNameEnd);
        }
        return this.paramName;
    }

    private String getValue()
    {
        Error v1_5;
        if (this.paramValue != null) {
            v1_5 = this.paramValue;
        } else {
            if (this.paramNameEnd != this.paramEnd) {
                try {
                    this.paramValue = java.net.URLDecoder.decode(this.queryString.substring((this.paramNameEnd + 1), this.paramEnd));
                } catch (Exception v0) {
                    throw new Error(v0);
                }
            } else {
                v1_5 = 0;
            }
        }
        return v1_5;
    }

    private boolean next()
    {
        int v3_0 = 0;
        int v1 = this.queryString.length();
        while (this.paramEnd != v1) {
            int v2_1;
            if (this.paramEnd != -1) {
                v2_1 = (this.paramEnd + 1);
            } else {
                v2_1 = 0;
            }
            this.paramBegin = v2_1;
            int v0_0 = this.queryString.indexOf(38, this.paramBegin);
            if (v0_0 == -1) {
                v0_0 = v1;
            }
            this.paramEnd = v0_0;
            if (this.paramEnd > this.paramBegin) {
                int v0_1 = this.queryString.indexOf(61, this.paramBegin);
                if ((v0_1 == -1) || (v0_1 > this.paramEnd)) {
                    v0_1 = this.paramEnd;
                }
                this.paramNameEnd = v0_1;
                this.paramName = 0;
                this.paramValue = 0;
                v3_0 = 1;
                break;
            }
        }
        return v3_0;
    }

    public String getQueryParamValue(String p2)
    {
        return ((String) this.paramPairs.get(p2));
    }
}
