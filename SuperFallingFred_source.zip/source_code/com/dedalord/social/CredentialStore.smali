.class public interface abstract Lcom/dedalord/social/CredentialStore;
.super Ljava/lang/Object;


.method public abstract clearCredentials()V
    # abstract or native method
.end method

.method public abstract read()[Ljava/lang/String;
    # abstract or native method
.end method

.method public abstract write([Ljava/lang/String;)V
    # abstract or native method
.end method
