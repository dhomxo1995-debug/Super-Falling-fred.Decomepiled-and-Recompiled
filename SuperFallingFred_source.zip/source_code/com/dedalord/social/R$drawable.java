package com.dedalord.social;
public final class R$drawable {
    public static final int close = 2130837504;
    public static final int facebook_icon = 2130837505;
    public static final int icon = 2130837506;

    public R$drawable()
    {
        return;
    }
}
