.class public Lcom/dedalord/social/Constants;
.super Ljava/lang/Object;

.field public static final ACCESS_URL:Ljava/lang/String;
.field public static final AUTHORIZE_URL:Ljava/lang/String;
.field public static CONSUMER_KEY:Ljava/lang/String;
.field public static CONSUMER_SECRET:Ljava/lang/String;
.field public static final OAUTH_CALLBACK_URL:Ljava/lang/String;
.field public static final REQUEST_URL:Ljava/lang/String;

.method static constructor <clinit>()V
    .registers 1
    const-string v0, "PUT YOUR TWITTER OAUTH CONSUMER KEY HERE"
    sput-object v0, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    const-string v0, "PUT YOUR TWITTER OAUTH CONSUMER SECRET HERE"
    sput-object v0, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
