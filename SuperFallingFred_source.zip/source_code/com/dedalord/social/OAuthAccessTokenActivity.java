package com.dedalord.social;
public class OAuthAccessTokenActivity extends android.app.Activity implements com.dedalord.social.IOAuthTokenCallback {
    final String TAG;
    private boolean cancel;
    private android.content.SharedPreferences prefs;
    private final com.google.api.client.auth.oauth.OAuthHmacSigner signer;
    private com.dedalord.social.TwitterWebViewClient twitterWebViewClient;
    private android.webkit.WebView webview;

    public OAuthAccessTokenActivity()
    {
        this.TAG = "Dedalord";
        this.signer = new com.google.api.client.auth.oauth.OAuthHmacSigner();
        this.cancel = 1;
        return;
    }

    public void OnTokenError(String p3)
    {
        this.cancel = 0;
        android.util.Log.i("Dedalord", "OnTokenError()");
        this.finish();
        com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "loginDidFail", p3);
        return;
    }

    public void OnTokenSuccess(com.google.api.client.auth.oauth.OAuthHmacSigner p5, String p6)
    {
        android.util.Log.i("Dedalord", "OnTokenSuccess()");
        if (this.webview == null) {
            this.webview = new android.webkit.WebView(this, 0, 16842885);
        }
        this.webview.getSettings().setJavaScriptEnabled(1);
        this.webview.setVisibility(0);
        this.setContentView(this.webview);
        if (this.twitterWebViewClient == null) {
            this.twitterWebViewClient = new com.dedalord.social.TwitterWebViewClient(this, p5, this, this.prefs);
        }
        this.webview.setWebViewClient(this.twitterWebViewClient);
        this.webview.loadUrl(p6);
        this.webview.getSettings().setUseWideViewPort(1);
        this.webview.requestFocus(130);
        return;
    }

    public void OnWebViewError(String p3)
    {
        this.cancel = 0;
        android.util.Log.i("Dedalord", "OnWebViewError()");
        this.finish();
        com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "loginDidFail", p3);
        return;
    }

    public void OnWebViewSuccess()
    {
        this.cancel = 0;
        android.util.Log.i("Dedalord", "OnWebViewSuccess()");
        this.finish();
        com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "loginDidSucceed", "");
        return;
    }

    public void onCreate(android.os.Bundle p3)
    {
        super.onCreate(p3);
        android.util.Log.i("Dedalord", "Starting task to retrieve request token.");
        this.prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
        return;
    }

    protected void onDestroy()
    {
        super.onDestroy();
        if (this.cancel) {
            com.unity3d.player.UnityPlayer.UnitySendMessage("TwitterManager", "loginDidFail", "Login cancelled by user...");
        }
        android.util.Log.i("Dedalord", "onDestroy()");
        return;
    }

    protected void onResume()
    {
        super.onResume();
        this.cancel = 1;
        android.util.Log.i("Dedalord", "Retrieving request token from Google servers");
        Void[] v1_0 = new Void[0];
        new com.dedalord.social.OAuthTempTokenTask(this, this.signer, this).execute(v1_0);
        return;
    }
}
