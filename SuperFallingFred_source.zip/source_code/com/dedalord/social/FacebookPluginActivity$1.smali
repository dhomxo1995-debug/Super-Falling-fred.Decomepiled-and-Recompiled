.class 0x0 Lcom/dedalord/social/FacebookPluginActivity$1;
.super Ljava/lang/Object;
.implements Lcom/facebook/android/Facebook$DialogListener;

.field final synthetic this$0:Lcom/dedalord/social/FacebookPluginActivity;

.method constructor <init>(Lcom/dedalord/social/FacebookPluginActivity;)V
    .registers 2
    iput-object v1, v0, Lcom/dedalord/social/FacebookPluginActivity$1;->this$0 Lcom/dedalord/social/FacebookPluginActivity;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onCancel()V
    .registers 4
    const-string v0, "FacebookManager"
    const-string v1, "loginDidFail"
    const-string v2, "Login cancelled..."
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onComplete(Landroid/os/Bundle;)V
    .registers 6
    invoke-static Lcom/dedalord/social/FacebookPluginActivity;->access$000()Landroid/content/SharedPreferences;
    move-result-object v1
    invoke-interface v1, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v1, "access_token"
    invoke-static Lcom/dedalord/social/FacebookPluginActivity;->access$100()Lcom/facebook/android/Facebook;
    move-result-object v2
    invoke-virtual v2, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v2
    invoke-interface v0, v1, v2, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String; Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    const-string v1, "access_expires"
    invoke-static Lcom/dedalord/social/FacebookPluginActivity;->access$100()Lcom/facebook/android/Facebook;
    move-result-object v2
    invoke-virtual v2, Lcom/facebook/android/Facebook;->getAccessExpires()J
    move-result-wide v2
    invoke-interface v0, v1, v2, v3, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String; J)Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->commit()Z
    const-string v1, "FacebookManager"
    const-string v2, "loginDidSucceed"
    const-string v3, ""
    invoke-static v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onError(Lcom/facebook/android/DialogError;)V
    .registers 5
    const-string v0, "FacebookManager"
    const-string v1, "loginDidFail"
    invoke-virtual v4, Lcom/facebook/android/DialogError;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onFacebookError(Lcom/facebook/android/FacebookError;)V
    .registers 5
    const-string v0, "FacebookManager"
    const-string v1, "loginDidFail"
    invoke-virtual v4, Lcom/facebook/android/FacebookError;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method
