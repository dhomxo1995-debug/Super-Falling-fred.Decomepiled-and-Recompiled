package com.dedalord.social;
public class TwitterWebViewClient extends android.webkit.WebViewClient {
    final String TAG;
    private com.dedalord.social.OAuthAccessTokenActivity callback;
    private android.content.Context context;
    private android.content.SharedPreferences prefs;
    private com.google.api.client.auth.oauth.OAuthHmacSigner signer;
    private com.dedalord.social.OAuthTokenTask tokenTask;

    public TwitterWebViewClient(com.dedalord.social.OAuthAccessTokenActivity p2, com.google.api.client.auth.oauth.OAuthHmacSigner p3, android.content.Context p4, android.content.SharedPreferences p5)
    {
        this.TAG = "Dedalord";
        this.signer = p3;
        this.prefs = p5;
        this.callback = p2;
        this.context = p4;
        return;
    }

    public void OnError(android.webkit.WebView p3, String p4)
    {
        android.util.Log.i("Dedalord", "OnError()");
        p3.setVisibility(4);
        new com.dedalord.social.SharedPreferencesCredentialStore(this.prefs).clearCredentials();
        this.callback.OnWebViewError(p4);
        return;
    }

    public void OnSuccess(android.webkit.WebView p5, com.google.api.client.auth.oauth.OAuthCredentialsResponse p6)
    {
        android.util.Log.i("Dedalord", "OnSuccess()");
        com.dedalord.social.SharedPreferencesCredentialStore v0_1 = new com.dedalord.social.SharedPreferencesCredentialStore(this.prefs);
        com.dedalord.social.OAuthAccessTokenActivity v1_5 = new String[2];
        v1_5[0] = p6.token;
        v1_5[1] = p6.tokenSecret;
        v0_1.write(v1_5);
        p5.setVisibility(4);
        this.callback.OnWebViewSuccess();
        return;
    }

    public void onPageFinished(android.webkit.WebView p7, String p8)
    {
        if ((p8.startsWith("http://localhost")) && (this.tokenTask == null)) {
            this.tokenTask = new com.dedalord.social.OAuthTokenTask(this, this.signer, p7, this.context, p8);
            Void[] v1_1 = new Void[0];
            this.tokenTask.execute(v1_1);
        }
        android.util.Log.d("Dedalord", new StringBuilder().append("onPageFinished : ").append(p8).toString());
        return;
    }

    public void onPageStarted(android.webkit.WebView p4, String p5, android.graphics.Bitmap p6)
    {
        android.util.Log.d("Dedalord", new StringBuilder().append("onPageStarted : ").append(p5).toString());
        return;
    }
}
