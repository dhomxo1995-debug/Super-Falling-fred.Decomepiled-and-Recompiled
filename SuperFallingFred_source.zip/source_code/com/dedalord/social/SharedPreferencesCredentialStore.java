package com.dedalord.social;
public class SharedPreferencesCredentialStore implements com.dedalord.social.CredentialStore {
    private static final String TOKEN = "token";
    private static final String TOKEN_SECRET = "token_secret";
    private android.content.SharedPreferences prefs;

    public SharedPreferencesCredentialStore(android.content.SharedPreferences p1)
    {
        this.prefs = p1;
        return;
    }

    public void clearCredentials()
    {
        android.content.SharedPreferences$Editor v0 = this.prefs.edit();
        v0.remove("token");
        v0.remove("token_secret");
        v0.commit();
        return;
    }

    public String[] read()
    {
        String[] v0 = new String[2];
        v0[0] = this.prefs.getString("token", "");
        v0[1] = this.prefs.getString("token_secret", "");
        return v0;
    }

    public void write(String[] p4)
    {
        android.content.SharedPreferences$Editor v0 = this.prefs.edit();
        v0.putString("token", p4[0]);
        v0.putString("token_secret", p4[1]);
        v0.commit();
        return;
    }
}
