package com.dedalord.social;
public class OAuthTokenTask extends android.os.AsyncTask {
    final String TAG;
    private com.dedalord.social.TwitterWebViewClient callback;
    private com.google.api.client.auth.oauth.OAuthCredentialsResponse credentials;
    private boolean res;
    private com.google.api.client.auth.oauth.OAuthHmacSigner signer;
    private String url;
    private android.webkit.WebView view;

    public OAuthTokenTask(com.dedalord.social.TwitterWebViewClient p2, com.google.api.client.auth.oauth.OAuthHmacSigner p3, android.webkit.WebView p4, android.content.Context p5, String p6)
    {
        this.TAG = "Dedalord";
        this.res = 0;
        this.callback = p2;
        this.url = p6;
        this.signer = p3;
        this.view = p4;
        return;
    }

    private String extractParamFromUrl(String p5, String p6)
    {
        return new com.dedalord.social.QueryStringParser(p5.substring((p5.indexOf("?", 0) + 1), p5.length())).getQueryParamValue(p6);
    }

    protected bridge synthetic Object doInBackground(Object[] p2)
    {
        return this.doInBackground(((Void[]) p2));
    }

    protected varargs Void doInBackground(Void[] p9)
    {
        android.util.Log.i("Dedalord", "doInBackground()");
        try {
            if (this.url.indexOf("oauth_token=") == -1) {
                if (this.url.indexOf("error=") != -1) {
                    this.res = 0;
                }
            } else {
                String v2 = this.extractParamFromUrl(this.url, "oauth_token");
                String v3 = this.extractParamFromUrl(this.url, "oauth_verifier");
                this.signer.clientSharedSecret = com.dedalord.social.Constants.CONSUMER_SECRET;
                com.google.api.client.auth.oauth.OAuthGetAccessToken v0_1 = new com.google.api.client.auth.oauth.OAuthGetAccessToken("http://api.twitter.com/oauth/access_token");
                v0_1.transport = new com.google.api.client.http.apache.ApacheHttpTransport();
                v0_1.temporaryToken = v2;
                v0_1.signer = this.signer;
                v0_1.consumerKey = com.dedalord.social.Constants.CONSUMER_KEY;
                v0_1.verifier = v3;
                this.credentials = v0_1.execute();
                this.signer.tokenSharedSecret = this.credentials.tokenSecret;
                this.res = 1;
            }
        } catch (java.io.IOException v1) {
            v1.printStackTrace();
            this.res = 0;
        }
        return 0;
    }

    protected bridge synthetic void onPostExecute(Object p1)
    {
        this.onPostExecute(((Void) p1));
        return;
    }

    protected void onPostExecute(Void p4)
    {
        android.util.Log.i("Dedalord", "OnPostExecute()");
        if (!this.res) {
            this.callback.OnError(this.view, this.url);
        } else {
            this.callback.OnSuccess(this.view, this.credentials);
        }
        return;
    }

    protected void onPreExecute()
    {
        return;
    }
}
