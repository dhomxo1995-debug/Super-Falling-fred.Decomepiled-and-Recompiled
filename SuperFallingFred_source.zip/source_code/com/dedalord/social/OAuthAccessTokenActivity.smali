.class public Lcom/dedalord/social/OAuthAccessTokenActivity;
.super Landroid/app/Activity;
.implements Lcom/dedalord/social/IOAuthTokenCallback;

.field final TAG:Ljava/lang/String;
.field private cancel:Z
.field private prefs:Landroid/content/SharedPreferences;
.field private final signer:Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
.field private twitterWebViewClient:Lcom/dedalord/social/TwitterWebViewClient;
.field private webview:Landroid/webkit/WebView;

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Landroid/app/Activity;-><init>()V
    const-string v0, "Dedalord"
    iput-object v0, v1, Lcom/dedalord/social/OAuthAccessTokenActivity;->TAG Ljava/lang/String;
    new-instance v0, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    invoke-direct v0, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;-><init>()V
    iput-object v0, v1, Lcom/dedalord/social/OAuthAccessTokenActivity;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    return-void
.end method

.method public OnTokenError(Ljava/lang/String;)V
    .registers 4
    const/4 v0, 0
    iput-boolean v0, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    const-string v0, "Dedalord"
    const-string v1, "OnTokenError()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->finish()V
    const-string v0, "TwitterManager"
    const-string v1, "loginDidFail"
    invoke-static v0, v1, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public OnTokenSuccess(Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Ljava/lang/String;)V
    .registers 7
    const/4 v3, 1
    const-string v0, "Dedalord"
    const-string v1, "OnTokenSuccess()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    if-nez v0, +00dh
    new-instance v0, Landroid/webkit/WebView;
    const/4 v1, 0
    const v2, 16842885
    invoke-direct v0, v4, v1, v2, Landroid/webkit/WebView;-><init>(Landroid/content/Context; Landroid/util/AttributeSet; I)V
    iput-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    invoke-virtual v0, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v0
    invoke-virtual v0, v3, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    const/4 v1, 0
    invoke-virtual v0, v1, Landroid/webkit/WebView;->setVisibility(I)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    invoke-virtual v4, v0, Lcom/dedalord/social/OAuthAccessTokenActivity;->setContentView(Landroid/view/View;)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->twitterWebViewClient Lcom/dedalord/social/TwitterWebViewClient;
    if-nez v0, +00bh
    new-instance v0, Lcom/dedalord/social/TwitterWebViewClient;
    iget-object v1, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->prefs Landroid/content/SharedPreferences;
    invoke-direct v0, v4, v5, v4, v1, Lcom/dedalord/social/TwitterWebViewClient;-><init>(Lcom/dedalord/social/OAuthAccessTokenActivity; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/content/Context; Landroid/content/SharedPreferences;)V
    iput-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->twitterWebViewClient Lcom/dedalord/social/TwitterWebViewClient;
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    iget-object v1, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->twitterWebViewClient Lcom/dedalord/social/TwitterWebViewClient;
    invoke-virtual v0, v1, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    invoke-virtual v0, v6, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    invoke-virtual v0, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v0
    invoke-virtual v0, v3, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V
    iget-object v0, v4, Lcom/dedalord/social/OAuthAccessTokenActivity;->webview Landroid/webkit/WebView;
    const/16 v1, 130
    invoke-virtual v0, v1, Landroid/webkit/WebView;->requestFocus(I)Z
    return-void
.end method

.method public OnWebViewError(Ljava/lang/String;)V
    .registers 4
    const/4 v0, 0
    iput-boolean v0, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    const-string v0, "Dedalord"
    const-string v1, "OnWebViewError()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->finish()V
    const-string v0, "TwitterManager"
    const-string v1, "loginDidFail"
    invoke-static v0, v1, v3, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public OnWebViewSuccess()V
    .registers 4
    const/4 v0, 0
    iput-boolean v0, v3, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    const-string v0, "Dedalord"
    const-string v1, "OnWebViewSuccess()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    invoke-virtual v3, Lcom/dedalord/social/OAuthAccessTokenActivity;->finish()V
    const-string v0, "TwitterManager"
    const-string v1, "loginDidSucceed"
    const-string v2, ""
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 4
    invoke-super v2, v3, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    const-string v0, "Dedalord"
    const-string v1, "Starting task to retrieve request token."
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    invoke-static v2, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;
    move-result-object v0
    iput-object v0, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->prefs Landroid/content/SharedPreferences;
    return-void
.end method

.method protected onDestroy()V
    .registers 4
    invoke-super v3, Landroid/app/Activity;->onDestroy()V
    iget-boolean v0, v3, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    if-eqz v0, +00bh
    const-string v0, "TwitterManager"
    const-string v1, "loginDidFail"
    const-string v2, "Login cancelled by user..."
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    const-string v0, "Dedalord"
    const-string v1, "onDestroy()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method

.method protected onResume()V
    .registers 3
    invoke-super v2, Landroid/app/Activity;->onResume()V
    const/4 v0, 1
    iput-boolean v0, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->cancel Z
    const-string v0, "Dedalord"
    const-string v1, "Retrieving request token from Google servers"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    new-instance v0, Lcom/dedalord/social/OAuthTempTokenTask;
    iget-object v1, v2, Lcom/dedalord/social/OAuthAccessTokenActivity;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    invoke-direct v0, v2, v1, v2, Lcom/dedalord/social/OAuthTempTokenTask;-><init>(Lcom/dedalord/social/OAuthAccessTokenActivity; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/content/Context;)V
    const/4 v1, 0
    new-array v1, v1, [Ljava/lang/Void;
    invoke-virtual v0, v1, Lcom/dedalord/social/OAuthTempTokenTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    return-void
.end method
