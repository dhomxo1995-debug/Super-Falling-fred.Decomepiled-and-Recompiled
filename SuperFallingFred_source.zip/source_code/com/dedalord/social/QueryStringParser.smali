.class public Lcom/dedalord/social/QueryStringParser;
.super Ljava/lang/Object;

.field private paramBegin:I
.field private paramEnd:I
.field private paramName:Ljava/lang/String;
.field private paramNameEnd:I
.field private paramPairs:Ljava/util/Map;
.field private paramValue:Ljava/lang/String;
.field private final queryString:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String;)V
    .registers 5
    invoke-direct v3, Ljava/lang/Object;-><init>()V
    const/4 v0, -1
    iput v0, v3, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v3, Lcom/dedalord/social/QueryStringParser;->paramPairs Ljava/util/Map;
    iput-object v4, v3, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    invoke-direct v3, Lcom/dedalord/social/QueryStringParser;->next()Z
    move-result v0
    if-eqz v0, +010h
    iget-object v0, v3, Lcom/dedalord/social/QueryStringParser;->paramPairs Ljava/util/Map;
    invoke-direct v3, Lcom/dedalord/social/QueryStringParser;->getName()Ljava/lang/String;
    move-result-object v1
    invoke-direct v3, Lcom/dedalord/social/QueryStringParser;->getValue()Ljava/lang/String;
    move-result-object v2
    invoke-interface v0, v1, v2, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -13h
    return-void
.end method

.method private getName()Ljava/lang/String;
    .registers 4
    iget-object v0, v3, Lcom/dedalord/social/QueryStringParser;->paramName Ljava/lang/String;
    if-nez v0, +00eh
    iget-object v0, v3, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    iget v1, v3, Lcom/dedalord/social/QueryStringParser;->paramBegin I
    iget v2, v3, Lcom/dedalord/social/QueryStringParser;->paramNameEnd I
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v3, Lcom/dedalord/social/QueryStringParser;->paramName Ljava/lang/String;
    iget-object v0, v3, Lcom/dedalord/social/QueryStringParser;->paramName Ljava/lang/String;
    return-object v0
.end method

.method private getValue()Ljava/lang/String;
    .registers 5
    iget-object v1, v4, Lcom/dedalord/social/QueryStringParser;->paramValue Ljava/lang/String;
    if-nez v1, +01ch
    iget v1, v4, Lcom/dedalord/social/QueryStringParser;->paramNameEnd I
    iget v2, v4, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    if-ne v1, v2, +004h
    const/4 v1, 0
    return-object v1
    iget-object v1, v4, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    iget v2, v4, Lcom/dedalord/social/QueryStringParser;->paramNameEnd I
    add-int/lit8 v2, v2, 1
    iget v3, v4, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    invoke-virtual v1, v2, v3, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v1
    invoke-static v1, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    iput-object v1, v4, Lcom/dedalord/social/QueryStringParser;->paramValue Ljava/lang/String;
    iget-object v1, v4, Lcom/dedalord/social/QueryStringParser;->paramValue Ljava/lang/String;
    goto -15h
    move-exception v0
    new-instance v1, Ljava/lang/Error;
    invoke-direct v1, v0, Ljava/lang/Error;-><init>(Ljava/lang/Throwable;)V
    throw v1
.end method

.method private next()Z
    .registers 9
    const/4 v7, 0
    const/4 v3, 0
    const/4 v6, -1
    iget-object v2, v8, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    invoke-virtual v2, Ljava/lang/String;->length()I
    move-result v1
    iget v2, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    if-ne v2, v1, +003h
    return v3
    iget v2, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    if-ne v2, v6, +034h
    move v2, v3
    iput v2, v8, Lcom/dedalord/social/QueryStringParser;->paramBegin I
    iget-object v2, v8, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    const/16 v4, 38
    iget v5, v8, Lcom/dedalord/social/QueryStringParser;->paramBegin I
    invoke-virtual v2, v4, v5, Ljava/lang/String;->indexOf(I I)I
    move-result v0
    if-ne v0, v6, +003h
    move v0, v1
    iput v0, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    iget v2, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    iget v4, v8, Lcom/dedalord/social/QueryStringParser;->paramBegin I
    if-le v2, v4, -01fh
    iget-object v2, v8, Lcom/dedalord/social/QueryStringParser;->queryString Ljava/lang/String;
    const/16 v3, 61
    iget v4, v8, Lcom/dedalord/social/QueryStringParser;->paramBegin I
    invoke-virtual v2, v3, v4, Ljava/lang/String;->indexOf(I I)I
    move-result v0
    if-eq v0, v6, +006h
    iget v2, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    if-le v0, v2, +004h
    iget v0, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    iput v0, v8, Lcom/dedalord/social/QueryStringParser;->paramNameEnd I
    iput-object v7, v8, Lcom/dedalord/social/QueryStringParser;->paramName Ljava/lang/String;
    iput-object v7, v8, Lcom/dedalord/social/QueryStringParser;->paramValue Ljava/lang/String;
    const/4 v3, 1
    goto -36h
    iget v2, v8, Lcom/dedalord/social/QueryStringParser;->paramEnd I
    add-int/lit8 v2, v2, 1
    goto -35h
.end method

.method public getQueryParamValue(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    iget-object v0, v1, Lcom/dedalord/social/QueryStringParser;->paramPairs Ljava/util/Map;
    invoke-interface v0, v2, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    return-object v0
.end method
