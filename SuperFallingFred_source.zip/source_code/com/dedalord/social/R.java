package com.dedalord.social;
public final class R {

    public R()
    {
        return;
    }
}
