.class public Lcom/dedalord/social/SharedPreferencesCredentialStore;
.super Ljava/lang/Object;
.implements Lcom/dedalord/social/CredentialStore;

.field private static final TOKEN:Ljava/lang/String;
.field private static final TOKEN_SECRET:Ljava/lang/String;
.field private prefs:Landroid/content/SharedPreferences;

.method public constructor <init>(Landroid/content/SharedPreferences;)V
    .registers 2
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-object v1, v0, Lcom/dedalord/social/SharedPreferencesCredentialStore;->prefs Landroid/content/SharedPreferences;
    return-void
.end method

.method public clearCredentials()V
    .registers 3
    iget-object v1, v2, Lcom/dedalord/social/SharedPreferencesCredentialStore;->prefs Landroid/content/SharedPreferences;
    invoke-interface v1, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v1, "token"
    invoke-interface v0, v1, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    const-string v1, "token_secret"
    invoke-interface v0, v1, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->commit()Z
    return-void
.end method

.method public read()[Ljava/lang/String;
    .registers 6
    const/4 v1, 2
    new-array v0, v1, [Ljava/lang/String;
    const/4 v1, 0
    iget-object v2, v5, Lcom/dedalord/social/SharedPreferencesCredentialStore;->prefs Landroid/content/SharedPreferences;
    const-string v3, "token"
    const-string v4, ""
    invoke-interface v2, v3, v4, Landroid/content/SharedPreferences;->getString(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    aput-object v2, v0, v1
    const/4 v1, 1
    iget-object v2, v5, Lcom/dedalord/social/SharedPreferencesCredentialStore;->prefs Landroid/content/SharedPreferences;
    const-string v3, "token_secret"
    const-string v4, ""
    invoke-interface v2, v3, v4, Landroid/content/SharedPreferences;->getString(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    aput-object v2, v0, v1
    return-object v0
.end method

.method public write([Ljava/lang/String;)V
    .registers 5
    iget-object v1, v3, Lcom/dedalord/social/SharedPreferencesCredentialStore;->prefs Landroid/content/SharedPreferences;
    invoke-interface v1, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    const-string v1, "token"
    const/4 v2, 0
    aget-object v2, v4, v2
    invoke-interface v0, v1, v2, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String; Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    const-string v1, "token_secret"
    const/4 v2, 1
    aget-object v2, v4, v2
    invoke-interface v0, v1, v2, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String; Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->commit()Z
    return-void
.end method
