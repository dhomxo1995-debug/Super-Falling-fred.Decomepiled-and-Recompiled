package com.dedalord.social;
public class UserFriendsRequestListener implements com.facebook.android.AsyncFacebookRunner$RequestListener {

    public UserFriendsRequestListener()
    {
        return;
    }

    public void onComplete(String p3, Object p4)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestFriendsList", p3);
        return;
    }

    public void onFacebookError(com.facebook.android.FacebookError p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestUserDataFailed", p4.getMessage());
        return;
    }

    public void onFileNotFoundException(java.io.FileNotFoundException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestUserDataFailed", p4.getMessage());
        return;
    }

    public void onIOException(java.io.IOException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestUserDataFailed", p4.getMessage());
        return;
    }

    public void onMalformedURLException(java.net.MalformedURLException p4, Object p5)
    {
        com.unity3d.player.UnityPlayer.UnitySendMessage("FacebookManager", "requestUserDataFailed", p4.getMessage());
        return;
    }
}
