.class public Lcom/dedalord/social/RevokePermissionListener;
.super Ljava/lang/Object;
.implements Lcom/facebook/android/AsyncFacebookRunner$RequestListener;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onComplete(Ljava/lang/String; Ljava/lang/Object;)V
    .registers 3
    return-void
.end method

.method public onFacebookError(Lcom/facebook/android/FacebookError; Ljava/lang/Object;)V
    .registers 3
    return-void
.end method

.method public onFileNotFoundException(Ljava/io/FileNotFoundException; Ljava/lang/Object;)V
    .registers 3
    return-void
.end method

.method public onIOException(Ljava/io/IOException; Ljava/lang/Object;)V
    .registers 3
    return-void
.end method

.method public onMalformedURLException(Ljava/net/MalformedURLException; Ljava/lang/Object;)V
    .registers 3
    return-void
.end method
