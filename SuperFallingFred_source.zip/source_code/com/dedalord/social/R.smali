.class public final Lcom/dedalord/social/R;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
