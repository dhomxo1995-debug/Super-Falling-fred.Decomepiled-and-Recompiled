.class public Lcom/dedalord/social/OAuthTokenTask;
.super Landroid/os/AsyncTask;

.field final TAG:Ljava/lang/String;
.field private callback:Lcom/dedalord/social/TwitterWebViewClient;
.field private credentials:Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
.field private res:Z
.field private signer:Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
.field private url:Ljava/lang/String;
.field private view:Landroid/webkit/WebView;

.method public constructor <init>(Lcom/dedalord/social/TwitterWebViewClient; Lcom/google/api/client/auth/oauth/OAuthHmacSigner; Landroid/webkit/WebView; Landroid/content/Context; Ljava/lang/String;)V
    .registers 7
    invoke-direct v1, Landroid/os/AsyncTask;-><init>()V
    const-string v0, "Dedalord"
    iput-object v0, v1, Lcom/dedalord/social/OAuthTokenTask;->TAG Ljava/lang/String;
    const/4 v0, 0
    iput-boolean v0, v1, Lcom/dedalord/social/OAuthTokenTask;->res Z
    iput-object v2, v1, Lcom/dedalord/social/OAuthTokenTask;->callback Lcom/dedalord/social/TwitterWebViewClient;
    iput-object v6, v1, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    iput-object v3, v1, Lcom/dedalord/social/OAuthTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iput-object v4, v1, Lcom/dedalord/social/OAuthTokenTask;->view Landroid/webkit/WebView;
    return-void
.end method

.method private extractParamFromUrl(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    const-string v2, "?"
    const/4 v3, 0
    invoke-virtual v5, v2, v3, Ljava/lang/String;->indexOf(Ljava/lang/String; I)I
    move-result v2
    add-int/lit8 v2, v2, 1
    invoke-virtual v5, Ljava/lang/String;->length()I
    move-result v3
    invoke-virtual v5, v2, v3, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v0
    new-instance v1, Lcom/dedalord/social/QueryStringParser;
    invoke-direct v1, v0, Lcom/dedalord/social/QueryStringParser;-><init>(Ljava/lang/String;)V
    invoke-virtual v1, v6, Lcom/dedalord/social/QueryStringParser;->getQueryParamValue(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    return-object v2
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    check-cast v2, [Ljava/lang/Void;
    invoke-virtual v1, v2, Lcom/dedalord/social/OAuthTokenTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    move-result-object v0
    return-object v0
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    .registers 10
    const/4 v7, 0
    const/4 v6, -1
    const-string v4, "Dedalord"
    const-string v5, "doInBackground()"
    invoke-static v4, v5, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    const-string v5, "oauth_token="
    invoke-virtual v4, v5, Ljava/lang/String;->indexOf(Ljava/lang/String;)I
    move-result v4
    if-eq v4, v6, +045h
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    const-string v5, "oauth_token"
    invoke-direct v8, v4, v5, Lcom/dedalord/social/OAuthTokenTask;->extractParamFromUrl(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    const-string v5, "oauth_verifier"
    invoke-direct v8, v4, v5, Lcom/dedalord/social/OAuthTokenTask;->extractParamFromUrl(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    sget-object v5, Lcom/dedalord/social/Constants;->CONSUMER_SECRET Ljava/lang/String;
    iput-object v5, v4, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->clientSharedSecret Ljava/lang/String;
    new-instance v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;
    const-string v4, "http://api.twitter.com/oauth/access_token"
    invoke-direct v0, v4, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;-><init>(Ljava/lang/String;)V
    new-instance v4, Lcom/google/api/client/http/apache/ApacheHttpTransport;
    invoke-direct v4, Lcom/google/api/client/http/apache/ApacheHttpTransport;-><init>()V
    iput-object v4, v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->transport Lcom/google/api/client/http/HttpTransport;
    iput-object v2, v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->temporaryToken Ljava/lang/String;
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iput-object v4, v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->signer Lcom/google/api/client/auth/oauth/OAuthSigner;
    sget-object v4, Lcom/dedalord/social/Constants;->CONSUMER_KEY Ljava/lang/String;
    iput-object v4, v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->consumerKey Ljava/lang/String;
    iput-object v3, v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->verifier Ljava/lang/String;
    invoke-virtual v0, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->execute()Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    move-result-object v4
    iput-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->credentials Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->signer Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
    iget-object v5, v8, Lcom/dedalord/social/OAuthTokenTask;->credentials Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    iget-object v5, v5, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;->tokenSecret Ljava/lang/String;
    iput-object v5, v4, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->tokenSharedSecret Ljava/lang/String;
    const/4 v4, 1
    iput-boolean v4, v8, Lcom/dedalord/social/OAuthTokenTask;->res Z
    const/4 v4, 0
    return-object v4
    iget-object v4, v8, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    const-string v5, "error="
    invoke-virtual v4, v5, Ljava/lang/String;->indexOf(Ljava/lang/String;)I
    move-result v4
    if-eq v4, v6, -00ah
    const/4 v4, 0
    iput-boolean v4, v8, Lcom/dedalord/social/OAuthTokenTask;->res Z
    goto -fh
    move-exception v1
    invoke-virtual v1, Ljava/io/IOException;->printStackTrace()V
    iput-boolean v7, v8, Lcom/dedalord/social/OAuthTokenTask;->res Z
    goto -16h
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2
    check-cast v1, Ljava/lang/Void;
    invoke-virtual v0, v1, Lcom/dedalord/social/OAuthTokenTask;->onPostExecute(Ljava/lang/Void;)V
    return-void
.end method

.method protected onPostExecute(Ljava/lang/Void;)V
    .registers 5
    const-string v0, "Dedalord"
    const-string v1, "OnPostExecute()"
    invoke-static v0, v1, Landroid/util/Log;->i(Ljava/lang/String; Ljava/lang/String;)I
    iget-boolean v0, v3, Lcom/dedalord/social/OAuthTokenTask;->res Z
    if-eqz v0, +00ch
    iget-object v0, v3, Lcom/dedalord/social/OAuthTokenTask;->callback Lcom/dedalord/social/TwitterWebViewClient;
    iget-object v1, v3, Lcom/dedalord/social/OAuthTokenTask;->view Landroid/webkit/WebView;
    iget-object v2, v3, Lcom/dedalord/social/OAuthTokenTask;->credentials Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    invoke-virtual v0, v1, v2, Lcom/dedalord/social/TwitterWebViewClient;->OnSuccess(Landroid/webkit/WebView; Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;)V
    return-void
    iget-object v0, v3, Lcom/dedalord/social/OAuthTokenTask;->callback Lcom/dedalord/social/TwitterWebViewClient;
    iget-object v1, v3, Lcom/dedalord/social/OAuthTokenTask;->view Landroid/webkit/WebView;
    iget-object v2, v3, Lcom/dedalord/social/OAuthTokenTask;->url Ljava/lang/String;
    invoke-virtual v0, v1, v2, Lcom/dedalord/social/TwitterWebViewClient;->OnError(Landroid/webkit/WebView; Ljava/lang/String;)V
    goto -ah
.end method

.method protected onPreExecute()V
    .registers 1
    return-void
.end method
