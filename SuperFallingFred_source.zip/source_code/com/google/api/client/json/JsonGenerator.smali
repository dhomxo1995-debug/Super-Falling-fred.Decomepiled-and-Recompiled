.class public abstract Lcom/google/api/client/json/JsonGenerator;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public abstract close()V
    # abstract or native method
.end method

.method public enablePrettyPrint()V
    .registers 1
    return-void
.end method

.method public abstract flush()V
    # abstract or native method
.end method

.method public abstract getFactory()Lcom/google/api/client/json/JsonFactory;
    # abstract or native method
.end method

.method public final serialize(Ljava/lang/Object;)V
    .registers 13
    if-nez v12, +003h
    return-void
    invoke-virtual v12, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v8
    invoke-static v12, Lcom/google/api/client/util/Data;->isNull(Ljava/lang/Object;)Z
    move-result v9
    if-eqz v9, +006h
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeNull()V
    goto -eh
    instance-of v9, v12, Ljava/lang/String;
    if-eqz v9, +008h
    check-cast v12, Ljava/lang/String;
    invoke-virtual v11, v12, Lcom/google/api/client/json/JsonGenerator;->writeString(Ljava/lang/String;)V
    goto -18h
    instance-of v9, v12, Ljava/math/BigDecimal;
    if-eqz v9, +008h
    check-cast v12, Ljava/math/BigDecimal;
    invoke-virtual v11, v12, Lcom/google/api/client/json/JsonGenerator;->writeNumber(Ljava/math/BigDecimal;)V
    goto -22h
    instance-of v9, v12, Ljava/math/BigInteger;
    if-eqz v9, +008h
    check-cast v12, Ljava/math/BigInteger;
    invoke-virtual v11, v12, Lcom/google/api/client/json/JsonGenerator;->writeNumber(Ljava/math/BigInteger;)V
    goto -2ch
    instance-of v9, v12, Lcom/google/common/primitives/UnsignedInteger;
    if-eqz v9, +008h
    check-cast v12, Lcom/google/common/primitives/UnsignedInteger;
    invoke-virtual v11, v12, Lcom/google/api/client/json/JsonGenerator;->writeNumber(Lcom/google/common/primitives/UnsignedInteger;)V
    goto -36h
    instance-of v9, v12, Lcom/google/common/primitives/UnsignedLong;
    if-eqz v9, +008h
    check-cast v12, Lcom/google/common/primitives/UnsignedLong;
    invoke-virtual v11, v12, Lcom/google/api/client/json/JsonGenerator;->writeNumber(Lcom/google/common/primitives/UnsignedLong;)V
    goto -40h
    instance-of v9, v12, Ljava/lang/Double;
    if-eqz v9, +00ch
    check-cast v12, Ljava/lang/Double;
    invoke-virtual v12, Ljava/lang/Double;->doubleValue()D
    move-result-wide v9
    invoke-virtual v11, v9, v10, Lcom/google/api/client/json/JsonGenerator;->writeNumber(D)V
    goto -4eh
    instance-of v9, v12, Ljava/lang/Long;
    if-eqz v9, +00ch
    check-cast v12, Ljava/lang/Long;
    invoke-virtual v12, Ljava/lang/Long;->longValue()J
    move-result-wide v9
    invoke-virtual v11, v9, v10, Lcom/google/api/client/json/JsonGenerator;->writeNumber(J)V
    goto -5ch
    instance-of v9, v12, Ljava/lang/Float;
    if-eqz v9, +00ch
    check-cast v12, Ljava/lang/Float;
    invoke-virtual v12, Ljava/lang/Float;->floatValue()F
    move-result v9
    invoke-virtual v11, v9, Lcom/google/api/client/json/JsonGenerator;->writeNumber(F)V
    goto -6ah
    instance-of v9, v12, Ljava/lang/Integer;
    if-nez v9, +00ah
    instance-of v9, v12, Ljava/lang/Short;
    if-nez v9, +006h
    instance-of v9, v12, Ljava/lang/Byte;
    if-eqz v9, +00ch
    check-cast v12, Ljava/lang/Number;
    invoke-virtual v12, Ljava/lang/Number;->intValue()I
    move-result v9
    invoke-virtual v11, v9, Lcom/google/api/client/json/JsonGenerator;->writeNumber(I)V
    goto -80h
    instance-of v9, v12, Ljava/lang/Boolean;
    if-eqz v9, +00dh
    check-cast v12, Ljava/lang/Boolean;
    invoke-virtual v12, Ljava/lang/Boolean;->booleanValue()Z
    move-result v9
    invoke-virtual v11, v9, Lcom/google/api/client/json/JsonGenerator;->writeBoolean(Z)V
    goto/16 -08eh
    instance-of v9, v12, Lcom/google/api/client/util/DateTime;
    if-eqz v9, +00dh
    check-cast v12, Lcom/google/api/client/util/DateTime;
    invoke-virtual v12, Lcom/google/api/client/util/DateTime;->toStringRfc3339()Ljava/lang/String;
    move-result-object v9
    invoke-virtual v11, v9, Lcom/google/api/client/json/JsonGenerator;->writeString(Ljava/lang/String;)V
    goto/16 -09dh
    instance-of v9, v12, Ljava/lang/Iterable;
    if-nez v9, +008h
    invoke-virtual v8, Ljava/lang/Class;->isArray()Z
    move-result v9
    if-eqz v9, +020h
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeStartArray()V
    invoke-static v12, Lcom/google/api/client/util/Types;->iterableOf(Ljava/lang/Object;)Ljava/lang/Iterable;
    move-result-object v9
    invoke-interface v9, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    move-result-object v5
    invoke-interface v5, Ljava/util/Iterator;->hasNext()Z
    move-result v9
    if-eqz v9, +00ah
    invoke-interface v5, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v7
    invoke-virtual v11, v7, Lcom/google/api/client/json/JsonGenerator;->serialize(Ljava/lang/Object;)V
    goto -dh
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeEndArray()V
    goto/16 -0c5h
    invoke-virtual v8, Ljava/lang/Class;->isEnum()Z
    move-result v9
    if-eqz v9, +018h
    check-cast v12, Ljava/lang/Enum;
    invoke-static v12, Lcom/google/api/client/util/FieldInfo;->of(Ljava/lang/Enum;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v9
    invoke-virtual v9, Lcom/google/api/client/util/FieldInfo;->getName()Ljava/lang/String;
    move-result-object v6
    if-nez v6, +007h
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeNull()V
    goto/16 -0dch
    invoke-virtual v11, v6, Lcom/google/api/client/json/JsonGenerator;->writeString(Ljava/lang/String;)V
    goto/16 -0e1h
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeStartObject()V
    invoke-static v8, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v0
    invoke-static v12, Lcom/google/api/client/util/Data;->mapOf(Ljava/lang/Object;)Ljava/util/Map;
    move-result-object v9
    invoke-interface v9, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v9
    invoke-interface v9, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v5
    invoke-interface v5, Ljava/util/Iterator;->hasNext()Z
    move-result v9
    if-eqz v9, +031h
    invoke-interface v5, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/util/Map$Entry;
    invoke-interface v1, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v4
    if-eqz v4, -010h
    invoke-interface v1, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v3
    check-cast v3, Ljava/lang/String;
    instance-of v9, v4, Ljava/lang/Number;
    if-eqz v9, +014h
    invoke-virtual v0, v3, Lcom/google/api/client/util/ClassInfo;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    move-result-object v2
    if-eqz v2, +00eh
    const-class v9, Lcom/google/api/client/json/JsonString;
    invoke-virtual v2, v9, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v9
    if-eqz v9, +006h
    invoke-virtual v4, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v11, v3, Lcom/google/api/client/json/JsonGenerator;->writeFieldName(Ljava/lang/String;)V
    invoke-virtual v11, v4, Lcom/google/api/client/json/JsonGenerator;->serialize(Ljava/lang/Object;)V
    goto -34h
    invoke-virtual v11, Lcom/google/api/client/json/JsonGenerator;->writeEndObject()V
    goto/16 -12eh
.end method

.method public abstract writeBoolean(Z)V
    # abstract or native method
.end method

.method public abstract writeEndArray()V
    # abstract or native method
.end method

.method public abstract writeEndObject()V
    # abstract or native method
.end method

.method public abstract writeFieldName(Ljava/lang/String;)V
    # abstract or native method
.end method

.method public abstract writeNull()V
    # abstract or native method
.end method

.method public abstract writeNumber(D)V
    # abstract or native method
.end method

.method public abstract writeNumber(F)V
    # abstract or native method
.end method

.method public abstract writeNumber(I)V
    # abstract or native method
.end method

.method public abstract writeNumber(J)V
    # abstract or native method
.end method

.method public abstract writeNumber(Lcom/google/common/primitives/UnsignedInteger;)V
    # abstract or native method
.end method

.method public abstract writeNumber(Lcom/google/common/primitives/UnsignedLong;)V
    # abstract or native method
.end method

.method public abstract writeNumber(Ljava/lang/String;)V
    # abstract or native method
.end method

.method public abstract writeNumber(Ljava/math/BigDecimal;)V
    # abstract or native method
.end method

.method public abstract writeNumber(Ljava/math/BigInteger;)V
    # abstract or native method
.end method

.method public abstract writeStartArray()V
    # abstract or native method
.end method

.method public abstract writeStartObject()V
    # abstract or native method
.end method

.method public abstract writeString(Ljava/lang/String;)V
    # abstract or native method
.end method
