.class public interface abstract Lcom/google/api/client/json/JsonString;
.super Ljava/lang/Object;
.implements Ljava/lang/annotation/Annotation;
