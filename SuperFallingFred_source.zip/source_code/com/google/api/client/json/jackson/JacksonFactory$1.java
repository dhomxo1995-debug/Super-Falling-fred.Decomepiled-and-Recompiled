package com.google.api.client.json.jackson;
synthetic class JacksonFactory$1 {
    static final synthetic int[] $SwitchMap$org$codehaus$jackson$JsonToken;

    static JacksonFactory$1()
    {
        NoSuchFieldError v0_5 = new int[org.codehaus.jackson.JsonToken.values().length];
        com.google.api.client.json.jackson.JacksonFactory$1.$SwitchMap$org$codehaus$jackson$JsonToken = v0_5;
        try {
            org.codehaus.jackson.JsonToken.END_ARRAY.ordinal()[int v1_21] = 1;
            try {
                org.codehaus.jackson.JsonToken.START_ARRAY.ordinal()[int v1_1] = 2;
                try {
                    org.codehaus.jackson.JsonToken.END_OBJECT.ordinal()[int v1_3] = 3;
                    try {
                        org.codehaus.jackson.JsonToken.START_OBJECT.ordinal()[int v1_5] = 4;
                        try {
                            org.codehaus.jackson.JsonToken.VALUE_FALSE.ordinal()[int v1_7] = 5;
                            try {
                                org.codehaus.jackson.JsonToken.VALUE_TRUE.ordinal()[int v1_9] = 6;
                                try {
                                    org.codehaus.jackson.JsonToken.VALUE_NULL.ordinal()[int v1_11] = 7;
                                    try {
                                        org.codehaus.jackson.JsonToken.VALUE_STRING.ordinal()[int v1_13] = 8;
                                        try {
                                            org.codehaus.jackson.JsonToken.VALUE_NUMBER_FLOAT.ordinal()[int v1_16] = 9;
                                            try {
                                                org.codehaus.jackson.JsonToken.VALUE_NUMBER_INT.ordinal()[int v1_18] = 10;
                                                try {
                                                    org.codehaus.jackson.JsonToken.FIELD_NAME.ordinal()[int v1_20] = 11;
                                                } catch (NoSuchFieldError v0) {
                                                }
                                                return;
                                            } catch (NoSuchFieldError v0) {
                                            }
                                        } catch (NoSuchFieldError v0) {
                                        }
                                    } catch (NoSuchFieldError v0) {
                                    }
                                } catch (NoSuchFieldError v0) {
                                }
                            } catch (NoSuchFieldError v0) {
                            }
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
