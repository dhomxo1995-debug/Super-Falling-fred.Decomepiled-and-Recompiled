package com.google.api.client.json.jackson;
final class JacksonParser extends com.google.api.client.json.JsonParser {
    private final com.google.api.client.json.jackson.JacksonFactory factory;
    private final org.codehaus.jackson.JsonParser parser;

    JacksonParser(com.google.api.client.json.jackson.JacksonFactory p1, org.codehaus.jackson.JsonParser p2)
    {
        this.factory = p1;
        this.parser = p2;
        return;
    }

    public void close()
    {
        this.parser.close();
        return;
    }

    public java.math.BigInteger getBigIntegerValue()
    {
        return this.parser.getBigIntegerValue();
    }

    public byte getByteValue()
    {
        return this.parser.getByteValue();
    }

    public String getCurrentName()
    {
        return this.parser.getCurrentName();
    }

    public com.google.api.client.json.JsonToken getCurrentToken()
    {
        return com.google.api.client.json.jackson.JacksonFactory.convert(this.parser.getCurrentToken());
    }

    public java.math.BigDecimal getDecimalValue()
    {
        return this.parser.getDecimalValue();
    }

    public double getDoubleValue()
    {
        return this.parser.getDoubleValue();
    }

    public bridge synthetic com.google.api.client.json.JsonFactory getFactory()
    {
        return this.getFactory();
    }

    public com.google.api.client.json.jackson.JacksonFactory getFactory()
    {
        return this.factory;
    }

    public float getFloatValue()
    {
        return this.parser.getFloatValue();
    }

    public int getIntValue()
    {
        return this.parser.getIntValue();
    }

    public long getLongValue()
    {
        return this.parser.getLongValue();
    }

    public short getShortValue()
    {
        return this.parser.getShortValue();
    }

    public String getText()
    {
        return this.parser.getText();
    }

    public com.google.common.primitives.UnsignedInteger getUnsignedIntegerValue()
    {
        return com.google.common.primitives.UnsignedInteger.valueOf(this.parser.getLongValue());
    }

    public com.google.common.primitives.UnsignedLong getUnsignedLongValue()
    {
        return com.google.common.primitives.UnsignedLong.valueOf(this.parser.getBigIntegerValue());
    }

    public com.google.api.client.json.JsonToken nextToken()
    {
        return com.google.api.client.json.jackson.JacksonFactory.convert(this.parser.nextToken());
    }

    public com.google.api.client.json.JsonParser skipChildren()
    {
        this.parser.skipChildren();
        return this;
    }
}
