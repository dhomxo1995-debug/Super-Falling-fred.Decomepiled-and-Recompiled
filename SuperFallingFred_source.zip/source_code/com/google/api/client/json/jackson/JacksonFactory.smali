.class public final Lcom/google/api/client/json/jackson/JacksonFactory;
.super Lcom/google/api/client/json/JsonFactory;

.field private final factory:Lorg/codehaus/jackson/JsonFactory;

.method public constructor <init>()V
    .registers 4
    invoke-direct v3, Lcom/google/api/client/json/JsonFactory;-><init>()V
    new-instance v0, Lorg/codehaus/jackson/JsonFactory;
    invoke-direct v0, Lorg/codehaus/jackson/JsonFactory;-><init>()V
    iput-object v0, v3, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    iget-object v0, v3, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    sget-object v1, Lorg/codehaus/jackson/JsonGenerator$Feature;->AUTO_CLOSE_JSON_CONTENT Lorg/codehaus/jackson/JsonGenerator$Feature;
    const/4 v2, 0
    invoke-virtual v0, v1, v2, Lorg/codehaus/jackson/JsonFactory;->configure(Lorg/codehaus/jackson/JsonGenerator$Feature; Z)Lorg/codehaus/jackson/JsonFactory;
    return-void
.end method

.method static convert(Lorg/codehaus/jackson/JsonToken;)Lcom/google/api/client/json/JsonToken;
    .registers 3
    if-nez v2, +004h
    const/4 v0, 0
    return-object v0
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    invoke-virtual v2, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    aget v0, v0, v1
    packed-switch v0, +0000028h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->NOT_AVAILABLE Lcom/google/api/client/json/JsonToken;
    goto -eh
    sget-object v0, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    goto -11h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    goto -14h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    goto -17h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    goto -1ah
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_FALSE Lcom/google/api/client/json/JsonToken;
    goto -1dh
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    goto -20h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NULL Lcom/google/api/client/json/JsonToken;
    goto -23h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_STRING Lcom/google/api/client/json/JsonToken;
    goto -26h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    goto -29h
    sget-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    goto -2ch
    sget-object v0, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    goto -2fh
    nop
    packed-switch-payload 1 2 3 4 5 6 7 8 9 a b
.end method

.method public createJsonGenerator(Ljava/io/OutputStream; Lcom/google/api/client/json/JsonEncoding;)Lcom/google/api/client/json/JsonGenerator;
    .registers 6
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonGenerator;
    iget-object v1, v3, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    sget-object v2, Lorg/codehaus/jackson/JsonEncoding;->UTF8 Lorg/codehaus/jackson/JsonEncoding;
    invoke-virtual v1, v4, v2, Lorg/codehaus/jackson/JsonFactory;->createJsonGenerator(Ljava/io/OutputStream; Lorg/codehaus/jackson/JsonEncoding;)Lorg/codehaus/jackson/JsonGenerator;
    move-result-object v1
    invoke-direct v0, v3, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonGenerator;)V
    return-object v0
.end method

.method public createJsonGenerator(Ljava/io/OutputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonGenerator;
    .registers 6
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonGenerator;
    iget-object v1, v3, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    sget-object v2, Lorg/codehaus/jackson/JsonEncoding;->UTF8 Lorg/codehaus/jackson/JsonEncoding;
    invoke-virtual v1, v4, v2, Lorg/codehaus/jackson/JsonFactory;->createJsonGenerator(Ljava/io/OutputStream; Lorg/codehaus/jackson/JsonEncoding;)Lorg/codehaus/jackson/JsonGenerator;
    move-result-object v1
    invoke-direct v0, v3, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonGenerator;)V
    return-object v0
.end method

.method public createJsonGenerator(Ljava/io/Writer;)Lcom/google/api/client/json/JsonGenerator;
    .registers 4
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonGenerator;
    iget-object v1, v2, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    invoke-virtual v1, v3, Lorg/codehaus/jackson/JsonFactory;->createJsonGenerator(Ljava/io/Writer;)Lorg/codehaus/jackson/JsonGenerator;
    move-result-object v1
    invoke-direct v0, v2, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonGenerator;)V
    return-object v0
.end method

.method public createJsonParser(Ljava/io/InputStream;)Lcom/google/api/client/json/JsonParser;
    .registers 4
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonParser;
    iget-object v1, v2, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    invoke-virtual v1, v3, Lorg/codehaus/jackson/JsonFactory;->createJsonParser(Ljava/io/InputStream;)Lorg/codehaus/jackson/JsonParser;
    move-result-object v1
    invoke-direct v0, v2, v1, Lcom/google/api/client/json/jackson/JacksonParser;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonParser;)V
    return-object v0
.end method

.method public createJsonParser(Ljava/io/InputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonParser;
    .registers 5
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonParser;
    iget-object v1, v2, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    invoke-virtual v1, v3, Lorg/codehaus/jackson/JsonFactory;->createJsonParser(Ljava/io/InputStream;)Lorg/codehaus/jackson/JsonParser;
    move-result-object v1
    invoke-direct v0, v2, v1, Lcom/google/api/client/json/jackson/JacksonParser;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonParser;)V
    return-object v0
.end method

.method public createJsonParser(Ljava/io/Reader;)Lcom/google/api/client/json/JsonParser;
    .registers 4
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonParser;
    iget-object v1, v2, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    invoke-virtual v1, v3, Lorg/codehaus/jackson/JsonFactory;->createJsonParser(Ljava/io/Reader;)Lorg/codehaus/jackson/JsonParser;
    move-result-object v1
    invoke-direct v0, v2, v1, Lcom/google/api/client/json/jackson/JacksonParser;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonParser;)V
    return-object v0
.end method

.method public createJsonParser(Ljava/lang/String;)Lcom/google/api/client/json/JsonParser;
    .registers 4
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    new-instance v0, Lcom/google/api/client/json/jackson/JacksonParser;
    iget-object v1, v2, Lcom/google/api/client/json/jackson/JacksonFactory;->factory Lorg/codehaus/jackson/JsonFactory;
    invoke-virtual v1, v3, Lorg/codehaus/jackson/JsonFactory;->createJsonParser(Ljava/lang/String;)Lorg/codehaus/jackson/JsonParser;
    move-result-object v1
    invoke-direct v0, v2, v1, Lcom/google/api/client/json/jackson/JacksonParser;-><init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonParser;)V
    return-object v0
.end method
