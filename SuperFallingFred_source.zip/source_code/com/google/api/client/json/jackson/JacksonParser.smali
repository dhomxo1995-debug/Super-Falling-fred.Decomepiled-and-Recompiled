.class final Lcom/google/api/client/json/jackson/JacksonParser;
.super Lcom/google/api/client/json/JsonParser;

.field private final factory:Lcom/google/api/client/json/jackson/JacksonFactory;
.field private final parser:Lorg/codehaus/jackson/JsonParser;

.method constructor <init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonParser;)V
    .registers 3
    invoke-direct v0, Lcom/google/api/client/json/JsonParser;-><init>()V
    iput-object v1, v0, Lcom/google/api/client/json/jackson/JacksonParser;->factory Lcom/google/api/client/json/jackson/JacksonFactory;
    iput-object v2, v0, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    return-void
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->close()V
    return-void
.end method

.method public getBigIntegerValue()Ljava/math/BigInteger;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getBigIntegerValue()Ljava/math/BigInteger;
    move-result-object v0
    return-object v0
.end method

.method public getByteValue()B
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getByteValue()B
    move-result v0
    return v0
.end method

.method public getCurrentName()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public getCurrentToken()Lcom/google/api/client/json/JsonToken;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getCurrentToken()Lorg/codehaus/jackson/JsonToken;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/json/jackson/JacksonFactory;->convert(Lorg/codehaus/jackson/JsonToken;)Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    return-object v0
.end method

.method public getDecimalValue()Ljava/math/BigDecimal;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getDecimalValue()Ljava/math/BigDecimal;
    move-result-object v0
    return-object v0
.end method

.method public getDoubleValue()D
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getDoubleValue()D
    move-result-wide v0
    return-wide v0
.end method

.method public bridge synthetic getFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/json/jackson/JacksonParser;->getFactory()Lcom/google/api/client/json/jackson/JacksonFactory;
    move-result-object v0
    return-object v0
.end method

.method public getFactory()Lcom/google/api/client/json/jackson/JacksonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->factory Lcom/google/api/client/json/jackson/JacksonFactory;
    return-object v0
.end method

.method public getFloatValue()F
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getFloatValue()F
    move-result v0
    return v0
.end method

.method public getIntValue()I
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getIntValue()I
    move-result v0
    return v0
.end method

.method public getLongValue()J
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getLongValue()J
    move-result-wide v0
    return-wide v0
.end method

.method public getShortValue()S
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getShortValue()S
    move-result v0
    return v0
.end method

.method public getText()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getText()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public getUnsignedIntegerValue()Lcom/google/common/primitives/UnsignedInteger;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getLongValue()J
    move-result-wide v0
    invoke-static v0, v1, Lcom/google/common/primitives/UnsignedInteger;->valueOf(J)Lcom/google/common/primitives/UnsignedInteger;
    move-result-object v0
    return-object v0
.end method

.method public getUnsignedLongValue()Lcom/google/common/primitives/UnsignedLong;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->getBigIntegerValue()Ljava/math/BigInteger;
    move-result-object v0
    invoke-static v0, Lcom/google/common/primitives/UnsignedLong;->valueOf(Ljava/math/BigInteger;)Lcom/google/common/primitives/UnsignedLong;
    move-result-object v0
    return-object v0
.end method

.method public nextToken()Lcom/google/api/client/json/JsonToken;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->nextToken()Lorg/codehaus/jackson/JsonToken;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/json/jackson/JacksonFactory;->convert(Lorg/codehaus/jackson/JsonToken;)Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    return-object v0
.end method

.method public skipChildren()Lcom/google/api/client/json/JsonParser;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonParser;->parser Lorg/codehaus/jackson/JsonParser;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonParser;->skipChildren()Lorg/codehaus/jackson/JsonParser;
    return-object v1
.end method
