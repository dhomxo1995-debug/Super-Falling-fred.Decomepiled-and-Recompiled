package com.google.api.client.json.jackson;
final class JacksonGenerator extends com.google.api.client.json.JsonGenerator {
    private final com.google.api.client.json.jackson.JacksonFactory factory;
    private final org.codehaus.jackson.JsonGenerator generator;

    JacksonGenerator(com.google.api.client.json.jackson.JacksonFactory p1, org.codehaus.jackson.JsonGenerator p2)
    {
        this.factory = p1;
        this.generator = p2;
        return;
    }

    public void close()
    {
        this.generator.close();
        return;
    }

    public void enablePrettyPrint()
    {
        this.generator.useDefaultPrettyPrinter();
        return;
    }

    public void flush()
    {
        this.generator.flush();
        return;
    }

    public bridge synthetic com.google.api.client.json.JsonFactory getFactory()
    {
        return this.getFactory();
    }

    public com.google.api.client.json.jackson.JacksonFactory getFactory()
    {
        return this.factory;
    }

    public void writeBoolean(boolean p2)
    {
        this.generator.writeBoolean(p2);
        return;
    }

    public void writeEndArray()
    {
        this.generator.writeEndArray();
        return;
    }

    public void writeEndObject()
    {
        this.generator.writeEndObject();
        return;
    }

    public void writeFieldName(String p2)
    {
        this.generator.writeFieldName(p2);
        return;
    }

    public void writeNull()
    {
        this.generator.writeNull();
        return;
    }

    public void writeNumber(double p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(float p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(int p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(long p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(com.google.common.primitives.UnsignedInteger p4)
    {
        this.generator.writeNumber(p4.longValue());
        return;
    }

    public void writeNumber(com.google.common.primitives.UnsignedLong p3)
    {
        this.generator.writeNumber(p3.bigIntegerValue());
        return;
    }

    public void writeNumber(String p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(java.math.BigDecimal p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeNumber(java.math.BigInteger p2)
    {
        this.generator.writeNumber(p2);
        return;
    }

    public void writeStartArray()
    {
        this.generator.writeStartArray();
        return;
    }

    public void writeStartObject()
    {
        this.generator.writeStartObject();
        return;
    }

    public void writeString(String p2)
    {
        this.generator.writeString(p2);
        return;
    }
}
