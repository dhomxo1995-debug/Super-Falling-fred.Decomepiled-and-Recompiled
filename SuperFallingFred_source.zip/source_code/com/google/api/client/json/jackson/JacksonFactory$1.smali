.class synthetic Lcom/google/api/client/json/jackson/JacksonFactory$1;
.super Ljava/lang/Object;

.field static final synthetic $SwitchMap$org$codehaus$jackson$JsonToken:[I

.method static constructor <clinit>()V
    .registers 3
    invoke-static Lorg/codehaus/jackson/JsonToken;->values()[Lorg/codehaus/jackson/JsonToken;
    move-result-object v0
    array-length v0, v0
    new-array v0, v0, [I
    sput-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->END_ARRAY Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 1
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->START_ARRAY Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 2
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->END_OBJECT Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 3
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->START_OBJECT Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 4
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_FALSE Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 5
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_TRUE Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 6
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_NULL Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 7
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_STRING Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 8
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_NUMBER_FLOAT Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 9
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->VALUE_NUMBER_INT Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 10
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/jackson/JacksonFactory$1;->$SwitchMap$org$codehaus$jackson$JsonToken [I
    sget-object v1, Lorg/codehaus/jackson/JsonToken;->FIELD_NAME Lorg/codehaus/jackson/JsonToken;
    invoke-virtual v1, Lorg/codehaus/jackson/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 11
    aput v2, v0, v1
    return-void
    move-exception v0
    goto -2h
    move-exception v0
    goto -10h
    move-exception v0
    goto -1eh
    move-exception v0
    goto -2ch
    move-exception v0
    goto -3ah
    move-exception v0
    goto -47h
    move-exception v0
    goto -54h
    move-exception v0
    goto -61h
    move-exception v0
    goto -6eh
    move-exception v0
    goto -7bh
    move-exception v0
    goto/16 -088h
.end method
