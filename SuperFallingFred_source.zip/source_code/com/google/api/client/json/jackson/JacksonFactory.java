package com.google.api.client.json.jackson;
public final class JacksonFactory extends com.google.api.client.json.JsonFactory {
    private final org.codehaus.jackson.JsonFactory factory;

    public JacksonFactory()
    {
        this.factory = new org.codehaus.jackson.JsonFactory();
        this.factory.configure(org.codehaus.jackson.JsonGenerator$Feature.AUTO_CLOSE_JSON_CONTENT, 0);
        return;
    }

    static com.google.api.client.json.JsonToken convert(org.codehaus.jackson.JsonToken p2)
    {
        com.google.api.client.json.JsonToken v0_1;
        if (p2 != null) {
            switch (com.google.api.client.json.jackson.JacksonFactory$1.$SwitchMap$org$codehaus$jackson$JsonToken[p2.ordinal()]) {
                case 1:
                    v0_1 = com.google.api.client.json.JsonToken.END_ARRAY;
                    break;
                case 2:
                    v0_1 = com.google.api.client.json.JsonToken.START_ARRAY;
                    break;
                case 3:
                    v0_1 = com.google.api.client.json.JsonToken.END_OBJECT;
                    break;
                case 4:
                    v0_1 = com.google.api.client.json.JsonToken.START_OBJECT;
                    break;
                case 5:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_FALSE;
                    break;
                case 6:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_TRUE;
                    break;
                case 7:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_NULL;
                    break;
                case 8:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_STRING;
                    break;
                case 9:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT;
                    break;
                case 10:
                    v0_1 = com.google.api.client.json.JsonToken.VALUE_NUMBER_INT;
                    break;
                case 11:
                    v0_1 = com.google.api.client.json.JsonToken.FIELD_NAME;
                    break;
                default:
                    v0_1 = com.google.api.client.json.JsonToken.NOT_AVAILABLE;
            }
        } else {
            v0_1 = 0;
        }
        return v0_1;
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p4, com.google.api.client.json.JsonEncoding p5)
    {
        return new com.google.api.client.json.jackson.JacksonGenerator(this, this.factory.createJsonGenerator(p4, org.codehaus.jackson.JsonEncoding.UTF8));
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p4, java.nio.charset.Charset p5)
    {
        return new com.google.api.client.json.jackson.JacksonGenerator(this, this.factory.createJsonGenerator(p4, org.codehaus.jackson.JsonEncoding.UTF8));
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.Writer p3)
    {
        return new com.google.api.client.json.jackson.JacksonGenerator(this, this.factory.createJsonGenerator(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p3)
    {
        com.google.common.base.Preconditions.checkNotNull(p3);
        return new com.google.api.client.json.jackson.JacksonParser(this, this.factory.createJsonParser(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p3, java.nio.charset.Charset p4)
    {
        com.google.common.base.Preconditions.checkNotNull(p3);
        return new com.google.api.client.json.jackson.JacksonParser(this, this.factory.createJsonParser(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.Reader p3)
    {
        com.google.common.base.Preconditions.checkNotNull(p3);
        return new com.google.api.client.json.jackson.JacksonParser(this, this.factory.createJsonParser(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(String p3)
    {
        com.google.common.base.Preconditions.checkNotNull(p3);
        return new com.google.api.client.json.jackson.JacksonParser(this, this.factory.createJsonParser(p3));
    }
}
