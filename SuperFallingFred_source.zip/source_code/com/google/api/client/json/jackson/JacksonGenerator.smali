.class final Lcom/google/api/client/json/jackson/JacksonGenerator;
.super Lcom/google/api/client/json/JsonGenerator;

.field private final factory:Lcom/google/api/client/json/jackson/JacksonFactory;
.field private final generator:Lorg/codehaus/jackson/JsonGenerator;

.method constructor <init>(Lcom/google/api/client/json/jackson/JacksonFactory; Lorg/codehaus/jackson/JsonGenerator;)V
    .registers 3
    invoke-direct v0, Lcom/google/api/client/json/JsonGenerator;-><init>()V
    iput-object v1, v0, Lcom/google/api/client/json/jackson/JacksonGenerator;->factory Lcom/google/api/client/json/jackson/JacksonFactory;
    iput-object v2, v0, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    return-void
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->close()V
    return-void
.end method

.method public enablePrettyPrint()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->useDefaultPrettyPrinter()Lorg/codehaus/jackson/JsonGenerator;
    return-void
.end method

.method public flush()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->flush()V
    return-void
.end method

.method public bridge synthetic getFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->getFactory()Lcom/google/api/client/json/jackson/JacksonFactory;
    move-result-object v0
    return-object v0
.end method

.method public getFactory()Lcom/google/api/client/json/jackson/JacksonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->factory Lcom/google/api/client/json/jackson/JacksonFactory;
    return-object v0
.end method

.method public writeBoolean(Z)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeBoolean(Z)V
    return-void
.end method

.method public writeEndArray()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->writeEndArray()V
    return-void
.end method

.method public writeEndObject()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->writeEndObject()V
    return-void
.end method

.method public writeFieldName(Ljava/lang/String;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeFieldName(Ljava/lang/String;)V
    return-void
.end method

.method public writeNull()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->writeNull()V
    return-void
.end method

.method public writeNumber(D)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, v3, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(D)V
    return-void
.end method

.method public writeNumber(F)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(F)V
    return-void
.end method

.method public writeNumber(I)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(I)V
    return-void
.end method

.method public writeNumber(J)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, v3, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(J)V
    return-void
.end method

.method public writeNumber(Lcom/google/common/primitives/UnsignedInteger;)V
    .registers 5
    iget-object v0, v3, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v4, Lcom/google/common/primitives/UnsignedInteger;->longValue()J
    move-result-wide v1
    invoke-virtual v0, v1, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(J)V
    return-void
.end method

.method public writeNumber(Lcom/google/common/primitives/UnsignedLong;)V
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v3, Lcom/google/common/primitives/UnsignedLong;->bigIntegerValue()Ljava/math/BigInteger;
    move-result-object v1
    invoke-virtual v0, v1, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(Ljava/math/BigInteger;)V
    return-void
.end method

.method public writeNumber(Ljava/lang/String;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(Ljava/lang/String;)V
    return-void
.end method

.method public writeNumber(Ljava/math/BigDecimal;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(Ljava/math/BigDecimal;)V
    return-void
.end method

.method public writeNumber(Ljava/math/BigInteger;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeNumber(Ljava/math/BigInteger;)V
    return-void
.end method

.method public writeStartArray()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->writeStartArray()V
    return-void
.end method

.method public writeStartObject()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, Lorg/codehaus/jackson/JsonGenerator;->writeStartObject()V
    return-void
.end method

.method public writeString(Ljava/lang/String;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/jackson/JacksonGenerator;->generator Lorg/codehaus/jackson/JsonGenerator;
    invoke-virtual v0, v2, Lorg/codehaus/jackson/JsonGenerator;->writeString(Ljava/lang/String;)V
    return-void
.end method
