.class public final enum Lcom/google/api/client/json/JsonToken;
.super Ljava/lang/Enum;

.field private static final synthetic $VALUES:[Lcom/google/api/client/json/JsonToken;
.field public static final enum END_ARRAY:Lcom/google/api/client/json/JsonToken;
.field public static final enum END_OBJECT:Lcom/google/api/client/json/JsonToken;
.field public static final enum FIELD_NAME:Lcom/google/api/client/json/JsonToken;
.field public static final enum NOT_AVAILABLE:Lcom/google/api/client/json/JsonToken;
.field public static final enum START_ARRAY:Lcom/google/api/client/json/JsonToken;
.field public static final enum START_OBJECT:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_FALSE:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_NULL:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_NUMBER_FLOAT:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_NUMBER_INT:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_STRING:Lcom/google/api/client/json/JsonToken;
.field public static final enum VALUE_TRUE:Lcom/google/api/client/json/JsonToken;

.method static constructor <clinit>()V
    .registers 8
    const/4 v7, 4
    const/4 v6, 3
    const/4 v5, 2
    const/4 v4, 1
    const/4 v3, 0
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "START_ARRAY"
    invoke-direct v0, v1, v3, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "END_ARRAY"
    invoke-direct v0, v1, v4, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "START_OBJECT"
    invoke-direct v0, v1, v5, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "END_OBJECT"
    invoke-direct v0, v1, v6, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "FIELD_NAME"
    invoke-direct v0, v1, v7, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_STRING"
    const/4 v2, 5
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_STRING Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_NUMBER_INT"
    const/4 v2, 6
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_NUMBER_FLOAT"
    const/4 v2, 7
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_TRUE"
    const/16 v2, 8
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_FALSE"
    const/16 v2, 9
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_FALSE Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "VALUE_NULL"
    const/16 v2, 10
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->VALUE_NULL Lcom/google/api/client/json/JsonToken;
    new-instance v0, Lcom/google/api/client/json/JsonToken;
    const-string v1, "NOT_AVAILABLE"
    const/16 v2, 11
    invoke-direct v0, v1, v2, Lcom/google/api/client/json/JsonToken;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/json/JsonToken;->NOT_AVAILABLE Lcom/google/api/client/json/JsonToken;
    const/16 v0, 12
    new-array v0, v0, [Lcom/google/api/client/json/JsonToken;
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    aput-object v1, v0, v3
    sget-object v1, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    aput-object v1, v0, v4
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    aput-object v1, v0, v5
    sget-object v1, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    aput-object v1, v0, v6
    sget-object v1, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    aput-object v1, v0, v7
    const/4 v1, 5
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_STRING Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/4 v1, 6
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/4 v1, 7
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/16 v1, 8
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/16 v1, 9
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_FALSE Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/16 v1, 10
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NULL Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    const/16 v1, 11
    sget-object v2, Lcom/google/api/client/json/JsonToken;->NOT_AVAILABLE Lcom/google/api/client/json/JsonToken;
    aput-object v2, v0, v1
    sput-object v0, Lcom/google/api/client/json/JsonToken;->$VALUES [Lcom/google/api/client/json/JsonToken;
    return-void
.end method

.method private constructor <init>(Ljava/lang/String; I)V
    .registers 3
    invoke-direct v0, v1, v2, Ljava/lang/Enum;-><init>(Ljava/lang/String; I)V
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/api/client/json/JsonToken;
    .registers 2
    const-class v0, Lcom/google/api/client/json/JsonToken;
    invoke-static v0, v1, Ljava/lang/Enum;->valueOf(Ljava/lang/Class; Ljava/lang/String;)Ljava/lang/Enum;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonToken;
    return-object v0
.end method

.method public static values()[Lcom/google/api/client/json/JsonToken;
    .registers 1
    sget-object v0, Lcom/google/api/client/json/JsonToken;->$VALUES [Lcom/google/api/client/json/JsonToken;
    invoke-virtual v0, [Lcom/google/api/client/json/JsonToken;->clone()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/google/api/client/json/JsonToken;
    return-object v0
.end method
