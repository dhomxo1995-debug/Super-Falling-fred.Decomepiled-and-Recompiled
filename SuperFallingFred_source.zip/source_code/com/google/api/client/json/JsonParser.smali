.class public abstract Lcom/google/api/client/json/JsonParser;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private parse(Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 25
    move-object/from16 v0, v23
    instance-of v3, v0, Lcom/google/api/client/json/GenericJson;
    if-eqz v3, +00dh
    move-object/from16 v3, v23
    check-cast v3, Lcom/google/api/client/json/GenericJson;
    invoke-virtual/range v21, Lcom/google/api/client/json/JsonParser;->getFactory()Lcom/google/api/client/json/JsonFactory;
    move-result-object v5
    invoke-virtual v3, v5, Lcom/google/api/client/json/GenericJson;->setFactory(Lcom/google/api/client/json/JsonFactory;)V
    invoke-direct/range v21, Lcom/google/api/client/json/JsonParser;->startParsingObjectOrArray()Lcom/google/api/client/json/JsonToken;
    move-result-object v13
    invoke-virtual/range v23, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v14
    invoke-static v14, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v11
    const-class v3, Lcom/google/api/client/util/GenericData;
    invoke-virtual v3, v14, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v18
    if-nez v18, +04fh
    const-class v3, Ljava/util/Map;
    invoke-virtual v3, v14, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v3
    if-eqz v3, +047h
    move-object/from16 v15, v23
    check-cast v15, Ljava/util/Map;
    invoke-static v14, Lcom/google/api/client/util/Types;->getMapValueParameter(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v3
    move-object/from16 v0, v21
    move-object/from16 v1, v22
    move-object/from16 v2, v24
    invoke-direct v0, v15, v3, v1, v2, Lcom/google/api/client/json/JsonParser;->parseMap(Ljava/util/Map; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    return-void
    invoke-virtual/range v16, Lcom/google/api/client/util/FieldInfo;->getField()Ljava/lang/reflect/Field;
    move-result-object v4
    invoke-virtual/range v22, Ljava/util/ArrayList;->size()I
    move-result v12
    invoke-virtual v4, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;
    move-result-object v3
    move-object/from16 v0, v22
    invoke-virtual v0, v3, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    invoke-virtual/range v16, Lcom/google/api/client/util/FieldInfo;->getGenericType()Ljava/lang/reflect/Type;
    move-result-object v5
    move-object/from16 v3, v21
    move-object/from16 v6, v22
    move-object/from16 v7, v23
    move-object/from16 v8, v24
    invoke-direct/range v3 ... v8, Lcom/google/api/client/json/JsonParser;->parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v17
    move-object/from16 v0, v22
    invoke-virtual v0, v12, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    move-object/from16 v0, v16
    move-object/from16 v1, v23
    move-object/from16 v2, v17
    invoke-virtual v0, v1, v2, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    invoke-virtual/range v21, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v13
    sget-object v3, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    if-ne v13, v3, -036h
    invoke-virtual/range v21, Lcom/google/api/client/json/JsonParser;->getText()Ljava/lang/String;
    move-result-object v19
    invoke-virtual/range v21, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    if-eqz v24, +00eh
    move-object/from16 v0, v24
    move-object/from16 v1, v23
    move-object/from16 v2, v19
    invoke-virtual v0, v1, v2, Lcom/google/api/client/json/CustomizeJsonParser;->stopAt(Ljava/lang/Object; Ljava/lang/String;)Z
    move-result v3
    if-nez v3, -04bh
    move-object/from16 v0, v19
    invoke-virtual v11, v0, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v16
    if-eqz v16, +016h
    invoke-virtual/range v16, Lcom/google/api/client/util/FieldInfo;->isFinal()Z
    move-result v3
    if-eqz v3, -058h
    invoke-virtual/range v16, Lcom/google/api/client/util/FieldInfo;->isPrimitive()Z
    move-result v3
    if-nez v3, -05eh
    new-instance v3, Ljava/lang/IllegalArgumentException;
    const-string v5, "final array/object fields are not supported"
    invoke-direct v3, v5, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v3
    if-eqz v18, +01ch
    move-object/from16 v20, v23
    check-cast v20, Lcom/google/api/client/util/GenericData;
    const/4 v6, 0
    const/4 v7, 0
    move-object/from16 v5, v21
    move-object/from16 v8, v22
    move-object/from16 v9, v23
    move-object/from16 v10, v24
    invoke-direct/range v5 ... v10, Lcom/google/api/client/json/JsonParser;->parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v3
    move-object/from16 v0, v20
    move-object/from16 v1, v19
    invoke-virtual v0, v1, v3, Lcom/google/api/client/util/GenericData;->set(Ljava/lang/String; Ljava/lang/Object;)V
    goto -54h
    if-eqz v24, +00bh
    move-object/from16 v0, v24
    move-object/from16 v1, v23
    move-object/from16 v2, v19
    invoke-virtual v0, v1, v2, Lcom/google/api/client/json/CustomizeJsonParser;->handleUnrecognizedKey(Ljava/lang/Object; Ljava/lang/String;)V
    invoke-virtual/range v21, Lcom/google/api/client/json/JsonParser;->skipChildren()Lcom/google/api/client/json/JsonParser;
    goto -63h
.end method

.method private parseArray(Ljava/util/Collection; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 13
    invoke-direct v8, Lcom/google/api/client/json/JsonParser;->startParsingObjectOrArray()Lcom/google/api/client/json/JsonToken;
    move-result-object v6
    sget-object v0, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    if-eq v6, v0, +014h
    const/4 v1, 0
    move-object v0, v8
    move-object v2, v10
    move-object v3, v11
    move-object v4, v9
    move-object v5, v12
    invoke-direct/range v0 ... v5, Lcom/google/api/client/json/JsonParser;->parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v7
    invoke-interface v9, v7, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    invoke-virtual v8, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v6
    goto -15h
    return-void
.end method

.method private parseMap(Ljava/util/Map; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 14
    invoke-direct v9, Lcom/google/api/client/json/JsonParser;->startParsingObjectOrArray()Lcom/google/api/client/json/JsonToken;
    move-result-object v6
    sget-object v0, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    if-ne v6, v0, +011h
    invoke-virtual v9, Lcom/google/api/client/json/JsonParser;->getText()Ljava/lang/String;
    move-result-object v7
    invoke-virtual v9, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    if-eqz v13, +009h
    invoke-virtual v13, v10, v7, Lcom/google/api/client/json/CustomizeJsonParser;->stopAt(Ljava/lang/Object; Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +003h
    return-void
    const/4 v1, 0
    move-object v0, v9
    move-object v2, v11
    move-object v3, v12
    move-object v4, v10
    move-object v5, v13
    invoke-direct/range v0 ... v5, Lcom/google/api/client/json/JsonParser;->parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v8
    invoke-interface v10, v7, v8, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v9, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v6
    goto -25h
.end method

.method private final parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    .registers 25
    move-object/from16 v0, v22
    move-object/from16 v1, v21
    invoke-static v0, v1, Lcom/google/api/client/util/Data;->resolveWildcardTypeOrTypeVariable(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v21
    move-object/from16 v0, v21
    instance-of v14, v0, Ljava/lang/Class;
    if-eqz v14, +045h
    move-object/from16 v14, v21
    check-cast v14, Ljava/lang/Class;
    move-object v13, v14
    move-object/from16 v0, v21
    instance-of v14, v0, Ljava/lang/reflect/ParameterizedType;
    if-eqz v14, +00ah
    move-object/from16 v14, v21
    check-cast v14, Ljava/lang/reflect/ParameterizedType;
    invoke-static v14, Lcom/google/api/client/util/Types;->getRawClass(Ljava/lang/reflect/ParameterizedType;)Ljava/lang/Class;
    move-result-object v13
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v12
    sget-object v14, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    invoke-virtual v12, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v15
    aget v14, v14, v15
    packed-switch v14, +0000347h
    new-instance v14, Ljava/lang/IllegalArgumentException;
    new-instance v15, Ljava/lang/StringBuilder;
    invoke-direct v15, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v16
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    const-string v16, ": unexpected JSON node type: "
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    invoke-virtual v15, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v15
    invoke-virtual v15, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v15
    invoke-direct v14, v15, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v14
    const/4 v13, 0
    goto -3fh
    invoke-static/range v21, Lcom/google/api/client/util/Types;->isArray(Ljava/lang/reflect/Type;)Z
    move-result v7
    if-eqz v21, +00eh
    if-nez v7, +00ch
    if-eqz v13, +060h
    const-class v14, Ljava/util/Collection;
    invoke-static v13, v14, Lcom/google/api/client/util/Types;->isAssignableToOrFrom(Ljava/lang/Class; Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +058h
    const/4 v14, 1
    const-string v15, "%s: expected collection or array type but got %s for field %s"
    const/16 v16, 3
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v21, v16, v17
    const/16 v17, 2
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    const/4 v3, 0
    if-eqz v24, +00eh
    if-eqz v20, +00ch
    move-object/from16 v0, v24
    move-object/from16 v1, v23
    move-object/from16 v2, v20
    invoke-virtual v0, v1, v2, Lcom/google/api/client/json/CustomizeJsonParser;->newInstanceForArray(Ljava/lang/Object; Ljava/lang/reflect/Field;)Ljava/util/Collection;
    move-result-object v3
    if-nez v3, +006h
    invoke-static/range v21, Lcom/google/api/client/util/Data;->newCollectionInstance(Ljava/lang/reflect/Type;)Ljava/util/Collection;
    move-result-object v3
    const/4 v10, 0
    if-eqz v7, +024h
    invoke-static/range v21, Lcom/google/api/client/util/Types;->getArrayComponentType(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v10
    move-object/from16 v0, v22
    invoke-static v0, v10, Lcom/google/api/client/util/Data;->resolveWildcardTypeOrTypeVariable(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v10
    move-object/from16 v0, v19
    move-object/from16 v1, v22
    move-object/from16 v2, v24
    invoke-direct v0, v3, v10, v1, v2, Lcom/google/api/client/json/JsonParser;->parseArray(Ljava/util/Collection; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    if-eqz v7, +01eh
    move-object/from16 v0, v22
    invoke-static v0, v10, Lcom/google/api/client/util/Types;->getRawArrayComponentType(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/Class;
    move-result-object v14
    invoke-static v3, v14, Lcom/google/api/client/util/Types;->toArray(Ljava/util/Collection; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v14
    return-object v14
    const/4 v14, 0
    goto -56h
    if-eqz v13, -01eh
    const-class v14, Ljava/lang/Iterable;
    invoke-virtual v14, v13, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, -026h
    invoke-static/range v21, Lcom/google/api/client/util/Types;->getIterableParameter(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v10
    goto -2ch
    move-object v14, v3
    goto -13h
    invoke-static/range v21, Lcom/google/api/client/util/Types;->isArray(Ljava/lang/reflect/Type;)Z
    move-result v14
    if-nez v14, +076h
    const/4 v14, 1
    const-string v15, "%s: expected object or map type but got %s for field %s"
    const/16 v16, 3
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v21, v16, v17
    const/16 v17, 2
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    const/4 v9, 0
    if-eqz v13, +00ch
    if-eqz v24, +00ah
    move-object/from16 v0, v24
    move-object/from16 v1, v23
    invoke-virtual v0, v1, v13, Lcom/google/api/client/json/CustomizeJsonParser;->newInstanceForObject(Ljava/lang/Object; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v9
    if-eqz v13, +04bh
    const-class v14, Ljava/util/Map;
    invoke-static v13, v14, Lcom/google/api/client/util/Types;->isAssignableToOrFrom(Ljava/lang/Class; Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +043h
    const/4 v8, 1
    if-nez v9, +266h
    if-nez v8, +004h
    if-nez v13, +03eh
    invoke-static v13, Lcom/google/api/client/util/Data;->newMapInstance(Ljava/lang/Class;)Ljava/util/Map;
    move-result-object v9
    move-object v14, v9
    invoke-virtual/range v22, Ljava/util/ArrayList;->size()I
    move-result v4
    if-eqz v21, +009h
    move-object/from16 v0, v22
    move-object/from16 v1, v21
    invoke-virtual v0, v1, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    if-eqz v8, +032h
    const-class v15, Lcom/google/api/client/util/GenericData;
    invoke-virtual v15, v13, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v15
    if-nez v15, +02ah
    const-class v15, Ljava/util/Map;
    invoke-virtual v15, v13, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v15
    if-eqz v15, +020h
    invoke-static/range v21, Lcom/google/api/client/util/Types;->getMapValueParameter(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v11
    if-eqz v11, +01ch
    move-object v5, v14
    check-cast v5, Ljava/util/Map;
    move-object/from16 v0, v19
    move-object/from16 v1, v22
    move-object/from16 v2, v24
    invoke-direct v0, v5, v11, v1, v2, Lcom/google/api/client/json/JsonParser;->parseMap(Ljava/util/Map; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    goto/16 -08ch
    const/4 v14, 0
    goto -74h
    const/4 v8, 0
    goto -41h
    invoke-static v13, Lcom/google/api/client/util/Types;->newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v9
    move-object v14, v9
    goto -3ch
    const/4 v11, 0
    goto -1bh
    move-object/from16 v0, v19
    move-object/from16 v1, v22
    move-object/from16 v2, v24
    invoke-direct v0, v1, v14, v2, Lcom/google/api/client/json/JsonParser;->parse(Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    if-eqz v21, -0a3h
    move-object/from16 v0, v22
    invoke-virtual v0, v4, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    goto/16 -0aah
    if-eqz v21, +010h
    sget-object v14, Ljava/lang/Boolean;->TYPE Ljava/lang/Class;
    if-eq v13, v14, +00ch
    if-eqz v13, +043h
    const-class v14, Ljava/lang/Boolean;
    invoke-virtual v13, v14, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +03bh
    const/4 v14, 1
    new-instance v15, Ljava/lang/StringBuilder;
    invoke-direct v15, Ljava/lang/StringBuilder;-><init>()V
    const-string v16, "%s: expected type Boolean or boolean but got %s for field %s"
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    move-object/from16 v0, v20
    invoke-virtual v15, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v15
    invoke-virtual v15, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v15
    const/16 v16, 3
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v21, v16, v17
    const/16 v17, 2
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    sget-object v14, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    if-ne v12, v14, +008h
    sget-object v14, Ljava/lang/Boolean;->TRUE Ljava/lang/Boolean;
    goto/16 -0f3h
    const/4 v14, 0
    goto -39h
    sget-object v14, Ljava/lang/Boolean;->FALSE Ljava/lang/Boolean;
    goto/16 -0f9h
    if-eqz v20, +00ch
    const-class v14, Lcom/google/api/client/json/JsonString;
    move-object/from16 v0, v20
    invoke-virtual v0, v14, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v14
    if-nez v14, +02ch
    const/4 v14, 1
    const-string v15, "%s: number type formatted as a JSON number cannot use @JsonString annotation on the field %s"
    const/16 v16, 2
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    if-eqz v13, +00ah
    const-class v14, Ljava/math/BigDecimal;
    invoke-virtual v13, v14, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +00ah
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getDecimalValue()Ljava/math/BigDecimal;
    move-result-object v14
    goto/16 -12fh
    const/4 v14, 0
    goto -2ah
    const-class v14, Ljava/math/BigInteger;
    if-ne v13, v14, +008h
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getBigIntegerValue()Ljava/math/BigInteger;
    move-result-object v14
    goto/16 -13bh
    const-class v14, Lcom/google/common/primitives/UnsignedInteger;
    if-ne v13, v14, +008h
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getUnsignedIntegerValue()Lcom/google/common/primitives/UnsignedInteger;
    move-result-object v14
    goto/16 -145h
    const-class v14, Lcom/google/common/primitives/UnsignedLong;
    if-ne v13, v14, +008h
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getUnsignedLongValue()Lcom/google/common/primitives/UnsignedLong;
    move-result-object v14
    goto/16 -14fh
    const-class v14, Ljava/lang/Double;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Double;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getDoubleValue()D
    move-result-wide v14
    invoke-static v14, v15, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    move-result-object v14
    goto/16 -161h
    const-class v14, Ljava/lang/Long;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Long;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getLongValue()J
    move-result-wide v14
    invoke-static v14, v15, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v14
    goto/16 -173h
    const-class v14, Ljava/lang/Float;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Float;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getFloatValue()F
    move-result v14
    invoke-static v14, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    move-result-object v14
    goto/16 -185h
    const-class v14, Ljava/lang/Integer;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Integer;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getIntValue()I
    move-result v14
    invoke-static v14, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v14
    goto/16 -197h
    const-class v14, Ljava/lang/Short;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Short;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getShortValue()S
    move-result v14
    invoke-static v14, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;
    move-result-object v14
    goto/16 -1a9h
    const-class v14, Ljava/lang/Byte;
    if-eq v13, v14, +006h
    sget-object v14, Ljava/lang/Byte;->TYPE Ljava/lang/Class;
    if-ne v13, v14, +00ch
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getByteValue()B
    move-result v14
    invoke-static v14, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;
    move-result-object v14
    goto/16 -1bbh
    new-instance v14, Ljava/lang/IllegalArgumentException;
    new-instance v15, Ljava/lang/StringBuilder;
    invoke-direct v15, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v16
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    const-string v16, ": expected numeric type but got "
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    move-object/from16 v0, v21
    invoke-virtual v15, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v15
    const-string v16, " for field "
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    move-object/from16 v0, v20
    invoke-virtual v15, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v15
    invoke-virtual v15, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v15
    invoke-direct v14, v15, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v14
    if-eqz v13, +016h
    const-class v14, Ljava/lang/Number;
    invoke-virtual v14, v13, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +00eh
    if-eqz v20, +032h
    const-class v14, Lcom/google/api/client/json/JsonString;
    move-object/from16 v0, v20
    invoke-virtual v0, v14, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v14
    if-eqz v14, +028h
    const/4 v14, 1
    const-string v15, "%s: number field formatted as a JSON string must use the @JsonString annotation: %s"
    const/16 v16, 2
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getText()Ljava/lang/String;
    move-result-object v14
    move-object/from16 v0, v21
    invoke-static v0, v14, Lcom/google/api/client/util/Data;->parsePrimitiveValue(Ljava/lang/reflect/Type; Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v14
    goto/16 -226h
    const/4 v14, 0
    goto -26h
    move-exception v6
    new-instance v14, Ljava/lang/IllegalArgumentException;
    new-instance v15, Ljava/lang/StringBuilder;
    invoke-direct v15, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v16
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    const-string v16, " for field "
    invoke-virtual/range v15 ... v16, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v15
    move-object/from16 v0, v20
    invoke-virtual v15, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v15
    invoke-virtual v15, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v15
    invoke-direct v14, v15, v6, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String; Ljava/lang/Throwable;)V
    throw v14
    if-eqz v13, +008h
    invoke-virtual v13, Ljava/lang/Class;->isPrimitive()Z
    move-result v14
    if-nez v14, +03ch
    const/4 v14, 1
    const-string v15, "%s: primitive number field but found a JSON null: %s"
    const/16 v16, 2
    move/from16 v0, v16
    new-array v0, v0, [Ljava/lang/Object;
    move-object/from16 v16, v0
    const/16 v17, 0
    invoke-virtual/range v19, Lcom/google/api/client/json/JsonParser;->getCurrentName()Ljava/lang/String;
    move-result-object v18
    aput-object v18, v16, v17
    const/16 v17, 1
    aput-object v20, v16, v17
    invoke-static/range v14 ... v16, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    if-eqz v13, +038h
    invoke-virtual v13, Ljava/lang/Class;->getModifiers()I
    move-result v14
    and-int/lit16 v14, v14, 1536
    if-eqz v14, +030h
    const-class v14, Ljava/util/Collection;
    invoke-static v13, v14, Lcom/google/api/client/util/Types;->isAssignableToOrFrom(Ljava/lang/Class; Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +012h
    invoke-static/range v21, Lcom/google/api/client/util/Data;->newCollectionInstance(Ljava/lang/reflect/Type;)Ljava/util/Collection;
    move-result-object v14
    invoke-virtual v14, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v14
    invoke-static v14, Lcom/google/api/client/util/Data;->nullOf(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v14
    goto/16 -28eh
    const/4 v14, 0
    goto -3ah
    const-class v14, Ljava/util/Map;
    invoke-static v13, v14, Lcom/google/api/client/util/Types;->isAssignableToOrFrom(Ljava/lang/Class; Ljava/lang/Class;)Z
    move-result v14
    if-eqz v14, +010h
    invoke-static v13, Lcom/google/api/client/util/Data;->newMapInstance(Ljava/lang/Class;)Ljava/util/Map;
    move-result-object v14
    invoke-virtual v14, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v14
    invoke-static v14, Lcom/google/api/client/util/Data;->nullOf(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v14
    goto/16 -2a6h
    move-object/from16 v0, v22
    move-object/from16 v1, v21
    invoke-static v0, v1, Lcom/google/api/client/util/Types;->getRawArrayComponentType(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/Class;
    move-result-object v14
    invoke-static v14, Lcom/google/api/client/util/Data;->nullOf(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v14
    goto/16 -2b4h
    move-object v14, v9
    goto/16 -25ch
    nop
    packed-switch-payload 1 2 3 4 5 6 7 8 9 a b
.end method

.method private startParsing()Lcom/google/api/client/json/JsonToken;
    .registers 4
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->getCurrentToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    if-nez v0, +006h
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    if-eqz v0, +009h
    const/4 v1, 1
    const-string v2, "no JSON input found"
    invoke-static v1, v2, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/Object;)V
    return-object v0
    const/4 v1, 0
    goto -7h
.end method

.method private startParsingObjectOrArray()Lcom/google/api/client/json/JsonToken;
    .registers 4
    invoke-direct v3, Lcom/google/api/client/json/JsonParser;->startParsing()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    sget-object v1, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    invoke-virtual v0, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v2
    aget v1, v1, v2
    packed-switch v1, +000001ch
    return-object v0
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    sget-object v1, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    if-eq v0, v1, +006h
    sget-object v1, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    if-ne v0, v1, +007h
    const/4 v1, 1
    invoke-static v1, v0, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/Object;)V
    goto -11h
    const/4 v1, 0
    goto -5h
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    goto -18h
    packed-switch-payload 1 2
.end method

.method public abstract close()V
    # abstract or native method
.end method

.method public abstract getBigIntegerValue()Ljava/math/BigInteger;
    # abstract or native method
.end method

.method public abstract getByteValue()B
    # abstract or native method
.end method

.method public abstract getCurrentName()Ljava/lang/String;
    # abstract or native method
.end method

.method public abstract getCurrentToken()Lcom/google/api/client/json/JsonToken;
    # abstract or native method
.end method

.method public abstract getDecimalValue()Ljava/math/BigDecimal;
    # abstract or native method
.end method

.method public abstract getDoubleValue()D
    # abstract or native method
.end method

.method public abstract getFactory()Lcom/google/api/client/json/JsonFactory;
    # abstract or native method
.end method

.method public abstract getFloatValue()F
    # abstract or native method
.end method

.method public abstract getIntValue()I
    # abstract or native method
.end method

.method public abstract getLongValue()J
    # abstract or native method
.end method

.method public abstract getShortValue()S
    # abstract or native method
.end method

.method public abstract getText()Ljava/lang/String;
    # abstract or native method
.end method

.method public abstract getUnsignedIntegerValue()Lcom/google/common/primitives/UnsignedInteger;
    # abstract or native method
.end method

.method public abstract getUnsignedLongValue()Lcom/google/common/primitives/UnsignedLong;
    # abstract or native method
.end method

.method public abstract nextToken()Lcom/google/api/client/json/JsonToken;
    # abstract or native method
.end method

.method public final parse(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    .registers 5
    invoke-direct v2, Lcom/google/api/client/json/JsonParser;->startParsing()Lcom/google/api/client/json/JsonToken;
    const/4 v1, 0
    invoke-virtual v2, v3, v1, v4, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/reflect/Type; Z Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public parse(Ljava/lang/reflect/Type; Z Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    .registers 10
    invoke-direct v6, Lcom/google/api/client/json/JsonParser;->startParsing()Lcom/google/api/client/json/JsonToken;
    const/4 v1, 0
    new-instance v3, Ljava/util/ArrayList;
    invoke-direct v3, Ljava/util/ArrayList;-><init>()V
    const/4 v4, 0
    move-object v0, v6
    move-object v2, v7
    move-object v5, v9
    invoke-direct/range v0 ... v5, Lcom/google/api/client/json/JsonParser;->parseValue(Ljava/lang/reflect/Field; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    if-eqz v8, +005h
    invoke-virtual v6, Lcom/google/api/client/json/JsonParser;->close()V
    return-object v0
    move-exception v0
    if-eqz v8, +005h
    invoke-virtual v6, Lcom/google/api/client/json/JsonParser;->close()V
    throw v0
.end method

.method public final parse(Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 5
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    invoke-virtual v3, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    invoke-direct v2, v0, v3, v4, Lcom/google/api/client/json/JsonParser;->parse(Ljava/util/ArrayList; Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    return-void
.end method

.method public final parseAndClose(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    .registers 4
    invoke-virtual v1, v2, v3, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    return-object v0
    move-exception v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    throw v0
.end method

.method public final parseAndClose(Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 4
    invoke-virtual v1, v2, v3, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/Object; Lcom/google/api/client/json/CustomizeJsonParser;)V
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    return-void
    move-exception v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    throw v0
.end method

.method public final parseArray(Ljava/lang/Class; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/util/Collection;
    .registers 5
    invoke-static v2, Lcom/google/api/client/util/Data;->newCollectionInstance(Ljava/lang/reflect/Type;)Ljava/util/Collection;
    move-result-object v0
    invoke-virtual v1, v0, v3, v4, Lcom/google/api/client/json/JsonParser;->parseArray(Ljava/util/Collection; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)V
    return-object v0
.end method

.method public final parseArray(Ljava/util/Collection; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 5
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    invoke-direct v1, v2, v3, v0, v4, Lcom/google/api/client/json/JsonParser;->parseArray(Ljava/util/Collection; Ljava/lang/reflect/Type; Ljava/util/ArrayList; Lcom/google/api/client/json/CustomizeJsonParser;)V
    return-void
.end method

.method public final parseArrayAndClose(Ljava/lang/Class; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/util/Collection;
    .registers 5
    invoke-virtual v1, v2, v3, v4, Lcom/google/api/client/json/JsonParser;->parseArray(Ljava/lang/Class; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/util/Collection;
    move-result-object v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    return-object v0
    move-exception v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    throw v0
.end method

.method public final parseArrayAndClose(Ljava/util/Collection; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)V
    .registers 5
    invoke-virtual v1, v2, v3, v4, Lcom/google/api/client/json/JsonParser;->parseArray(Ljava/util/Collection; Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)V
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    return-void
    move-exception v0
    invoke-virtual v1, Lcom/google/api/client/json/JsonParser;->close()V
    throw v0
.end method

.method public abstract skipChildren()Lcom/google/api/client/json/JsonParser;
    # abstract or native method
.end method

.method public final skipToKey(Ljava/util/Set;)Ljava/lang/String;
    .registers 5
    invoke-direct v3, Lcom/google/api/client/json/JsonParser;->startParsingObjectOrArray()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    sget-object v2, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    if-ne v0, v2, +018h
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->getText()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    invoke-interface v4, v1, Ljava/util/Set;->contains(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +003h
    return-object v1
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->skipChildren()Lcom/google/api/client/json/JsonParser;
    invoke-virtual v3, Lcom/google/api/client/json/JsonParser;->nextToken()Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    goto -19h
    const/4 v1, 0
    goto -ah
.end method

.method public final skipToKey(Ljava/lang/String;)V
    .registers 3
    invoke-static v2, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;
    move-result-object v0
    invoke-virtual v1, v0, Lcom/google/api/client/json/JsonParser;->skipToKey(Ljava/util/Set;)Ljava/lang/String;
    return-void
.end method
