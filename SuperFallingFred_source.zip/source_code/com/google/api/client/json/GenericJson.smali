.class public Lcom/google/api/client/json/GenericJson;
.super Lcom/google/api/client/util/GenericData;
.implements Ljava/lang/Cloneable;

.field private jsonFactory:Lcom/google/api/client/json/JsonFactory;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/util/GenericData;-><init>()V
    return-void
.end method

.method public clone()Lcom/google/api/client/json/GenericJson;
    .registers 2
    invoke-super v1, Lcom/google/api/client/util/GenericData;->clone()Lcom/google/api/client/util/GenericData;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/GenericJson;
    return-object v0
.end method

.method public bridge synthetic clone()Lcom/google/api/client/util/GenericData;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/json/GenericJson;->clone()Lcom/google/api/client/json/GenericJson;
    move-result-object v0
    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/json/GenericJson;->clone()Lcom/google/api/client/json/GenericJson;
    move-result-object v0
    return-object v0
.end method

.method public final getFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final setFactory(Lcom/google/api/client/json/JsonFactory;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-void
.end method

.method public toPrettyString()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    if-eqz v0, +009h
    iget-object v0, v1, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v0, v1, Lcom/google/api/client/json/JsonFactory;->toPrettyString(Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v0
    return-object v0
    invoke-super v1, Lcom/google/api/client/util/GenericData;->toString()Ljava/lang/String;
    move-result-object v0
    goto -5h
.end method

.method public toString()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    if-eqz v0, +009h
    iget-object v0, v1, Lcom/google/api/client/json/GenericJson;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v0, v1, Lcom/google/api/client/json/JsonFactory;->toString(Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v0
    return-object v0
    invoke-super v1, Lcom/google/api/client/util/GenericData;->toString()Ljava/lang/String;
    move-result-object v0
    goto -5h
.end method
