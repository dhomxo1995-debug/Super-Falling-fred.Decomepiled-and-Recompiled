.class synthetic Lcom/google/api/client/json/JsonParser$1;
.super Ljava/lang/Object;

.field static final synthetic $SwitchMap$com$google$api$client$json$JsonToken:[I

.method static constructor <clinit>()V
    .registers 3
    invoke-static Lcom/google/api/client/json/JsonToken;->values()[Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    array-length v0, v0
    new-array v0, v0, [I
    sput-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 1
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 2
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 3
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 4
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 5
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 6
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_FALSE Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 7
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 8
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 9
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_STRING Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 10
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/JsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_NULL Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 11
    aput v2, v0, v1
    return-void
    move-exception v0
    goto -2h
    move-exception v0
    goto -10h
    move-exception v0
    goto -1eh
    move-exception v0
    goto -2ch
    move-exception v0
    goto -3ah
    move-exception v0
    goto -47h
    move-exception v0
    goto -54h
    move-exception v0
    goto -61h
    move-exception v0
    goto -6eh
    move-exception v0
    goto -7bh
    move-exception v0
    goto/16 -088h
.end method
