package com.google.api.client.json;
public class JsonObjectParser implements com.google.api.client.util.ObjectParser {
    private final com.google.api.client.json.JsonFactory jsonFactory;

    public JsonObjectParser(com.google.api.client.json.JsonFactory p2)
    {
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p2));
        return;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public Object parseAndClose(java.io.InputStream p2, java.nio.charset.Charset p3, Class p4)
    {
        return this.parseAndClose(p2, p3, p4);
    }

    public Object parseAndClose(java.io.InputStream p4, java.nio.charset.Charset p5, reflect.Type p6)
    {
        return this.jsonFactory.createJsonParser(p4, p5).parse(p6, 1, 0);
    }

    public Object parseAndClose(java.io.Reader p2, Class p3)
    {
        return this.parseAndClose(p2, p3);
    }

    public Object parseAndClose(java.io.Reader p4, reflect.Type p5)
    {
        return this.jsonFactory.createJsonParser(p4).parse(p5, 1, 0);
    }
}
