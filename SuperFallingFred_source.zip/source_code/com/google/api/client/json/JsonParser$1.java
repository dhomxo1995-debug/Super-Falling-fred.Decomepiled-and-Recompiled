package com.google.api.client.json;
synthetic class JsonParser$1 {
    static final synthetic int[] $SwitchMap$com$google$api$client$json$JsonToken;

    static JsonParser$1()
    {
        NoSuchFieldError v0_5 = new int[com.google.api.client.json.JsonToken.values().length];
        com.google.api.client.json.JsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken = v0_5;
        try {
            com.google.api.client.json.JsonToken.START_OBJECT.ordinal()[int v1_21] = 1;
            try {
                com.google.api.client.json.JsonToken.START_ARRAY.ordinal()[int v1_1] = 2;
                try {
                    com.google.api.client.json.JsonToken.END_ARRAY.ordinal()[int v1_3] = 3;
                    try {
                        com.google.api.client.json.JsonToken.FIELD_NAME.ordinal()[int v1_5] = 4;
                        try {
                            com.google.api.client.json.JsonToken.END_OBJECT.ordinal()[int v1_7] = 5;
                            try {
                                com.google.api.client.json.JsonToken.VALUE_TRUE.ordinal()[int v1_9] = 6;
                                try {
                                    com.google.api.client.json.JsonToken.VALUE_FALSE.ordinal()[int v1_11] = 7;
                                    try {
                                        com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT.ordinal()[int v1_13] = 8;
                                        try {
                                            com.google.api.client.json.JsonToken.VALUE_NUMBER_INT.ordinal()[int v1_16] = 9;
                                            try {
                                                com.google.api.client.json.JsonToken.VALUE_STRING.ordinal()[int v1_18] = 10;
                                                try {
                                                    com.google.api.client.json.JsonToken.VALUE_NULL.ordinal()[int v1_20] = 11;
                                                } catch (NoSuchFieldError v0) {
                                                }
                                                return;
                                            } catch (NoSuchFieldError v0) {
                                            }
                                        } catch (NoSuchFieldError v0) {
                                        }
                                    } catch (NoSuchFieldError v0) {
                                    }
                                } catch (NoSuchFieldError v0) {
                                }
                            } catch (NoSuchFieldError v0) {
                            }
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
