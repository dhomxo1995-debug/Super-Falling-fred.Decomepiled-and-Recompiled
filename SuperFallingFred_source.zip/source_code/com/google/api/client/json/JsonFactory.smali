.class public abstract Lcom/google/api/client/json/JsonFactory;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private toByteStream(Ljava/lang/Object; Z)Ljava/io/ByteArrayOutputStream;
    .registers 7
    new-instance v0, Ljava/io/ByteArrayOutputStream;
    invoke-direct v0, Ljava/io/ByteArrayOutputStream;-><init>()V
    sget-object v3, Lcom/google/common/base/Charsets;->UTF_8 Ljava/nio/charset/Charset;
    invoke-virtual v4, v0, v3, Lcom/google/api/client/json/JsonFactory;->createJsonGenerator(Ljava/io/OutputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonGenerator;
    move-result-object v2
    if-eqz v6, +005h
    invoke-virtual v2, Lcom/google/api/client/json/JsonGenerator;->enablePrettyPrint()V
    invoke-virtual v2, v5, Lcom/google/api/client/json/JsonGenerator;->serialize(Ljava/lang/Object;)V
    invoke-virtual v2, Lcom/google/api/client/json/JsonGenerator;->flush()V
    return-object v0
    move-exception v1
    new-instance v3, Ljava/lang/RuntimeException;
    invoke-direct v3, v1, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    throw v3
.end method

.method private toString(Ljava/lang/Object; Z)Ljava/lang/String;
    .registers 6
    invoke-direct v3, v4, v5, Lcom/google/api/client/json/JsonFactory;->toByteStream(Ljava/lang/Object; Z)Ljava/io/ByteArrayOutputStream;
    move-result-object v1
    const-string v2, "UTF-8"
    invoke-virtual v1, v2, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    return-object v1
    move-exception v0
    new-instance v1, Ljava/lang/RuntimeException;
    invoke-direct v1, v0, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    throw v1
.end method

.method public abstract createJsonGenerator(Ljava/io/OutputStream; Lcom/google/api/client/json/JsonEncoding;)Lcom/google/api/client/json/JsonGenerator;
    # abstract or native method
.end method

.method public abstract createJsonGenerator(Ljava/io/OutputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonGenerator;
    # abstract or native method
.end method

.method public abstract createJsonGenerator(Ljava/io/Writer;)Lcom/google/api/client/json/JsonGenerator;
    # abstract or native method
.end method

.method public final createJsonObjectParser()Lcom/google/api/client/json/JsonObjectParser;
    .registers 2
    new-instance v0, Lcom/google/api/client/json/JsonObjectParser;
    invoke-direct v0, v1, Lcom/google/api/client/json/JsonObjectParser;-><init>(Lcom/google/api/client/json/JsonFactory;)V
    return-object v0
.end method

.method public abstract createJsonParser(Ljava/io/InputStream;)Lcom/google/api/client/json/JsonParser;
    # abstract or native method
.end method

.method public abstract createJsonParser(Ljava/io/InputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonParser;
    # abstract or native method
.end method

.method public abstract createJsonParser(Ljava/io/Reader;)Lcom/google/api/client/json/JsonParser;
    # abstract or native method
.end method

.method public abstract createJsonParser(Ljava/lang/String;)Lcom/google/api/client/json/JsonParser;
    # abstract or native method
.end method

.method public final fromInputStream(Ljava/io/InputStream; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 5
    invoke-virtual v2, v3, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/io/InputStream;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v4, v1, Lcom/google/api/client/json/JsonParser;->parseAndClose(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final fromInputStream(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 6
    invoke-virtual v2, v3, v4, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/io/InputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v5, v1, Lcom/google/api/client/json/JsonParser;->parseAndClose(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final fromReader(Ljava/io/Reader; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 5
    invoke-virtual v2, v3, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/io/Reader;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v4, v1, Lcom/google/api/client/json/JsonParser;->parseAndClose(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final fromString(Ljava/lang/String; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 5
    invoke-virtual v2, v3, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/lang/String;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v4, v1, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/Class; Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final toByteArray(Ljava/lang/Object;)[B
    .registers 3
    const/4 v0, 0
    invoke-direct v1, v2, v0, Lcom/google/api/client/json/JsonFactory;->toByteStream(Ljava/lang/Object; Z)Ljava/io/ByteArrayOutputStream;
    move-result-object v0
    invoke-virtual v0, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v0
    return-object v0
.end method

.method public final toPrettyString(Ljava/lang/Object;)Ljava/lang/String;
    .registers 3
    const/4 v0, 1
    invoke-direct v1, v2, v0, Lcom/google/api/client/json/JsonFactory;->toString(Ljava/lang/Object; Z)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public final toString(Ljava/lang/Object;)Ljava/lang/String;
    .registers 3
    const/4 v0, 0
    invoke-direct v1, v2, v0, Lcom/google/api/client/json/JsonFactory;->toString(Ljava/lang/Object; Z)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
