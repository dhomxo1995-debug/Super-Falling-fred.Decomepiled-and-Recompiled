package com.google.api.client.json;
public class GenericJson extends com.google.api.client.util.GenericData implements java.lang.Cloneable {
    private com.google.api.client.json.JsonFactory jsonFactory;

    public GenericJson()
    {
        return;
    }

    public com.google.api.client.json.GenericJson clone()
    {
        return ((com.google.api.client.json.GenericJson) super.clone());
    }

    public bridge synthetic com.google.api.client.util.GenericData clone()
    {
        return this.clone();
    }

    public bridge synthetic Object clone()
    {
        return this.clone();
    }

    public final com.google.api.client.json.JsonFactory getFactory()
    {
        return this.jsonFactory;
    }

    public final void setFactory(com.google.api.client.json.JsonFactory p1)
    {
        this.jsonFactory = p1;
        return;
    }

    public String toPrettyString()
    {
        String v0_1;
        if (this.jsonFactory == null) {
            v0_1 = super.toString();
        } else {
            v0_1 = this.jsonFactory.toPrettyString(this);
        }
        return v0_1;
    }

    public String toString()
    {
        String v0_1;
        if (this.jsonFactory == null) {
            v0_1 = super.toString();
        } else {
            v0_1 = this.jsonFactory.toString(this);
        }
        return v0_1;
    }
}
