package com.google.api.client.json;
public abstract class JsonGenerator {

    public JsonGenerator()
    {
        return;
    }

    public abstract void close();

    public void enablePrettyPrint()
    {
        return;
    }

    public abstract void flush();

    public abstract com.google.api.client.json.JsonFactory getFactory();

    public final void serialize(Object p12)
    {
        if (p12 != null) {
            Class v8 = p12.getClass();
            if (!com.google.api.client.util.Data.isNull(p12)) {
                if (!(p12 instanceof String)) {
                    if (!(p12 instanceof java.math.BigDecimal)) {
                        if (!(p12 instanceof java.math.BigInteger)) {
                            if (!(p12 instanceof com.google.common.primitives.UnsignedInteger)) {
                                if (!(p12 instanceof com.google.common.primitives.UnsignedLong)) {
                                    if (!(p12 instanceof Double)) {
                                        if (!(p12 instanceof Long)) {
                                            if (!(p12 instanceof Float)) {
                                                if ((!(p12 instanceof Integer)) && ((!(p12 instanceof Short)) && (!(p12 instanceof Byte)))) {
                                                    if (!(p12 instanceof Boolean)) {
                                                        if (!(p12 instanceof com.google.api.client.util.DateTime)) {
                                                            if ((!(p12 instanceof Iterable)) && (!v8.isArray())) {
                                                                if (!v8.isEnum()) {
                                                                    this.writeStartObject();
                                                                    com.google.api.client.util.ClassInfo v0 = com.google.api.client.util.ClassInfo.of(v8);
                                                                    java.util.Iterator v5_0 = com.google.api.client.util.Data.mapOf(p12).entrySet().iterator();
                                                                    while (v5_0.hasNext()) {
                                                                        java.util.Map$Entry v1_1 = ((java.util.Map$Entry) v5_0.next());
                                                                        String v4 = v1_1.getValue();
                                                                        if (v4 != null) {
                                                                            String v3_1 = ((String) v1_1.getKey());
                                                                            if ((v4 instanceof Number)) {
                                                                                reflect.Field v2 = v0.getField(v3_1);
                                                                                if ((v2 != null) && (v2.getAnnotation(com.google.api.client.json.JsonString) != null)) {
                                                                                    v4 = v4.toString();
                                                                                }
                                                                            }
                                                                            this.writeFieldName(v3_1);
                                                                            this.serialize(v4);
                                                                        }
                                                                    }
                                                                    this.writeEndObject();
                                                                } else {
                                                                    String v6 = com.google.api.client.util.FieldInfo.of(((Enum) p12)).getName();
                                                                    if (v6 != null) {
                                                                        this.writeString(v6);
                                                                    } else {
                                                                        this.writeNull();
                                                                    }
                                                                }
                                                            } else {
                                                                this.writeStartArray();
                                                                java.util.Iterator v5_1 = com.google.api.client.util.Types.iterableOf(p12).iterator();
                                                                while (v5_1.hasNext()) {
                                                                    this.serialize(v5_1.next());
                                                                }
                                                                this.writeEndArray();
                                                            }
                                                        } else {
                                                            this.writeString(((com.google.api.client.util.DateTime) p12).toStringRfc3339());
                                                        }
                                                    } else {
                                                        this.writeBoolean(((Boolean) p12).booleanValue());
                                                    }
                                                } else {
                                                    this.writeNumber(((Number) p12).intValue());
                                                }
                                            } else {
                                                this.writeNumber(((Float) p12).floatValue());
                                            }
                                        } else {
                                            this.writeNumber(((Long) p12).longValue());
                                        }
                                    } else {
                                        this.writeNumber(((Double) p12).doubleValue());
                                    }
                                } else {
                                    this.writeNumber(((com.google.common.primitives.UnsignedLong) p12));
                                }
                            } else {
                                this.writeNumber(((com.google.common.primitives.UnsignedInteger) p12));
                            }
                        } else {
                            this.writeNumber(((java.math.BigInteger) p12));
                        }
                    } else {
                        this.writeNumber(((java.math.BigDecimal) p12));
                    }
                } else {
                    this.writeString(((String) p12));
                }
            } else {
                this.writeNull();
            }
        }
        return;
    }

    public abstract void writeBoolean(boolean p0);

    public abstract void writeEndArray();

    public abstract void writeEndObject();

    public abstract void writeFieldName(String p0);

    public abstract void writeNull();

    public abstract void writeNumber(double p0);

    public abstract void writeNumber(float p0);

    public abstract void writeNumber(int p0);

    public abstract void writeNumber(long p0);

    public abstract void writeNumber(com.google.common.primitives.UnsignedInteger p0);

    public abstract void writeNumber(com.google.common.primitives.UnsignedLong p0);

    public abstract void writeNumber(String p0);

    public abstract void writeNumber(java.math.BigDecimal p0);

    public abstract void writeNumber(java.math.BigInteger p0);

    public abstract void writeStartArray();

    public abstract void writeStartObject();

    public abstract void writeString(String p0);
}
