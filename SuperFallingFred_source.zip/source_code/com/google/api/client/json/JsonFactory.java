package com.google.api.client.json;
public abstract class JsonFactory {

    public JsonFactory()
    {
        return;
    }

    private java.io.ByteArrayOutputStream toByteStream(Object p5, boolean p6)
    {
        java.io.ByteArrayOutputStream v0_1 = new java.io.ByteArrayOutputStream();
        try {
            com.google.api.client.json.JsonGenerator v2 = this.createJsonGenerator(v0_1, com.google.common.base.Charsets.UTF_8);
        } catch (java.io.IOException v1) {
            throw new RuntimeException(v1);
        }
        if (p6) {
            v2.enablePrettyPrint();
        }
        v2.serialize(p5);
        v2.flush();
        return v0_1;
    }

    private String toString(Object p4, boolean p5)
    {
        try {
            return this.toByteStream(p4, p5).toString("UTF-8");
        } catch (java.io.UnsupportedEncodingException v0) {
            throw new RuntimeException(v0);
        }
    }

    public abstract com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p0, com.google.api.client.json.JsonEncoding p1);

    public abstract com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p0, java.nio.charset.Charset p1);

    public abstract com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.Writer p0);

    public final com.google.api.client.json.JsonObjectParser createJsonObjectParser()
    {
        return new com.google.api.client.json.JsonObjectParser(this);
    }

    public abstract com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p0);

    public abstract com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p0, java.nio.charset.Charset p1);

    public abstract com.google.api.client.json.JsonParser createJsonParser(java.io.Reader p0);

    public abstract com.google.api.client.json.JsonParser createJsonParser(String p0);

    public final Object fromInputStream(java.io.InputStream p3, Class p4)
    {
        return this.createJsonParser(p3).parseAndClose(p4, 0);
    }

    public final Object fromInputStream(java.io.InputStream p3, java.nio.charset.Charset p4, Class p5)
    {
        return this.createJsonParser(p3, p4).parseAndClose(p5, 0);
    }

    public final Object fromReader(java.io.Reader p3, Class p4)
    {
        return this.createJsonParser(p3).parseAndClose(p4, 0);
    }

    public final Object fromString(String p3, Class p4)
    {
        return this.createJsonParser(p3).parse(p4, 0);
    }

    public final byte[] toByteArray(Object p2)
    {
        return this.toByteStream(p2, 0).toByteArray();
    }

    public final String toPrettyString(Object p2)
    {
        return this.toString(p2, 1);
    }

    public final String toString(Object p2)
    {
        return this.toString(p2, 0);
    }
}
