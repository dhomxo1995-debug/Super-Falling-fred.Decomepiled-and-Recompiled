package com.google.api.client.json;
public class CustomizeJsonParser {

    public CustomizeJsonParser()
    {
        return;
    }

    public void handleUnrecognizedKey(Object p1, String p2)
    {
        return;
    }

    public java.util.Collection newInstanceForArray(Object p2, reflect.Field p3)
    {
        return 0;
    }

    public Object newInstanceForObject(Object p2, Class p3)
    {
        return 0;
    }

    public boolean stopAt(Object p2, String p3)
    {
        return 0;
    }
}
