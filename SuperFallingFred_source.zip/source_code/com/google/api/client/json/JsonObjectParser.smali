.class public Lcom/google/api/client/json/JsonObjectParser;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/util/ObjectParser;

.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;

.method public constructor <init>(Lcom/google/api/client/json/JsonFactory;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/json/JsonObjectParser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-void
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/JsonObjectParser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 5
    invoke-virtual v1, v2, v3, v4, Lcom/google/api/client/json/JsonObjectParser;->parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .registers 7
    iget-object v1, v3, Lcom/google/api/client/json/JsonObjectParser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v1, v4, v5, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/io/InputStream; Ljava/nio/charset/Charset;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 1
    const/4 v2, 0
    invoke-virtual v0, v6, v1, v2, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/reflect/Type; Z Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v1
    return-object v1
.end method

.method public parseAndClose(Ljava/io/Reader; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 4
    invoke-virtual v1, v2, v3, Lcom/google/api/client/json/JsonObjectParser;->parseAndClose(Ljava/io/Reader; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public parseAndClose(Ljava/io/Reader; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .registers 6
    iget-object v1, v3, Lcom/google/api/client/json/JsonObjectParser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v1, v4, Lcom/google/api/client/json/JsonFactory;->createJsonParser(Ljava/io/Reader;)Lcom/google/api/client/json/JsonParser;
    move-result-object v0
    const/4 v1, 1
    const/4 v2, 0
    invoke-virtual v0, v5, v1, v2, Lcom/google/api/client/json/JsonParser;->parse(Ljava/lang/reflect/Type; Z Lcom/google/api/client/json/CustomizeJsonParser;)Ljava/lang/Object;
    move-result-object v1
    return-object v1
.end method
