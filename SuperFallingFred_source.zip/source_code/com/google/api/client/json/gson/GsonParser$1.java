package com.google.api.client.json.gson;
synthetic class GsonParser$1 {
    static final synthetic int[] $SwitchMap$com$google$api$client$json$JsonToken;
    static final synthetic int[] $SwitchMap$com$google$gson$stream$JsonToken;

    static GsonParser$1()
    {
        NoSuchFieldError v0_5 = new int[com.google.gson.stream.JsonToken.values().length];
        com.google.api.client.json.gson.GsonParser$1.$SwitchMap$com$google$gson$stream$JsonToken = v0_5;
        try {
            com.google.gson.stream.JsonToken.BEGIN_ARRAY.ordinal()[int v1_19] = 1;
            try {
                com.google.gson.stream.JsonToken.END_ARRAY.ordinal()[int v1_1] = 2;
                try {
                    com.google.gson.stream.JsonToken.BEGIN_OBJECT.ordinal()[int v1_3] = 3;
                    try {
                        com.google.gson.stream.JsonToken.END_OBJECT.ordinal()[int v1_5] = 4;
                        try {
                            com.google.gson.stream.JsonToken.BOOLEAN.ordinal()[int v1_7] = 5;
                            try {
                                com.google.gson.stream.JsonToken.NULL.ordinal()[int v1_9] = 6;
                                try {
                                    com.google.gson.stream.JsonToken.STRING.ordinal()[int v1_11] = 7;
                                    try {
                                        com.google.gson.stream.JsonToken.NUMBER.ordinal()[int v1_13] = 8;
                                        try {
                                            com.google.gson.stream.JsonToken.NAME.ordinal()[int v1_16] = 9;
                                        } catch (NoSuchFieldError v0) {
                                        }
                                        NoSuchFieldError v0_14 = new int[com.google.api.client.json.JsonToken.values().length];
                                        com.google.api.client.json.gson.GsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken = v0_14;
                                        try {
                                            com.google.api.client.json.JsonToken.START_ARRAY.ordinal()[int v1_18] = 1;
                                            try {
                                                com.google.api.client.json.JsonToken.START_OBJECT.ordinal()[int v1_21] = 2;
                                            } catch (NoSuchFieldError v0) {
                                            }
                                            return;
                                        } catch (NoSuchFieldError v0) {
                                        }
                                    } catch (NoSuchFieldError v0) {
                                    }
                                } catch (NoSuchFieldError v0) {
                                }
                            } catch (NoSuchFieldError v0) {
                            }
                        } catch (NoSuchFieldError v0) {
                        }
                    } catch (NoSuchFieldError v0) {
                    }
                } catch (NoSuchFieldError v0) {
                }
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
