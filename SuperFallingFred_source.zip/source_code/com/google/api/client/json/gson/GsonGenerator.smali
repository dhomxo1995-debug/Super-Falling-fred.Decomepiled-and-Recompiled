.class 0x0 Lcom/google/api/client/json/gson/GsonGenerator;
.super Lcom/google/api/client/json/JsonGenerator;

.field private final factory:Lcom/google/api/client/json/gson/GsonFactory;
.field private final writer:Lcom/google/gson/stream/JsonWriter;

.method constructor <init>(Lcom/google/api/client/json/gson/GsonFactory; Lcom/google/gson/stream/JsonWriter;)V
    .registers 4
    invoke-direct v1, Lcom/google/api/client/json/JsonGenerator;-><init>()V
    iput-object v2, v1, Lcom/google/api/client/json/gson/GsonGenerator;->factory Lcom/google/api/client/json/gson/GsonFactory;
    iput-object v3, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    const/4 v0, 1
    invoke-virtual v3, v0, Lcom/google/gson/stream/JsonWriter;->setLenient(Z)V
    return-void
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->close()V
    return-void
.end method

.method public enablePrettyPrint()V
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    const-string v1, "  "
    invoke-virtual v0, v1, Lcom/google/gson/stream/JsonWriter;->setIndent(Ljava/lang/String;)V
    return-void
.end method

.method public flush()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->flush()V
    return-void
.end method

.method public getFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->factory Lcom/google/api/client/json/gson/GsonFactory;
    return-object v0
.end method

.method public writeBoolean(Z)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Z)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeEndArray()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->endArray()Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeEndObject()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->endObject()Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeFieldName(Ljava/lang/String;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->name(Ljava/lang/String;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNull()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->nullValue()Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(D)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, v3, Lcom/google/gson/stream/JsonWriter;->value(D)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(F)V
    .registers 5
    iget-object v0, v3, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    float-to-double v1, v4
    invoke-virtual v0, v1, v2, Lcom/google/gson/stream/JsonWriter;->value(D)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(I)V
    .registers 5
    iget-object v0, v3, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    int-to-long v1, v4
    invoke-virtual v0, v1, v2, Lcom/google/gson/stream/JsonWriter;->value(J)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(J)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, v3, Lcom/google/gson/stream/JsonWriter;->value(J)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(Lcom/google/common/primitives/UnsignedInteger;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/Number;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(Lcom/google/common/primitives/UnsignedLong;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/Number;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(Ljava/lang/String;)V
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    new-instance v1, Lcom/google/api/client/json/gson/GsonGenerator$StringNumber;
    invoke-direct v1, v3, Lcom/google/api/client/json/gson/GsonGenerator$StringNumber;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, v1, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/Number;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(Ljava/math/BigDecimal;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/Number;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeNumber(Ljava/math/BigInteger;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/Number;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeStartArray()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->beginArray()Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeStartObject()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, Lcom/google/gson/stream/JsonWriter;->beginObject()Lcom/google/gson/stream/JsonWriter;
    return-void
.end method

.method public writeString(Ljava/lang/String;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator;->writer Lcom/google/gson/stream/JsonWriter;
    invoke-virtual v0, v2, Lcom/google/gson/stream/JsonWriter;->value(Ljava/lang/String;)Lcom/google/gson/stream/JsonWriter;
    return-void
.end method
