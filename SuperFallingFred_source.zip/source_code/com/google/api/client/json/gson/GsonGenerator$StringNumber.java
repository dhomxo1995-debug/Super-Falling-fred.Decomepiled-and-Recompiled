package com.google.api.client.json.gson;
final class GsonGenerator$StringNumber extends java.lang.Number {
    private static final long serialVersionUID = 1;
    private final String encodedValue;

    GsonGenerator$StringNumber(String p1)
    {
        this.encodedValue = p1;
        return;
    }

    public double doubleValue()
    {
        return 0;
    }

    public float floatValue()
    {
        return 0;
    }

    public int intValue()
    {
        return 0;
    }

    public long longValue()
    {
        return 0;
    }

    public String toString()
    {
        return this.encodedValue;
    }
}
