package com.google.api.client.json.gson;
public class GsonFactory extends com.google.api.client.json.JsonFactory {

    public GsonFactory()
    {
        return;
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p3, com.google.api.client.json.JsonEncoding p4)
    {
        return this.createJsonGenerator(new java.io.OutputStreamWriter(p3, com.google.common.base.Charsets.UTF_8));
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.OutputStream p2, java.nio.charset.Charset p3)
    {
        return this.createJsonGenerator(new java.io.OutputStreamWriter(p2, p3));
    }

    public com.google.api.client.json.JsonGenerator createJsonGenerator(java.io.Writer p3)
    {
        return new com.google.api.client.json.gson.GsonGenerator(this, new com.google.gson.stream.JsonWriter(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p3)
    {
        return this.createJsonParser(new java.io.InputStreamReader(p3, com.google.common.base.Charsets.UTF_8));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.InputStream p2, java.nio.charset.Charset p3)
    {
        return this.createJsonParser(new java.io.InputStreamReader(p2, p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(java.io.Reader p3)
    {
        return new com.google.api.client.json.gson.GsonParser(this, new com.google.gson.stream.JsonReader(p3));
    }

    public com.google.api.client.json.JsonParser createJsonParser(String p2)
    {
        return this.createJsonParser(new java.io.StringReader(p2));
    }
}
