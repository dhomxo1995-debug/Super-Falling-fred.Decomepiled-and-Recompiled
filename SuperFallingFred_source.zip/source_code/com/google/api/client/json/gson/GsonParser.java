package com.google.api.client.json.gson;
 class GsonParser extends com.google.api.client.json.JsonParser {
    private java.util.List currentNameStack;
    private String currentText;
    private com.google.api.client.json.JsonToken currentToken;
    private final com.google.api.client.json.gson.GsonFactory factory;
    private final com.google.gson.stream.JsonReader reader;

    GsonParser(com.google.api.client.json.gson.GsonFactory p2, com.google.gson.stream.JsonReader p3)
    {
        this.currentNameStack = new java.util.ArrayList();
        this.factory = p2;
        this.reader = p3;
        p3.setLenient(1);
        return;
    }

    private void checkNumber()
    {
        if ((this.currentToken != com.google.api.client.json.JsonToken.VALUE_NUMBER_INT) && (this.currentToken != com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT)) {
            int v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_2);
        return;
    }

    public void close()
    {
        this.reader.close();
        return;
    }

    public java.math.BigInteger getBigIntegerValue()
    {
        this.checkNumber();
        return new java.math.BigInteger(this.currentText);
    }

    public byte getByteValue()
    {
        this.checkNumber();
        return Byte.valueOf(this.currentText).byteValue();
    }

    public String getCurrentName()
    {
        String v0_2;
        if (!this.currentNameStack.isEmpty()) {
            v0_2 = ((String) this.currentNameStack.get((this.currentNameStack.size() - 1)));
        } else {
            v0_2 = 0;
        }
        return v0_2;
    }

    public com.google.api.client.json.JsonToken getCurrentToken()
    {
        return this.currentToken;
    }

    public java.math.BigDecimal getDecimalValue()
    {
        this.checkNumber();
        return new java.math.BigDecimal(this.currentText);
    }

    public double getDoubleValue()
    {
        this.checkNumber();
        return Double.valueOf(this.currentText).doubleValue();
    }

    public com.google.api.client.json.JsonFactory getFactory()
    {
        return this.factory;
    }

    public float getFloatValue()
    {
        this.checkNumber();
        return Float.valueOf(this.currentText).floatValue();
    }

    public int getIntValue()
    {
        this.checkNumber();
        return Integer.valueOf(this.currentText).intValue();
    }

    public long getLongValue()
    {
        this.checkNumber();
        return Long.valueOf(this.currentText).longValue();
    }

    public short getShortValue()
    {
        this.checkNumber();
        return Short.valueOf(this.currentText).shortValue();
    }

    public String getText()
    {
        return this.currentText;
    }

    public com.google.common.primitives.UnsignedInteger getUnsignedIntegerValue()
    {
        this.checkNumber();
        return com.google.common.primitives.UnsignedInteger.valueOf(this.currentText);
    }

    public com.google.common.primitives.UnsignedLong getUnsignedLongValue()
    {
        this.checkNumber();
        return com.google.common.primitives.UnsignedLong.valueOf(this.currentText);
    }

    public com.google.api.client.json.JsonToken nextToken()
    {
        if (this.currentToken != null) {
            switch (com.google.api.client.json.gson.GsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken[this.currentToken.ordinal()]) {
                case 1:
                    this.reader.beginArray();
                    this.currentNameStack.add(0);
                    break;
                case 2:
                    this.reader.beginObject();
                    this.currentNameStack.add(0);
                    break;
                default:
                    com.google.gson.stream.JsonToken v1 = this.reader.peek();
                    switch (com.google.api.client.json.gson.GsonParser$1.$SwitchMap$com$google$gson$stream$JsonToken[v1.ordinal()]) {
                        case 1:
                            this.currentText = "[";
                            this.currentToken = com.google.api.client.json.JsonToken.START_ARRAY;
                            break;
                        case 2:
                            this.currentText = "]";
                            this.currentToken = com.google.api.client.json.JsonToken.END_ARRAY;
                            this.currentNameStack.remove((this.currentNameStack.size() - 1));
                            this.reader.endArray();
                            break;
                        case 3:
                            this.currentText = "{";
                            this.currentToken = com.google.api.client.json.JsonToken.START_OBJECT;
                            break;
                        case 4:
                            this.currentText = "}";
                            this.currentToken = com.google.api.client.json.JsonToken.END_OBJECT;
                            this.currentNameStack.remove((this.currentNameStack.size() - 1));
                            this.reader.endObject();
                            break;
                        case 5:
                            if (!this.reader.nextBoolean()) {
                                this.currentText = "false";
                                this.currentToken = com.google.api.client.json.JsonToken.VALUE_FALSE;
                            } else {
                                this.currentText = "true";
                                this.currentToken = com.google.api.client.json.JsonToken.VALUE_TRUE;
                            }
                            break;
                        case 6:
                            this.currentText = "null";
                            this.currentToken = com.google.api.client.json.JsonToken.VALUE_NULL;
                            this.reader.nextNull();
                            break;
                        case 7:
                            this.currentText = this.reader.nextString();
                            this.currentToken = com.google.api.client.json.JsonToken.VALUE_STRING;
                            break;
                        case 8:
                            com.google.api.client.json.JsonToken v2_20;
                            this.currentText = this.reader.nextString();
                            if (this.currentText.indexOf(46) != -1) {
                                v2_20 = com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT;
                            } else {
                                v2_20 = com.google.api.client.json.JsonToken.VALUE_NUMBER_INT;
                            }
                            this.currentToken = v2_20;
                            break;
                        case 9:
                            this.currentText = this.reader.nextName();
                            this.currentToken = com.google.api.client.json.JsonToken.FIELD_NAME;
                            this.currentNameStack.set((this.currentNameStack.size() - 1), this.currentText);
                            break;
                        default:
                            this.currentText = 0;
                            this.currentToken = 0;
                    }
                    return this.currentToken;
            }
        }
        try {
        } catch (java.io.EOFException v0) {
            v1 = com.google.gson.stream.JsonToken.END_DOCUMENT;
        }
    }

    public com.google.api.client.json.JsonParser skipChildren()
    {
        switch (com.google.api.client.json.gson.GsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken[this.currentToken.ordinal()]) {
            case 1:
                this.reader.skipValue();
                this.currentText = "]";
                this.currentToken = com.google.api.client.json.JsonToken.END_ARRAY;
                break;
            case 2:
                this.reader.skipValue();
                this.currentText = "}";
                this.currentToken = com.google.api.client.json.JsonToken.END_OBJECT;
                break;
        }
        return this;
    }
}
