.class final Lcom/google/api/client/json/gson/GsonGenerator$StringNumber;
.super Ljava/lang/Number;

.field private static final serialVersionUID:J
.field private final encodedValue:Ljava/lang/String;

.method constructor <init>(Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, Ljava/lang/Number;-><init>()V
    iput-object v1, v0, Lcom/google/api/client/json/gson/GsonGenerator$StringNumber;->encodedValue Ljava/lang/String;
    return-void
.end method

.method public doubleValue()D
    .registers 3
    const-wide/16 v0, 0
    return-wide v0
.end method

.method public floatValue()F
    .registers 2
    const/4 v0, 0
    return v0
.end method

.method public intValue()I
    .registers 2
    const/4 v0, 0
    return v0
.end method

.method public longValue()J
    .registers 3
    const-wide/16 v0, 0
    return-wide v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonGenerator$StringNumber;->encodedValue Ljava/lang/String;
    return-object v0
.end method
