.class 0x0 Lcom/google/api/client/json/gson/GsonParser;
.super Lcom/google/api/client/json/JsonParser;

.field private currentNameStack:Ljava/util/List;
.field private currentText:Ljava/lang/String;
.field private currentToken:Lcom/google/api/client/json/JsonToken;
.field private final factory:Lcom/google/api/client/json/gson/GsonFactory;
.field private final reader:Lcom/google/gson/stream/JsonReader;

.method constructor <init>(Lcom/google/api/client/json/gson/GsonFactory; Lcom/google/gson/stream/JsonReader;)V
    .registers 4
    invoke-direct v1, Lcom/google/api/client/json/JsonParser;-><init>()V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    iput-object v2, v1, Lcom/google/api/client/json/gson/GsonParser;->factory Lcom/google/api/client/json/gson/GsonFactory;
    iput-object v3, v1, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    const/4 v0, 1
    invoke-virtual v3, v0, Lcom/google/gson/stream/JsonReader;->setLenient(Z)V
    return-void
.end method

.method private checkNumber()V
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    if-eq v0, v1, +008h
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    sget-object v1, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    if-ne v0, v1, +007h
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    return-void
    const/4 v0, 0
    goto -5h
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v0, Lcom/google/gson/stream/JsonReader;->close()V
    return-void
.end method

.method public getBigIntegerValue()Ljava/math/BigInteger;
    .registers 3
    invoke-direct v2, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    new-instance v0, Ljava/math/BigInteger;
    iget-object v1, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-direct v0, v1, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V
    return-object v0
.end method

.method public getByteValue()B
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Byte;->valueOf(Ljava/lang/String;)Ljava/lang/Byte;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Byte;->byteValue()B
    move-result v0
    return v0
.end method

.method public getCurrentName()Ljava/lang/String;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 0
    return-object v0
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    iget-object v1, v2, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v1
    add-int/lit8 v1, v1, -1
    invoke-interface v0, v1, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    goto -11h
.end method

.method public getCurrentToken()Lcom/google/api/client/json/JsonToken;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    return-object v0
.end method

.method public getDecimalValue()Ljava/math/BigDecimal;
    .registers 3
    invoke-direct v2, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    new-instance v0, Ljava/math/BigDecimal;
    iget-object v1, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-direct v0, v1, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V
    return-object v0
.end method

.method public getDoubleValue()D
    .registers 3
    invoke-direct v2, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Double;->doubleValue()D
    move-result-wide v0
    return-wide v0
.end method

.method public getFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->factory Lcom/google/api/client/json/gson/GsonFactory;
    return-object v0
.end method

.method public getFloatValue()F
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Float;->floatValue()F
    move-result v0
    return v0
.end method

.method public getIntValue()I
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Integer;->intValue()I
    move-result v0
    return v0
.end method

.method public getLongValue()J
    .registers 3
    invoke-direct v2, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v0
    return-wide v0
.end method

.method public getShortValue()S
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Ljava/lang/Short;->valueOf(Ljava/lang/String;)Ljava/lang/Short;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Short;->shortValue()S
    move-result v0
    return v0
.end method

.method public getText()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    return-object v0
.end method

.method public getUnsignedIntegerValue()Lcom/google/common/primitives/UnsignedInteger;
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Lcom/google/common/primitives/UnsignedInteger;->valueOf(Ljava/lang/String;)Lcom/google/common/primitives/UnsignedInteger;
    move-result-object v0
    return-object v0
.end method

.method public getUnsignedLongValue()Lcom/google/common/primitives/UnsignedLong;
    .registers 2
    invoke-direct v1, Lcom/google/api/client/json/gson/GsonParser;->checkNumber()V
    iget-object v0, v1, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-static v0, Lcom/google/common/primitives/UnsignedLong;->valueOf(Ljava/lang/String;)Lcom/google/common/primitives/UnsignedLong;
    move-result-object v0
    return-object v0
.end method

.method public nextToken()Lcom/google/api/client/json/JsonToken;
    .registers 6
    const/4 v4, 0
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    if-eqz v2, +00fh
    sget-object v2, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    iget-object v3, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    invoke-virtual v3, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v3
    aget v2, v2, v3
    packed-switch v2, +00000edh
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->peek()Lcom/google/gson/stream/JsonToken;
    move-result-object v1
    sget-object v2, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v3
    aget v2, v2, v3
    packed-switch v2, +00000e4h
    iput-object v4, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    iput-object v4, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    return-object v2
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->beginArray()V
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v2, v4, Ljava/util/List;->add(Ljava/lang/Object;)Z
    goto -22h
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->beginObject()V
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v2, v4, Ljava/util/List;->add(Ljava/lang/Object;)Z
    goto -2dh
    move-exception v0
    sget-object v1, Lcom/google/gson/stream/JsonToken;->END_DOCUMENT Lcom/google/gson/stream/JsonToken;
    goto -2bh
    const-string v2, "["
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -25h
    const-string v2, "]"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    iget-object v3, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v3, Ljava/util/List;->size()I
    move-result v3
    add-int/lit8 v3, v3, -1
    invoke-interface v2, v3, Ljava/util/List;->remove(I)Ljava/lang/Object;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->endArray()V
    goto -40h
    const-string v2, "{"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -49h
    const-string v2, "}"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    iget-object v3, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v3, Ljava/util/List;->size()I
    move-result v3
    add-int/lit8 v3, v3, -1
    invoke-interface v2, v3, Ljava/util/List;->remove(I)Ljava/lang/Object;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->endObject()V
    goto -64h
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->nextBoolean()Z
    move-result v2
    if-eqz v2, +00bh
    const-string v2, "true"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_TRUE Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -75h
    const-string v2, "false"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_FALSE Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -7eh
    const-string v2, "null"
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NULL Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->nextNull()V
    goto/16 -08ch
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->nextString()Ljava/lang/String;
    move-result-object v2
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_STRING Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto/16 -09ah
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->nextString()Ljava/lang/String;
    move-result-object v2
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    const/16 v3, 46
    invoke-virtual v2, v3, Ljava/lang/String;->indexOf(I)I
    move-result v2
    const/4 v3, -1
    if-ne v2, v3, +008h
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_INT Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto/16 -0b3h
    sget-object v2, Lcom/google/api/client/json/JsonToken;->VALUE_NUMBER_FLOAT Lcom/google/api/client/json/JsonToken;
    goto -6h
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v2, Lcom/google/gson/stream/JsonReader;->nextName()Ljava/lang/String;
    move-result-object v2
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/json/JsonToken;->FIELD_NAME Lcom/google/api/client/json/JsonToken;
    iput-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    iget-object v2, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    iget-object v3, v5, Lcom/google/api/client/json/gson/GsonParser;->currentNameStack Ljava/util/List;
    invoke-interface v3, Ljava/util/List;->size()I
    move-result v3
    add-int/lit8 v3, v3, -1
    iget-object v4, v5, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    invoke-interface v2, v3, v4, Ljava/util/List;->set(I Ljava/lang/Object;)Ljava/lang/Object;
    goto/16 -0d3h
    packed-switch-payload 1 2
    packed-switch-payload 1 2 3 4 5 6 7 8 9
.end method

.method public skipChildren()Lcom/google/api/client/json/JsonParser;
    .registers 3
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    iget-object v1, v2, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    aget v0, v0, v1
    packed-switch v0, +0000020h
    return-object v2
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v0, Lcom/google/gson/stream/JsonReader;->skipValue()V
    const-string v0, "]"
    iput-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v0, Lcom/google/api/client/json/JsonToken;->END_ARRAY Lcom/google/api/client/json/JsonToken;
    iput-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -eh
    iget-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->reader Lcom/google/gson/stream/JsonReader;
    invoke-virtual v0, Lcom/google/gson/stream/JsonReader;->skipValue()V
    const-string v0, "}"
    iput-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentText Ljava/lang/String;
    sget-object v0, Lcom/google/api/client/json/JsonToken;->END_OBJECT Lcom/google/api/client/json/JsonToken;
    iput-object v0, v2, Lcom/google/api/client/json/gson/GsonParser;->currentToken Lcom/google/api/client/json/JsonToken;
    goto -1ch
    packed-switch-payload 1 2
.end method
