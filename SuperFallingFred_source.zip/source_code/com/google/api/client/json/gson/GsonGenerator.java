package com.google.api.client.json.gson;
 class GsonGenerator extends com.google.api.client.json.JsonGenerator {
    private final com.google.api.client.json.gson.GsonFactory factory;
    private final com.google.gson.stream.JsonWriter writer;

    GsonGenerator(com.google.api.client.json.gson.GsonFactory p2, com.google.gson.stream.JsonWriter p3)
    {
        this.factory = p2;
        this.writer = p3;
        p3.setLenient(1);
        return;
    }

    public void close()
    {
        this.writer.close();
        return;
    }

    public void enablePrettyPrint()
    {
        this.writer.setIndent("  ");
        return;
    }

    public void flush()
    {
        this.writer.flush();
        return;
    }

    public com.google.api.client.json.JsonFactory getFactory()
    {
        return this.factory;
    }

    public void writeBoolean(boolean p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeEndArray()
    {
        this.writer.endArray();
        return;
    }

    public void writeEndObject()
    {
        this.writer.endObject();
        return;
    }

    public void writeFieldName(String p2)
    {
        this.writer.name(p2);
        return;
    }

    public void writeNull()
    {
        this.writer.nullValue();
        return;
    }

    public void writeNumber(double p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeNumber(float p4)
    {
        this.writer.value(((double) p4));
        return;
    }

    public void writeNumber(int p4)
    {
        this.writer.value(((long) p4));
        return;
    }

    public void writeNumber(long p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeNumber(com.google.common.primitives.UnsignedInteger p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeNumber(com.google.common.primitives.UnsignedLong p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeNumber(String p3)
    {
        this.writer.value(new com.google.api.client.json.gson.GsonGenerator$StringNumber(p3));
        return;
    }

    public void writeNumber(java.math.BigDecimal p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeNumber(java.math.BigInteger p2)
    {
        this.writer.value(p2);
        return;
    }

    public void writeStartArray()
    {
        this.writer.beginArray();
        return;
    }

    public void writeStartObject()
    {
        this.writer.beginObject();
        return;
    }

    public void writeString(String p2)
    {
        this.writer.value(p2);
        return;
    }
}
