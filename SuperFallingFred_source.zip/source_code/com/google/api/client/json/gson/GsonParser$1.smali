.class synthetic Lcom/google/api/client/json/gson/GsonParser$1;
.super Ljava/lang/Object;

.field static final synthetic $SwitchMap$com$google$api$client$json$JsonToken:[I
.field static final synthetic $SwitchMap$com$google$gson$stream$JsonToken:[I

.method static constructor <clinit>()V
    .registers 3
    invoke-static Lcom/google/gson/stream/JsonToken;->values()[Lcom/google/gson/stream/JsonToken;
    move-result-object v0
    array-length v0, v0
    new-array v0, v0, [I
    sput-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->BEGIN_ARRAY Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 1
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->END_ARRAY Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 2
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->BEGIN_OBJECT Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 3
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->END_OBJECT Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 4
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->BOOLEAN Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 5
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->NULL Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 6
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->STRING Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 7
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->NUMBER Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 8
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$gson$stream$JsonToken [I
    sget-object v1, Lcom/google/gson/stream/JsonToken;->NAME Lcom/google/gson/stream/JsonToken;
    invoke-virtual v1, Lcom/google/gson/stream/JsonToken;->ordinal()I
    move-result v1
    const/16 v2, 9
    aput v2, v0, v1
    invoke-static Lcom/google/api/client/json/JsonToken;->values()[Lcom/google/api/client/json/JsonToken;
    move-result-object v0
    array-length v0, v0
    new-array v0, v0, [I
    sput-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_ARRAY Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 1
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/json/gson/GsonParser$1;->$SwitchMap$com$google$api$client$json$JsonToken [I
    sget-object v1, Lcom/google/api/client/json/JsonToken;->START_OBJECT Lcom/google/api/client/json/JsonToken;
    invoke-virtual v1, Lcom/google/api/client/json/JsonToken;->ordinal()I
    move-result v1
    const/4 v2, 2
    aput v2, v0, v1
    return-void
    move-exception v0
    goto -2h
    move-exception v0
    goto -fh
    move-exception v0
    goto -25h
    move-exception v0
    goto -33h
    move-exception v0
    goto -41h
    move-exception v0
    goto -4eh
    move-exception v0
    goto -5bh
    move-exception v0
    goto -68h
    move-exception v0
    goto -75h
    move-exception v0
    goto/16 -082h
    move-exception v0
    goto/16 -090h
.end method
