package com.google.api.client.json;
public final enum class JsonEncoding extends java.lang.Enum {
    private static final synthetic com.google.api.client.json.JsonEncoding[] $VALUES;
    public static final enum com.google.api.client.json.JsonEncoding UTF8;

    static JsonEncoding()
    {
        com.google.api.client.json.JsonEncoding.UTF8 = new com.google.api.client.json.JsonEncoding("UTF8", 0);
        com.google.api.client.json.JsonEncoding[] v0_3 = new com.google.api.client.json.JsonEncoding[1];
        v0_3[0] = com.google.api.client.json.JsonEncoding.UTF8;
        com.google.api.client.json.JsonEncoding.$VALUES = v0_3;
        return;
    }

    private JsonEncoding(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.json.JsonEncoding valueOf(String p1)
    {
        return ((com.google.api.client.json.JsonEncoding) Enum.valueOf(com.google.api.client.json.JsonEncoding, p1));
    }

    public static com.google.api.client.json.JsonEncoding[] values()
    {
        return ((com.google.api.client.json.JsonEncoding[]) com.google.api.client.json.JsonEncoding.$VALUES.clone());
    }
}
