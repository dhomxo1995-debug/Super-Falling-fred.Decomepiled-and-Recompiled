package com.google.api.client.json.rpc2;
public class JsonRpcRequest extends com.google.api.client.util.GenericData {
    private Object id;
    private final String jsonrpc;
    private String method;
    private Object params;

    public JsonRpcRequest()
    {
        this.jsonrpc = "2.0";
        return;
    }

    public Object getId()
    {
        return this.id;
    }

    public String getMethod()
    {
        return this.method;
    }

    public Object getParameters()
    {
        return this.params;
    }

    public String getVersion()
    {
        return "2.0";
    }

    public void setId(Object p1)
    {
        this.id = p1;
        return;
    }

    public void setMethod(String p1)
    {
        this.method = p1;
        return;
    }

    public void setParameters(Object p1)
    {
        this.params = p1;
        return;
    }
}
