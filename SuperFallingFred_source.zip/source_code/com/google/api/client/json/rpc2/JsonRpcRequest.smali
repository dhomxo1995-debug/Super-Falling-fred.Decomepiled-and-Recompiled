.class public Lcom/google/api/client/json/rpc2/JsonRpcRequest;
.super Lcom/google/api/client/util/GenericData;

.field private id:Ljava/lang/Object;
.field private final jsonrpc:Ljava/lang/String;
.field private method:Ljava/lang/String;
.field private params:Ljava/lang/Object;

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Lcom/google/api/client/util/GenericData;-><init>()V
    const-string v0, "2.0"
    iput-object v0, v1, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->jsonrpc Ljava/lang/String;
    return-void
.end method

.method public getId()Ljava/lang/Object;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->id Ljava/lang/Object;
    return-object v0
.end method

.method public getMethod()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->method Ljava/lang/String;
    return-object v0
.end method

.method public getParameters()Ljava/lang/Object;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->params Ljava/lang/Object;
    return-object v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2
    const-string v0, "2.0"
    return-object v0
.end method

.method public setId(Ljava/lang/Object;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->id Ljava/lang/Object;
    return-void
.end method

.method public setMethod(Ljava/lang/String;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->method Ljava/lang/String;
    return-void
.end method

.method public setParameters(Ljava/lang/Object;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/json/rpc2/JsonRpcRequest;->params Ljava/lang/Object;
    return-void
.end method
