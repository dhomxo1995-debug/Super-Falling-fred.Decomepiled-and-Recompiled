package com.google.api.client.json;
public final enum class JsonToken extends java.lang.Enum {
    private static final synthetic com.google.api.client.json.JsonToken[] $VALUES;
    public static final enum com.google.api.client.json.JsonToken END_ARRAY;
    public static final enum com.google.api.client.json.JsonToken END_OBJECT;
    public static final enum com.google.api.client.json.JsonToken FIELD_NAME;
    public static final enum com.google.api.client.json.JsonToken NOT_AVAILABLE;
    public static final enum com.google.api.client.json.JsonToken START_ARRAY;
    public static final enum com.google.api.client.json.JsonToken START_OBJECT;
    public static final enum com.google.api.client.json.JsonToken VALUE_FALSE;
    public static final enum com.google.api.client.json.JsonToken VALUE_NULL;
    public static final enum com.google.api.client.json.JsonToken VALUE_NUMBER_FLOAT;
    public static final enum com.google.api.client.json.JsonToken VALUE_NUMBER_INT;
    public static final enum com.google.api.client.json.JsonToken VALUE_STRING;
    public static final enum com.google.api.client.json.JsonToken VALUE_TRUE;

    static JsonToken()
    {
        com.google.api.client.json.JsonToken.START_ARRAY = new com.google.api.client.json.JsonToken("START_ARRAY", 0);
        com.google.api.client.json.JsonToken.END_ARRAY = new com.google.api.client.json.JsonToken("END_ARRAY", 1);
        com.google.api.client.json.JsonToken.START_OBJECT = new com.google.api.client.json.JsonToken("START_OBJECT", 2);
        com.google.api.client.json.JsonToken.END_OBJECT = new com.google.api.client.json.JsonToken("END_OBJECT", 3);
        com.google.api.client.json.JsonToken.FIELD_NAME = new com.google.api.client.json.JsonToken("FIELD_NAME", 4);
        com.google.api.client.json.JsonToken.VALUE_STRING = new com.google.api.client.json.JsonToken("VALUE_STRING", 5);
        com.google.api.client.json.JsonToken.VALUE_NUMBER_INT = new com.google.api.client.json.JsonToken("VALUE_NUMBER_INT", 6);
        com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT = new com.google.api.client.json.JsonToken("VALUE_NUMBER_FLOAT", 7);
        com.google.api.client.json.JsonToken.VALUE_TRUE = new com.google.api.client.json.JsonToken("VALUE_TRUE", 8);
        com.google.api.client.json.JsonToken.VALUE_FALSE = new com.google.api.client.json.JsonToken("VALUE_FALSE", 9);
        com.google.api.client.json.JsonToken.VALUE_NULL = new com.google.api.client.json.JsonToken("VALUE_NULL", 10);
        com.google.api.client.json.JsonToken.NOT_AVAILABLE = new com.google.api.client.json.JsonToken("NOT_AVAILABLE", 11);
        com.google.api.client.json.JsonToken[] v0_23 = new com.google.api.client.json.JsonToken[12];
        v0_23[0] = com.google.api.client.json.JsonToken.START_ARRAY;
        v0_23[1] = com.google.api.client.json.JsonToken.END_ARRAY;
        v0_23[2] = com.google.api.client.json.JsonToken.START_OBJECT;
        v0_23[3] = com.google.api.client.json.JsonToken.END_OBJECT;
        v0_23[4] = com.google.api.client.json.JsonToken.FIELD_NAME;
        v0_23[5] = com.google.api.client.json.JsonToken.VALUE_STRING;
        v0_23[6] = com.google.api.client.json.JsonToken.VALUE_NUMBER_INT;
        v0_23[7] = com.google.api.client.json.JsonToken.VALUE_NUMBER_FLOAT;
        v0_23[8] = com.google.api.client.json.JsonToken.VALUE_TRUE;
        v0_23[9] = com.google.api.client.json.JsonToken.VALUE_FALSE;
        v0_23[10] = com.google.api.client.json.JsonToken.VALUE_NULL;
        v0_23[11] = com.google.api.client.json.JsonToken.NOT_AVAILABLE;
        com.google.api.client.json.JsonToken.$VALUES = v0_23;
        return;
    }

    private JsonToken(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.json.JsonToken valueOf(String p1)
    {
        return ((com.google.api.client.json.JsonToken) Enum.valueOf(com.google.api.client.json.JsonToken, p1));
    }

    public static com.google.api.client.json.JsonToken[] values()
    {
        return ((com.google.api.client.json.JsonToken[]) com.google.api.client.json.JsonToken.$VALUES.clone());
    }
}
