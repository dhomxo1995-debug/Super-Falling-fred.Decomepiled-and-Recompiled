package com.google.api.client.json;
public abstract class JsonParser {

    public JsonParser()
    {
        return;
    }

    private void parse(java.util.ArrayList p22, Object p23, com.google.api.client.json.CustomizeJsonParser p24)
    {
        if ((p23 instanceof com.google.api.client.json.GenericJson)) {
            ((com.google.api.client.json.GenericJson) p23).setFactory(this.getFactory());
        }
        com.google.api.client.json.JsonToken v13 = this.startParsingObjectOrArray();
        Class v14 = p23.getClass();
        com.google.api.client.util.ClassInfo v11 = com.google.api.client.util.ClassInfo.of(v14);
        boolean v18 = com.google.api.client.util.GenericData.isAssignableFrom(v14);
        if ((v18) || (!java.util.Map.isAssignableFrom(v14))) {
            while (v13 == com.google.api.client.json.JsonToken.FIELD_NAME) {
                String v19 = this.getText();
                this.nextToken();
                if ((p24 != null) && (p24.stopAt(p23, v19))) {
                    break;
                }
                com.google.api.client.util.FieldInfo v16 = v11.getFieldInfo(v19);
                if (v16 == null) {
                    if (!v18) {
                        if (p24 != null) {
                            p24.handleUnrecognizedKey(p23, v19);
                        }
                        this.skipChildren();
                    } else {
                        ((com.google.api.client.util.GenericData) p23).set(v19, this.parseValue(0, 0, p22, p23, p24));
                    }
                } else {
                    if ((!v16.isFinal()) || (v16.isPrimitive())) {
                        reflect.Field v4 = v16.getField();
                        int v12 = p22.size();
                        p22.add(v4.getGenericType());
                        Object v17 = this.parseValue(v4, v16.getGenericType(), p22, p23, p24);
                        p22.remove(v12);
                        v16.setValue(p23, v17);
                    } else {
                        throw new IllegalArgumentException("final array/object fields are not supported");
                    }
                }
                v13 = this.nextToken();
            }
        } else {
            this.parseMap(((java.util.Map) p23), com.google.api.client.util.Types.getMapValueParameter(v14), p22, p24);
        }
        return;
    }

    private void parseArray(java.util.Collection p9, reflect.Type p10, java.util.ArrayList p11, com.google.api.client.json.CustomizeJsonParser p12)
    {
        com.google.api.client.json.JsonToken v6 = this.startParsingObjectOrArray();
        while (v6 != com.google.api.client.json.JsonToken.END_ARRAY) {
            p9.add(this.parseValue(0, p10, p11, p9, p12));
            v6 = this.nextToken();
        }
        return;
    }

    private void parseMap(java.util.Map p10, reflect.Type p11, java.util.ArrayList p12, com.google.api.client.json.CustomizeJsonParser p13)
    {
        com.google.api.client.json.JsonToken v6 = this.startParsingObjectOrArray();
        while (v6 == com.google.api.client.json.JsonToken.FIELD_NAME) {
            String v7 = this.getText();
            this.nextToken();
            if ((p13 != null) && (p13.stopAt(p10, v7))) {
                break;
            }
            p10.put(v7, this.parseValue(0, p11, p12, p10, p13));
            v6 = this.nextToken();
        }
        return;
    }

    private final Object parseValue(reflect.Field p20, reflect.Type p21, java.util.ArrayList p22, Object p23, com.google.api.client.json.CustomizeJsonParser p24)
    {
        Class v13;
        reflect.Type v21_1 = com.google.api.client.util.Data.resolveWildcardTypeOrTypeVariable(p22, p21);
        if (!(v21_1 instanceof Class)) {
            v13 = 0;
        } else {
            v13 = ((Class) v21_1);
        }
        if ((v21_1 instanceof reflect.ParameterizedType)) {
            v13 = com.google.api.client.util.Types.getRawClass(((reflect.ParameterizedType) v21_1));
        }
        IllegalArgumentException v14_1;
        com.google.api.client.json.JsonToken v12 = this.getCurrentToken();
        switch (com.google.api.client.json.JsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken[v12.ordinal()]) {
            case 1:
            case 4:
            case 5:
                IllegalArgumentException v14_51;
                if (com.google.api.client.util.Types.isArray(v21_1)) {
                    v14_51 = 0;
                } else {
                    v14_51 = 1;
                }
                reflect.Field v0_20 = new Object[3];
                String v16_14 = v0_20;
                v16_14[0] = this.getCurrentName();
                v16_14[1] = v21_1;
                v16_14[2] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_51, "%s: expected object or map type but got %s for field %s", v16_14);
                Object v9_0 = 0;
                if ((v13 != null) && (p24 != null)) {
                    v9_0 = p24.newInstanceForObject(p23, v13);
                }
                if ((v13 == null) || (!com.google.api.client.util.Types.isAssignableToOrFrom(v13, java.util.Map))) {
                    int v8 = 0;
                } else {
                    v8 = 1;
                }
                if (v9_0 != null) {
                    v14_1 = v9_0;
                } else {
                    if ((v8 == 0) && (v13 != null)) {
                        v14_1 = com.google.api.client.util.Types.newInstance(v13);
                    } else {
                        v14_1 = com.google.api.client.util.Data.newMapInstance(v13);
                    }
                }
                int v4 = p22.size();
                if (v21_1 != null) {
                    p22.add(v21_1);
                }
                if ((v8 != 0) && (!com.google.api.client.util.GenericData.isAssignableFrom(v13))) {
                    int v11;
                    if (!java.util.Map.isAssignableFrom(v13)) {
                        v11 = 0;
                    } else {
                        v11 = com.google.api.client.util.Types.getMapValueParameter(v21_1);
                    }
                    if (v11 != 0) {
                        this.parseMap(((java.util.Map) v14_1), v11, p22, p24);
                    }
                }
                this.parse(p22, v14_1, p24);
                if (v21_1 == null) {
                } else {
                    p22.remove(v4);
                }
                break;
            case 2:
            case 3:
                IllegalArgumentException v14_45;
                boolean v7 = com.google.api.client.util.Types.isArray(v21_1);
                if ((v21_1 != null) && ((!v7) && ((v13 == null) || (!com.google.api.client.util.Types.isAssignableToOrFrom(v13, java.util.Collection))))) {
                    v14_45 = 0;
                } else {
                    v14_45 = 1;
                }
                reflect.Field v0_13 = new Object[3];
                String v16_11 = v0_13;
                v16_11[0] = this.getCurrentName();
                v16_11[1] = v21_1;
                v16_11[2] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_45, "%s: expected collection or array type but got %s for field %s", v16_11);
                java.util.Collection v3 = 0;
                if ((p24 != null) && (p20 != null)) {
                    v3 = p24.newInstanceForArray(p23, p20);
                }
                if (v3 == null) {
                    v3 = com.google.api.client.util.Data.newCollectionInstance(v21_1);
                }
                reflect.Type v10_0 = 0;
                if (!v7) {
                    if ((v13 != null) && (Iterable.isAssignableFrom(v13))) {
                        v10_0 = com.google.api.client.util.Types.getIterableParameter(v21_1);
                    }
                } else {
                    v10_0 = com.google.api.client.util.Types.getArrayComponentType(v21_1);
                }
                reflect.Type v10_1 = com.google.api.client.util.Data.resolveWildcardTypeOrTypeVariable(p22, v10_0);
                this.parseArray(v3, v10_1, p22, p24);
                if (!v7) {
                    v14_1 = v3;
                } else {
                    v14_1 = com.google.api.client.util.Types.toArray(v3, com.google.api.client.util.Types.getRawArrayComponentType(p22, v10_1));
                }
                break;
            case 6:
            case 7:
                if ((v21_1 != null) && ((v13 != Boolean.TYPE) && ((v13 == null) || (!v13.isAssignableFrom(Boolean))))) {
                    IllegalArgumentException v14_40 = 0;
                } else {
                    v14_40 = 1;
                }
                String v15_20 = new StringBuilder().append("%s: expected type Boolean or boolean but got %s for field %s").append(p20).toString();
                reflect.Field v0_11 = new Object[3];
                String v16_9 = v0_11;
                v16_9[0] = this.getCurrentName();
                v16_9[1] = v21_1;
                v16_9[2] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_40, v15_20, v16_9);
                if (v12 != com.google.api.client.json.JsonToken.VALUE_TRUE) {
                    v14_1 = Boolean.FALSE;
                } else {
                    v14_1 = Boolean.TRUE;
                }
                break;
            case 8:
            case 9:
                if ((p20 != null) && (p20.getAnnotation(com.google.api.client.json.JsonString) != null)) {
                    IllegalArgumentException v14_7 = 0;
                } else {
                    v14_7 = 1;
                }
                reflect.Field v0_6 = new Object[2];
                String v16_3 = v0_6;
                v16_3[0] = this.getCurrentName();
                v16_3[1] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_7, "%s: number type formatted as a JSON number cannot use @JsonString annotation on the field %s", v16_3);
                if ((v13 != null) && (!v13.isAssignableFrom(java.math.BigDecimal))) {
                    if (v13 != java.math.BigInteger) {
                        if (v13 != com.google.common.primitives.UnsignedInteger) {
                            if (v13 != com.google.common.primitives.UnsignedLong) {
                                if ((v13 != Double) && (v13 != Double.TYPE)) {
                                    if ((v13 != Long) && (v13 != Long.TYPE)) {
                                        if ((v13 != Float) && (v13 != Float.TYPE)) {
                                            if ((v13 != Integer) && (v13 != Integer.TYPE)) {
                                                if ((v13 != Short) && (v13 != Short.TYPE)) {
                                                    if ((v13 != Byte) && (v13 != Byte.TYPE)) {
                                                        throw new IllegalArgumentException(new StringBuilder().append(this.getCurrentName()).append(": expected numeric type but got ").append(v21_1).append(" for field ").append(p20).toString());
                                                    } else {
                                                        v14_1 = Byte.valueOf(this.getByteValue());
                                                    }
                                                } else {
                                                    v14_1 = Short.valueOf(this.getShortValue());
                                                }
                                            } else {
                                                v14_1 = Integer.valueOf(this.getIntValue());
                                            }
                                        } else {
                                            v14_1 = Float.valueOf(this.getFloatValue());
                                        }
                                    } else {
                                        v14_1 = Long.valueOf(this.getLongValue());
                                    }
                                } else {
                                    v14_1 = Double.valueOf(this.getDoubleValue());
                                }
                            } else {
                                v14_1 = this.getUnsignedLongValue();
                            }
                        } else {
                            v14_1 = this.getUnsignedIntegerValue();
                        }
                    } else {
                        v14_1 = this.getBigIntegerValue();
                    }
                } else {
                    v14_1 = this.getDecimalValue();
                }
                break;
            case 10:
                if ((v13 != null) && ((Number.isAssignableFrom(v13)) && ((p20 == null) || (p20.getAnnotation(com.google.api.client.json.JsonString) == null)))) {
                    IllegalArgumentException v14_73 = 0;
                } else {
                    v14_73 = 1;
                }
                reflect.Field v0_31 = new Object[2];
                String v16_19 = v0_31;
                v16_19[0] = this.getCurrentName();
                v16_19[1] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_73, "%s: number field formatted as a JSON string must use the @JsonString annotation: %s", v16_19);
                try {
                    v14_1 = com.google.api.client.util.Data.parsePrimitiveValue(v21_1, this.getText());
                } catch (IllegalArgumentException v6) {
                    throw new IllegalArgumentException(new StringBuilder().append(this.getCurrentName()).append(" for field ").append(p20).toString(), v6);
                }
                break;
            case 11:
                if ((v13 != null) && (v13.isPrimitive())) {
                    IllegalArgumentException v14_46 = 0;
                } else {
                    v14_46 = 1;
                }
                reflect.Field v0_21 = new Object[2];
                String v16_15 = v0_21;
                v16_15[0] = this.getCurrentName();
                v16_15[1] = p20;
                com.google.common.base.Preconditions.checkArgument(v14_46, "%s: primitive number field but found a JSON null: %s", v16_15);
                if ((v13 != null) && ((v13.getModifiers() & 1536) != 0)) {
                    if (!com.google.api.client.util.Types.isAssignableToOrFrom(v13, java.util.Collection)) {
                        if (com.google.api.client.util.Types.isAssignableToOrFrom(v13, java.util.Map)) {
                            v14_1 = com.google.api.client.util.Data.nullOf(com.google.api.client.util.Data.newMapInstance(v13).getClass());
                        }
                    } else {
                        v14_1 = com.google.api.client.util.Data.nullOf(com.google.api.client.util.Data.newCollectionInstance(v21_1).getClass());
                    }
                }
                v14_1 = com.google.api.client.util.Data.nullOf(com.google.api.client.util.Types.getRawArrayComponentType(p22, v21_1));
                break;
            default:
                throw new IllegalArgumentException(new StringBuilder().append(this.getCurrentName()).append(": unexpected JSON node type: ").append(v12).toString());
        }
        return v14_1;
    }

    private com.google.api.client.json.JsonToken startParsing()
    {
        com.google.api.client.json.JsonToken v0 = this.getCurrentToken();
        if (v0 == null) {
            v0 = this.nextToken();
        }
        int v1;
        if (v0 == null) {
            v1 = 0;
        } else {
            v1 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v1, "no JSON input found");
        return v0;
    }

    private com.google.api.client.json.JsonToken startParsingObjectOrArray()
    {
        com.google.api.client.json.JsonToken v0 = this.startParsing();
        switch (com.google.api.client.json.JsonParser$1.$SwitchMap$com$google$api$client$json$JsonToken[v0.ordinal()]) {
            case 1:
                int v1_2;
                v0 = this.nextToken();
                if ((v0 != com.google.api.client.json.JsonToken.FIELD_NAME) && (v0 != com.google.api.client.json.JsonToken.END_OBJECT)) {
                    v1_2 = 0;
                } else {
                    v1_2 = 1;
                }
                com.google.common.base.Preconditions.checkArgument(v1_2, v0);
                break;
            case 2:
                v0 = this.nextToken();
                break;
        }
        return v0;
    }

    public abstract void close();

    public abstract java.math.BigInteger getBigIntegerValue();

    public abstract byte getByteValue();

    public abstract String getCurrentName();

    public abstract com.google.api.client.json.JsonToken getCurrentToken();

    public abstract java.math.BigDecimal getDecimalValue();

    public abstract double getDoubleValue();

    public abstract com.google.api.client.json.JsonFactory getFactory();

    public abstract float getFloatValue();

    public abstract int getIntValue();

    public abstract long getLongValue();

    public abstract short getShortValue();

    public abstract String getText();

    public abstract com.google.common.primitives.UnsignedInteger getUnsignedIntegerValue();

    public abstract com.google.common.primitives.UnsignedLong getUnsignedLongValue();

    public abstract com.google.api.client.json.JsonToken nextToken();

    public final Object parse(Class p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        this.startParsing();
        return this.parse(p3, 0, p4);
    }

    public Object parse(reflect.Type p7, boolean p8, com.google.api.client.json.CustomizeJsonParser p9)
    {
        try {
            this.startParsing();
            Throwable v0_2 = this.parseValue(0, p7, new java.util.ArrayList(), 0, p9);
        } catch (Throwable v0_0) {
            if (p8) {
                this.close();
            }
            throw v0_0;
        }
        if (p8) {
            this.close();
        }
        return v0_2;
    }

    public final void parse(Object p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add(p3.getClass());
        this.parse(v0_1, p3, p4);
        return;
    }

    public final Object parseAndClose(Class p2, com.google.api.client.json.CustomizeJsonParser p3)
    {
        try {
            Throwable v0_0 = this.parse(p2, p3);
            this.close();
            return v0_0;
        } catch (Throwable v0_1) {
            this.close();
            throw v0_1;
        }
    }

    public final void parseAndClose(Object p2, com.google.api.client.json.CustomizeJsonParser p3)
    {
        try {
            this.parse(p2, p3);
            this.close();
            return;
        } catch (Throwable v0) {
            this.close();
            throw v0;
        }
    }

    public final java.util.Collection parseArray(Class p2, Class p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        java.util.Collection v0 = com.google.api.client.util.Data.newCollectionInstance(p2);
        this.parseArray(v0, p3, p4);
        return v0;
    }

    public final void parseArray(java.util.Collection p2, Class p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        this.parseArray(p2, p3, new java.util.ArrayList(), p4);
        return;
    }

    public final java.util.Collection parseArrayAndClose(Class p2, Class p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        try {
            Throwable v0_0 = this.parseArray(p2, p3, p4);
            this.close();
            return v0_0;
        } catch (Throwable v0_1) {
            this.close();
            throw v0_1;
        }
    }

    public final void parseArrayAndClose(java.util.Collection p2, Class p3, com.google.api.client.json.CustomizeJsonParser p4)
    {
        try {
            this.parseArray(p2, p3, p4);
            this.close();
            return;
        } catch (Throwable v0) {
            this.close();
            throw v0;
        }
    }

    public abstract com.google.api.client.json.JsonParser skipChildren();

    public final String skipToKey(java.util.Set p4)
    {
        com.google.api.client.json.JsonToken v0 = this.startParsingObjectOrArray();
        while (v0 == com.google.api.client.json.JsonToken.FIELD_NAME) {
            int v1 = this.getText();
            this.nextToken();
            if (!p4.contains(v1)) {
                this.skipChildren();
                v0 = this.nextToken();
            }
            return v1;
        }
        v1 = 0;
        return v1;
    }

    public final void skipToKey(String p2)
    {
        this.skipToKey(java.util.Collections.singleton(p2));
        return;
    }
}
