package com.google.api.client.json;
public class Json {
    public static final String CONTENT_TYPE = "application/json";
    public static final String MEDIA_TYPE;

    static Json()
    {
        com.google.api.client.json.Json.MEDIA_TYPE = new com.google.api.client.http.HttpMediaType("application/json").setCharsetParameter(com.google.common.base.Charsets.UTF_8).build();
        return;
    }

    public Json()
    {
        return;
    }
}
