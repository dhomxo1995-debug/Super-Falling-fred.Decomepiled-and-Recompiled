.class public Lcom/google/api/client/json/CustomizeJsonParser;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public handleUnrecognizedKey(Ljava/lang/Object; Ljava/lang/String;)V
    .registers 3
    return-void
.end method

.method public newInstanceForArray(Ljava/lang/Object; Ljava/lang/reflect/Field;)Ljava/util/Collection;
    .registers 4
    const/4 v0, 0
    return-object v0
.end method

.method public newInstanceForObject(Ljava/lang/Object; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 4
    const/4 v0, 0
    return-object v0
.end method

.method public stopAt(Ljava/lang/Object; Ljava/lang/String;)Z
    .registers 4
    const/4 v0, 0
    return v0
.end method
