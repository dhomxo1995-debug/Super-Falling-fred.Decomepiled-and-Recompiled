.class public interface abstract Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;
.super Ljava/lang/Object;


.method public abstract onTokenErrorResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenErrorResponse;)V
    # abstract or native method
.end method

.method public abstract onTokenResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenResponse;)V
    # abstract or native method
.end method
