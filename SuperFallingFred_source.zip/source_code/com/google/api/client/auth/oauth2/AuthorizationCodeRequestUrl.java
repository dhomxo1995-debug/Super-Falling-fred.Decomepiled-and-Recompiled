package com.google.api.client.auth.oauth2;
public class AuthorizationCodeRequestUrl extends com.google.api.client.auth.oauth2.AuthorizationRequestUrl {

    public AuthorizationCodeRequestUrl(String p2, String p3)
    {
        super(p2, p3, java.util.Collections.singleton("code"));
        return;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setClientId(String p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setClientId(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setClientId(String p2)
    {
        return this.setClientId(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setRedirectUri(String p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setRedirectUri(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setRedirectUri(String p2)
    {
        return this.setRedirectUri(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setResponseTypes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setResponseTypes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setResponseTypes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setResponseTypes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(Iterable p2)
    {
        return this.setResponseTypes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(String[] p2)
    {
        return this.setResponseTypes(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setScopes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setScopes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setScopes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setScopes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(Iterable p2)
    {
        return this.setScopes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(String[] p2)
    {
        return this.setScopes(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl setState(String p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl) super.setState(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setState(String p2)
    {
        return this.setState(p2);
    }
}
