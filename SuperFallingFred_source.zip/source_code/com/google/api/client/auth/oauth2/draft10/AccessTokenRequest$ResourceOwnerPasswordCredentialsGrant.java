package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenRequest$ResourceOwnerPasswordCredentialsGrant extends com.google.api.client.auth.oauth2.draft10.AccessTokenRequest {
    public String password;
    public String username;

    public AccessTokenRequest$ResourceOwnerPasswordCredentialsGrant()
    {
        this.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.PASSWORD;
        return;
    }

    public AccessTokenRequest$ResourceOwnerPasswordCredentialsGrant(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5, String p6, String p7, String p8)
    {
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$ResourceOwnerPasswordCredentialsGrant v1_1 = super(p2, p3, p4, p5, p6);
        v1_1.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.PASSWORD;
        v1_1.username = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        v1_1.password = ((String) com.google.common.base.Preconditions.checkNotNull(p8));
        return;
    }
}
