package com.google.api.client.auth.oauth2.draft10;
public final enum class AuthorizationResponse$KnownError extends java.lang.Enum {
    private static final synthetic com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError[] $VALUES;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError ACCESS_DENIED;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError INVALID_CLIENT;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError INVALID_REQUEST;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError INVALID_SCOPE;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError REDIRECT_URI_MISMATCH;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError UNAUTHORIZED_CLIENT;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError UNSUPPORTED_RESPONSE_TYPE;

    static AuthorizationResponse$KnownError()
    {
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_REQUEST = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("INVALID_REQUEST", 0);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_CLIENT = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("INVALID_CLIENT", 1);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.UNAUTHORIZED_CLIENT = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("UNAUTHORIZED_CLIENT", 2);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.REDIRECT_URI_MISMATCH = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("REDIRECT_URI_MISMATCH", 3);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.ACCESS_DENIED = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("ACCESS_DENIED", 4);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.UNSUPPORTED_RESPONSE_TYPE = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("UNSUPPORTED_RESPONSE_TYPE", 5);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_SCOPE = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError("INVALID_SCOPE", 6);
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError[] v0_12 = new com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError[7];
        v0_12[0] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_REQUEST;
        v0_12[1] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_CLIENT;
        v0_12[2] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.UNAUTHORIZED_CLIENT;
        v0_12[3] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.REDIRECT_URI_MISMATCH;
        v0_12[4] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.ACCESS_DENIED;
        v0_12[5] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.UNSUPPORTED_RESPONSE_TYPE;
        v0_12[6] = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.INVALID_SCOPE;
        com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.$VALUES = v0_12;
        return;
    }

    private AuthorizationResponse$KnownError(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError valueOf(String p1)
    {
        return ((com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError) Enum.valueOf(com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError, p1));
    }

    public static com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError[] values()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError[]) com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.$VALUES.clone());
    }
}
