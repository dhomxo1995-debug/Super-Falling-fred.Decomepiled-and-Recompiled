.class public Lcom/google/api/client/auth/oauth2/TokenRequest;
.super Lcom/google/api/client/util/GenericData;

.field  clientAuthentication:Lcom/google/api/client/http/HttpExecuteInterceptor;
.field private grantType:Ljava/lang/String;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field  requestInitializer:Lcom/google/api/client/http/HttpRequestInitializer;
.field private scopes:Ljava/lang/String;
.field private tokenServerUrl:Lcom/google/api/client/http/GenericUrl;
.field private final transport:Lcom/google/api/client/http/HttpTransport;

.method public constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Ljava/lang/String;)V
    .registers 6
    invoke-direct v1, Lcom/google/api/client/util/GenericData;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/HttpTransport;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v1, v4, Lcom/google/api/client/auth/oauth2/TokenRequest;->setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    invoke-virtual v1, v5, Lcom/google/api/client/auth/oauth2/TokenRequest;->setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    return-void
.end method

.method public execute()Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->executeUnparsed()Lcom/google/api/client/http/HttpResponse;
    move-result-object v0
    const-class v1, Lcom/google/api/client/auth/oauth2/TokenResponse;
    invoke-virtual v0, v1, Lcom/google/api/client/http/HttpResponse;->parseAs(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/TokenResponse;
    return-object v0
.end method

.method public final executeUnparsed()Lcom/google/api/client/http/HttpResponse;
    .registers 6
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/TokenRequest;->transport Lcom/google/api/client/http/HttpTransport;
    new-instance v4, Lcom/google/api/client/auth/oauth2/TokenRequest$1;
    invoke-direct v4, v5, Lcom/google/api/client/auth/oauth2/TokenRequest$1;-><init>(Lcom/google/api/client/auth/oauth2/TokenRequest;)V
    invoke-virtual v3, v4, Lcom/google/api/client/http/HttpTransport;->createRequestFactory(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/http/HttpRequestFactory;
    move-result-object v1
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/TokenRequest;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    new-instance v4, Lcom/google/api/client/http/UrlEncodedContent;
    invoke-direct v4, v5, Lcom/google/api/client/http/UrlEncodedContent;-><init>(Ljava/lang/Object;)V
    invoke-virtual v1, v3, v4, Lcom/google/api/client/http/HttpRequestFactory;->buildPostRequest(Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpContent;)Lcom/google/api/client/http/HttpRequest;
    move-result-object v0
    new-instance v3, Lcom/google/api/client/json/JsonObjectParser;
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/TokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-direct v3, v4, Lcom/google/api/client/json/JsonObjectParser;-><init>(Lcom/google/api/client/json/JsonFactory;)V
    invoke-virtual v0, v3, Lcom/google/api/client/http/HttpRequest;->setParser(Lcom/google/api/client/util/ObjectParser;)V
    const/4 v3, 0
    invoke-virtual v0, v3, Lcom/google/api/client/http/HttpRequest;->setThrowExceptionOnExecuteError(Z)Lcom/google/api/client/http/HttpRequest;
    invoke-virtual v0, Lcom/google/api/client/http/HttpRequest;->execute()Lcom/google/api/client/http/HttpResponse;
    move-result-object v2
    invoke-virtual v2, Lcom/google/api/client/http/HttpResponse;->isSuccessStatusCode()Z
    move-result v3
    if-eqz v3, +003h
    return-object v2
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/TokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-static v3, v2, Lcom/google/api/client/auth/oauth2/TokenResponseException;->from(Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/HttpResponse;)Lcom/google/api/client/auth/oauth2/TokenResponseException;
    move-result-object v3
    throw v3
.end method

.method public final getClientAuthentication()Lcom/google/api/client/http/HttpExecuteInterceptor;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public final getGrantType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->grantType Ljava/lang/String;
    return-object v0
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getRequestInitializer()Lcom/google/api/client/http/HttpRequestInitializer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public final getScopes()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->scopes Ljava/lang/String;
    return-object v0
.end method

.method public final getTokenServerUrl()Lcom/google/api/client/http/GenericUrl;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    return-object v0
.end method

.method public final getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->grantType Ljava/lang/String;
    return-object v1
.end method

.method public setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    if-nez v2, +006h
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->scopes Ljava/lang/String;
    return-object v1
    const/16 v0, 32
    invoke-static v0, Lcom/google/common/base/Joiner;->on(C)Lcom/google/common/base/Joiner;
    move-result-object v0
    invoke-virtual v0, v2, Lcom/google/common/base/Joiner;->join(Ljava/lang/Iterable;)Ljava/lang/String;
    move-result-object v0
    goto -dh
.end method

.method public varargs setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    if-nez v2, +008h
    const/4 v0, 0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;->setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    return-object v0
    invoke-static v2, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    goto -9h
.end method

.method public setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    iput-object v2, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    invoke-virtual v2, Lcom/google/api/client/http/GenericUrl;->getFragment()Ljava/lang/String;
    move-result-object v0
    if-nez v0, +007h
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    return-object v1
    const/4 v0, 0
    goto -5h
.end method
