.class public final Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;

.field private final credentialStore:Lcom/google/api/client/auth/oauth2/CredentialStore;
.field private final userId:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore;)V
    .registers 4
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->userId Ljava/lang/String;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/CredentialStore;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    return-void
.end method

.method public getCredentialStore()Lcom/google/api/client/auth/oauth2/CredentialStore;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    return-object v0
.end method

.method public makePersistent(Lcom/google/api/client/auth/oauth2/Credential;)V
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->userId Ljava/lang/String;
    invoke-interface v0, v1, v3, Lcom/google/api/client/auth/oauth2/CredentialStore;->store(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    return-void
.end method

.method public onTokenErrorResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenErrorResponse;)V
    .registers 3
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->makePersistent(Lcom/google/api/client/auth/oauth2/Credential;)V
    return-void
.end method

.method public onTokenResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenResponse;)V
    .registers 3
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;->makePersistent(Lcom/google/api/client/auth/oauth2/Credential;)V
    return-void
.end method
