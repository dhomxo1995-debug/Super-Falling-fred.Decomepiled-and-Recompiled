package com.google.api.client.auth.oauth2;
public interface CredentialStore {

    public abstract void delete(String p0, com.google.api.client.auth.oauth2.Credential p1);

    public abstract boolean load(String p0, com.google.api.client.auth.oauth2.Credential p1);

    public abstract void store(String p0, com.google.api.client.auth.oauth2.Credential p1);
}
