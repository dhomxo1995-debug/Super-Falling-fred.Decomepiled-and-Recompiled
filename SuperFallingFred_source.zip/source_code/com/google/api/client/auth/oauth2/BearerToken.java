package com.google.api.client.auth.oauth2;
public class BearerToken {
    static final String PARAM_NAME = "access_token";

    public BearerToken()
    {
        return;
    }

    public static com.google.api.client.auth.oauth2.Credential$AccessMethod authorizationHeaderAccessMethod()
    {
        return new com.google.api.client.auth.oauth2.BearerToken$AuthorizationHeaderAccessMethod();
    }

    public static com.google.api.client.auth.oauth2.Credential$AccessMethod formEncodedBodyAccessMethod()
    {
        return new com.google.api.client.auth.oauth2.BearerToken$FormEncodedBodyAccessMethod();
    }

    public static com.google.api.client.auth.oauth2.Credential$AccessMethod queryParameterAccessMethod()
    {
        return new com.google.api.client.auth.oauth2.BearerToken$QueryParameterAccessMethod();
    }
}
