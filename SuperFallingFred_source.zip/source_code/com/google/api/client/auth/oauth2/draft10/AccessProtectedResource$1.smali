.class synthetic Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;
.super Ljava/lang/Object;

.field static final synthetic $SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method:[I

.method static constructor <clinit>()V
    .registers 3
    invoke-static Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->values()[Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    move-result-object v0
    array-length v0, v0
    new-array v0, v0, [I
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->AUTHORIZATION_HEADER Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-virtual v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->ordinal()I
    move-result v1
    const/4 v2, 1
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->QUERY_PARAMETER Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-virtual v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->ordinal()I
    move-result v1
    const/4 v2, 2
    aput v2, v0, v1
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->FORM_ENCODED_BODY Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-virtual v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->ordinal()I
    move-result v1
    const/4 v2, 3
    aput v2, v0, v1
    return-void
    move-exception v0
    goto -2h
    move-exception v0
    goto -fh
    move-exception v0
    goto -1ch
.end method
