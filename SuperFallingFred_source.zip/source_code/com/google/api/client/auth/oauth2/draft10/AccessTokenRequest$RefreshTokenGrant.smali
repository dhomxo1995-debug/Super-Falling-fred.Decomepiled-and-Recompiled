.class public Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;
.super Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;

.field public refreshToken:Ljava/lang/String;

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;-><init>()V
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;->REFRESH_TOKEN Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;->grantType Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    return-void
.end method

.method public constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 8
    invoke-direct/range v1 ... v6, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;->REFRESH_TOKEN Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;->grantType Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    invoke-static v7, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;->refreshToken Ljava/lang/String;
    return-void
.end method
