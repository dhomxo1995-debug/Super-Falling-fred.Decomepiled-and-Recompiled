package com.google.api.client.auth.oauth2;
public class MemoryCredentialStore implements com.google.api.client.auth.oauth2.CredentialStore {
    private final java.util.concurrent.locks.Lock lock;
    private final java.util.Map store;

    public MemoryCredentialStore()
    {
        this.lock = new java.util.concurrent.locks.ReentrantLock();
        this.store = new java.util.HashMap();
        return;
    }

    public void delete(String p3, com.google.api.client.auth.oauth2.Credential p4)
    {
        this.lock.lock();
        try {
            this.store.remove(p3);
            this.lock.unlock();
            return;
        } catch (Throwable v0_3) {
            this.lock.unlock();
            throw v0_3;
        }
    }

    public boolean load(String p4, com.google.api.client.auth.oauth2.Credential p5)
    {
        this.lock.lock();
        try {
            com.google.api.client.auth.oauth2.MemoryPersistedCredential v0_1 = ((com.google.api.client.auth.oauth2.MemoryPersistedCredential) this.store.get(p4));
        } catch (int v1_3) {
            this.lock.unlock();
            throw v1_3;
        }
        if (v0_1 != null) {
            v0_1.load(p5);
        }
        int v1_1;
        if (v0_1 == null) {
            v1_1 = 0;
        } else {
            v1_1 = 1;
        }
        this.lock.unlock();
        return v1_1;
    }

    public void store(String p4, com.google.api.client.auth.oauth2.Credential p5)
    {
        this.lock.lock();
        try {
            com.google.api.client.auth.oauth2.MemoryPersistedCredential v0_1 = ((com.google.api.client.auth.oauth2.MemoryPersistedCredential) this.store.get(p4));
        } catch (java.util.concurrent.locks.Lock v1_1) {
            this.lock.unlock();
            throw v1_1;
        }
        if (v0_1 == null) {
            v0_1 = new com.google.api.client.auth.oauth2.MemoryPersistedCredential();
            this.store.put(p4, v0_1);
        }
        v0_1.store(p5);
        this.lock.unlock();
        return;
    }
}
