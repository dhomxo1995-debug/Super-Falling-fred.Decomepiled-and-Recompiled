package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenRequest$AssertionGrant extends com.google.api.client.auth.oauth2.draft10.AccessTokenRequest {
    public String assertion;
    public String assertionType;

    public AccessTokenRequest$AssertionGrant()
    {
        this.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.ASSERTION;
        return;
    }

    public AccessTokenRequest$AssertionGrant(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5, String p6)
    {
        super(p2, p3, p4);
        super.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.ASSERTION;
        super.assertionType = ((String) com.google.common.base.Preconditions.checkNotNull(p5));
        super.assertion = ((String) com.google.common.base.Preconditions.checkNotNull(p6));
        return;
    }
}
