package com.google.api.client.auth.oauth2;
public class ClientParametersAuthentication implements com.google.api.client.http.HttpRequestInitializer, com.google.api.client.http.HttpExecuteInterceptor {
    private final String clientId;
    private final String clientSecret;

    public ClientParametersAuthentication(String p2, String p3)
    {
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        this.clientSecret = ((String) com.google.common.base.Preconditions.checkNotNull(p3));
        return;
    }

    public final String getClientId()
    {
        return this.clientId;
    }

    public final String getClientSecret()
    {
        return this.clientSecret;
    }

    public void initialize(com.google.api.client.http.HttpRequest p1)
    {
        p1.setInterceptor(this);
        return;
    }

    public void intercept(com.google.api.client.http.HttpRequest p4)
    {
        java.util.Map v0 = com.google.api.client.util.Data.mapOf(com.google.api.client.http.UrlEncodedContent.getContent(p4).getData());
        v0.put("client_id", this.clientId);
        v0.put("client_secret", this.clientSecret);
        return;
    }
}
