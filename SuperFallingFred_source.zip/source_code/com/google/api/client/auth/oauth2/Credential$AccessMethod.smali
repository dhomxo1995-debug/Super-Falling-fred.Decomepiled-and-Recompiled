.class public interface abstract Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
.super Ljava/lang/Object;


.method public abstract getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    # abstract or native method
.end method

.method public abstract intercept(Lcom/google/api/client/http/HttpRequest; Ljava/lang/String;)V
    # abstract or native method
.end method
