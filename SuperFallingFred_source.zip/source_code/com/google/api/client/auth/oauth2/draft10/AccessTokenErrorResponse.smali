.class public Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse;
.super Lcom/google/api/client/util/GenericData;

.field public error:Ljava/lang/String;
.field public errorDescription:Ljava/lang/String;
.field public errorUri:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/util/GenericData;-><init>()V
    return-void
.end method

.method public final getErrorCodeIfKnown()Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse;->error Ljava/lang/String;
    if-eqz v0, +00eh
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse;->error Ljava/lang/String;
    invoke-virtual v0, Ljava/lang/String;->toUpperCase()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->valueOf(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    move-result-object v0
    return-object v0
    move-exception v0
    const/4 v0, 0
    goto -3h
.end method
