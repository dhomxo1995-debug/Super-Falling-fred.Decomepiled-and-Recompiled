package com.google.api.client.auth.oauth2;
public class TokenRequest extends com.google.api.client.util.GenericData {
    com.google.api.client.http.HttpExecuteInterceptor clientAuthentication;
    private String grantType;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    com.google.api.client.http.HttpRequestInitializer requestInitializer;
    private String scopes;
    private com.google.api.client.http.GenericUrl tokenServerUrl;
    private final com.google.api.client.http.HttpTransport transport;

    public TokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, com.google.api.client.http.GenericUrl p4, String p5)
    {
        this.transport = ((com.google.api.client.http.HttpTransport) com.google.common.base.Preconditions.checkNotNull(p2));
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p3));
        this.setTokenServerUrl(p4);
        this.setGrantType(p5);
        return;
    }

    public com.google.api.client.auth.oauth2.TokenResponse execute()
    {
        return ((com.google.api.client.auth.oauth2.TokenResponse) this.executeUnparsed().parseAs(com.google.api.client.auth.oauth2.TokenResponse));
    }

    public final com.google.api.client.http.HttpResponse executeUnparsed()
    {
        com.google.api.client.http.HttpRequest v0 = this.transport.createRequestFactory(new com.google.api.client.auth.oauth2.TokenRequest$1(this)).buildPostRequest(this.tokenServerUrl, new com.google.api.client.http.UrlEncodedContent(this));
        v0.setParser(new com.google.api.client.json.JsonObjectParser(this.jsonFactory));
        v0.setThrowExceptionOnExecuteError(0);
        com.google.api.client.http.HttpResponse v2 = v0.execute();
        if (!v2.isSuccessStatusCode()) {
            throw com.google.api.client.auth.oauth2.TokenResponseException.from(this.jsonFactory, v2);
        } else {
            return v2;
        }
    }

    public final com.google.api.client.http.HttpExecuteInterceptor getClientAuthentication()
    {
        return this.clientAuthentication;
    }

    public final String getGrantType()
    {
        return this.grantType;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.http.HttpRequestInitializer getRequestInitializer()
    {
        return this.requestInitializer;
    }

    public final String getScopes()
    {
        return this.scopes;
    }

    public final com.google.api.client.http.GenericUrl getTokenServerUrl()
    {
        return this.tokenServerUrl;
    }

    public final com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public com.google.api.client.auth.oauth2.TokenRequest setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p1)
    {
        this.clientAuthentication = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenRequest setGrantType(String p2)
    {
        this.grantType = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenRequest setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p1)
    {
        this.requestInitializer = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenRequest setScopes(Iterable p2)
    {
        String v0_2;
        if (p2 != null) {
            v0_2 = com.google.common.base.Joiner.on(32).join(p2);
        } else {
            v0_2 = 0;
        }
        this.scopes = v0_2;
        return this;
    }

    public varargs com.google.api.client.auth.oauth2.TokenRequest setScopes(String[] p2)
    {
        com.google.api.client.auth.oauth2.TokenRequest v0_0;
        if (p2 != null) {
            v0_0 = java.util.Arrays.asList(p2);
        } else {
            v0_0 = 0;
        }
        return this.setScopes(v0_0);
    }

    public com.google.api.client.auth.oauth2.TokenRequest setTokenServerUrl(com.google.api.client.http.GenericUrl p2)
    {
        int v0_1;
        this.tokenServerUrl = p2;
        if (p2.getFragment() != null) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_1);
        return this;
    }
}
