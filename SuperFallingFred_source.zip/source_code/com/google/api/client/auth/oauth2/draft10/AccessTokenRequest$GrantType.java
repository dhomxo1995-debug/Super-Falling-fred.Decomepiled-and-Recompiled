package com.google.api.client.auth.oauth2.draft10;
public final enum class AccessTokenRequest$GrantType extends java.lang.Enum {
    private static final synthetic com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType[] $VALUES;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType ASSERTION;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType AUTHORIZATION_CODE;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType NONE;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType PASSWORD;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType REFRESH_TOKEN;

    static AccessTokenRequest$GrantType()
    {
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.AUTHORIZATION_CODE = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType("AUTHORIZATION_CODE", 0);
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.PASSWORD = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType("PASSWORD", 1);
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.ASSERTION = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType("ASSERTION", 2);
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.REFRESH_TOKEN = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType("REFRESH_TOKEN", 3);
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.NONE = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType("NONE", 4);
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType[] v0_8 = new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType[5];
        v0_8[0] = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.AUTHORIZATION_CODE;
        v0_8[1] = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.PASSWORD;
        v0_8[2] = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.ASSERTION;
        v0_8[3] = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.REFRESH_TOKEN;
        v0_8[4] = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.NONE;
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.$VALUES = v0_8;
        return;
    }

    private AccessTokenRequest$GrantType(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType valueOf(String p1)
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType) Enum.valueOf(com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType, p1));
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType[] values()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType[]) com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.$VALUES.clone());
    }
}
