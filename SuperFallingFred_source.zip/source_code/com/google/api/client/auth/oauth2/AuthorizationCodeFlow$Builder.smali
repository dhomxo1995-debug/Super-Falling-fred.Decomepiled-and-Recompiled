.class public Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
.super Ljava/lang/Object;

.field private final authorizationServerEncodedUrl:Ljava/lang/String;
.field private final clientAuthentication:Lcom/google/api/client/http/HttpExecuteInterceptor;
.field private final clientId:Ljava/lang/String;
.field private clock:Lcom/google/api/client/util/Clock;
.field private credentialStore:Lcom/google/api/client/auth/oauth2/CredentialStore;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private final method:Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
.field private requestInitializer:Lcom/google/api/client/http/HttpRequestInitializer;
.field private scopes:Ljava/lang/String;
.field private final tokenServerUrl:Lcom/google/api/client/http/GenericUrl;
.field private final transport:Lcom/google/api/client/http/HttpTransport;

.method public constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpExecuteInterceptor; Ljava/lang/String; Ljava/lang/String;)V
    .registers 9
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    sget-object v0, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clock Lcom/google/api/client/util/Clock;
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/HttpTransport;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-static v5, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/GenericUrl;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    iput-object v6, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-static v7, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientId Ljava/lang/String;
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->authorizationServerEncodedUrl Ljava/lang/String;
    return-void
.end method

.method public build()Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;
    .registers 13
    new-instance v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;
    iget-object v1, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iget-object v2, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v3, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    iget-object v4, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    iget-object v5, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    iget-object v6, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientId Ljava/lang/String;
    iget-object v7, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->authorizationServerEncodedUrl Ljava/lang/String;
    iget-object v8, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    iget-object v9, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    iget-object v10, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->scopes Ljava/lang/String;
    iget-object v11, v12, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clock Lcom/google/api/client/util/Clock;
    invoke-direct/range v0 ... v11, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpExecuteInterceptor; Ljava/lang/String; Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/lang/String; Lcom/google/api/client/util/Clock;)V
    return-object v0
.end method

.method public final getAuthorizationServerEncodedUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->authorizationServerEncodedUrl Ljava/lang/String;
    return-object v0
.end method

.method public final getClientAuthentication()Lcom/google/api/client/http/HttpExecuteInterceptor;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public final getClientId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clientId Ljava/lang/String;
    return-object v0
.end method

.method public final getClock()Lcom/google/api/client/util/Clock;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clock Lcom/google/api/client/util/Clock;
    return-object v0
.end method

.method public final getCredentialStore()Lcom/google/api/client/auth/oauth2/CredentialStore;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    return-object v0
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getMethod()Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    return-object v0
.end method

.method public final getRequestInitializer()Lcom/google/api/client/http/HttpRequestInitializer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public final getScopes()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->scopes Ljava/lang/String;
    return-object v0
.end method

.method public final getTokenServerUrl()Lcom/google/api/client/http/GenericUrl;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    return-object v0
.end method

.method public final getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public setClock(Lcom/google/api/client/util/Clock;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->clock Lcom/google/api/client/util/Clock;
    return-object v1
.end method

.method public setCredentialStore(Lcom/google/api/client/auth/oauth2/CredentialStore;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    return-object v0
.end method

.method public setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    .registers 3
    if-nez v2, +006h
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->scopes Ljava/lang/String;
    return-object v1
    const/16 v0, 32
    invoke-static v0, Lcom/google/common/base/Joiner;->on(C)Lcom/google/common/base/Joiner;
    move-result-object v0
    invoke-virtual v0, v2, Lcom/google/common/base/Joiner;->join(Ljava/lang/Iterable;)Ljava/lang/String;
    move-result-object v0
    goto -dh
.end method

.method public varargs setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    .registers 3
    if-nez v2, +008h
    const/4 v0, 0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;->setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow$Builder;
    move-result-object v0
    return-object v0
    invoke-static v2, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    goto -9h
.end method
