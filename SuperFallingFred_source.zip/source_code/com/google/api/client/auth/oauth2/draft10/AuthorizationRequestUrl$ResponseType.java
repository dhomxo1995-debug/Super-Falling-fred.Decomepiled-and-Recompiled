package com.google.api.client.auth.oauth2.draft10;
public final enum class AuthorizationRequestUrl$ResponseType extends java.lang.Enum {
    private static final synthetic com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType[] $VALUES;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType CODE;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType CODE_AND_TOKEN;
    public static final enum com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType TOKEN;

    static AuthorizationRequestUrl$ResponseType()
    {
        com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.CODE = new com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType("CODE", 0);
        com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.TOKEN = new com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType("TOKEN", 1);
        com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.CODE_AND_TOKEN = new com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType("CODE_AND_TOKEN", 2);
        com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType[] v0_3 = new com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType[3];
        v0_3[0] = com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.CODE;
        v0_3[1] = com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.TOKEN;
        v0_3[2] = com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.CODE_AND_TOKEN;
        com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.$VALUES = v0_3;
        return;
    }

    private AuthorizationRequestUrl$ResponseType(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType valueOf(String p1)
    {
        return ((com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType) Enum.valueOf(com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType, p1));
    }

    public static com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType[] values()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType[]) com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl$ResponseType.$VALUES.clone());
    }

    public void set(com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl p2)
    {
        p2.responseType = this.toString().toLowerCase();
        return;
    }
}
