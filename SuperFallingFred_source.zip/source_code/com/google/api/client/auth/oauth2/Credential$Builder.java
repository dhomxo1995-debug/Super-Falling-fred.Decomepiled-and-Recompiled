package com.google.api.client.auth.oauth2;
public class Credential$Builder {
    private com.google.api.client.http.HttpExecuteInterceptor clientAuthentication;
    private com.google.api.client.util.Clock clock;
    private com.google.api.client.json.JsonFactory jsonFactory;
    private final com.google.api.client.auth.oauth2.Credential$AccessMethod method;
    private java.util.List refreshListeners;
    private com.google.api.client.http.HttpRequestInitializer requestInitializer;
    private com.google.api.client.http.GenericUrl tokenServerUrl;
    private com.google.api.client.http.HttpTransport transport;

    public Credential$Builder(com.google.api.client.auth.oauth2.Credential$AccessMethod p2)
    {
        this.clock = com.google.api.client.util.Clock.SYSTEM;
        this.refreshListeners = new java.util.ArrayList();
        this.method = ((com.google.api.client.auth.oauth2.Credential$AccessMethod) com.google.common.base.Preconditions.checkNotNull(p2));
        return;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder addRefreshListener(com.google.api.client.auth.oauth2.CredentialRefreshListener p3)
    {
        this.refreshListeners.add(com.google.common.base.Preconditions.checkNotNull(p3));
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential build()
    {
        String v4_2;
        com.google.api.client.auth.oauth2.Credential$AccessMethod v1 = this.method;
        com.google.api.client.http.HttpTransport v2 = this.transport;
        com.google.api.client.json.JsonFactory v3 = this.jsonFactory;
        if (this.tokenServerUrl != null) {
            v4_2 = this.tokenServerUrl.build();
        } else {
            v4_2 = 0;
        }
        return new com.google.api.client.auth.oauth2.Credential(v1, v2, v3, v4_2, this.clientAuthentication, this.requestInitializer, this.refreshListeners, this.clock);
    }

    public final com.google.api.client.http.HttpExecuteInterceptor getClientAuthentication()
    {
        return this.clientAuthentication;
    }

    public final com.google.api.client.util.Clock getClock()
    {
        return this.clock;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.auth.oauth2.Credential$AccessMethod getMethod()
    {
        return this.method;
    }

    public final java.util.List getRefreshListeners()
    {
        return this.refreshListeners;
    }

    public final com.google.api.client.http.HttpRequestInitializer getRequestInitializer()
    {
        return this.requestInitializer;
    }

    public final com.google.api.client.http.GenericUrl getTokenServerUrl()
    {
        return this.tokenServerUrl;
    }

    public final com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p1)
    {
        this.clientAuthentication = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setClock(com.google.api.client.util.Clock p2)
    {
        this.clock = ((com.google.api.client.util.Clock) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setJsonFactory(com.google.api.client.json.JsonFactory p1)
    {
        this.jsonFactory = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setRefreshListeners(java.util.List p1)
    {
        this.refreshListeners = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p1)
    {
        this.requestInitializer = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setTokenServerEncodedUrl(String p2)
    {
        com.google.api.client.http.GenericUrl v0_1;
        if (p2 != null) {
            v0_1 = new com.google.api.client.http.GenericUrl(p2);
        } else {
            v0_1 = 0;
        }
        this.tokenServerUrl = v0_1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setTokenServerUrl(com.google.api.client.http.GenericUrl p1)
    {
        this.tokenServerUrl = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential$Builder setTransport(com.google.api.client.http.HttpTransport p1)
    {
        this.transport = p1;
        return this;
    }
}
