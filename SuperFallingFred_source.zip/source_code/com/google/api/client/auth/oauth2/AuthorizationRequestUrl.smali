.class public Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
.super Lcom/google/api/client/http/GenericUrl;

.field private clientId:Ljava/lang/String;
.field private redirectUri:Ljava/lang/String;
.field private responseTypes:Ljava/lang/String;
.field private scopes:Ljava/lang/String;
.field private state:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String; Ljava/lang/String; Ljava/lang/Iterable;)V
    .registers 5
    invoke-direct v1, v2, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    invoke-virtual v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->getFragment()Ljava/lang/String;
    move-result-object v0
    if-nez v0, +00dh
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    invoke-virtual v1, v3, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->setClientId(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    invoke-virtual v1, v4, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->setResponseTypes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    return-void
    const/4 v0, 0
    goto -bh
.end method

.method public final getClientId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->clientId Ljava/lang/String;
    return-object v0
.end method

.method public final getRedirectUri()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->redirectUri Ljava/lang/String;
    return-object v0
.end method

.method public final getResponseTypes()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->responseTypes Ljava/lang/String;
    return-object v0
.end method

.method public final getScopes()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->scopes Ljava/lang/String;
    return-object v0
.end method

.method public final getState()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->state Ljava/lang/String;
    return-object v0
.end method

.method public setClientId(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->clientId Ljava/lang/String;
    return-object v1
.end method

.method public setRedirectUri(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->redirectUri Ljava/lang/String;
    return-object v0
.end method

.method public setResponseTypes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 3
    const/16 v0, 32
    invoke-static v0, Lcom/google/common/base/Joiner;->on(C)Lcom/google/common/base/Joiner;
    move-result-object v0
    invoke-virtual v0, v2, Lcom/google/common/base/Joiner;->join(Ljava/lang/Iterable;)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->responseTypes Ljava/lang/String;
    return-object v1
.end method

.method public varargs setResponseTypes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 3
    invoke-static v2, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->setResponseTypes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    move-result-object v0
    return-object v0
.end method

.method public setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 3
    if-nez v2, +006h
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->scopes Ljava/lang/String;
    return-object v1
    const/16 v0, 32
    invoke-static v0, Lcom/google/common/base/Joiner;->on(C)Lcom/google/common/base/Joiner;
    move-result-object v0
    invoke-virtual v0, v2, Lcom/google/common/base/Joiner;->join(Ljava/lang/Iterable;)Ljava/lang/String;
    move-result-object v0
    goto -dh
.end method

.method public varargs setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 3
    if-nez v2, +008h
    const/4 v0, 0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    move-result-object v0
    return-object v0
    invoke-static v2, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v0
    goto -9h
.end method

.method public setState(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationRequestUrl;->state Ljava/lang/String;
    return-object v0
.end method
