.class public Lcom/google/api/client/auth/oauth2/Credential;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpExecuteInterceptor;
.implements Lcom/google/api/client/http/HttpRequestInitializer;
.implements Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;

.field static final LOGGER:Ljava/util/logging/Logger;
.field private accessToken:Ljava/lang/String;
.field private final clientAuthentication:Lcom/google/api/client/http/HttpExecuteInterceptor;
.field private final clock:Lcom/google/api/client/util/Clock;
.field private expirationTimeMilliseconds:Ljava/lang/Long;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private final lock:Ljava/util/concurrent/locks/Lock;
.field private final method:Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
.field private final refreshListeners:Ljava/util/List;
.field private refreshToken:Ljava/lang/String;
.field private final requestInitializer:Lcom/google/api/client/http/HttpRequestInitializer;
.field private final tokenServerEncodedUrl:Ljava/lang/String;
.field private final transport:Lcom/google/api/client/http/HttpTransport;

.method static constructor <clinit>()V
    .registers 1
    const-class v0, Lcom/google/api/client/auth/oauth2/Credential;
    invoke-virtual v0, Ljava/lang/Class;->getName()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/auth/oauth2/Credential;->LOGGER Ljava/util/logging/Logger;
    return-void
.end method

.method public constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;)V
    .registers 10
    const/4 v2, 0
    move-object v0, v8
    move-object v1, v9
    move-object v3, v2
    move-object v4, v2
    move-object v5, v2
    move-object v6, v2
    move-object v7, v2
    invoke-direct/range v0 ... v7, Lcom/google/api/client/auth/oauth2/Credential;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Lcom/google/api/client/http/HttpExecuteInterceptor; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/util/List;)V
    return-void
.end method

.method protected constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Lcom/google/api/client/http/HttpExecuteInterceptor; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/util/List;)V
    .registers 17
    sget-object v8, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    move-object v0, v9
    move-object v1, v10
    move-object v2, v11
    move-object v3, v12
    move-object v4, v13
    move-object v5, v14
    move-object v6, v15
    move-object/from16 v7, v16
    invoke-direct/range v0 ... v8, Lcom/google/api/client/auth/oauth2/Credential;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Lcom/google/api/client/http/HttpExecuteInterceptor; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/util/List; Lcom/google/api/client/util/Clock;)V
    return-void
.end method

.method protected constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Lcom/google/api/client/http/HttpExecuteInterceptor; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/util/List; Lcom/google/api/client/util/Clock;)V
    .registers 10
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;
    invoke-direct v0, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iput-object v3, v1, Lcom/google/api/client/auth/oauth2/Credential;->transport Lcom/google/api/client/http/HttpTransport;
    iput-object v4, v1, Lcom/google/api/client/auth/oauth2/Credential;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    iput-object v5, v1, Lcom/google/api/client/auth/oauth2/Credential;->tokenServerEncodedUrl Ljava/lang/String;
    iput-object v6, v1, Lcom/google/api/client/auth/oauth2/Credential;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    iput-object v7, v1, Lcom/google/api/client/auth/oauth2/Credential;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    if-nez v8, +011h
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->refreshListeners Ljava/util/List;
    invoke-static v9, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->clock Lcom/google/api/client/util/Clock;
    return-void
    invoke-static v8, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    move-result-object v0
    goto -fh
.end method

.method protected executeRefreshToken()Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 6
    iget-object v0, v5, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken Ljava/lang/String;
    if-nez v0, +004h
    const/4 v0, 0
    return-object v0
    new-instance v0, Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/Credential;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    new-instance v3, Lcom/google/api/client/http/GenericUrl;
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/Credential;->tokenServerEncodedUrl Ljava/lang/String;
    invoke-direct v3, v4, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken Ljava/lang/String;
    invoke-direct v0, v1, v2, v3, v4, Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Ljava/lang/String;)V
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;->setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;
    move-result-object v0
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;->setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;
    move-result-object v0
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/RefreshTokenRequest;->execute()Lcom/google/api/client/auth/oauth2/TokenResponse;
    move-result-object v0
    goto -23h
.end method

.method public final getAccessToken()Ljava/lang/String;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v0
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public final getClientAuthentication()Lcom/google/api/client/http/HttpExecuteInterceptor;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public final getClock()Lcom/google/api/client/util/Clock;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->clock Lcom/google/api/client/util/Clock;
    return-object v0
.end method

.method public final getExpirationTimeMilliseconds()Ljava/lang/Long;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->expirationTimeMilliseconds Ljava/lang/Long;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v0
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public final getExpiresInSeconds()Ljava/lang/Long;
    .registers 5
    iget-object v0, v4, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v4, Lcom/google/api/client/auth/oauth2/Credential;->expirationTimeMilliseconds Ljava/lang/Long;
    if-nez v0, +009h
    const/4 v0, 0
    iget-object v1, v4, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v0
    iget-object v0, v4, Lcom/google/api/client/auth/oauth2/Credential;->expirationTimeMilliseconds Ljava/lang/Long;
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v0
    iget-object v2, v4, Lcom/google/api/client/auth/oauth2/Credential;->clock Lcom/google/api/client/util/Clock;
    invoke-interface v2, Lcom/google/api/client/util/Clock;->currentTimeMillis()J
    move-result-wide v2
    sub-long/2addr v0, v2
    const-wide/16 v2, 1000
    div-long/2addr v0, v2
    invoke-static v0, v1, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v0
    iget-object v1, v4, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    goto -1ah
    move-exception v0
    iget-object v1, v4, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getMethod()Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    return-object v0
.end method

.method public final getRefreshListeners()Ljava/util/List;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->refreshListeners Ljava/util/List;
    return-object v0
.end method

.method public final getRefreshToken()Ljava/lang/String;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken Ljava/lang/String;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v0
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public final getRequestInitializer()Lcom/google/api/client/http/HttpRequestInitializer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public final getTokenServerEncodedUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->tokenServerEncodedUrl Ljava/lang/String;
    return-object v0
.end method

.method public final getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public handleResponse(Lcom/google/api/client/http/HttpRequest; Lcom/google/api/client/http/HttpResponse; Z)Z
    .registers 9
    const/4 v2, 0
    invoke-virtual v7, Lcom/google/api/client/http/HttpResponse;->getStatusCode()I
    move-result v1
    const/16 v3, 401
    if-ne v1, v3, +035h
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/Credential;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    invoke-interface v3, v6, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;->getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    move-result-object v3
    invoke-static v1, v3, Lcom/google/common/base/Objects;->equal(Ljava/lang/Object; Ljava/lang/Object;)Z
    move-result v1
    if-eqz v1, +008h
    invoke-virtual v5, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken()Z
    move-result v1
    if-eqz v1, +009h
    const/4 v1, 1
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v3, Ljava/util/concurrent/locks/Lock;->unlock()V
    return v1
    move v1, v2
    goto -7h
    move-exception v1
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v3, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v1
    move-exception v0
    sget-object v1, Lcom/google/api/client/auth/oauth2/Credential;->LOGGER Ljava/util/logging/Logger;
    sget-object v3, Ljava/util/logging/Level;->SEVERE Ljava/util/logging/Level;
    const-string v4, "unable to refresh token"
    invoke-virtual v1, v3, v4, v0, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level; Ljava/lang/String; Ljava/lang/Throwable;)V
    move v1, v2
    goto -15h
.end method

.method public initialize(Lcom/google/api/client/http/HttpRequest;)V
    .registers 2
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setInterceptor(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/http/HttpRequest;
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setUnsuccessfulResponseHandler(Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;)Lcom/google/api/client/http/HttpRequest;
    return-void
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest;)V
    .registers 7
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->lock()V
    invoke-virtual v5, Lcom/google/api/client/auth/oauth2/Credential;->getExpiresInSeconds()Ljava/lang/Long;
    move-result-object v0
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    if-eqz v1, +00eh
    if-eqz v0, +019h
    invoke-virtual v0, Ljava/lang/Long;->longValue()J
    move-result-wide v1
    const-wide/16 v3, 60
    cmp-long v1, v1, v3
    if-gtz v1, +00fh
    invoke-virtual v5, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken()Z
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    if-nez v1, +008h
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-void
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    invoke-interface v1, v6, v2, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;->intercept(Lcom/google/api/client/http/HttpRequest; Ljava/lang/String;)V
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    goto -dh
    move-exception v1
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v2, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v1
.end method

.method public final refreshToken()Z
    .registers 10
    const/4 v5, 1
    const/4 v6, 0
    iget-object v7, v9, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v7, Ljava/util/concurrent/locks/Lock;->lock()V
    invoke-virtual v9, Lcom/google/api/client/auth/oauth2/Credential;->executeRefreshToken()Lcom/google/api/client/auth/oauth2/TokenResponse;
    move-result-object v4
    if-eqz v4, +069h
    invoke-virtual v9, v4, Lcom/google/api/client/auth/oauth2/Credential;->setFromTokenResponse(Lcom/google/api/client/auth/oauth2/TokenResponse;)Lcom/google/api/client/auth/oauth2/Credential;
    iget-object v7, v9, Lcom/google/api/client/auth/oauth2/Credential;->refreshListeners Ljava/util/List;
    invoke-interface v7, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v7
    if-eqz v7, +04fh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;
    invoke-interface v2, v9, v4, Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;->onTokenResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenResponse;)V
    goto -fh
    move-exception v0
    const/16 v7, 400
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/TokenResponseException;->getStatusCode()I
    move-result v8
    if-gt v7, v8, +042h
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/TokenResponseException;->getStatusCode()I
    move-result v7
    const/16 v8, 500
    if-ge v7, v8, +03ah
    move v3, v5
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/TokenResponseException;->getDetails()Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    move-result-object v5
    if-eqz v5, +00ch
    if-eqz v3, +00ah
    const/4 v5, 0
    invoke-virtual v9, v5, Lcom/google/api/client/auth/oauth2/Credential;->setAccessToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    const/4 v5, 0
    invoke-virtual v9, v5, Lcom/google/api/client/auth/oauth2/Credential;->setExpiresInSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    iget-object v5, v9, Lcom/google/api/client/auth/oauth2/Credential;->refreshListeners Ljava/util/List;
    invoke-interface v5, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v5
    if-eqz v5, +01fh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/TokenResponseException;->getDetails()Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    move-result-object v5
    invoke-interface v2, v9, v5, Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;->onTokenErrorResponse(Lcom/google/api/client/auth/oauth2/Credential; Lcom/google/api/client/auth/oauth2/TokenErrorResponse;)V
    goto -13h
    move-exception v5
    iget-object v6, v9, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v6, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v5
    iget-object v6, v9, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v6, Ljava/util/concurrent/locks/Lock;->unlock()V
    return v5
    move v3, v6
    goto -38h
    if-eqz v3, +003h
    throw v0
    iget-object v5, v9, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v5, Ljava/util/concurrent/locks/Lock;->unlock()V
    move v5, v6
    goto -ch
.end method

.method public setAccessToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iput-object v3, v2, Lcom/google/api/client/auth/oauth2/Credential;->accessToken Ljava/lang/String;
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v2
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public setExpirationTimeMilliseconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iput-object v3, v2, Lcom/google/api/client/auth/oauth2/Credential;->expirationTimeMilliseconds Ljava/lang/Long;
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v2
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public setExpiresInSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 8
    if-nez v7, +008h
    const/4 v0, 0
    invoke-virtual v6, v0, Lcom/google/api/client/auth/oauth2/Credential;->setExpirationTimeMilliseconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    move-result-object v0
    return-object v0
    iget-object v0, v6, Lcom/google/api/client/auth/oauth2/Credential;->clock Lcom/google/api/client/util/Clock;
    invoke-interface v0, Lcom/google/api/client/util/Clock;->currentTimeMillis()J
    move-result-wide v0
    invoke-virtual v7, Ljava/lang/Long;->longValue()J
    move-result-wide v2
    const-wide/16 v4, 1000
    mul-long/2addr v2, v4
    add-long/2addr v0, v2
    invoke-static v0, v1, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    move-result-object v0
    goto -17h
.end method

.method public setFromTokenResponse(Lcom/google/api/client/auth/oauth2/TokenResponse;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/TokenResponse;->getAccessToken()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/Credential;->setAccessToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/TokenResponse;->getRefreshToken()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +009h
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/TokenResponse;->getRefreshToken()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/Credential;->setRefreshToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/TokenResponse;->getExpiresInSeconds()Ljava/lang/Long;
    move-result-object v0
    invoke-virtual v1, v0, Lcom/google/api/client/auth/oauth2/Credential;->setExpiresInSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    return-object v1
.end method

.method public setRefreshToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    if-eqz v3, +018h
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    if-eqz v0, +01ch
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->transport Lcom/google/api/client/http/HttpTransport;
    if-eqz v0, +018h
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    if-eqz v0, +014h
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->tokenServerEncodedUrl Ljava/lang/String;
    if-eqz v0, +010h
    const/4 v0, 1
    const-string v1, "Please use the Builder and call setJsonFactory, setTransport, setClientAuthentication and setTokenServerUrl/setTokenServerEncodedUrl"
    invoke-static v0, v1, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/Object;)V
    iput-object v3, v2, Lcom/google/api/client/auth/oauth2/Credential;->refreshToken Ljava/lang/String;
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v2
    const/4 v0, 0
    goto -eh
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/Credential;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method
