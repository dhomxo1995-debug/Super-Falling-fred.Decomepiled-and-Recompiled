package com.google.api.client.auth.oauth2.draft10;
public class AuthorizationRequestUrl extends com.google.api.client.http.GenericUrl {
    public String clientId;
    public String redirectUri;
    public String responseType;
    public String scope;
    public String state;

    public AuthorizationRequestUrl(String p2)
    {
        super(p2);
        super.responseType = "code";
        return;
    }

    public AuthorizationRequestUrl(String p1, String p2)
    {
        this(p1);
        this.clientId = p2;
        return;
    }
}
