.class 0x0 Lcom/google/api/client/auth/oauth2/TokenRequest$1;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpRequestInitializer;

.field final synthetic this$0:Lcom/google/api/client/auth/oauth2/TokenRequest;

.method constructor <init>(Lcom/google/api/client/auth/oauth2/TokenRequest;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1;->this$0 Lcom/google/api/client/auth/oauth2/TokenRequest;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public initialize(Lcom/google/api/client/http/HttpRequest;)V
    .registers 4
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest$1;->this$0 Lcom/google/api/client/auth/oauth2/TokenRequest;
    iget-object v1, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    if-eqz v1, +009h
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest$1;->this$0 Lcom/google/api/client/auth/oauth2/TokenRequest;
    iget-object v1, v1, Lcom/google/api/client/auth/oauth2/TokenRequest;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    invoke-interface v1, v3, Lcom/google/api/client/http/HttpRequestInitializer;->initialize(Lcom/google/api/client/http/HttpRequest;)V
    invoke-virtual v3, Lcom/google/api/client/http/HttpRequest;->getInterceptor()Lcom/google/api/client/http/HttpExecuteInterceptor;
    move-result-object v0
    new-instance v1, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;
    invoke-direct v1, v2, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;-><init>(Lcom/google/api/client/auth/oauth2/TokenRequest$1; Lcom/google/api/client/http/HttpExecuteInterceptor;)V
    invoke-virtual v3, v1, Lcom/google/api/client/http/HttpRequest;->setInterceptor(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/http/HttpRequest;
    return-void
.end method
