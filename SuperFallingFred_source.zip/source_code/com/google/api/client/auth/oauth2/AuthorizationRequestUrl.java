package com.google.api.client.auth.oauth2;
public class AuthorizationRequestUrl extends com.google.api.client.http.GenericUrl {
    private String clientId;
    private String redirectUri;
    private String responseTypes;
    private String scopes;
    private String state;

    public AuthorizationRequestUrl(String p2, String p3, Iterable p4)
    {
        int v0_1;
        super(p2);
        if (super.getFragment() != null) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_1);
        super.setClientId(p3);
        super.setResponseTypes(p4);
        return;
    }

    public final String getClientId()
    {
        return this.clientId;
    }

    public final String getRedirectUri()
    {
        return this.redirectUri;
    }

    public final String getResponseTypes()
    {
        return this.responseTypes;
    }

    public final String getScopes()
    {
        return this.scopes;
    }

    public final String getState()
    {
        return this.state;
    }

    public com.google.api.client.auth.oauth2.AuthorizationRequestUrl setClientId(String p2)
    {
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationRequestUrl setRedirectUri(String p1)
    {
        this.redirectUri = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(Iterable p2)
    {
        this.responseTypes = com.google.common.base.Joiner.on(32).join(p2);
        return this;
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(String[] p2)
    {
        return this.setResponseTypes(java.util.Arrays.asList(p2));
    }

    public com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(Iterable p2)
    {
        String v0_2;
        if (p2 != null) {
            v0_2 = com.google.common.base.Joiner.on(32).join(p2);
        } else {
            v0_2 = 0;
        }
        this.scopes = v0_2;
        return this;
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(String[] p2)
    {
        com.google.api.client.auth.oauth2.AuthorizationRequestUrl v0_0;
        if (p2 != null) {
            v0_0 = java.util.Arrays.asList(p2);
        } else {
            v0_0 = 0;
        }
        return this.setScopes(v0_0);
    }

    public com.google.api.client.auth.oauth2.AuthorizationRequestUrl setState(String p1)
    {
        this.state = p1;
        return this;
    }
}
