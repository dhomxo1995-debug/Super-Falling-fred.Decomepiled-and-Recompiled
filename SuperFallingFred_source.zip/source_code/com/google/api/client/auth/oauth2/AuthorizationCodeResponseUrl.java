package com.google.api.client.auth.oauth2;
public class AuthorizationCodeResponseUrl extends com.google.api.client.http.GenericUrl {
    private String code;
    private String error;
    private String errorDescription;
    private String errorUri;
    private String state;

    public AuthorizationCodeResponseUrl(String p5)
    {
        int v0_1;
        int v1 = 1;
        super(p5);
        if (super.code != null) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        int v3_0;
        if (super.error != null) {
            v3_0 = 0;
        } else {
            v3_0 = 1;
        }
        if (v0_1 == v3_0) {
            v1 = 0;
        }
        com.google.common.base.Preconditions.checkArgument(v1);
        return;
    }

    public final String getCode()
    {
        return this.code;
    }

    public final String getError()
    {
        return this.error;
    }

    public final String getErrorDescription()
    {
        return this.errorDescription;
    }

    public final String getErrorUri()
    {
        return this.errorUri;
    }

    public final String getState()
    {
        return this.state;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl setCode(String p1)
    {
        this.code = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl setError(String p1)
    {
        this.error = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl setErrorDescription(String p1)
    {
        this.errorDescription = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl setErrorUri(String p1)
    {
        this.errorUri = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl setState(String p1)
    {
        this.state = p1;
        return this;
    }
}
