package com.google.api.client.auth.oauth2;
public class TokenResponse extends com.google.api.client.json.GenericJson {
    private String accessToken;
    private Long expiresInSeconds;
    private String refreshToken;
    private String scope;
    private String tokenType;

    public TokenResponse()
    {
        return;
    }

    public final String getAccessToken()
    {
        return this.accessToken;
    }

    public final Long getExpiresInSeconds()
    {
        return this.expiresInSeconds;
    }

    public final String getRefreshToken()
    {
        return this.refreshToken;
    }

    public final String getScope()
    {
        return this.scope;
    }

    public final String getTokenType()
    {
        return this.tokenType;
    }

    public com.google.api.client.auth.oauth2.TokenResponse setAccessToken(String p2)
    {
        this.accessToken = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenResponse setExpiresInSeconds(Long p1)
    {
        this.expiresInSeconds = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenResponse setRefreshToken(String p1)
    {
        this.refreshToken = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenResponse setScope(String p1)
    {
        this.scope = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenResponse setTokenType(String p2)
    {
        this.tokenType = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }
}
