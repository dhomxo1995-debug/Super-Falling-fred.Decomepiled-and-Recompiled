package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenRequest extends com.google.api.client.util.GenericData {
    public String authorizationServerUrl;
    public String clientId;
    public String clientSecret;
    public com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType grantType;
    public com.google.api.client.json.JsonFactory jsonFactory;
    public String scope;
    public com.google.api.client.http.HttpTransport transport;
    public boolean useBasicAuthorization;

    public AccessTokenRequest()
    {
        this.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.NONE;
        return;
    }

    protected AccessTokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4)
    {
        this.transport = ((com.google.api.client.http.HttpTransport) com.google.common.base.Preconditions.checkNotNull(p2));
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p3));
        this.authorizationServerUrl = ((String) com.google.common.base.Preconditions.checkNotNull(p4));
        return;
    }

    protected AccessTokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5)
    {
        this(p2, p3, p4);
        this.clientSecret = ((String) com.google.common.base.Preconditions.checkNotNull(p5));
        return;
    }

    public AccessTokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5, String p6)
    {
        this(p2, p3, p4, p6);
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p5));
        return;
    }

    public final com.google.api.client.auth.oauth2.draft10.AccessTokenResponse execute()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessTokenResponse) this.executeUnparsed().parseAs(com.google.api.client.auth.oauth2.draft10.AccessTokenResponse));
    }

    public final com.google.api.client.http.HttpResponse executeUnparsed()
    {
        com.google.api.client.http.HttpRequest v0 = this.transport.createRequestFactory().buildPostRequest(new com.google.api.client.http.GenericUrl(this.authorizationServerUrl), new com.google.api.client.http.UrlEncodedContent(this));
        v0.addParser(new com.google.api.client.http.json.JsonHttpParser(this.jsonFactory));
        if (!this.useBasicAuthorization) {
            this.put("client_secret", this.clientSecret);
        } else {
            v0.getHeaders().setBasicAuthentication(this.clientId, this.clientSecret);
        }
        return v0.execute();
    }
}
