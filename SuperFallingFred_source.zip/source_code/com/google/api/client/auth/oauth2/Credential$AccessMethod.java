package com.google.api.client.auth.oauth2;
public interface Credential$AccessMethod {

    public abstract String getAccessTokenFromRequest(com.google.api.client.http.HttpRequest p0);

    public abstract void intercept(com.google.api.client.http.HttpRequest p0, String p1);
}
