package com.google.api.client.auth.oauth2;
final class BearerToken$AuthorizationHeaderAccessMethod implements com.google.api.client.auth.oauth2.Credential$AccessMethod {
    static final String HEADER_PREFIX = "Bearer ";

    BearerToken$AuthorizationHeaderAccessMethod()
    {
        return;
    }

    public String getAccessTokenFromRequest(com.google.api.client.http.HttpRequest p3)
    {
        String v1_3;
        String v0 = p3.getHeaders().getAuthorization();
        if ((v0 == null) || (!v0.startsWith("Bearer "))) {
            v1_3 = 0;
        } else {
            v1_3 = v0.substring("Bearer ".length());
        }
        return v1_3;
    }

    public void intercept(com.google.api.client.http.HttpRequest p4, String p5)
    {
        p4.getHeaders().setAuthorization(new StringBuilder().append("Bearer ").append(p5).toString());
        return;
    }
}
