.class 0x0 Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;
.super Ljava/lang/Object;

.field private accessToken:Ljava/lang/String;
.field private expirationTimeMillis:Ljava/lang/Long;
.field private refreshToken:Ljava/lang/String;

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method  load(Lcom/google/api/client/auth/oauth2/Credential;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->accessToken Ljava/lang/String;
    invoke-virtual v2, v0, Lcom/google/api/client/auth/oauth2/Credential;->setAccessToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->refreshToken Ljava/lang/String;
    invoke-virtual v2, v0, Lcom/google/api/client/auth/oauth2/Credential;->setRefreshToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->expirationTimeMillis Ljava/lang/Long;
    invoke-virtual v2, v0, Lcom/google/api/client/auth/oauth2/Credential;->setExpirationTimeMilliseconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/Credential;
    return-void
.end method

.method  store(Lcom/google/api/client/auth/oauth2/Credential;)V
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/Credential;->getAccessToken()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->accessToken Ljava/lang/String;
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/Credential;->getRefreshToken()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->refreshToken Ljava/lang/String;
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/Credential;->getExpirationTimeMilliseconds()Ljava/lang/Long;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->expirationTimeMillis Ljava/lang/Long;
    return-void
.end method
