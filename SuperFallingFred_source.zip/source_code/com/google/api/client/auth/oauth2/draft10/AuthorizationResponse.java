package com.google.api.client.auth.oauth2.draft10;
public class AuthorizationResponse extends com.google.api.client.json.GenericJson {
    public String accessToken;
    public String code;
    public String error;
    public String errorDescription;
    public String errorUri;
    public Long expiresIn;
    public String scope;
    public String state;

    public AuthorizationResponse(String p4)
    {
        try {
            java.net.URI v1_1 = new java.net.URI(p4);
            com.google.api.client.http.UrlEncodedParser.parse(v1_1.getRawQuery(), this);
            com.google.api.client.http.UrlEncodedParser.parse(v1_1.getRawFragment(), this);
            return;
        } catch (java.net.URISyntaxException v0) {
            throw new IllegalArgumentException(v0);
        }
    }

    public final com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError getErrorCodeIfKnown()
    {
        IllegalArgumentException v0_3;
        if (this.error == null) {
            v0_3 = 0;
        } else {
            try {
                v0_3 = com.google.api.client.auth.oauth2.draft10.AuthorizationResponse$KnownError.valueOf(this.error.toUpperCase());
            } catch (IllegalArgumentException v0) {
            }
        }
        return v0_3;
    }
}
