package com.google.api.client.auth.oauth2;
final class BearerToken$FormEncodedBodyAccessMethod implements com.google.api.client.auth.oauth2.Credential$AccessMethod {

    BearerToken$FormEncodedBodyAccessMethod()
    {
        return;
    }

    private static java.util.Map getData(com.google.api.client.http.HttpRequest p1)
    {
        return com.google.api.client.util.Data.mapOf(com.google.api.client.http.UrlEncodedContent.getContent(p1).getData());
    }

    public String getAccessTokenFromRequest(com.google.api.client.http.HttpRequest p4)
    {
        String v1_1;
        Object v0 = com.google.api.client.auth.oauth2.BearerToken$FormEncodedBodyAccessMethod.getData(p4).get("access_token");
        if (v0 != null) {
            v1_1 = v0.toString();
        } else {
            v1_1 = 0;
        }
        return v1_1;
    }

    public void intercept(com.google.api.client.http.HttpRequest p3, String p4)
    {
        java.util.Map v0_1;
        if (p3.getMethod() == com.google.api.client.http.HttpMethod.GET) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_1, "HTTP GET method is not supported");
        com.google.api.client.auth.oauth2.BearerToken$FormEncodedBodyAccessMethod.getData(p3).put("access_token", p4);
        return;
    }
}
