.class public Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpExecuteInterceptor;
.implements Lcom/google/api/client/http/HttpRequestInitializer;
.implements Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;

.field private static final ALLOWED_METHODS:Ljava/util/EnumSet;
.field static final HEADER_PREFIX:Ljava/lang/String;
.field static final LOGGER:Ljava/util/logging/Logger;
.field private accessToken:Ljava/lang/String;
.field private final authorizationServerUrl:Ljava/lang/String;
.field private final clientId:Ljava/lang/String;
.field private final clientSecret:Ljava/lang/String;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private final method:Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
.field private final refreshToken:Ljava/lang/String;
.field private final tokenLock:Ljava/util/concurrent/locks/Lock;
.field private final transport:Lcom/google/api/client/http/HttpTransport;

.method static constructor <clinit>()V
    .registers 3
    const-class v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;
    invoke-virtual v0, Ljava/lang/Class;->getName()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->LOGGER Ljava/util/logging/Logger;
    sget-object v0, Lcom/google/api/client/http/HttpMethod;->POST Lcom/google/api/client/http/HttpMethod;
    sget-object v1, Lcom/google/api/client/http/HttpMethod;->PUT Lcom/google/api/client/http/HttpMethod;
    sget-object v2, Lcom/google/api/client/http/HttpMethod;->DELETE Lcom/google/api/client/http/HttpMethod;
    invoke-static v0, v1, v2, Ljava/util/EnumSet;->of(Ljava/lang/Enum; Ljava/lang/Enum; Ljava/lang/Enum;)Ljava/util/EnumSet;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->ALLOWED_METHODS Ljava/util/EnumSet;
    return-void
.end method

.method public constructor <init>(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;)V
    .registers 5
    const/4 v1, 0
    invoke-direct v2, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;
    invoke-direct v0, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V
    iput-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    iput-object v3, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->accessToken Ljava/lang/String;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    iput-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->method Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->transport Lcom/google/api/client/http/HttpTransport;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->authorizationServerUrl Ljava/lang/String;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientId Ljava/lang/String;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientSecret Ljava/lang/String;
    iput-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken Ljava/lang/String;
    return-void
.end method

.method public constructor <init>(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 10
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;
    invoke-direct v0, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    iput-object v2, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->accessToken Ljava/lang/String;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->method Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/HttpTransport;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-static v5, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-static v6, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->authorizationServerUrl Ljava/lang/String;
    invoke-static v7, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientId Ljava/lang/String;
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientSecret Ljava/lang/String;
    iput-object v9, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken Ljava/lang/String;
    return-void
.end method

.method private getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    .registers 9
    const/4 v4, 0
    sget-object v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    iget-object v6, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->method Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-virtual v6, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->ordinal()I
    move-result v6
    aget v5, v5, v6
    packed-switch v5, +000004bh
    invoke-static v8, Lcom/google/api/client/http/UrlEncodedContent;->getContent(Lcom/google/api/client/http/HttpRequest;)Lcom/google/api/client/http/UrlEncodedContent;
    move-result-object v5
    invoke-virtual v5, Lcom/google/api/client/http/UrlEncodedContent;->getData()Ljava/lang/Object;
    move-result-object v5
    invoke-static v5, Lcom/google/api/client/util/Data;->mapOf(Ljava/lang/Object;)Ljava/util/Map;
    move-result-object v1
    const-string v5, "oauth_token"
    invoke-interface v1, v5, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    if-nez v0, +031h
    return-object v4
    invoke-virtual v8, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v5
    invoke-virtual v5, Lcom/google/api/client/http/HttpHeaders;->getAuthorization()Ljava/lang/String;
    move-result-object v2
    if-eqz v2, -009h
    const-string v5, "OAuth "
    invoke-virtual v2, v5, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v5
    if-eqz v5, -011h
    const-string v4, "OAuth "
    invoke-virtual v4, Ljava/lang/String;->length()I
    move-result v4
    invoke-virtual v2, v4, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v4
    goto -1dh
    invoke-virtual v8, Lcom/google/api/client/http/HttpRequest;->getUrl()Lcom/google/api/client/http/GenericUrl;
    move-result-object v5
    const-string v6, "oauth_token"
    invoke-virtual v5, v6, Lcom/google/api/client/http/GenericUrl;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v3
    if-eqz v3, -028h
    invoke-virtual v3, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v4
    goto -2eh
    invoke-virtual v0, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v4
    goto -33h
    packed-switch-payload 1 2
.end method

.method protected final executeAccessTokenRequest(Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;)Z
    .registers 5
    invoke-virtual v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->execute()Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;
    move-result-object v2
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;->accessToken Ljava/lang/String;
    invoke-virtual v3, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->setAccessToken(Ljava/lang/String;)V
    if-eqz v1, +007h
    const/4 v2, 1
    return v2
    move-exception v0
    const/4 v1, 0
    goto -9h
    const/4 v2, 0
    goto -5h
.end method

.method protected executeRefreshToken()Z
    .registers 8
    iget-object v1, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken Ljava/lang/String;
    if-eqz v1, +018h
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;
    iget-object v1, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v2, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    iget-object v3, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->authorizationServerUrl Ljava/lang/String;
    iget-object v4, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientId Ljava/lang/String;
    iget-object v5, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientSecret Ljava/lang/String;
    iget-object v6, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken Ljava/lang/String;
    invoke-direct/range v0 ... v6, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$RefreshTokenGrant;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v7, v0, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->executeAccessTokenRequest(Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;)Z
    move-result v1
    return v1
    const/4 v1, 0
    goto -2h
.end method

.method public final getAccessToken()Ljava/lang/String;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->accessToken Ljava/lang/String;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-object v0
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public getAuthorizationServerUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->authorizationServerUrl Ljava/lang/String;
    return-object v0
.end method

.method public getClientId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientId Ljava/lang/String;
    return-object v0
.end method

.method public getClientSecret()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->clientSecret Ljava/lang/String;
    return-object v0
.end method

.method public getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getMethod()Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->method Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    return-object v0
.end method

.method public getRefreshToken()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken Ljava/lang/String;
    return-object v0
.end method

.method public getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public handleResponse(Lcom/google/api/client/http/HttpRequest; Lcom/google/api/client/http/HttpResponse; Z)Z
    .registers 9
    const/4 v3, 0
    invoke-virtual v7, Lcom/google/api/client/http/HttpResponse;->getStatusCode()I
    move-result v2
    const/16 v4, 401
    if-ne v2, v4, +033h
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v2, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->accessToken Ljava/lang/String;
    invoke-direct v5, v6, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    move-result-object v4
    invoke-static v2, v4, Lcom/google/common/base/Objects;->equal(Ljava/lang/Object; Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +008h
    invoke-virtual v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->refreshToken()Z
    move-result v2
    if-eqz v2, +009h
    const/4 v2, 1
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v4, Ljava/util/concurrent/locks/Lock;->unlock()V
    return v2
    move v2, v3
    goto -7h
    move-exception v2
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v4, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v2
    move-exception v0
    sget-object v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->LOGGER Ljava/util/logging/Logger;
    invoke-virtual v0, Lcom/google/api/client/http/HttpResponseException;->getMessage()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v2, v4, Ljava/util/logging/Logger;->severe(Ljava/lang/String;)V
    move v2, v3
    goto -15h
    move-exception v1
    sget-object v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->LOGGER Ljava/util/logging/Logger;
    invoke-virtual v1, Ljava/io/IOException;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v2, v4, Ljava/util/logging/Logger;->severe(Ljava/lang/String;)V
    goto -ch
.end method

.method public final initialize(Lcom/google/api/client/http/HttpRequest;)V
    .registers 2
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setInterceptor(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/http/HttpRequest;
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setUnsuccessfulResponseHandler(Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;)Lcom/google/api/client/http/HttpRequest;
    return-void
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest;)V
    .registers 9
    invoke-virtual v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->getAccessToken()Ljava/lang/String;
    move-result-object v0
    if-nez v0, +003h
    return-void
    sget-object v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$1;->$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method [I
    iget-object v3, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->method Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;
    invoke-virtual v3, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource$Method;->ordinal()I
    move-result v3
    aget v2, v2, v3
    packed-switch v2, +0000053h
    goto -eh
    invoke-virtual v8, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v2
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "OAuth "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Lcom/google/api/client/http/HttpHeaders;->setAuthorization(Ljava/lang/String;)V
    goto -29h
    invoke-virtual v8, Lcom/google/api/client/http/HttpRequest;->getUrl()Lcom/google/api/client/http/GenericUrl;
    move-result-object v2
    const-string v3, "oauth_token"
    invoke-virtual v2, v3, v0, Lcom/google/api/client/http/GenericUrl;->set(Ljava/lang/String; Ljava/lang/Object;)V
    goto -33h
    sget-object v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->ALLOWED_METHODS Ljava/util/EnumSet;
    invoke-virtual v8, Lcom/google/api/client/http/HttpRequest;->getMethod()Lcom/google/api/client/http/HttpMethod;
    move-result-object v3
    invoke-virtual v2, v3, Ljava/util/EnumSet;->contains(Ljava/lang/Object;)Z
    move-result v2
    const-string v3, "expected one of these HTTP methods: %s"
    const/4 v4, 1
    new-array v4, v4, [Ljava/lang/Object;
    const/4 v5, 0
    sget-object v6, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->ALLOWED_METHODS Ljava/util/EnumSet;
    aput-object v6, v4, v5
    invoke-static v2, v3, v4, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    invoke-static v8, Lcom/google/api/client/http/UrlEncodedContent;->getContent(Lcom/google/api/client/http/HttpRequest;)Lcom/google/api/client/http/UrlEncodedContent;
    move-result-object v2
    invoke-virtual v2, Lcom/google/api/client/http/UrlEncodedContent;->getData()Ljava/lang/Object;
    move-result-object v2
    invoke-static v2, Lcom/google/api/client/util/Data;->mapOf(Ljava/lang/Object;)Ljava/util/Map;
    move-result-object v1
    const-string v2, "oauth_token"
    invoke-interface v1, v2, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -5ch
    nop
    packed-switch-payload 1 2 3
.end method

.method protected onAccessToken(Ljava/lang/String;)V
    .registers 2
    return-void
.end method

.method public final refreshToken()Z
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->executeRefreshToken()Z
    move-result v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return v0
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public final setAccessToken(Ljava/lang/String;)V
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iput-object v3, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->accessToken Ljava/lang/String;
    invoke-virtual v2, v3, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->onAccessToken(Ljava/lang/String;)V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-void
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessProtectedResource;->tokenLock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method
