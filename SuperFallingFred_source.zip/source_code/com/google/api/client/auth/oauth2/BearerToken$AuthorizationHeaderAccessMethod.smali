.class final Lcom/google/api/client/auth/oauth2/BearerToken$AuthorizationHeaderAccessMethod;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;

.field static final HEADER_PREFIX:Ljava/lang/String;

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    .registers 4
    invoke-virtual v3, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v1
    invoke-virtual v1, Lcom/google/api/client/http/HttpHeaders;->getAuthorization()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +015h
    const-string v1, "Bearer "
    invoke-virtual v0, v1, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v1
    if-eqz v1, +00dh
    const-string v1, "Bearer "
    invoke-virtual v1, Ljava/lang/String;->length()I
    move-result v1
    invoke-virtual v0, v1, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v1
    return-object v1
    const/4 v1, 0
    goto -2h
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest; Ljava/lang/String;)V
    .registers 6
    invoke-virtual v4, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v0
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Bearer "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/google/api/client/http/HttpHeaders;->setAuthorization(Ljava/lang/String;)V
    return-void
.end method
