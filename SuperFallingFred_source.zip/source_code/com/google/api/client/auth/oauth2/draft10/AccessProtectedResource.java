package com.google.api.client.auth.oauth2.draft10;
public class AccessProtectedResource implements com.google.api.client.http.HttpExecuteInterceptor, com.google.api.client.http.HttpRequestInitializer, com.google.api.client.http.HttpUnsuccessfulResponseHandler {
    private static final java.util.EnumSet ALLOWED_METHODS = None;
    static final String HEADER_PREFIX = "OAuth ";
    static final java.util.logging.Logger LOGGER;
    private String accessToken;
    private final String authorizationServerUrl;
    private final String clientId;
    private final String clientSecret;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    private final com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method method;
    private final String refreshToken;
    private final java.util.concurrent.locks.Lock tokenLock;
    private final com.google.api.client.http.HttpTransport transport;

    static AccessProtectedResource()
    {
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.LOGGER = java.util.logging.Logger.getLogger(com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.getName());
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.ALLOWED_METHODS = java.util.EnumSet.of(com.google.api.client.http.HttpMethod.POST, com.google.api.client.http.HttpMethod.PUT, com.google.api.client.http.HttpMethod.DELETE);
        return;
    }

    public AccessProtectedResource(String p3, com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method p4)
    {
        this.tokenLock = new java.util.concurrent.locks.ReentrantLock();
        this.accessToken = p3;
        this.method = ((com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method) com.google.common.base.Preconditions.checkNotNull(p4));
        this.transport = 0;
        this.jsonFactory = 0;
        this.authorizationServerUrl = 0;
        this.clientId = 0;
        this.clientSecret = 0;
        this.refreshToken = 0;
        return;
    }

    public AccessProtectedResource(String p2, com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method p3, com.google.api.client.http.HttpTransport p4, com.google.api.client.json.JsonFactory p5, String p6, String p7, String p8, String p9)
    {
        this.tokenLock = new java.util.concurrent.locks.ReentrantLock();
        this.accessToken = p2;
        this.method = ((com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method) com.google.common.base.Preconditions.checkNotNull(p3));
        this.transport = ((com.google.api.client.http.HttpTransport) com.google.common.base.Preconditions.checkNotNull(p4));
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p5));
        this.authorizationServerUrl = ((String) com.google.common.base.Preconditions.checkNotNull(p6));
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        this.clientSecret = ((String) com.google.common.base.Preconditions.checkNotNull(p8));
        this.refreshToken = p9;
        return;
    }

    private String getAccessTokenFromRequest(com.google.api.client.http.HttpRequest p8)
    {
        String v4_0 = 0;
        switch (com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$1.$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method[this.method.ordinal()]) {
            case 1:
                String v2 = p8.getHeaders().getAuthorization();
                if ((v2 == null) || (!v2.startsWith("OAuth "))) {
                } else {
                    v4_0 = v2.substring("OAuth ".length());
                }
                break;
            case 2:
                Object v3 = p8.getUrl().get("oauth_token");
                if (v3 == null) {
                } else {
                    v4_0 = v3.toString();
                }
                break;
            default:
                Object v0 = com.google.api.client.util.Data.mapOf(com.google.api.client.http.UrlEncodedContent.getContent(p8).getData()).get("oauth_token");
                if (v0 != null) {
                    v4_0 = v0.toString();
                } else {
                }
        }
        return v4_0;
    }

    protected final boolean executeAccessTokenRequest(com.google.api.client.auth.oauth2.draft10.AccessTokenRequest p4)
    {
        try {
            int v1 = p4.execute().accessToken;
        } catch (com.google.api.client.http.HttpResponseException v0) {
            v1 = 0;
        }
        int v2_1;
        this.setAccessToken(v1);
        if (v1 == 0) {
            v2_1 = 0;
        } else {
            v2_1 = 1;
        }
        return v2_1;
    }

    protected boolean executeRefreshToken()
    {
        int v1_1;
        if (this.refreshToken == null) {
            v1_1 = 0;
        } else {
            v1_1 = this.executeAccessTokenRequest(new com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$RefreshTokenGrant(this.transport, this.jsonFactory, this.authorizationServerUrl, this.clientId, this.clientSecret, this.refreshToken));
        }
        return v1_1;
    }

    public final String getAccessToken()
    {
        this.tokenLock.lock();
        try {
            Throwable v0_1 = this.accessToken;
            this.tokenLock.unlock();
            return v0_1;
        } catch (Throwable v0_2) {
            this.tokenLock.unlock();
            throw v0_2;
        }
    }

    public String getAuthorizationServerUrl()
    {
        return this.authorizationServerUrl;
    }

    public String getClientId()
    {
        return this.clientId;
    }

    public String getClientSecret()
    {
        return this.clientSecret;
    }

    public com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method getMethod()
    {
        return this.method;
    }

    public String getRefreshToken()
    {
        return this.refreshToken;
    }

    public com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public boolean handleResponse(com.google.api.client.http.HttpRequest p6, com.google.api.client.http.HttpResponse p7, boolean p8)
    {
        try {
            int v2_4;
            if (p7.getStatusCode() == 401) {
                this.tokenLock.lock();
                if ((com.google.common.base.Objects.equal(this.accessToken, this.getAccessTokenFromRequest(p6))) && (!this.refreshToken())) {
                    v2_4 = 0;
                } else {
                    v2_4 = 1;
                }
                this.tokenLock.unlock();
                return v2_4;
            }
        } catch (com.google.api.client.http.HttpResponseException v0) {
            com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.LOGGER.severe(v0.getMessage());
        } catch (java.io.IOException v1) {
            com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.LOGGER.severe(v1.toString());
        }
        v2_4 = 0;
        return v2_4;
    }

    public final void initialize(com.google.api.client.http.HttpRequest p1)
    {
        p1.setInterceptor(this);
        p1.setUnsuccessfulResponseHandler(this);
        return;
    }

    public void intercept(com.google.api.client.http.HttpRequest p8)
    {
        String v0 = this.getAccessToken();
        if (v0 != null) {
            switch (com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$1.$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method[this.method.ordinal()]) {
                case 1:
                    p8.getHeaders().setAuthorization(new StringBuilder().append("OAuth ").append(v0).toString());
                    break;
                case 2:
                    p8.getUrl().set("oauth_token", v0);
                    break;
                case 3:
                    String v2_0 = com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.ALLOWED_METHODS.contains(p8.getMethod());
                    Object[] v4_1 = new Object[1];
                    v4_1[0] = com.google.api.client.auth.oauth2.draft10.AccessProtectedResource.ALLOWED_METHODS;
                    com.google.common.base.Preconditions.checkArgument(v2_0, "expected one of these HTTP methods: %s", v4_1);
                    com.google.api.client.util.Data.mapOf(com.google.api.client.http.UrlEncodedContent.getContent(p8).getData()).put("oauth_token", v0);
                    break;
                default:
            }
        }
        return;
    }

    protected void onAccessToken(String p1)
    {
        return;
    }

    public final boolean refreshToken()
    {
        this.tokenLock.lock();
        try {
            Throwable v0_1 = this.executeRefreshToken();
            this.tokenLock.unlock();
            return v0_1;
        } catch (Throwable v0_2) {
            this.tokenLock.unlock();
            throw v0_2;
        }
    }

    public final void setAccessToken(String p3)
    {
        this.tokenLock.lock();
        try {
            this.accessToken = p3;
            this.onAccessToken(p3);
            this.tokenLock.unlock();
            return;
        } catch (Throwable v0_2) {
            this.tokenLock.unlock();
            throw v0_2;
        }
    }
}
