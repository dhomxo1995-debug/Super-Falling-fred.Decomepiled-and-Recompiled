package com.google.api.client.auth.oauth2;
final class BearerToken$QueryParameterAccessMethod implements com.google.api.client.auth.oauth2.Credential$AccessMethod {

    BearerToken$QueryParameterAccessMethod()
    {
        return;
    }

    public String getAccessTokenFromRequest(com.google.api.client.http.HttpRequest p4)
    {
        String v1_1;
        Object v0 = p4.getUrl().get("access_token");
        if (v0 != null) {
            v1_1 = v0.toString();
        } else {
            v1_1 = 0;
        }
        return v1_1;
    }

    public void intercept(com.google.api.client.http.HttpRequest p3, String p4)
    {
        p3.getUrl().set("access_token", p4);
        return;
    }
}
