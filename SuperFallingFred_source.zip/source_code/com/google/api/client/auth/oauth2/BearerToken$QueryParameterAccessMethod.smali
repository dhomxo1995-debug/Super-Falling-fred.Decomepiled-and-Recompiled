.class final Lcom/google/api/client/auth/oauth2/BearerToken$QueryParameterAccessMethod;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    .registers 5
    invoke-virtual v4, Lcom/google/api/client/http/HttpRequest;->getUrl()Lcom/google/api/client/http/GenericUrl;
    move-result-object v1
    const-string v2, "access_token"
    invoke-virtual v1, v2, Lcom/google/api/client/http/GenericUrl;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    if-nez v0, +004h
    const/4 v1, 0
    return-object v1
    invoke-virtual v0, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v1
    goto -5h
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest; Ljava/lang/String;)V
    .registers 5
    invoke-virtual v3, Lcom/google/api/client/http/HttpRequest;->getUrl()Lcom/google/api/client/http/GenericUrl;
    move-result-object v0
    const-string v1, "access_token"
    invoke-virtual v0, v1, v4, Lcom/google/api/client/http/GenericUrl;->set(Ljava/lang/String; Ljava/lang/Object;)V
    return-void
.end method
