package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenRequest$RefreshTokenGrant extends com.google.api.client.auth.oauth2.draft10.AccessTokenRequest {
    public String refreshToken;

    public AccessTokenRequest$RefreshTokenGrant()
    {
        this.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.REFRESH_TOKEN;
        return;
    }

    public AccessTokenRequest$RefreshTokenGrant(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5, String p6, String p7)
    {
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$RefreshTokenGrant v1_1 = super(p2, p3, p4, p5, p6);
        v1_1.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.REFRESH_TOKEN;
        v1_1.refreshToken = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        return;
    }
}
