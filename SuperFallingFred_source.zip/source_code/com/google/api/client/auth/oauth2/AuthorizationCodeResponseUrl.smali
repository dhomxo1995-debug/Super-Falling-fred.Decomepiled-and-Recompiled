.class public Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
.super Lcom/google/api/client/http/GenericUrl;

.field private code:Ljava/lang/String;
.field private error:Ljava/lang/String;
.field private errorDescription:Ljava/lang/String;
.field private errorUri:Ljava/lang/String;
.field private state:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String;)V
    .registers 6
    const/4 v1, 1
    const/4 v2, 0
    invoke-direct v4, v5, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    iget-object v0, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->code Ljava/lang/String;
    if-nez v0, +00eh
    move v0, v1
    iget-object v3, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->error Ljava/lang/String;
    if-nez v3, +00bh
    move v3, v1
    if-eq v0, v3, +00ah
    invoke-static v1, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    return-void
    move v0, v2
    goto -ch
    move v3, v2
    goto -9h
    move v1, v2
    goto -9h
.end method

.method public final getCode()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->code Ljava/lang/String;
    return-object v0
.end method

.method public final getError()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->error Ljava/lang/String;
    return-object v0
.end method

.method public final getErrorDescription()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->errorDescription Ljava/lang/String;
    return-object v0
.end method

.method public final getErrorUri()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->errorUri Ljava/lang/String;
    return-object v0
.end method

.method public final getState()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->state Ljava/lang/String;
    return-object v0
.end method

.method public setCode(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->code Ljava/lang/String;
    return-object v0
.end method

.method public setError(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->error Ljava/lang/String;
    return-object v0
.end method

.method public setErrorDescription(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->errorDescription Ljava/lang/String;
    return-object v0
.end method

.method public setErrorUri(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->errorUri Ljava/lang/String;
    return-object v0
.end method

.method public setState(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeResponseUrl;->state Ljava/lang/String;
    return-object v0
.end method
