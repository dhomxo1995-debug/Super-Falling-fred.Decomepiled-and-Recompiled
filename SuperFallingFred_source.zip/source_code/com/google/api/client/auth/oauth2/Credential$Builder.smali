.class public Lcom/google/api/client/auth/oauth2/Credential$Builder;
.super Ljava/lang/Object;

.field private clientAuthentication:Lcom/google/api/client/http/HttpExecuteInterceptor;
.field private clock:Lcom/google/api/client/util/Clock;
.field private jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private final method:Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
.field private refreshListeners:Ljava/util/List;
.field private requestInitializer:Lcom/google/api/client/http/HttpRequestInitializer;
.field private tokenServerUrl:Lcom/google/api/client/http/GenericUrl;
.field private transport:Lcom/google/api/client/http/HttpTransport;

.method public constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    sget-object v0, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clock Lcom/google/api/client/util/Clock;
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->refreshListeners Ljava/util/List;
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    return-void
.end method

.method public addRefreshListener(Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->refreshListeners Ljava/util/List;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    invoke-interface v0, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    return-object v2
.end method

.method public build()Lcom/google/api/client/auth/oauth2/Credential;
    .registers 10
    new-instance v0, Lcom/google/api/client/auth/oauth2/Credential;
    iget-object v1, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iget-object v2, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v3, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    iget-object v4, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    if-nez v4, +00fh
    const/4 v4, 0
    iget-object v5, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    iget-object v6, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    iget-object v7, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->refreshListeners Ljava/util/List;
    iget-object v8, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clock Lcom/google/api/client/util/Clock;
    invoke-direct/range v0 ... v8, Lcom/google/api/client/auth/oauth2/Credential;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Lcom/google/api/client/http/HttpExecuteInterceptor; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/util/List; Lcom/google/api/client/util/Clock;)V
    return-object v0
    iget-object v4, v9, Lcom/google/api/client/auth/oauth2/Credential$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    invoke-virtual v4, Lcom/google/api/client/http/GenericUrl;->build()Ljava/lang/String;
    move-result-object v4
    goto -12h
.end method

.method public final getClientAuthentication()Lcom/google/api/client/http/HttpExecuteInterceptor;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public final getClock()Lcom/google/api/client/util/Clock;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clock Lcom/google/api/client/util/Clock;
    return-object v0
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getMethod()Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    return-object v0
.end method

.method public final getRefreshListeners()Ljava/util/List;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->refreshListeners Ljava/util/List;
    return-object v0
.end method

.method public final getRequestInitializer()Lcom/google/api/client/http/HttpRequestInitializer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public final getTokenServerUrl()Lcom/google/api/client/http/GenericUrl;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    return-object v0
.end method

.method public final getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public setClock(Lcom/google/api/client/util/Clock;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->clock Lcom/google/api/client/util/Clock;
    return-object v1
.end method

.method public setJsonFactory(Lcom/google/api/client/json/JsonFactory;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public setRefreshListeners(Ljava/util/List;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->refreshListeners Ljava/util/List;
    return-object v0
.end method

.method public setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public setTokenServerEncodedUrl(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 3
    if-nez v2, +006h
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    return-object v1
    new-instance v0, Lcom/google/api/client/http/GenericUrl;
    invoke-direct v0, v2, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    goto -8h
.end method

.method public setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->tokenServerUrl Lcom/google/api/client/http/GenericUrl;
    return-object v0
.end method

.method public setTransport(Lcom/google/api/client/http/HttpTransport;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method
