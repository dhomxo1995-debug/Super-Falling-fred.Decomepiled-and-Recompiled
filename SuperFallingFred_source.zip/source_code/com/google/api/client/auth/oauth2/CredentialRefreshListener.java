package com.google.api.client.auth.oauth2;
public interface CredentialRefreshListener {

    public abstract void onTokenErrorResponse(com.google.api.client.auth.oauth2.Credential p0, com.google.api.client.auth.oauth2.TokenErrorResponse p1);

    public abstract void onTokenResponse(com.google.api.client.auth.oauth2.Credential p0, com.google.api.client.auth.oauth2.TokenResponse p1);
}
