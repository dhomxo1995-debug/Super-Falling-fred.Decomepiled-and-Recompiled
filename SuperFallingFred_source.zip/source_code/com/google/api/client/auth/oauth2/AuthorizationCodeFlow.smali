.class public Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;
.super Ljava/lang/Object;

.field private final authorizationServerEncodedUrl:Ljava/lang/String;
.field private final clientAuthentication:Lcom/google/api/client/http/HttpExecuteInterceptor;
.field private final clientId:Ljava/lang/String;
.field private final clock:Lcom/google/api/client/util/Clock;
.field private final credentialStore:Lcom/google/api/client/auth/oauth2/CredentialStore;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private final method:Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
.field private final requestInitializer:Lcom/google/api/client/http/HttpRequestInitializer;
.field private scopes:Ljava/lang/String;
.field private final tokenServerEncodedUrl:Ljava/lang/String;
.field private final transport:Lcom/google/api/client/http/HttpTransport;

.method protected constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpExecuteInterceptor; Ljava/lang/String; Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/lang/String;)V
    .registers 23
    sget-object v11, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    move-object v0, v12
    move-object v1, v13
    move-object v2, v14
    move-object v3, v15
    move-object/from16 v4, v16
    move-object/from16 v5, v17
    move-object/from16 v6, v18
    move-object/from16 v7, v19
    move-object/from16 v8, v20
    move-object/from16 v9, v21
    move-object/from16 v10, v22
    invoke-direct/range v0 ... v11, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpExecuteInterceptor; Ljava/lang/String; Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/lang/String; Lcom/google/api/client/util/Clock;)V
    return-void
.end method

.method protected constructor <init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod; Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpExecuteInterceptor; Ljava/lang/String; Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore; Lcom/google/api/client/http/HttpRequestInitializer; Ljava/lang/String; Lcom/google/api/client/util/Clock;)V
    .registers 13
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/HttpTransport;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-static v5, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/GenericUrl;
    invoke-virtual v0, Lcom/google/api/client/http/GenericUrl;->build()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->tokenServerEncodedUrl Ljava/lang/String;
    iput-object v6, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-static v7, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientId Ljava/lang/String;
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->authorizationServerEncodedUrl Ljava/lang/String;
    iput-object v10, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    iput-object v9, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    iput-object v11, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->scopes Ljava/lang/String;
    invoke-static v12, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clock Lcom/google/api/client/util/Clock;
    return-void
.end method

.method private newCredential(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 5
    new-instance v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    invoke-direct v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;-><init>(Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;)V
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setTransport(Lcom/google/api/client/http/HttpTransport;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setJsonFactory(Lcom/google/api/client/json/JsonFactory;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->tokenServerEncodedUrl Ljava/lang/String;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setTokenServerEncodedUrl(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clock Lcom/google/api/client/util/Clock;
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/Credential$Builder;->setClock(Lcom/google/api/client/util/Clock;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    move-result-object v0
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    if-eqz v1, +00ch
    new-instance v1, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    invoke-direct v1, v4, v2, Lcom/google/api/client/auth/oauth2/CredentialStoreRefreshListener;-><init>(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/CredentialStore;)V
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/Credential$Builder;->addRefreshListener(Lcom/google/api/client/auth/oauth2/CredentialRefreshListener;)Lcom/google/api/client/auth/oauth2/Credential$Builder;
    invoke-virtual v0, Lcom/google/api/client/auth/oauth2/Credential$Builder;->build()Lcom/google/api/client/auth/oauth2/Credential;
    move-result-object v1
    return-object v1
.end method

.method public createAndStoreCredential(Lcom/google/api/client/auth/oauth2/TokenResponse; Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 5
    invoke-direct v2, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->newCredential(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    move-result-object v1
    invoke-virtual v1, v3, Lcom/google/api/client/auth/oauth2/Credential;->setFromTokenResponse(Lcom/google/api/client/auth/oauth2/TokenResponse;)Lcom/google/api/client/auth/oauth2/Credential;
    move-result-object v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    if-eqz v1, +007h
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    invoke-interface v1, v4, v0, Lcom/google/api/client/auth/oauth2/CredentialStore;->store(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    return-object v0
.end method

.method public final getAuthorizationServerEncodedUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->authorizationServerEncodedUrl Ljava/lang/String;
    return-object v0
.end method

.method public final getClientAuthentication()Lcom/google/api/client/http/HttpExecuteInterceptor;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    return-object v0
.end method

.method public final getClientId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientId Ljava/lang/String;
    return-object v0
.end method

.method public final getClock()Lcom/google/api/client/util/Clock;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clock Lcom/google/api/client/util/Clock;
    return-object v0
.end method

.method public final getCredentialStore()Lcom/google/api/client/auth/oauth2/CredentialStore;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    return-object v0
.end method

.method public final getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public final getMethod()Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->method Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;
    return-object v0
.end method

.method public final getRequestInitializer()Lcom/google/api/client/http/HttpRequestInitializer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    return-object v0
.end method

.method public final getScopes()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->scopes Ljava/lang/String;
    return-object v0
.end method

.method public final getTokenServerEncodedUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->tokenServerEncodedUrl Ljava/lang/String;
    return-object v0
.end method

.method public final getTransport()Lcom/google/api/client/http/HttpTransport;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->transport Lcom/google/api/client/http/HttpTransport;
    return-object v0
.end method

.method public loadCredential(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    .registers 5
    const/4 v1, 0
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    if-nez v2, +004h
    move-object v0, v1
    return-object v0
    invoke-direct v3, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->newCredential(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/Credential;
    move-result-object v0
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->credentialStore Lcom/google/api/client/auth/oauth2/CredentialStore;
    invoke-interface v2, v4, v0, Lcom/google/api/client/auth/oauth2/CredentialStore;->load(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)Z
    move-result v2
    if-nez v2, -00bh
    move-object v0, v1
    goto -eh
.end method

.method public newAuthorizationUrl()Lcom/google/api/client/auth/oauth2/AuthorizationCodeRequestUrl;
    .registers 5
    new-instance v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeRequestUrl;
    iget-object v1, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->authorizationServerEncodedUrl Ljava/lang/String;
    iget-object v2, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientId Ljava/lang/String;
    invoke-direct v0, v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeRequestUrl;-><init>(Ljava/lang/String; Ljava/lang/String;)V
    const/4 v1, 1
    new-array v1, v1, [Ljava/lang/String;
    const/4 v2, 0
    iget-object v3, v4, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->scopes Ljava/lang/String;
    aput-object v3, v1, v2
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeRequestUrl;->setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeRequestUrl;
    move-result-object v0
    return-object v0
.end method

.method public newTokenRequest(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 7
    new-instance v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->transport Lcom/google/api/client/http/HttpTransport;
    iget-object v2, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    new-instance v3, Lcom/google/api/client/http/GenericUrl;
    iget-object v4, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->tokenServerEncodedUrl Ljava/lang/String;
    invoke-direct v3, v4, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    invoke-direct v0, v1, v2, v3, v6, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Ljava/lang/String;)V
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    iget-object v1, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->requestInitializer Lcom/google/api/client/http/HttpRequestInitializer;
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    const/4 v1, 1
    new-array v1, v1, [Ljava/lang/String;
    const/4 v2, 0
    iget-object v3, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeFlow;->scopes Ljava/lang/String;
    aput-object v3, v1, v2
    invoke-virtual v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method
