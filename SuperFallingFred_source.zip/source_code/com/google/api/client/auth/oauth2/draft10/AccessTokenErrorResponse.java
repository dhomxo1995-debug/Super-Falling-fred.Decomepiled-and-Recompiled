package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenErrorResponse extends com.google.api.client.util.GenericData {
    public String error;
    public String errorDescription;
    public String errorUri;

    public AccessTokenErrorResponse()
    {
        return;
    }

    public final com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError getErrorCodeIfKnown()
    {
        IllegalArgumentException v0_3;
        if (this.error == null) {
            v0_3 = 0;
        } else {
            try {
                v0_3 = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.valueOf(this.error.toUpperCase());
            } catch (IllegalArgumentException v0) {
            }
        }
        return v0_3;
    }
}
