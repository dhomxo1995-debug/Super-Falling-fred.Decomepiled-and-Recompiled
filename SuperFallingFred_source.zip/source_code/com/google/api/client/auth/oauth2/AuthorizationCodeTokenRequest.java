package com.google.api.client.auth.oauth2;
public class AuthorizationCodeTokenRequest extends com.google.api.client.auth.oauth2.TokenRequest {
    private String code;
    private String redirectUri;

    public AuthorizationCodeTokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, com.google.api.client.http.GenericUrl p4, String p5)
    {
        super(p2, p3, p4, "authorization_code");
        super.setCode(p5);
        return;
    }

    public final String getCode()
    {
        return this.code;
    }

    public final String getRedirectUri()
    {
        return this.redirectUri;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setClientAuthentication(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p2)
    {
        return this.setClientAuthentication(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setCode(String p2)
    {
        this.code = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setGrantType(String p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setGrantType(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setGrantType(String p2)
    {
        return this.setGrantType(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setRedirectUri(String p1)
    {
        this.redirectUri = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setRequestInitializer(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p2)
    {
        return this.setRequestInitializer(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setScopes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setScopes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setScopes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setScopes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setScopes(Iterable p2)
    {
        return this.setScopes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setScopes(String[] p2)
    {
        return this.setScopes(p2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest setTokenServerUrl(com.google.api.client.http.GenericUrl p2)
    {
        return ((com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest) super.setTokenServerUrl(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setTokenServerUrl(com.google.api.client.http.GenericUrl p2)
    {
        return this.setTokenServerUrl(p2);
    }
}
