.class public Lcom/google/api/client/auth/oauth2/TokenResponse;
.super Lcom/google/api/client/json/GenericJson;

.field private accessToken:Ljava/lang/String;
.field private expiresInSeconds:Ljava/lang/Long;
.field private refreshToken:Ljava/lang/String;
.field private scope:Ljava/lang/String;
.field private tokenType:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/json/GenericJson;-><init>()V
    return-void
.end method

.method public final getAccessToken()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->accessToken Ljava/lang/String;
    return-object v0
.end method

.method public final getExpiresInSeconds()Ljava/lang/Long;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->expiresInSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public final getRefreshToken()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->refreshToken Ljava/lang/String;
    return-object v0
.end method

.method public final getScope()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->scope Ljava/lang/String;
    return-object v0
.end method

.method public final getTokenType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->tokenType Ljava/lang/String;
    return-object v0
.end method

.method public setAccessToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->accessToken Ljava/lang/String;
    return-object v1
.end method

.method public setExpiresInSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenResponse;->expiresInSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public setRefreshToken(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenResponse;->refreshToken Ljava/lang/String;
    return-object v0
.end method

.method public setScope(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenResponse;->scope Ljava/lang/String;
    return-object v0
.end method

.method public setTokenType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenResponse;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponse;->tokenType Ljava/lang/String;
    return-object v1
.end method
