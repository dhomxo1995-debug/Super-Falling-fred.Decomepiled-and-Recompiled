package com.google.api.client.auth.oauth2.draft10;
synthetic class AccessProtectedResource$1 {
    static final synthetic int[] $SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method;

    static AccessProtectedResource$1()
    {
        NoSuchFieldError v0_4 = new int[com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.values().length];
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$1.$SwitchMap$com$google$api$client$auth$oauth2$draft10$AccessProtectedResource$Method = v0_4;
        try {
            com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.AUTHORIZATION_HEADER.ordinal()[int v1_5] = 1;
            try {
                com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.QUERY_PARAMETER.ordinal()[int v1_1] = 2;
                try {
                    com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.FORM_ENCODED_BODY.ordinal()[int v1_3] = 3;
                } catch (NoSuchFieldError v0) {
                }
                return;
            } catch (NoSuchFieldError v0) {
            }
        } catch (NoSuchFieldError v0) {
        }
    }
}
