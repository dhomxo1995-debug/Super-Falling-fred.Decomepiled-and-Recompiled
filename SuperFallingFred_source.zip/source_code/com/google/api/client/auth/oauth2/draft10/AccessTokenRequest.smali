.class public Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;
.super Lcom/google/api/client/util/GenericData;

.field public authorizationServerUrl:Ljava/lang/String;
.field public clientId:Ljava/lang/String;
.field public clientSecret:Ljava/lang/String;
.field public grantType:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
.field public jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field public scope:Ljava/lang/String;
.field public transport:Lcom/google/api/client/http/HttpTransport;
.field public useBasicAuthorization:Z

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Lcom/google/api/client/util/GenericData;-><init>()V
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;->NONE Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->grantType Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest$GrantType;
    return-void
.end method

.method protected constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String;)V
    .registers 5
    invoke-direct v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/http/HttpTransport;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->authorizationServerUrl Ljava/lang/String;
    return-void
.end method

.method protected constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String;)V
    .registers 6
    invoke-direct v1, v2, v3, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String;)V
    invoke-static v5, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->clientSecret Ljava/lang/String;
    return-void
.end method

.method public constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    .registers 7
    invoke-direct v1, v2, v3, v4, v6, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Ljava/lang/String; Ljava/lang/String;)V
    invoke-static v5, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->clientId Ljava/lang/String;
    return-void
.end method

.method public final execute()Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->executeUnparsed()Lcom/google/api/client/http/HttpResponse;
    move-result-object v0
    const-class v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;
    invoke-virtual v0, v1, Lcom/google/api/client/http/HttpResponse;->parseAs(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;
    return-object v0
.end method

.method public final executeUnparsed()Lcom/google/api/client/http/HttpResponse;
    .registers 5
    iget-object v1, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-virtual v1, Lcom/google/api/client/http/HttpTransport;->createRequestFactory()Lcom/google/api/client/http/HttpRequestFactory;
    move-result-object v1
    new-instance v2, Lcom/google/api/client/http/GenericUrl;
    iget-object v3, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->authorizationServerUrl Ljava/lang/String;
    invoke-direct v2, v3, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    new-instance v3, Lcom/google/api/client/http/UrlEncodedContent;
    invoke-direct v3, v4, Lcom/google/api/client/http/UrlEncodedContent;-><init>(Ljava/lang/Object;)V
    invoke-virtual v1, v2, v3, Lcom/google/api/client/http/HttpRequestFactory;->buildPostRequest(Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpContent;)Lcom/google/api/client/http/HttpRequest;
    move-result-object v0
    new-instance v1, Lcom/google/api/client/http/json/JsonHttpParser;
    iget-object v2, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    invoke-direct v1, v2, Lcom/google/api/client/http/json/JsonHttpParser;-><init>(Lcom/google/api/client/json/JsonFactory;)V
    invoke-virtual v0, v1, Lcom/google/api/client/http/HttpRequest;->addParser(Lcom/google/api/client/http/HttpParser;)V
    iget-boolean v1, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->useBasicAuthorization Z
    if-eqz v1, +012h
    invoke-virtual v0, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v1
    iget-object v2, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->clientId Ljava/lang/String;
    iget-object v3, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->clientSecret Ljava/lang/String;
    invoke-virtual v1, v2, v3, Lcom/google/api/client/http/HttpHeaders;->setBasicAuthentication(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v0, Lcom/google/api/client/http/HttpRequest;->execute()Lcom/google/api/client/http/HttpResponse;
    move-result-object v1
    return-object v1
    const-string v1, "client_secret"
    iget-object v2, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->clientSecret Ljava/lang/String;
    invoke-virtual v4, v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenRequest;->put(Ljava/lang/String; Ljava/lang/Object;)Ljava/lang/Object;
    goto -ch
.end method
