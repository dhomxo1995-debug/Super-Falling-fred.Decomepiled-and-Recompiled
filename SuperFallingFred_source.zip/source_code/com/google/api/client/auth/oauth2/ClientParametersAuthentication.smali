.class public Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpRequestInitializer;
.implements Lcom/google/api/client/http/HttpExecuteInterceptor;

.field private final clientId:Ljava/lang/String;
.field private final clientSecret:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String; Ljava/lang/String;)V
    .registers 4
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientId Ljava/lang/String;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientSecret Ljava/lang/String;
    return-void
.end method

.method public final getClientId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientId Ljava/lang/String;
    return-object v0
.end method

.method public final getClientSecret()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientSecret Ljava/lang/String;
    return-object v0
.end method

.method public initialize(Lcom/google/api/client/http/HttpRequest;)V
    .registers 2
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setInterceptor(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/http/HttpRequest;
    return-void
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest;)V
    .registers 5
    invoke-static v4, Lcom/google/api/client/http/UrlEncodedContent;->getContent(Lcom/google/api/client/http/HttpRequest;)Lcom/google/api/client/http/UrlEncodedContent;
    move-result-object v1
    invoke-virtual v1, Lcom/google/api/client/http/UrlEncodedContent;->getData()Ljava/lang/Object;
    move-result-object v1
    invoke-static v1, Lcom/google/api/client/util/Data;->mapOf(Ljava/lang/Object;)Ljava/util/Map;
    move-result-object v0
    const-string v1, "client_id"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientId Ljava/lang/String;
    invoke-interface v0, v1, v2, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    const-string v1, "client_secret"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/ClientParametersAuthentication;->clientSecret Ljava/lang/String;
    invoke-interface v0, v1, v2, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
.end method
