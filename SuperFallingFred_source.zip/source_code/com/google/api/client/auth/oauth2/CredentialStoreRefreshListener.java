package com.google.api.client.auth.oauth2;
public final class CredentialStoreRefreshListener implements com.google.api.client.auth.oauth2.CredentialRefreshListener {
    private final com.google.api.client.auth.oauth2.CredentialStore credentialStore;
    private final String userId;

    public CredentialStoreRefreshListener(String p2, com.google.api.client.auth.oauth2.CredentialStore p3)
    {
        this.userId = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        this.credentialStore = ((com.google.api.client.auth.oauth2.CredentialStore) com.google.common.base.Preconditions.checkNotNull(p3));
        return;
    }

    public com.google.api.client.auth.oauth2.CredentialStore getCredentialStore()
    {
        return this.credentialStore;
    }

    public void makePersistent(com.google.api.client.auth.oauth2.Credential p3)
    {
        this.credentialStore.store(this.userId, p3);
        return;
    }

    public void onTokenErrorResponse(com.google.api.client.auth.oauth2.Credential p1, com.google.api.client.auth.oauth2.TokenErrorResponse p2)
    {
        this.makePersistent(p1);
        return;
    }

    public void onTokenResponse(com.google.api.client.auth.oauth2.Credential p1, com.google.api.client.auth.oauth2.TokenResponse p2)
    {
        this.makePersistent(p1);
        return;
    }
}
