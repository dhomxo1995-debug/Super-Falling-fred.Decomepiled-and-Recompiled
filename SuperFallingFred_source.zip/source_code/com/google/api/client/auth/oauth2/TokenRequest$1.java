package com.google.api.client.auth.oauth2;
 class TokenRequest$1 implements com.google.api.client.http.HttpRequestInitializer {
    final synthetic com.google.api.client.auth.oauth2.TokenRequest this$0;

    TokenRequest$1(com.google.api.client.auth.oauth2.TokenRequest p1)
    {
        this.this$0 = p1;
        return;
    }

    public void initialize(com.google.api.client.http.HttpRequest p3)
    {
        if (this.this$0.requestInitializer != null) {
            this.this$0.requestInitializer.initialize(p3);
        }
        p3.setInterceptor(new com.google.api.client.auth.oauth2.TokenRequest$1$1(this, p3.getInterceptor()));
        return;
    }
}
