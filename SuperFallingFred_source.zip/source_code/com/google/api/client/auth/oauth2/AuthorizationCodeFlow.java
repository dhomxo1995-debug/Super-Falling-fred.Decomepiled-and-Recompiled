package com.google.api.client.auth.oauth2;
public class AuthorizationCodeFlow {
    private final String authorizationServerEncodedUrl;
    private final com.google.api.client.http.HttpExecuteInterceptor clientAuthentication;
    private final String clientId;
    private final com.google.api.client.util.Clock clock;
    private final com.google.api.client.auth.oauth2.CredentialStore credentialStore;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    private final com.google.api.client.auth.oauth2.Credential$AccessMethod method;
    private final com.google.api.client.http.HttpRequestInitializer requestInitializer;
    private String scopes;
    private final String tokenServerEncodedUrl;
    private final com.google.api.client.http.HttpTransport transport;

    protected AuthorizationCodeFlow(com.google.api.client.auth.oauth2.Credential$AccessMethod p13, com.google.api.client.http.HttpTransport p14, com.google.api.client.json.JsonFactory p15, com.google.api.client.http.GenericUrl p16, com.google.api.client.http.HttpExecuteInterceptor p17, String p18, String p19, com.google.api.client.auth.oauth2.CredentialStore p20, com.google.api.client.http.HttpRequestInitializer p21, String p22)
    {
        this(p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, com.google.api.client.util.Clock.SYSTEM);
        return;
    }

    protected AuthorizationCodeFlow(com.google.api.client.auth.oauth2.Credential$AccessMethod p2, com.google.api.client.http.HttpTransport p3, com.google.api.client.json.JsonFactory p4, com.google.api.client.http.GenericUrl p5, com.google.api.client.http.HttpExecuteInterceptor p6, String p7, String p8, com.google.api.client.auth.oauth2.CredentialStore p9, com.google.api.client.http.HttpRequestInitializer p10, String p11, com.google.api.client.util.Clock p12)
    {
        this.method = ((com.google.api.client.auth.oauth2.Credential$AccessMethod) com.google.common.base.Preconditions.checkNotNull(p2));
        this.transport = ((com.google.api.client.http.HttpTransport) com.google.common.base.Preconditions.checkNotNull(p3));
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p4));
        this.tokenServerEncodedUrl = ((com.google.api.client.http.GenericUrl) com.google.common.base.Preconditions.checkNotNull(p5)).build();
        this.clientAuthentication = p6;
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        this.authorizationServerEncodedUrl = ((String) com.google.common.base.Preconditions.checkNotNull(p8));
        this.requestInitializer = p10;
        this.credentialStore = p9;
        this.scopes = p11;
        this.clock = ((com.google.api.client.util.Clock) com.google.common.base.Preconditions.checkNotNull(p12));
        return;
    }

    private com.google.api.client.auth.oauth2.Credential newCredential(String p4)
    {
        com.google.api.client.auth.oauth2.Credential$Builder v0 = new com.google.api.client.auth.oauth2.Credential$Builder(this.method).setTransport(this.transport).setJsonFactory(this.jsonFactory).setTokenServerEncodedUrl(this.tokenServerEncodedUrl).setClientAuthentication(this.clientAuthentication).setRequestInitializer(this.requestInitializer).setClock(this.clock);
        if (this.credentialStore != null) {
            v0.addRefreshListener(new com.google.api.client.auth.oauth2.CredentialStoreRefreshListener(p4, this.credentialStore));
        }
        return v0.build();
    }

    public com.google.api.client.auth.oauth2.Credential createAndStoreCredential(com.google.api.client.auth.oauth2.TokenResponse p3, String p4)
    {
        com.google.api.client.auth.oauth2.Credential v0 = this.newCredential(p4).setFromTokenResponse(p3);
        if (this.credentialStore != null) {
            this.credentialStore.store(p4, v0);
        }
        return v0;
    }

    public final String getAuthorizationServerEncodedUrl()
    {
        return this.authorizationServerEncodedUrl;
    }

    public final com.google.api.client.http.HttpExecuteInterceptor getClientAuthentication()
    {
        return this.clientAuthentication;
    }

    public final String getClientId()
    {
        return this.clientId;
    }

    public final com.google.api.client.util.Clock getClock()
    {
        return this.clock;
    }

    public final com.google.api.client.auth.oauth2.CredentialStore getCredentialStore()
    {
        return this.credentialStore;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.auth.oauth2.Credential$AccessMethod getMethod()
    {
        return this.method;
    }

    public final com.google.api.client.http.HttpRequestInitializer getRequestInitializer()
    {
        return this.requestInitializer;
    }

    public final String getScopes()
    {
        return this.scopes;
    }

    public final String getTokenServerEncodedUrl()
    {
        return this.tokenServerEncodedUrl;
    }

    public final com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public com.google.api.client.auth.oauth2.Credential loadCredential(String p4)
    {
        int v0;
        if (this.credentialStore != null) {
            v0 = this.newCredential(p4);
            if (!this.credentialStore.load(p4, v0)) {
                v0 = 0;
            }
        } else {
            v0 = 0;
        }
        return v0;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl newAuthorizationUrl()
    {
        com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl v0_2 = new com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl(this.authorizationServerEncodedUrl, this.clientId);
        String[] v1_2 = new String[1];
        v1_2[0] = this.scopes;
        return v0_2.setScopes(v1_2);
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest newTokenRequest(String p6)
    {
        com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest v0_1 = new com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest(this.transport, this.jsonFactory, new com.google.api.client.http.GenericUrl(this.tokenServerEncodedUrl), p6).setClientAuthentication(this.clientAuthentication).setRequestInitializer(this.requestInitializer);
        String[] v1_3 = new String[1];
        v1_3[0] = this.scopes;
        return v0_1.setScopes(v1_3);
    }
}
