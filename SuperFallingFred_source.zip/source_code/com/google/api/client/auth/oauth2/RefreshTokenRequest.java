package com.google.api.client.auth.oauth2;
public class RefreshTokenRequest extends com.google.api.client.auth.oauth2.TokenRequest {
    private String refreshToken;

    public RefreshTokenRequest(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, com.google.api.client.http.GenericUrl p4, String p5)
    {
        super(p2, p3, p4, "refresh_token");
        super.setRefreshToken(p5);
        return;
    }

    public final String getRefreshToken()
    {
        return this.refreshToken;
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setClientAuthentication(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setClientAuthentication(com.google.api.client.http.HttpExecuteInterceptor p2)
    {
        return this.setClientAuthentication(p2);
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setGrantType(String p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setGrantType(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setGrantType(String p2)
    {
        return this.setGrantType(p2);
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setRefreshToken(String p2)
    {
        this.refreshToken = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setRequestInitializer(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p2)
    {
        return this.setRequestInitializer(p2);
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setScopes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setScopes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.RefreshTokenRequest setScopes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setScopes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setScopes(Iterable p2)
    {
        return this.setScopes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setScopes(String[] p2)
    {
        return this.setScopes(p2);
    }

    public com.google.api.client.auth.oauth2.RefreshTokenRequest setTokenServerUrl(com.google.api.client.http.GenericUrl p2)
    {
        return ((com.google.api.client.auth.oauth2.RefreshTokenRequest) super.setTokenServerUrl(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.TokenRequest setTokenServerUrl(com.google.api.client.http.GenericUrl p2)
    {
        return this.setTokenServerUrl(p2);
    }
}
