.class public Lcom/google/api/client/auth/oauth2/TokenResponseException;
.super Lcom/google/api/client/http/HttpResponseException;

.field private static final serialVersionUID:J
.field private final varargs details:Lcom/google/api/client/auth/oauth2/TokenErrorResponse;

.method private constructor <init>(Lcom/google/api/client/http/HttpResponse; Lcom/google/api/client/auth/oauth2/TokenErrorResponse; Ljava/lang/String;)V
    .registers 4
    invoke-direct v0, v1, v3, Lcom/google/api/client/http/HttpResponseException;-><init>(Lcom/google/api/client/http/HttpResponse; Ljava/lang/String;)V
    iput-object v2, v0, Lcom/google/api/client/auth/oauth2/TokenResponseException;->details Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    return-void
.end method

.method public static from(Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/HttpResponse;)Lcom/google/api/client/auth/oauth2/TokenResponseException;
    .registers 12
    invoke-static v10, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    const/4 v3, 0
    const/4 v2, 0
    invoke-virtual v11, Lcom/google/api/client/http/HttpResponse;->getContentType()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v11, Lcom/google/api/client/http/HttpResponse;->isSuccessStatusCode()Z
    move-result v6
    if-nez v6, +044h
    if-eqz v1, +042h
    sget-object v6, Lcom/google/api/client/json/Json;->MEDIA_TYPE Ljava/lang/String;
    invoke-static v6, v1, Lcom/google/api/client/http/HttpMediaType;->equalsIgnoreParameters(Ljava/lang/String; Ljava/lang/String;)Z
    move-result v6
    if-eqz v6, +03ah
    new-instance v6, Lcom/google/api/client/json/JsonObjectParser;
    invoke-direct v6, v10, Lcom/google/api/client/json/JsonObjectParser;-><init>(Lcom/google/api/client/json/JsonFactory;)V
    invoke-virtual v11, Lcom/google/api/client/http/HttpResponse;->getContent()Ljava/io/InputStream;
    move-result-object v7
    invoke-virtual v11, Lcom/google/api/client/http/HttpResponse;->getContentCharset()Ljava/nio/charset/Charset;
    move-result-object v8
    const-class v9, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    invoke-virtual v6, v7, v8, v9, Lcom/google/api/client/json/JsonObjectParser;->parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v6
    move-object v0, v6
    check-cast v0, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    move-object v3, v0
    invoke-virtual v3, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->toPrettyString()Ljava/lang/String;
    move-result-object v2
    invoke-static v11, Lcom/google/api/client/http/HttpResponseException;->computeMessageBuffer(Lcom/google/api/client/http/HttpResponse;)Ljava/lang/StringBuilder;
    move-result-object v5
    invoke-static v2, Lcom/google/common/base/Strings;->isNullOrEmpty(Ljava/lang/String;)Z
    move-result v6
    if-nez v6, +00bh
    sget-object v6, Lcom/google/api/client/util/StringUtils;->LINE_SEPARATOR Ljava/lang/String;
    invoke-virtual v5, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v6, Lcom/google/api/client/auth/oauth2/TokenResponseException;
    invoke-virtual v5, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v7
    invoke-direct v6, v11, v3, v7, Lcom/google/api/client/auth/oauth2/TokenResponseException;-><init>(Lcom/google/api/client/http/HttpResponse; Lcom/google/api/client/auth/oauth2/TokenErrorResponse; Ljava/lang/String;)V
    return-object v6
    invoke-virtual v11, Lcom/google/api/client/http/HttpResponse;->parseAsString()Ljava/lang/String;
    move-result-object v2
    goto -21h
    move-exception v4
    invoke-virtual v4, Ljava/io/IOException;->printStackTrace()V
    goto -26h
.end method

.method public final getDetails()Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenResponseException;->details Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    return-object v0
.end method
