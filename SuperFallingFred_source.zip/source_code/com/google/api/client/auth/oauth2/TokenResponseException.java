package com.google.api.client.auth.oauth2;
public class TokenResponseException extends com.google.api.client.http.HttpResponseException {
    private static final long serialVersionUID = 4020689092957439244;
    private final transient com.google.api.client.auth.oauth2.TokenErrorResponse details;

    private TokenResponseException(com.google.api.client.http.HttpResponse p1, com.google.api.client.auth.oauth2.TokenErrorResponse p2, String p3)
    {
        super(p1, p3);
        super.details = p2;
        return;
    }

    public static com.google.api.client.auth.oauth2.TokenResponseException from(com.google.api.client.json.JsonFactory p10, com.google.api.client.http.HttpResponse p11)
    {
        com.google.common.base.Preconditions.checkNotNull(p10);
        com.google.api.client.auth.oauth2.TokenErrorResponse v3 = 0;
        String v2 = 0;
        String v1 = p11.getContentType();
        try {
            if ((p11.isSuccessStatusCode()) || ((v1 == null) || (!com.google.api.client.http.HttpMediaType.equalsIgnoreParameters(com.google.api.client.json.Json.MEDIA_TYPE, v1)))) {
                v2 = p11.parseAsString();
            } else {
                v3 = ((com.google.api.client.auth.oauth2.TokenErrorResponse) new com.google.api.client.json.JsonObjectParser(p10).parseAndClose(p11.getContent(), p11.getContentCharset(), com.google.api.client.auth.oauth2.TokenErrorResponse));
                v2 = v3.toPrettyString();
            }
        } catch (java.io.IOException v4) {
            v4.printStackTrace();
        }
        StringBuilder v5 = com.google.api.client.http.HttpResponseException.computeMessageBuffer(p11);
        if (!com.google.common.base.Strings.isNullOrEmpty(v2)) {
            v5.append(com.google.api.client.util.StringUtils.LINE_SEPARATOR).append(v2);
        }
        return new com.google.api.client.auth.oauth2.TokenResponseException(p11, v3, v5.toString());
    }

    public final com.google.api.client.auth.oauth2.TokenErrorResponse getDetails()
    {
        return this.details;
    }
}
