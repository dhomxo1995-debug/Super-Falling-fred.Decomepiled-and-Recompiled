package com.google.api.client.auth.oauth2;
public class Credential implements com.google.api.client.http.HttpExecuteInterceptor, com.google.api.client.http.HttpRequestInitializer, com.google.api.client.http.HttpUnsuccessfulResponseHandler {
    static final java.util.logging.Logger LOGGER;
    private String accessToken;
    private final com.google.api.client.http.HttpExecuteInterceptor clientAuthentication;
    private final com.google.api.client.util.Clock clock;
    private Long expirationTimeMilliseconds;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    private final java.util.concurrent.locks.Lock lock;
    private final com.google.api.client.auth.oauth2.Credential$AccessMethod method;
    private final java.util.List refreshListeners;
    private String refreshToken;
    private final com.google.api.client.http.HttpRequestInitializer requestInitializer;
    private final String tokenServerEncodedUrl;
    private final com.google.api.client.http.HttpTransport transport;

    static Credential()
    {
        com.google.api.client.auth.oauth2.Credential.LOGGER = java.util.logging.Logger.getLogger(com.google.api.client.auth.oauth2.Credential.getName());
        return;
    }

    public Credential(com.google.api.client.auth.oauth2.Credential$AccessMethod p9)
    {
        this(p9, 0, 0, 0, 0, 0, 0);
        return;
    }

    protected Credential(com.google.api.client.auth.oauth2.Credential$AccessMethod p10, com.google.api.client.http.HttpTransport p11, com.google.api.client.json.JsonFactory p12, String p13, com.google.api.client.http.HttpExecuteInterceptor p14, com.google.api.client.http.HttpRequestInitializer p15, java.util.List p16)
    {
        this(p10, p11, p12, p13, p14, p15, p16, com.google.api.client.util.Clock.SYSTEM);
        return;
    }

    protected Credential(com.google.api.client.auth.oauth2.Credential$AccessMethod p2, com.google.api.client.http.HttpTransport p3, com.google.api.client.json.JsonFactory p4, String p5, com.google.api.client.http.HttpExecuteInterceptor p6, com.google.api.client.http.HttpRequestInitializer p7, java.util.List p8, com.google.api.client.util.Clock p9)
    {
        com.google.api.client.util.Clock v0_1;
        this.lock = new java.util.concurrent.locks.ReentrantLock();
        this.method = ((com.google.api.client.auth.oauth2.Credential$AccessMethod) com.google.common.base.Preconditions.checkNotNull(p2));
        this.transport = p3;
        this.jsonFactory = p4;
        this.tokenServerEncodedUrl = p5;
        this.clientAuthentication = p6;
        this.requestInitializer = p7;
        if (p8 != null) {
            v0_1 = java.util.Collections.unmodifiableList(p8);
        } else {
            v0_1 = java.util.Collections.emptyList();
        }
        this.refreshListeners = v0_1;
        this.clock = ((com.google.api.client.util.Clock) com.google.common.base.Preconditions.checkNotNull(p9));
        return;
    }

    protected com.google.api.client.auth.oauth2.TokenResponse executeRefreshToken()
    {
        com.google.api.client.auth.oauth2.TokenResponse v0_3;
        if (this.refreshToken != null) {
            v0_3 = new com.google.api.client.auth.oauth2.RefreshTokenRequest(this.transport, this.jsonFactory, new com.google.api.client.http.GenericUrl(this.tokenServerEncodedUrl), this.refreshToken).setClientAuthentication(this.clientAuthentication).setRequestInitializer(this.requestInitializer).execute();
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }

    public final String getAccessToken()
    {
        this.lock.lock();
        try {
            Throwable v0_1 = this.accessToken;
            this.lock.unlock();
            return v0_1;
        } catch (Throwable v0_2) {
            this.lock.unlock();
            throw v0_2;
        }
    }

    public final com.google.api.client.http.HttpExecuteInterceptor getClientAuthentication()
    {
        return this.clientAuthentication;
    }

    public final com.google.api.client.util.Clock getClock()
    {
        return this.clock;
    }

    public final Long getExpirationTimeMilliseconds()
    {
        this.lock.lock();
        try {
            Throwable v0_1 = this.expirationTimeMilliseconds;
            this.lock.unlock();
            return v0_1;
        } catch (Throwable v0_2) {
            this.lock.unlock();
            throw v0_2;
        }
    }

    public final Long getExpiresInSeconds()
    {
        this.lock.lock();
        try {
            Long v0_3;
            if (this.expirationTimeMilliseconds != null) {
                v0_3 = Long.valueOf(((this.expirationTimeMilliseconds.longValue() - this.clock.currentTimeMillis()) / 1000));
                this.lock.unlock();
            } else {
                v0_3 = 0;
                this.lock.unlock();
            }
        } catch (Long v0_4) {
            this.lock.unlock();
            throw v0_4;
        }
        return v0_3;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.auth.oauth2.Credential$AccessMethod getMethod()
    {
        return this.method;
    }

    public final java.util.List getRefreshListeners()
    {
        return this.refreshListeners;
    }

    public final String getRefreshToken()
    {
        this.lock.lock();
        try {
            Throwable v0_1 = this.refreshToken;
            this.lock.unlock();
            return v0_1;
        } catch (Throwable v0_2) {
            this.lock.unlock();
            throw v0_2;
        }
    }

    public final com.google.api.client.http.HttpRequestInitializer getRequestInitializer()
    {
        return this.requestInitializer;
    }

    public final String getTokenServerEncodedUrl()
    {
        return this.tokenServerEncodedUrl;
    }

    public final com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public boolean handleResponse(com.google.api.client.http.HttpRequest p6, com.google.api.client.http.HttpResponse p7, boolean p8)
    {
        try {
            int v1_4;
            if (p7.getStatusCode() == 401) {
                this.lock.lock();
                if ((com.google.common.base.Objects.equal(this.accessToken, this.method.getAccessTokenFromRequest(p6))) && (!this.refreshToken())) {
                    v1_4 = 0;
                } else {
                    v1_4 = 1;
                }
                this.lock.unlock();
                return v1_4;
            }
        } catch (java.io.IOException v0) {
            com.google.api.client.auth.oauth2.Credential.LOGGER.log(java.util.logging.Level.SEVERE, "unable to refresh token", v0);
        }
        v1_4 = 0;
        return v1_4;
    }

    public void initialize(com.google.api.client.http.HttpRequest p1)
    {
        p1.setInterceptor(this);
        p1.setUnsuccessfulResponseHandler(this);
        return;
    }

    public void intercept(com.google.api.client.http.HttpRequest p6)
    {
        this.lock.lock();
        try {
            Long v0 = this.getExpiresInSeconds();
        } catch (java.util.concurrent.locks.Lock v1_5) {
            this.lock.unlock();
            throw v1_5;
        }
        if ((this.accessToken != null) && ((v0 == null) || (v0.longValue() > 60))) {
            this.method.intercept(p6, this.accessToken);
            this.lock.unlock();
        } else {
            this.refreshToken();
            if (this.accessToken != null) {
            } else {
                this.lock.unlock();
            }
        }
        return;
    }

    public final boolean refreshToken()
    {
        com.google.api.client.auth.oauth2.TokenErrorResponse v5_0 = 1;
        this.lock.lock();
        try {
            com.google.api.client.auth.oauth2.TokenResponse v4 = this.executeRefreshToken();
        } catch (com.google.api.client.auth.oauth2.TokenResponseException v0) {
            if (400 > v0.getStatusCode()) {
                java.util.concurrent.locks.Lock v3 = 0;
            } else {
                if (v0.getStatusCode() >= 500) {
                } else {
                    v3 = 1;
                }
            }
            if (v0.getDetails() != null) {
                if (v3 != null) {
                    this.setAccessToken(0);
                    this.setExpiresInSeconds(0);
                }
            }
            java.util.Iterator v1_1 = this.refreshListeners.iterator();
        } catch (com.google.api.client.auth.oauth2.TokenErrorResponse v5_7) {
            this.lock.unlock();
            throw v5_7;
        }
        if (v4 == null) {
            this.lock.unlock();
            v5_0 = 0;
            return v5_0;
        } else {
            this.setFromTokenResponse(v4);
            java.util.Iterator v1_0 = this.refreshListeners.iterator();
            while (v1_0.hasNext()) {
                ((com.google.api.client.auth.oauth2.CredentialRefreshListener) v1_0.next()).onTokenResponse(this, v4);
            }
            this.lock.unlock();
            return v5_0;
        }
    }

    public com.google.api.client.auth.oauth2.Credential setAccessToken(String p3)
    {
        this.lock.lock();
        try {
            this.accessToken = p3;
            this.lock.unlock();
            return this;
        } catch (Throwable v0_2) {
            this.lock.unlock();
            throw v0_2;
        }
    }

    public com.google.api.client.auth.oauth2.Credential setExpirationTimeMilliseconds(Long p3)
    {
        this.lock.lock();
        try {
            this.expirationTimeMilliseconds = p3;
            this.lock.unlock();
            return this;
        } catch (Throwable v0_2) {
            this.lock.unlock();
            throw v0_2;
        }
    }

    public com.google.api.client.auth.oauth2.Credential setExpiresInSeconds(Long p7)
    {
        com.google.api.client.auth.oauth2.Credential v0_1;
        if (p7 != null) {
            v0_1 = Long.valueOf((this.clock.currentTimeMillis() + (p7.longValue() * 1000)));
        } else {
            v0_1 = 0;
        }
        return this.setExpirationTimeMilliseconds(v0_1);
    }

    public com.google.api.client.auth.oauth2.Credential setFromTokenResponse(com.google.api.client.auth.oauth2.TokenResponse p2)
    {
        this.setAccessToken(p2.getAccessToken());
        if (p2.getRefreshToken() != null) {
            this.setRefreshToken(p2.getRefreshToken());
        }
        this.setExpiresInSeconds(p2.getExpiresInSeconds());
        return this;
    }

    public com.google.api.client.auth.oauth2.Credential setRefreshToken(String p3)
    {
        this.lock.lock();
        if (p3 != null) {
            try {
                if ((this.jsonFactory == null) || ((this.transport == null) || ((this.clientAuthentication == null) || (this.tokenServerEncodedUrl == null)))) {
                    int v0_1 = 0;
                } else {
                    v0_1 = 1;
                }
            } catch (int v0_2) {
                this.lock.unlock();
                throw v0_2;
            }
            com.google.common.base.Preconditions.checkArgument(v0_1, "Please use the Builder and call setJsonFactory, setTransport, setClientAuthentication and setTokenServerUrl/setTokenServerEncodedUrl");
        }
        this.refreshToken = p3;
        this.lock.unlock();
        return this;
    }
}
