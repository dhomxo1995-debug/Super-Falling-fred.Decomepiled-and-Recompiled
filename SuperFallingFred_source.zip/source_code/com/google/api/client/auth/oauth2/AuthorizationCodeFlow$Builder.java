package com.google.api.client.auth.oauth2;
public class AuthorizationCodeFlow$Builder {
    private final String authorizationServerEncodedUrl;
    private final com.google.api.client.http.HttpExecuteInterceptor clientAuthentication;
    private final String clientId;
    private com.google.api.client.util.Clock clock;
    private com.google.api.client.auth.oauth2.CredentialStore credentialStore;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    private final com.google.api.client.auth.oauth2.Credential$AccessMethod method;
    private com.google.api.client.http.HttpRequestInitializer requestInitializer;
    private String scopes;
    private final com.google.api.client.http.GenericUrl tokenServerUrl;
    private final com.google.api.client.http.HttpTransport transport;

    public AuthorizationCodeFlow$Builder(com.google.api.client.auth.oauth2.Credential$AccessMethod p2, com.google.api.client.http.HttpTransport p3, com.google.api.client.json.JsonFactory p4, com.google.api.client.http.GenericUrl p5, com.google.api.client.http.HttpExecuteInterceptor p6, String p7, String p8)
    {
        this.clock = com.google.api.client.util.Clock.SYSTEM;
        this.method = ((com.google.api.client.auth.oauth2.Credential$AccessMethod) com.google.common.base.Preconditions.checkNotNull(p2));
        this.transport = ((com.google.api.client.http.HttpTransport) com.google.common.base.Preconditions.checkNotNull(p3));
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p4));
        this.tokenServerUrl = ((com.google.api.client.http.GenericUrl) com.google.common.base.Preconditions.checkNotNull(p5));
        this.clientAuthentication = p6;
        this.clientId = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        this.authorizationServerEncodedUrl = ((String) com.google.common.base.Preconditions.checkNotNull(p8));
        return;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeFlow build()
    {
        return new com.google.api.client.auth.oauth2.AuthorizationCodeFlow(this.method, this.transport, this.jsonFactory, this.tokenServerUrl, this.clientAuthentication, this.clientId, this.authorizationServerEncodedUrl, this.credentialStore, this.requestInitializer, this.scopes, this.clock);
    }

    public final String getAuthorizationServerEncodedUrl()
    {
        return this.authorizationServerEncodedUrl;
    }

    public final com.google.api.client.http.HttpExecuteInterceptor getClientAuthentication()
    {
        return this.clientAuthentication;
    }

    public final String getClientId()
    {
        return this.clientId;
    }

    public final com.google.api.client.util.Clock getClock()
    {
        return this.clock;
    }

    public final com.google.api.client.auth.oauth2.CredentialStore getCredentialStore()
    {
        return this.credentialStore;
    }

    public final com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public final com.google.api.client.auth.oauth2.Credential$AccessMethod getMethod()
    {
        return this.method;
    }

    public final com.google.api.client.http.HttpRequestInitializer getRequestInitializer()
    {
        return this.requestInitializer;
    }

    public final String getScopes()
    {
        return this.scopes;
    }

    public final com.google.api.client.http.GenericUrl getTokenServerUrl()
    {
        return this.tokenServerUrl;
    }

    public final com.google.api.client.http.HttpTransport getTransport()
    {
        return this.transport;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder setClock(com.google.api.client.util.Clock p2)
    {
        this.clock = ((com.google.api.client.util.Clock) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder setCredentialStore(com.google.api.client.auth.oauth2.CredentialStore p1)
    {
        this.credentialStore = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder setRequestInitializer(com.google.api.client.http.HttpRequestInitializer p1)
    {
        this.requestInitializer = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder setScopes(Iterable p2)
    {
        String v0_2;
        if (p2 != null) {
            v0_2 = com.google.common.base.Joiner.on(32).join(p2);
        } else {
            v0_2 = 0;
        }
        this.scopes = v0_2;
        return this;
    }

    public varargs com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder setScopes(String[] p2)
    {
        com.google.api.client.auth.oauth2.AuthorizationCodeFlow$Builder v0_0;
        if (p2 != null) {
            v0_0 = java.util.Arrays.asList(p2);
        } else {
            v0_0 = 0;
        }
        return this.setScopes(v0_0);
    }
}
