.class final Lcom/google/api/client/auth/oauth2/BearerToken$FormEncodedBodyAccessMethod;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth2/Credential$AccessMethod;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private static getData(Lcom/google/api/client/http/HttpRequest;)Ljava/util/Map;
    .registers 2
    invoke-static v1, Lcom/google/api/client/http/UrlEncodedContent;->getContent(Lcom/google/api/client/http/HttpRequest;)Lcom/google/api/client/http/UrlEncodedContent;
    move-result-object v0
    invoke-virtual v0, Lcom/google/api/client/http/UrlEncodedContent;->getData()Ljava/lang/Object;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/util/Data;->mapOf(Ljava/lang/Object;)Ljava/util/Map;
    move-result-object v0
    return-object v0
.end method

.method public getAccessTokenFromRequest(Lcom/google/api/client/http/HttpRequest;)Ljava/lang/String;
    .registers 5
    invoke-static v4, Lcom/google/api/client/auth/oauth2/BearerToken$FormEncodedBodyAccessMethod;->getData(Lcom/google/api/client/http/HttpRequest;)Ljava/util/Map;
    move-result-object v1
    const-string v2, "access_token"
    invoke-interface v1, v2, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    if-nez v0, +004h
    const/4 v1, 0
    return-object v1
    invoke-virtual v0, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v1
    goto -5h
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest; Ljava/lang/String;)V
    .registers 5
    invoke-virtual v3, Lcom/google/api/client/http/HttpRequest;->getMethod()Lcom/google/api/client/http/HttpMethod;
    move-result-object v0
    sget-object v1, Lcom/google/api/client/http/HttpMethod;->GET Lcom/google/api/client/http/HttpMethod;
    if-eq v0, v1, +012h
    const/4 v0, 1
    const-string v1, "HTTP GET method is not supported"
    invoke-static v0, v1, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/Object;)V
    invoke-static v3, Lcom/google/api/client/auth/oauth2/BearerToken$FormEncodedBodyAccessMethod;->getData(Lcom/google/api/client/http/HttpRequest;)Ljava/util/Map;
    move-result-object v0
    const-string v1, "access_token"
    invoke-interface v0, v1, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
    const/4 v0, 0
    goto -10h
.end method
