.class public Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth2/CredentialStore;

.field private final lock:Ljava/util/concurrent/locks/Lock;
.field private final store:Ljava/util/Map;

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;
    invoke-direct v0, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    new-instance v0, Ljava/util/HashMap;
    invoke-direct v0, Ljava/util/HashMap;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->store Ljava/util/Map;
    return-void
.end method

.method public delete(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    .registers 5
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->store Ljava/util/Map;
    invoke-interface v0, v3, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    iget-object v0, v2, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v0, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-void
    move-exception v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v0
.end method

.method public load(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)Z
    .registers 6
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->store Ljava/util/Map;
    invoke-interface v1, v4, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;
    if-eqz v0, +005h
    invoke-virtual v0, v5, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->load(Lcom/google/api/client/auth/oauth2/Credential;)V
    if-eqz v0, +009h
    const/4 v1, 1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v2, Ljava/util/concurrent/locks/Lock;->unlock()V
    return v1
    const/4 v1, 0
    goto -7h
    move-exception v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v2, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v1
.end method

.method public store(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    .registers 6
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->lock()V
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->store Ljava/util/Map;
    invoke-interface v1, v4, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;
    if-nez v0, +00ch
    new-instance v0, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;
    invoke-direct v0, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;-><init>()V
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->store Ljava/util/Map;
    invoke-interface v1, v4, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v0, v5, Lcom/google/api/client/auth/oauth2/MemoryPersistedCredential;->store(Lcom/google/api/client/auth/oauth2/Credential;)V
    iget-object v1, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v1, Ljava/util/concurrent/locks/Lock;->unlock()V
    return-void
    move-exception v1
    iget-object v2, v3, Lcom/google/api/client/auth/oauth2/MemoryCredentialStore;->lock Ljava/util/concurrent/locks/Lock;
    invoke-interface v2, Ljava/util/concurrent/locks/Lock;->unlock()V
    throw v1
.end method
