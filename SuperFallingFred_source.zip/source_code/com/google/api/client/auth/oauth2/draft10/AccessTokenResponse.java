package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenResponse extends com.google.api.client.util.GenericData {
    public String accessToken;
    public Long expiresIn;
    public String refreshToken;
    public String scope;

    public AccessTokenResponse()
    {
        return;
    }
}
