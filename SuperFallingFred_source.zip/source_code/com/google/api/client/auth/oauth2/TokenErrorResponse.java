package com.google.api.client.auth.oauth2;
public class TokenErrorResponse extends com.google.api.client.json.GenericJson {
    private String error;
    private String errorDescription;
    private String errorUri;

    public TokenErrorResponse()
    {
        return;
    }

    public final String getError()
    {
        return this.error;
    }

    public final String getErrorDescription()
    {
        return this.errorDescription;
    }

    public final String getErrorUri()
    {
        return this.errorUri;
    }

    public com.google.api.client.auth.oauth2.TokenErrorResponse setError(String p2)
    {
        this.error = ((String) com.google.common.base.Preconditions.checkNotNull(p2));
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenErrorResponse setErrorDescription(String p1)
    {
        this.errorDescription = p1;
        return this;
    }

    public com.google.api.client.auth.oauth2.TokenErrorResponse setErrorUri(String p1)
    {
        this.errorUri = p1;
        return this;
    }
}
