.class public Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
.super Lcom/google/api/client/auth/oauth2/TokenRequest;

.field private code:Ljava/lang/String;
.field private redirectUri:Ljava/lang/String;

.method public constructor <init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Ljava/lang/String;)V
    .registers 6
    const-string v0, "authorization_code"
    invoke-direct v1, v2, v3, v4, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;-><init>(Lcom/google/api/client/http/HttpTransport; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/http/GenericUrl; Ljava/lang/String;)V
    invoke-virtual v1, v5, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setCode(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-void
.end method

.method public final getCode()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->code Ljava/lang/String;
    return-object v0
.end method

.method public final getRedirectUri()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->redirectUri Ljava/lang/String;
    return-object v0
.end method

.method public setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public bridge synthetic setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setClientAuthentication(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method

.method public setCode(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->code Ljava/lang/String;
    return-object v1
.end method

.method public setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public bridge synthetic setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setGrantType(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method

.method public setRedirectUri(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->redirectUri Ljava/lang/String;
    return-object v0
.end method

.method public setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public bridge synthetic setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setRequestInitializer(Lcom/google/api/client/http/HttpRequestInitializer;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method

.method public setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public varargs setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public bridge synthetic setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setScopes(Ljava/lang/Iterable;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method

.method public bridge synthetic setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setScopes([Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method

.method public setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    .registers 3
    invoke-super v1, v2, Lcom/google/api/client/auth/oauth2/TokenRequest;->setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    return-object v0
.end method

.method public bridge synthetic setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/TokenRequest;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;->setTokenServerUrl(Lcom/google/api/client/http/GenericUrl;)Lcom/google/api/client/auth/oauth2/AuthorizationCodeTokenRequest;
    move-result-object v0
    return-object v0
.end method
