package com.google.api.client.auth.oauth2.draft10;
public final enum class AccessTokenErrorResponse$KnownError extends java.lang.Enum {
    private static final synthetic com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError[] $VALUES;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError INVALID_CLIENT;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError INVALID_GRANT;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError INVALID_REQUEST;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError INVALID_SCOPE;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError UNAUTHORIZED_CLIENT;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError UNSUPPORTED_GRANT_TYPE;

    static AccessTokenErrorResponse$KnownError()
    {
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_REQUEST = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("INVALID_REQUEST", 0);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_CLIENT = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("INVALID_CLIENT", 1);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.UNAUTHORIZED_CLIENT = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("UNAUTHORIZED_CLIENT", 2);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_GRANT = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("INVALID_GRANT", 3);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.UNSUPPORTED_GRANT_TYPE = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("UNSUPPORTED_GRANT_TYPE", 4);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_SCOPE = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError("INVALID_SCOPE", 5);
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError[] v0_10 = new com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError[6];
        v0_10[0] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_REQUEST;
        v0_10[1] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_CLIENT;
        v0_10[2] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.UNAUTHORIZED_CLIENT;
        v0_10[3] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_GRANT;
        v0_10[4] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.UNSUPPORTED_GRANT_TYPE;
        v0_10[5] = com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.INVALID_SCOPE;
        com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.$VALUES = v0_10;
        return;
    }

    private AccessTokenErrorResponse$KnownError(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError valueOf(String p1)
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError) Enum.valueOf(com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError, p1));
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError[] values()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError[]) com.google.api.client.auth.oauth2.draft10.AccessTokenErrorResponse$KnownError.$VALUES.clone());
    }
}
