.class 0x0 Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpExecuteInterceptor;

.field final synthetic this$1:Lcom/google/api/client/auth/oauth2/TokenRequest$1;
.field final synthetic val$interceptor:Lcom/google/api/client/http/HttpExecuteInterceptor;

.method constructor <init>(Lcom/google/api/client/auth/oauth2/TokenRequest$1; Lcom/google/api/client/http/HttpExecuteInterceptor;)V
    .registers 3
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->this$1 Lcom/google/api/client/auth/oauth2/TokenRequest$1;
    iput-object v2, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->val$interceptor Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest;)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->val$interceptor Lcom/google/api/client/http/HttpExecuteInterceptor;
    if-eqz v0, +007h
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->val$interceptor Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-interface v0, v2, Lcom/google/api/client/http/HttpExecuteInterceptor;->intercept(Lcom/google/api/client/http/HttpRequest;)V
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->this$1 Lcom/google/api/client/auth/oauth2/TokenRequest$1;
    iget-object v0, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1;->this$0 Lcom/google/api/client/auth/oauth2/TokenRequest;
    iget-object v0, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    if-eqz v0, +00bh
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenRequest$1$1;->this$1 Lcom/google/api/client/auth/oauth2/TokenRequest$1;
    iget-object v0, v0, Lcom/google/api/client/auth/oauth2/TokenRequest$1;->this$0 Lcom/google/api/client/auth/oauth2/TokenRequest;
    iget-object v0, v0, Lcom/google/api/client/auth/oauth2/TokenRequest;->clientAuthentication Lcom/google/api/client/http/HttpExecuteInterceptor;
    invoke-interface v0, v2, Lcom/google/api/client/http/HttpExecuteInterceptor;->intercept(Lcom/google/api/client/http/HttpRequest;)V
    return-void
.end method
