.class public Lcom/google/api/client/auth/oauth2/draft10/AccessTokenResponse;
.super Lcom/google/api/client/util/GenericData;

.field public accessToken:Ljava/lang/String;
.field public expiresIn:Ljava/lang/Long;
.field public refreshToken:Ljava/lang/String;
.field public scope:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/util/GenericData;-><init>()V
    return-void
.end method
