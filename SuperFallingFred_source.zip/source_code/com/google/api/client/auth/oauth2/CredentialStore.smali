.class public interface abstract Lcom/google/api/client/auth/oauth2/CredentialStore;
.super Ljava/lang/Object;


.method public abstract delete(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    # abstract or native method
.end method

.method public abstract load(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)Z
    # abstract or native method
.end method

.method public abstract store(Ljava/lang/String; Lcom/google/api/client/auth/oauth2/Credential;)V
    # abstract or native method
.end method
