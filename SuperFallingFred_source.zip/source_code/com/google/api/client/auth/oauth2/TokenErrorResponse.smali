.class public Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
.super Lcom/google/api/client/json/GenericJson;

.field private error:Ljava/lang/String;
.field private errorDescription:Ljava/lang/String;
.field private errorUri:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/json/GenericJson;-><init>()V
    return-void
.end method

.method public final getError()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->error Ljava/lang/String;
    return-object v0
.end method

.method public final getErrorDescription()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->errorDescription Ljava/lang/String;
    return-object v0
.end method

.method public final getErrorUri()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->errorUri Ljava/lang/String;
    return-object v0
.end method

.method public setError(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    .registers 3
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v1, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->error Ljava/lang/String;
    return-object v1
.end method

.method public setErrorDescription(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->errorDescription Ljava/lang/String;
    return-object v0
.end method

.method public setErrorUri(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/TokenErrorResponse;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/oauth2/TokenErrorResponse;->errorUri Ljava/lang/String;
    return-object v0
.end method
