.class public final enum Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.super Ljava/lang/Enum;

.field private static final synthetic $VALUES:[Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum INVALID_CLIENT:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum INVALID_GRANT:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum INVALID_REQUEST:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum INVALID_SCOPE:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum UNAUTHORIZED_CLIENT:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
.field public static final enum UNSUPPORTED_GRANT_TYPE:Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;

.method static constructor <clinit>()V
    .registers 8
    const/4 v7, 4
    const/4 v6, 3
    const/4 v5, 2
    const/4 v4, 1
    const/4 v3, 0
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "INVALID_REQUEST"
    invoke-direct v0, v1, v3, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_REQUEST Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "INVALID_CLIENT"
    invoke-direct v0, v1, v4, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_CLIENT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "UNAUTHORIZED_CLIENT"
    invoke-direct v0, v1, v5, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->UNAUTHORIZED_CLIENT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "INVALID_GRANT"
    invoke-direct v0, v1, v6, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_GRANT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "UNSUPPORTED_GRANT_TYPE"
    invoke-direct v0, v1, v7, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->UNSUPPORTED_GRANT_TYPE Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    new-instance v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const-string v1, "INVALID_SCOPE"
    const/4 v2, 5
    invoke-direct v0, v1, v2, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;-><init>(Ljava/lang/String; I)V
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_SCOPE Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    const/4 v0, 6
    new-array v0, v0, [Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_REQUEST Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v1, v0, v3
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_CLIENT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v1, v0, v4
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->UNAUTHORIZED_CLIENT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v1, v0, v5
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_GRANT Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v1, v0, v6
    sget-object v1, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->UNSUPPORTED_GRANT_TYPE Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v1, v0, v7
    const/4 v1, 5
    sget-object v2, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->INVALID_SCOPE Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    aput-object v2, v0, v1
    sput-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->$VALUES [Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    return-void
.end method

.method private constructor <init>(Ljava/lang/String; I)V
    .registers 3
    invoke-direct v0, v1, v2, Ljava/lang/Enum;-><init>(Ljava/lang/String; I)V
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    .registers 2
    const-class v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    invoke-static v0, v1, Ljava/lang/Enum;->valueOf(Ljava/lang/Class; Ljava/lang/String;)Ljava/lang/Enum;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    return-object v0
.end method

.method public static values()[Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    .registers 1
    sget-object v0, Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->$VALUES [Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    invoke-virtual v0, [Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;->clone()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/google/api/client/auth/oauth2/draft10/AccessTokenErrorResponse$KnownError;
    return-object v0
.end method
