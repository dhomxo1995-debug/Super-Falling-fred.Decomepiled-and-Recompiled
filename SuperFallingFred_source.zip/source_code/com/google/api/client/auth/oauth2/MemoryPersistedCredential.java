package com.google.api.client.auth.oauth2;
 class MemoryPersistedCredential {
    private String accessToken;
    private Long expirationTimeMillis;
    private String refreshToken;

    MemoryPersistedCredential()
    {
        return;
    }

    void load(com.google.api.client.auth.oauth2.Credential p2)
    {
        p2.setAccessToken(this.accessToken);
        p2.setRefreshToken(this.refreshToken);
        p2.setExpirationTimeMilliseconds(this.expirationTimeMillis);
        return;
    }

    void store(com.google.api.client.auth.oauth2.Credential p2)
    {
        this.accessToken = p2.getAccessToken();
        this.refreshToken = p2.getRefreshToken();
        this.expirationTimeMillis = p2.getExpirationTimeMilliseconds();
        return;
    }
}
