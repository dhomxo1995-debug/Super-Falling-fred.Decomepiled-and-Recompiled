package com.google.api.client.auth.oauth2.draft10;
public class AccessTokenRequest$AuthorizationCodeGrant extends com.google.api.client.auth.oauth2.draft10.AccessTokenRequest {
    public String code;
    public String redirectUri;

    public AccessTokenRequest$AuthorizationCodeGrant()
    {
        this.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.AUTHORIZATION_CODE;
        return;
    }

    public AccessTokenRequest$AuthorizationCodeGrant(com.google.api.client.http.HttpTransport p2, com.google.api.client.json.JsonFactory p3, String p4, String p5, String p6, String p7, String p8)
    {
        com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$AuthorizationCodeGrant v1_1 = super(p2, p3, p4, p5, p6);
        v1_1.grantType = com.google.api.client.auth.oauth2.draft10.AccessTokenRequest$GrantType.AUTHORIZATION_CODE;
        v1_1.code = ((String) com.google.common.base.Preconditions.checkNotNull(p7));
        v1_1.redirectUri = ((String) com.google.common.base.Preconditions.checkNotNull(p8));
        return;
    }
}
