package com.google.api.client.auth.oauth2.draft10;
public final enum class AccessProtectedResource$Method extends java.lang.Enum {
    private static final synthetic com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method[] $VALUES;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method AUTHORIZATION_HEADER;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method FORM_ENCODED_BODY;
    public static final enum com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method QUERY_PARAMETER;

    static AccessProtectedResource$Method()
    {
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.AUTHORIZATION_HEADER = new com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method("AUTHORIZATION_HEADER", 0);
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.QUERY_PARAMETER = new com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method("QUERY_PARAMETER", 1);
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.FORM_ENCODED_BODY = new com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method("FORM_ENCODED_BODY", 2);
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method[] v0_3 = new com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method[3];
        v0_3[0] = com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.AUTHORIZATION_HEADER;
        v0_3[1] = com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.QUERY_PARAMETER;
        v0_3[2] = com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.FORM_ENCODED_BODY;
        com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.$VALUES = v0_3;
        return;
    }

    private AccessProtectedResource$Method(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method valueOf(String p1)
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method) Enum.valueOf(com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method, p1));
    }

    public static com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method[] values()
    {
        return ((com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method[]) com.google.api.client.auth.oauth2.draft10.AccessProtectedResource$Method.$VALUES.clone());
    }
}
