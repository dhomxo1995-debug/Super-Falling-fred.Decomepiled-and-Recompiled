package com.google.api.client.auth.oauth2;
 class TokenRequest$1$1 implements com.google.api.client.http.HttpExecuteInterceptor {
    final synthetic com.google.api.client.auth.oauth2.TokenRequest$1 this$1;
    final synthetic com.google.api.client.http.HttpExecuteInterceptor val$interceptor;

    TokenRequest$1$1(com.google.api.client.auth.oauth2.TokenRequest$1 p1, com.google.api.client.http.HttpExecuteInterceptor p2)
    {
        this.this$1 = p1;
        this.val$interceptor = p2;
        return;
    }

    public void intercept(com.google.api.client.http.HttpRequest p2)
    {
        if (this.val$interceptor != null) {
            this.val$interceptor.intercept(p2);
        }
        if (this.this$1.this$0.clientAuthentication != null) {
            this.this$1.this$0.clientAuthentication.intercept(p2);
        }
        return;
    }
}
