package com.google.api.client.auth.oauth2;
public class BrowserClientRequestUrl extends com.google.api.client.auth.oauth2.AuthorizationRequestUrl {

    public BrowserClientRequestUrl(String p2, String p3)
    {
        super(p2, p3, java.util.Collections.singleton("token"));
        return;
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setClientId(String p2)
    {
        return this.setClientId(p2);
    }

    public com.google.api.client.auth.oauth2.BrowserClientRequestUrl setClientId(String p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setClientId(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setRedirectUri(String p2)
    {
        return this.setRedirectUri(p2);
    }

    public com.google.api.client.auth.oauth2.BrowserClientRequestUrl setRedirectUri(String p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setRedirectUri(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(Iterable p2)
    {
        return this.setResponseTypes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setResponseTypes(String[] p2)
    {
        return this.setResponseTypes(p2);
    }

    public com.google.api.client.auth.oauth2.BrowserClientRequestUrl setResponseTypes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setResponseTypes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.BrowserClientRequestUrl setResponseTypes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setResponseTypes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(Iterable p2)
    {
        return this.setScopes(p2);
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setScopes(String[] p2)
    {
        return this.setScopes(p2);
    }

    public com.google.api.client.auth.oauth2.BrowserClientRequestUrl setScopes(Iterable p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setScopes(p2));
    }

    public varargs com.google.api.client.auth.oauth2.BrowserClientRequestUrl setScopes(String[] p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setScopes(p2));
    }

    public bridge synthetic com.google.api.client.auth.oauth2.AuthorizationRequestUrl setState(String p2)
    {
        return this.setState(p2);
    }

    public com.google.api.client.auth.oauth2.BrowserClientRequestUrl setState(String p2)
    {
        return ((com.google.api.client.auth.oauth2.BrowserClientRequestUrl) super.setState(p2));
    }
}
