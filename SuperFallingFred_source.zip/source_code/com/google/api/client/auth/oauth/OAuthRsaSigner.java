package com.google.api.client.auth.oauth;
public final class OAuthRsaSigner implements com.google.api.client.auth.oauth.OAuthSigner {
    public java.security.PrivateKey privateKey;

    public OAuthRsaSigner()
    {
        return;
    }

    public String computeSignature(String p3)
    {
        java.security.Signature v0 = java.security.Signature.getInstance("SHA1withRSA");
        v0.initSign(this.privateKey);
        v0.update(com.google.api.client.util.StringUtils.getBytesUtf8(p3));
        return com.google.api.client.util.Base64.encodeBase64String(v0.sign());
    }

    public String getSignatureMethod()
    {
        return "RSA-SHA1";
    }
}
