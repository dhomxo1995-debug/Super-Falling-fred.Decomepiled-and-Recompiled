package com.google.api.client.auth.oauth;
public final class OAuthHmacSigner implements com.google.api.client.auth.oauth.OAuthSigner {
    public String clientSharedSecret;
    public String tokenSharedSecret;

    public OAuthHmacSigner()
    {
        return;
    }

    public String computeSignature(String p9)
    {
        StringBuilder v2_1 = new StringBuilder();
        String v0 = this.clientSharedSecret;
        if (v0 != null) {
            v2_1.append(com.google.api.client.auth.oauth.OAuthParameters.escape(v0));
        }
        v2_1.append(38);
        String v5 = this.tokenSharedSecret;
        if (v5 != null) {
            v2_1.append(com.google.api.client.auth.oauth.OAuthParameters.escape(v5));
        }
        javax.crypto.spec.SecretKeySpec v4_1 = new javax.crypto.spec.SecretKeySpec(com.google.api.client.util.StringUtils.getBytesUtf8(v2_1.toString()), "HmacSHA1");
        javax.crypto.Mac v3 = javax.crypto.Mac.getInstance("HmacSHA1");
        v3.init(v4_1);
        return com.google.api.client.util.Base64.encodeBase64String(v3.doFinal(com.google.api.client.util.StringUtils.getBytesUtf8(p9)));
    }

    public String getSignatureMethod()
    {
        return "HMAC-SHA1";
    }
}
