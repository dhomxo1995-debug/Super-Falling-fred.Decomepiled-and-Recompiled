.class public final Lcom/google/api/client/auth/oauth/OAuthParameters;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/http/HttpExecuteInterceptor;
.implements Lcom/google/api/client/http/HttpRequestInitializer;

.field private static final ESCAPER:Lcom/google/api/client/util/escape/PercentEscaper;
.field private static final RANDOM:Ljava/security/SecureRandom;
.field public callback:Ljava/lang/String;
.field public consumerKey:Ljava/lang/String;
.field public nonce:Ljava/lang/String;
.field public realm:Ljava/lang/String;
.field public signature:Ljava/lang/String;
.field public signatureMethod:Ljava/lang/String;
.field public signer:Lcom/google/api/client/auth/oauth/OAuthSigner;
.field public timestamp:Ljava/lang/String;
.field public token:Ljava/lang/String;
.field public verifier:Ljava/lang/String;
.field public version:Ljava/lang/String;

.method static constructor <clinit>()V
    .registers 3
    new-instance v0, Ljava/security/SecureRandom;
    invoke-direct v0, Ljava/security/SecureRandom;-><init>()V
    sput-object v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->RANDOM Ljava/security/SecureRandom;
    new-instance v0, Lcom/google/api/client/util/escape/PercentEscaper;
    const-string v1, "-_.~"
    const/4 v2, 0
    invoke-direct v0, v1, v2, Lcom/google/api/client/util/escape/PercentEscaper;-><init>(Ljava/lang/String; Z)V
    sput-object v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->ESCAPER Lcom/google/api/client/util/escape/PercentEscaper;
    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    .registers 6
    if-eqz v5, +023h
    const/16 v0, 32
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "=""
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v5, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "","
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    return-void
.end method

.method public static escape(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    sget-object v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->ESCAPER Lcom/google/api/client/util/escape/PercentEscaper;
    invoke-virtual v0, v1, Lcom/google/api/client/util/escape/PercentEscaper;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method private putParameter(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/Object;)V
    .registers 6
    invoke-static v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    if-nez v5, +007h
    const/4 v0, 0
    invoke-virtual v3, v1, v0, Ljava/util/TreeMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
    invoke-virtual v5, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    goto -ch
.end method

.method private putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    .registers 4
    if-eqz v3, +005h
    invoke-direct v0, v1, v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameter(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/Object;)V
    return-void
.end method

.method public computeNonce()V
    .registers 3
    sget-object v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->RANDOM Ljava/security/SecureRandom;
    invoke-virtual v0, Ljava/security/SecureRandom;->nextLong()J
    move-result-wide v0
    invoke-static v0, v1, Ljava/lang/Math;->abs(J)J
    move-result-wide v0
    invoke-static v0, v1, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->nonce Ljava/lang/String;
    return-void
.end method

.method public computeSignature(Ljava/lang/String; Lcom/google/api/client/http/GenericUrl;)V
    .registers 27
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->signer Lcom/google/api/client/auth/oauth/OAuthSigner;
    move-object/from16 v20, v0
    invoke-interface/range v20, Lcom/google/api/client/auth/oauth/OAuthSigner;->getSignatureMethod()Ljava/lang/String;
    move-result-object v19
    move-object/from16 v0, v19
    move-object/from16 v1, v24
    iput-object v0, v1, Lcom/google/api/client/auth/oauth/OAuthParameters;->signatureMethod Ljava/lang/String;
    new-instance v13, Ljava/util/TreeMap;
    invoke-direct v13, Ljava/util/TreeMap;-><init>()V
    const-string v22, "oauth_callback"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->callback Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_consumer_key"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->consumerKey Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_nonce"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->nonce Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_signature_method"
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v19
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_timestamp"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->timestamp Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_token"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->token Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_verifier"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->verifier Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    const-string v22, "oauth_version"
    move-object/from16 v0, v24
    iget-object v0, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->version Ljava/lang/String;
    move-object/from16 v23, v0
    move-object/from16 v0, v24
    move-object/from16 v1, v22
    move-object/from16 v2, v23
    invoke-direct v0, v13, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameterIfValueNotNull(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual/range v26, Lcom/google/api/client/http/GenericUrl;->entrySet()Ljava/util/Set;
    move-result-object v22
    invoke-interface/range v22, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v7
    invoke-interface v7, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +03ch
    invoke-interface v7, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v5
    check-cast v5, Ljava/util/Map$Entry;
    invoke-interface v5, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v21
    if-eqz v21, -010h
    invoke-interface v5, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v9
    check-cast v9, Ljava/lang/String;
    move-object/from16 v0, v21
    instance-of v0, v0, Ljava/util/Collection;
    move/from16 v22, v0
    if-eqz v22, +01ah
    check-cast v21, Ljava/util/Collection;
    invoke-interface/range v21, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v8
    invoke-interface v8, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, -02ah
    invoke-interface v8, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v16
    move-object/from16 v0, v24
    move-object/from16 v1, v16
    invoke-direct v0, v13, v9, v1, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameter(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/Object;)V
    goto -11h
    move-object/from16 v0, v24
    move-object/from16 v1, v21
    invoke-direct v0, v13, v9, v1, Lcom/google/api/client/auth/oauth/OAuthParameters;->putParameter(Ljava/util/TreeMap; Ljava/lang/String; Ljava/lang/Object;)V
    goto -3fh
    new-instance v14, Ljava/lang/StringBuilder;
    invoke-direct v14, Ljava/lang/StringBuilder;-><init>()V
    const/4 v6, 1
    invoke-virtual v13, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;
    move-result-object v22
    invoke-interface/range v22, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v7
    invoke-interface v7, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +036h
    invoke-interface v7, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Ljava/util/Map$Entry;
    if-eqz v6, +026h
    const/4 v6, 0
    invoke-interface v4, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v22
    check-cast v22, Ljava/lang/String;
    move-object/from16 v0, v22
    invoke-virtual v14, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-interface v4, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v21
    check-cast v21, Ljava/lang/String;
    if-eqz v21, -020h
    const/16 v22, 61
    move/from16 v0, v22
    invoke-virtual v14, v0, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    move-result-object v22
    move-object/from16 v0, v22
    move-object/from16 v1, v21
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -31h
    const/16 v22, 38
    move/from16 v0, v22
    invoke-virtual v14, v0, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    goto -2ah
    invoke-virtual v14, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v11
    new-instance v10, Lcom/google/api/client/http/GenericUrl;
    invoke-direct v10, Lcom/google/api/client/http/GenericUrl;-><init>()V
    invoke-virtual/range v26, Lcom/google/api/client/http/GenericUrl;->getScheme()Ljava/lang/String;
    move-result-object v17
    move-object/from16 v0, v17
    invoke-virtual v10, v0, Lcom/google/api/client/http/GenericUrl;->setScheme(Ljava/lang/String;)V
    invoke-virtual/range v26, Lcom/google/api/client/http/GenericUrl;->getHost()Ljava/lang/String;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v10, v0, Lcom/google/api/client/http/GenericUrl;->setHost(Ljava/lang/String;)V
    invoke-virtual/range v26, Lcom/google/api/client/http/GenericUrl;->getPathParts()Ljava/util/List;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v10, v0, Lcom/google/api/client/http/GenericUrl;->setPathParts(Ljava/util/List;)V
    invoke-virtual/range v26, Lcom/google/api/client/http/GenericUrl;->getPort()I
    move-result v15
    const-string v22, "http"
    move-object/from16 v0, v22
    move-object/from16 v1, v17
    invoke-virtual v0, v1, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v22
    if-eqz v22, +008h
    const/16 v22, 80
    move/from16 v0, v22
    if-eq v15, v0, +014h
    const-string v22, "https"
    move-object/from16 v0, v22
    move-object/from16 v1, v17
    invoke-virtual v0, v1, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v22
    if-eqz v22, +009h
    const/16 v22, 443
    move/from16 v0, v22
    if-ne v15, v0, +003h
    const/4 v15, -1
    invoke-virtual v10, v15, Lcom/google/api/client/http/GenericUrl;->setPort(I)V
    invoke-virtual v10, Lcom/google/api/client/http/GenericUrl;->build()Ljava/lang/String;
    move-result-object v12
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    invoke-static/range v25, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v22
    const/16 v23, 38
    invoke-virtual/range v22 ... v23, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    invoke-static v12, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v22
    const/16 v23, 38
    invoke-virtual/range v22 ... v23, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    invoke-static v11, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v18
    move-object/from16 v0, v20
    move-object/from16 v1, v18
    invoke-interface v0, v1, Lcom/google/api/client/auth/oauth/OAuthSigner;->computeSignature(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v22
    move-object/from16 v0, v22
    move-object/from16 v1, v24
    iput-object v0, v1, Lcom/google/api/client/auth/oauth/OAuthParameters;->signature Ljava/lang/String;
    return-void
.end method

.method public computeTimestamp()V
    .registers 5
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    const-wide/16 v2, 1000
    div-long/2addr v0, v2
    invoke-static v0, v1, Ljava/lang/Long;->toString(J)Ljava/lang/String;
    move-result-object v0
    iput-object v0, v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->timestamp Ljava/lang/String;
    return-void
.end method

.method public getAuthorizationHeader()Ljava/lang/String;
    .registers 4
    new-instance v0, Ljava/lang/StringBuilder;
    const-string v1, "OAuth"
    invoke-direct v0, v1, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    const-string v1, "realm"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->realm Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_callback"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->callback Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_consumer_key"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->consumerKey Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_nonce"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->nonce Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_signature"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->signature Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_signature_method"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->signatureMethod Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_timestamp"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->timestamp Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_token"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->token Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_verifier"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->verifier Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const-string v1, "oauth_version"
    iget-object v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->version Ljava/lang/String;
    invoke-direct v3, v0, v1, v2, Lcom/google/api/client/auth/oauth/OAuthParameters;->appendParameter(Ljava/lang/StringBuilder; Ljava/lang/String; Ljava/lang/String;)V
    const/4 v1, 0
    invoke-virtual v0, Ljava/lang/StringBuilder;->length()I
    move-result v2
    add-int/lit8 v2, v2, -1
    invoke-virtual v0, v1, v2, Ljava/lang/StringBuilder;->substring(I I)Ljava/lang/String;
    move-result-object v1
    return-object v1
.end method

.method public initialize(Lcom/google/api/client/http/HttpRequest;)V
    .registers 2
    invoke-virtual v1, v0, Lcom/google/api/client/http/HttpRequest;->setInterceptor(Lcom/google/api/client/http/HttpExecuteInterceptor;)Lcom/google/api/client/http/HttpRequest;
    return-void
.end method

.method public intercept(Lcom/google/api/client/http/HttpRequest;)V
    .registers 6
    invoke-virtual v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->computeNonce()V
    invoke-virtual v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->computeTimestamp()V
    invoke-virtual v5, Lcom/google/api/client/http/HttpRequest;->getMethod()Lcom/google/api/client/http/HttpMethod;
    move-result-object v2
    invoke-virtual v2, Lcom/google/api/client/http/HttpMethod;->name()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v5, Lcom/google/api/client/http/HttpRequest;->getUrl()Lcom/google/api/client/http/GenericUrl;
    move-result-object v3
    invoke-virtual v4, v2, v3, Lcom/google/api/client/auth/oauth/OAuthParameters;->computeSignature(Ljava/lang/String; Lcom/google/api/client/http/GenericUrl;)V
    invoke-virtual v5, Lcom/google/api/client/http/HttpRequest;->getHeaders()Lcom/google/api/client/http/HttpHeaders;
    move-result-object v2
    invoke-virtual v4, Lcom/google/api/client/auth/oauth/OAuthParameters;->getAuthorizationHeader()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Lcom/google/api/client/http/HttpHeaders;->setAuthorization(Ljava/lang/String;)V
    return-void
    move-exception v0
    new-instance v1, Ljava/io/IOException;
    invoke-direct v1, Ljava/io/IOException;-><init>()V
    invoke-virtual v1, v0, Ljava/io/IOException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    throw v1
.end method
