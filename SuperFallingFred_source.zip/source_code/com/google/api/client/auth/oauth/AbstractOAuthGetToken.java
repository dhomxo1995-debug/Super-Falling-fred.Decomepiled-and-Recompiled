package com.google.api.client.auth.oauth;
public abstract class AbstractOAuthGetToken extends com.google.api.client.http.GenericUrl {
    public String consumerKey;
    public com.google.api.client.auth.oauth.OAuthSigner signer;
    public com.google.api.client.http.HttpTransport transport;
    protected boolean usePost;

    protected AbstractOAuthGetToken(String p1)
    {
        super(p1);
        return;
    }

    public com.google.api.client.auth.oauth.OAuthParameters createParameters()
    {
        com.google.api.client.auth.oauth.OAuthParameters v0_1 = new com.google.api.client.auth.oauth.OAuthParameters();
        v0_1.consumerKey = this.consumerKey;
        v0_1.signer = this.signer;
        return v0_1;
    }

    public final com.google.api.client.auth.oauth.OAuthCredentialsResponse execute()
    {
        String v4_5;
        com.google.api.client.http.HttpRequestFactory vtmp1 = this.transport.createRequestFactory();
        if (!this.usePost) {
            v4_5 = com.google.api.client.http.HttpMethod.GET;
        } else {
            v4_5 = com.google.api.client.http.HttpMethod.POST;
        }
        com.google.api.client.http.HttpRequest v1 = vtmp1.buildRequest(v4_5, this, 0);
        this.createParameters().intercept(v1);
        com.google.api.client.http.HttpResponse v3 = v1.execute();
        v3.setContentLoggingLimit(0);
        com.google.api.client.auth.oauth.OAuthCredentialsResponse v0_1 = new com.google.api.client.auth.oauth.OAuthCredentialsResponse();
        com.google.api.client.http.UrlEncodedParser.parse(v3.parseAsString(), v0_1);
        return v0_1;
    }
}
