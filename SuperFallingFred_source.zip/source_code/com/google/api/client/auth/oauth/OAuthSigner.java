package com.google.api.client.auth.oauth;
public interface OAuthSigner {

    public abstract String computeSignature(String p0);

    public abstract String getSignatureMethod();
}
