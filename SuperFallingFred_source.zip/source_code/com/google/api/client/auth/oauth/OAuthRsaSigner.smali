.class public final Lcom/google/api/client/auth/oauth/OAuthRsaSigner;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth/OAuthSigner;

.field public privateKey:Ljava/security/PrivateKey;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public computeSignature(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    const-string v1, "SHA1withRSA"
    invoke-static v1, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;
    move-result-object v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth/OAuthRsaSigner;->privateKey Ljava/security/PrivateKey;
    invoke-virtual v0, v1, Ljava/security/Signature;->initSign(Ljava/security/PrivateKey;)V
    invoke-static v3, Lcom/google/api/client/util/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v1
    invoke-virtual v0, v1, Ljava/security/Signature;->update([B)V
    invoke-virtual v0, Ljava/security/Signature;->sign()[B
    move-result-object v1
    invoke-static v1, Lcom/google/api/client/util/Base64;->encodeBase64String([B)Ljava/lang/String;
    move-result-object v1
    return-object v1
.end method

.method public getSignatureMethod()Ljava/lang/String;
    .registers 2
    const-string v0, "RSA-SHA1"
    return-object v0
.end method
