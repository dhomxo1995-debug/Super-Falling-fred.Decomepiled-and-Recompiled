.class public abstract Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;
.super Lcom/google/api/client/http/GenericUrl;

.field public consumerKey:Ljava/lang/String;
.field public signer:Lcom/google/api/client/auth/oauth/OAuthSigner;
.field public transport:Lcom/google/api/client/http/HttpTransport;
.field protected usePost:Z

.method protected constructor <init>(Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, v1, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    return-void
.end method

.method public createParameters()Lcom/google/api/client/auth/oauth/OAuthParameters;
    .registers 3
    new-instance v0, Lcom/google/api/client/auth/oauth/OAuthParameters;
    invoke-direct v0, Lcom/google/api/client/auth/oauth/OAuthParameters;-><init>()V
    iget-object v1, v2, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->consumerKey Ljava/lang/String;
    iput-object v1, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->consumerKey Ljava/lang/String;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->signer Lcom/google/api/client/auth/oauth/OAuthSigner;
    iput-object v1, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->signer Lcom/google/api/client/auth/oauth/OAuthSigner;
    return-object v0
.end method

.method public final execute()Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    .registers 7
    iget-object v4, v6, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->transport Lcom/google/api/client/http/HttpTransport;
    invoke-virtual v4, Lcom/google/api/client/http/HttpTransport;->createRequestFactory()Lcom/google/api/client/http/HttpRequestFactory;
    move-result-object v2
    iget-boolean v4, v6, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->usePost Z
    if-eqz v4, +025h
    sget-object v4, Lcom/google/api/client/http/HttpMethod;->POST Lcom/google/api/client/http/HttpMethod;
    const/4 v5, 0
    invoke-virtual v2, v4, v6, v5, Lcom/google/api/client/http/HttpRequestFactory;->buildRequest(Lcom/google/api/client/http/HttpMethod; Lcom/google/api/client/http/GenericUrl; Lcom/google/api/client/http/HttpContent;)Lcom/google/api/client/http/HttpRequest;
    move-result-object v1
    invoke-virtual v6, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->createParameters()Lcom/google/api/client/auth/oauth/OAuthParameters;
    move-result-object v4
    invoke-virtual v4, v1, Lcom/google/api/client/auth/oauth/OAuthParameters;->intercept(Lcom/google/api/client/http/HttpRequest;)V
    invoke-virtual v1, Lcom/google/api/client/http/HttpRequest;->execute()Lcom/google/api/client/http/HttpResponse;
    move-result-object v3
    const/4 v4, 0
    invoke-virtual v3, v4, Lcom/google/api/client/http/HttpResponse;->setContentLoggingLimit(I)Lcom/google/api/client/http/HttpResponse;
    new-instance v0, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
    invoke-direct v0, Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;-><init>()V
    invoke-virtual v3, Lcom/google/api/client/http/HttpResponse;->parseAsString()Ljava/lang/String;
    move-result-object v4
    invoke-static v4, v0, Lcom/google/api/client/http/UrlEncodedParser;->parse(Ljava/lang/String; Ljava/lang/Object;)V
    return-object v0
    sget-object v4, Lcom/google/api/client/http/HttpMethod;->GET Lcom/google/api/client/http/HttpMethod;
    goto -23h
.end method
