.class public Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;
.super Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;

.field public temporaryToken:Ljava/lang/String;
.field public verifier:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, v1, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;-><init>(Ljava/lang/String;)V
    return-void
.end method

.method public createParameters()Lcom/google/api/client/auth/oauth/OAuthParameters;
    .registers 3
    invoke-super v2, Lcom/google/api/client/auth/oauth/AbstractOAuthGetToken;->createParameters()Lcom/google/api/client/auth/oauth/OAuthParameters;
    move-result-object v0
    iget-object v1, v2, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->temporaryToken Ljava/lang/String;
    iput-object v1, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->token Ljava/lang/String;
    iget-object v1, v2, Lcom/google/api/client/auth/oauth/OAuthGetAccessToken;->verifier Ljava/lang/String;
    iput-object v1, v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->verifier Ljava/lang/String;
    return-object v0
.end method
