.class public Lcom/google/api/client/auth/oauth/OAuthCallbackUrl;
.super Lcom/google/api/client/http/GenericUrl;

.field public token:Ljava/lang/String;
.field public verifier:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, v1, Lcom/google/api/client/http/GenericUrl;-><init>(Ljava/lang/String;)V
    return-void
.end method
