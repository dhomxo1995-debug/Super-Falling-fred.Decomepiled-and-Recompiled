package com.google.api.client.auth.oauth;
public final class OAuthParameters implements com.google.api.client.http.HttpExecuteInterceptor, com.google.api.client.http.HttpRequestInitializer {
    private static final com.google.api.client.util.escape.PercentEscaper ESCAPER;
    private static final java.security.SecureRandom RANDOM;
    public String callback;
    public String consumerKey;
    public String nonce;
    public String realm;
    public String signature;
    public String signatureMethod;
    public com.google.api.client.auth.oauth.OAuthSigner signer;
    public String timestamp;
    public String token;
    public String verifier;
    public String version;

    static OAuthParameters()
    {
        com.google.api.client.auth.oauth.OAuthParameters.RANDOM = new java.security.SecureRandom();
        com.google.api.client.auth.oauth.OAuthParameters.ESCAPER = new com.google.api.client.util.escape.PercentEscaper("-_.~", 0);
        return;
    }

    public OAuthParameters()
    {
        return;
    }

    private void appendParameter(StringBuilder p3, String p4, String p5)
    {
        if (p5 != null) {
            p3.append(32).append(com.google.api.client.auth.oauth.OAuthParameters.escape(p4)).append("=\"").append(com.google.api.client.auth.oauth.OAuthParameters.escape(p5)).append("\",");
        }
        return;
    }

    public static String escape(String p1)
    {
        return com.google.api.client.auth.oauth.OAuthParameters.ESCAPER.escape(p1);
    }

    private void putParameter(java.util.TreeMap p3, String p4, Object p5)
    {
        String v0_1;
        String v1 = com.google.api.client.auth.oauth.OAuthParameters.escape(p4);
        if (p5 != null) {
            v0_1 = com.google.api.client.auth.oauth.OAuthParameters.escape(p5.toString());
        } else {
            v0_1 = 0;
        }
        p3.put(v1, v0_1);
        return;
    }

    private void putParameterIfValueNotNull(java.util.TreeMap p1, String p2, String p3)
    {
        if (p3 != null) {
            this.putParameter(p1, p2, p3);
        }
        return;
    }

    public void computeNonce()
    {
        this.nonce = Long.toHexString(Math.abs(com.google.api.client.auth.oauth.OAuthParameters.RANDOM.nextLong()));
        return;
    }

    public void computeSignature(String p25, com.google.api.client.http.GenericUrl p26)
    {
        com.google.api.client.auth.oauth.OAuthSigner v20 = this.signer;
        String v19 = v20.getSignatureMethod();
        this.signatureMethod = v19;
        java.util.TreeMap v13_1 = new java.util.TreeMap();
        this.putParameterIfValueNotNull(v13_1, "oauth_callback", this.callback);
        this.putParameterIfValueNotNull(v13_1, "oauth_consumer_key", this.consumerKey);
        this.putParameterIfValueNotNull(v13_1, "oauth_nonce", this.nonce);
        this.putParameterIfValueNotNull(v13_1, "oauth_signature_method", v19);
        this.putParameterIfValueNotNull(v13_1, "oauth_timestamp", this.timestamp);
        this.putParameterIfValueNotNull(v13_1, "oauth_token", this.token);
        this.putParameterIfValueNotNull(v13_1, "oauth_verifier", this.verifier);
        this.putParameterIfValueNotNull(v13_1, "oauth_version", this.version);
        java.util.Iterator v7_0 = p26.entrySet().iterator();
        while (v7_0.hasNext()) {
            java.util.Map$Entry v5_1 = ((java.util.Map$Entry) v7_0.next());
            String v21_2 = v5_1.getValue();
            if (v21_2 != null) {
                String v9_1 = ((String) v5_1.getKey());
                if (!(v21_2 instanceof java.util.Collection)) {
                    this.putParameter(v13_1, v9_1, v21_2);
                } else {
                    java.util.Iterator v8 = ((java.util.Collection) v21_2).iterator();
                    while (v8.hasNext()) {
                        this.putParameter(v13_1, v9_1, v8.next());
                    }
                }
            }
        }
        StringBuilder v14_1 = new StringBuilder();
        int v6 = 1;
        java.util.Iterator v7_1 = v13_1.entrySet().iterator();
        while (v7_1.hasNext()) {
            java.util.Map$Entry v4_1 = ((java.util.Map$Entry) v7_1.next());
            if (v6 == 0) {
                v14_1.append(38);
            } else {
                v6 = 0;
            }
            v14_1.append(((String) v4_1.getKey()));
            String v21_1 = ((String) v4_1.getValue());
            if (v21_1 != null) {
                v14_1.append(61).append(v21_1);
            }
        }
        String v11 = v14_1.toString();
        com.google.api.client.http.GenericUrl v10_1 = new com.google.api.client.http.GenericUrl();
        String v17 = p26.getScheme();
        v10_1.setScheme(v17);
        v10_1.setHost(p26.getHost());
        v10_1.setPathParts(p26.getPathParts());
        int v15 = p26.getPort();
        if ((("http".equals(v17)) && (v15 == 80)) || (("https".equals(v17)) && (v15 == 443))) {
            v15 = -1;
        }
        v10_1.setPort(v15);
        String v12 = v10_1.build();
        StringBuilder v3_1 = new StringBuilder();
        v3_1.append(com.google.api.client.auth.oauth.OAuthParameters.escape(p25)).append(38);
        v3_1.append(com.google.api.client.auth.oauth.OAuthParameters.escape(v12)).append(38);
        v3_1.append(com.google.api.client.auth.oauth.OAuthParameters.escape(v11));
        this.signature = v20.computeSignature(v3_1.toString());
        return;
    }

    public void computeTimestamp()
    {
        this.timestamp = Long.toString((System.currentTimeMillis() / 1000));
        return;
    }

    public String getAuthorizationHeader()
    {
        StringBuilder v0_1 = new StringBuilder("OAuth");
        this.appendParameter(v0_1, "realm", this.realm);
        this.appendParameter(v0_1, "oauth_callback", this.callback);
        this.appendParameter(v0_1, "oauth_consumer_key", this.consumerKey);
        this.appendParameter(v0_1, "oauth_nonce", this.nonce);
        this.appendParameter(v0_1, "oauth_signature", this.signature);
        this.appendParameter(v0_1, "oauth_signature_method", this.signatureMethod);
        this.appendParameter(v0_1, "oauth_timestamp", this.timestamp);
        this.appendParameter(v0_1, "oauth_token", this.token);
        this.appendParameter(v0_1, "oauth_verifier", this.verifier);
        this.appendParameter(v0_1, "oauth_version", this.version);
        return v0_1.substring(0, (v0_1.length() - 1));
    }

    public void initialize(com.google.api.client.http.HttpRequest p1)
    {
        p1.setInterceptor(this);
        return;
    }

    public void intercept(com.google.api.client.http.HttpRequest p5)
    {
        this.computeNonce();
        this.computeTimestamp();
        try {
            this.computeSignature(p5.getMethod().name(), p5.getUrl());
            p5.getHeaders().setAuthorization(this.getAuthorizationHeader());
            return;
        } catch (java.security.GeneralSecurityException v0) {
            java.io.IOException v1_1 = new java.io.IOException();
            v1_1.initCause(v0);
            throw v1_1;
        }
    }
}
