.class public final Lcom/google/api/client/auth/oauth/OAuthCredentialsResponse;
.super Ljava/lang/Object;

.field public callbackConfirmed:Ljava/lang/Boolean;
.field public token:Ljava/lang/String;
.field public tokenSecret:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
