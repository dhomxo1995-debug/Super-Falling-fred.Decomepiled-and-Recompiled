package com.google.api.client.auth.oauth;
public class OAuthGetTemporaryToken extends com.google.api.client.auth.oauth.AbstractOAuthGetToken {
    public String callback;

    public OAuthGetTemporaryToken(String p1)
    {
        super(p1);
        return;
    }

    public com.google.api.client.auth.oauth.OAuthParameters createParameters()
    {
        com.google.api.client.auth.oauth.OAuthParameters v0 = super.createParameters();
        v0.callback = this.callback;
        return v0;
    }
}
