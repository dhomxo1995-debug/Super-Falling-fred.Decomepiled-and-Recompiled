package com.google.api.client.auth.oauth;
public final class OAuthCredentialsResponse {
    public Boolean callbackConfirmed;
    public String token;
    public String tokenSecret;

    public OAuthCredentialsResponse()
    {
        return;
    }
}
