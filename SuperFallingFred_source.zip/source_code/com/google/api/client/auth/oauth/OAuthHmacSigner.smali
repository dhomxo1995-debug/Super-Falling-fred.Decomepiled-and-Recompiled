.class public final Lcom/google/api/client/auth/oauth/OAuthHmacSigner;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/auth/oauth/OAuthSigner;

.field public clientSharedSecret:Ljava/lang/String;
.field public tokenSharedSecret:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public computeSignature(Ljava/lang/String;)Ljava/lang/String;
    .registers 10
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    iget-object v0, v8, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->clientSharedSecret Ljava/lang/String;
    if-eqz v0, +009h
    invoke-static v0, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-virtual v2, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const/16 v6, 38
    invoke-virtual v2, v6, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    iget-object v5, v8, Lcom/google/api/client/auth/oauth/OAuthHmacSigner;->tokenSharedSecret Ljava/lang/String;
    if-eqz v5, +009h
    invoke-static v5, Lcom/google/api/client/auth/oauth/OAuthParameters;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-virtual v2, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    new-instance v4, Ljavax/crypto/spec/SecretKeySpec;
    invoke-static v1, Lcom/google/api/client/util/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v6
    const-string v7, "HmacSHA1"
    invoke-direct v4, v6, v7, Ljavax/crypto/spec/SecretKeySpec;-><init>([B Ljava/lang/String;)V
    const-string v6, "HmacSHA1"
    invoke-static v6, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;)Ljavax/crypto/Mac;
    move-result-object v3
    invoke-virtual v3, v4, Ljavax/crypto/Mac;->init(Ljava/security/Key;)V
    invoke-static v9, Lcom/google/api/client/util/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v6
    invoke-virtual v3, v6, Ljavax/crypto/Mac;->doFinal([B)[B
    move-result-object v6
    invoke-static v6, Lcom/google/api/client/util/Base64;->encodeBase64String([B)Ljava/lang/String;
    move-result-object v6
    return-object v6
.end method

.method public getSignatureMethod()Ljava/lang/String;
    .registers 2
    const-string v0, "HMAC-SHA1"
    return-object v0
.end method
