package com.google.api.client.auth.oauth;
public class OAuthGetAccessToken extends com.google.api.client.auth.oauth.AbstractOAuthGetToken {
    public String temporaryToken;
    public String verifier;

    public OAuthGetAccessToken(String p1)
    {
        super(p1);
        return;
    }

    public com.google.api.client.auth.oauth.OAuthParameters createParameters()
    {
        com.google.api.client.auth.oauth.OAuthParameters v0 = super.createParameters();
        v0.token = this.temporaryToken;
        v0.verifier = this.verifier;
        return v0;
    }
}
