.class public interface abstract Lcom/google/api/client/auth/oauth/OAuthSigner;
.super Ljava/lang/Object;


.method public abstract computeSignature(Ljava/lang/String;)Ljava/lang/String;
    # abstract or native method
.end method

.method public abstract getSignatureMethod()Ljava/lang/String;
    # abstract or native method
.end method
