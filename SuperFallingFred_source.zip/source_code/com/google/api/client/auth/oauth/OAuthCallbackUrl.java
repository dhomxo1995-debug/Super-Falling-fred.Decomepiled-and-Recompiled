package com.google.api.client.auth.oauth;
public class OAuthCallbackUrl extends com.google.api.client.http.GenericUrl {
    public String token;
    public String verifier;

    public OAuthCallbackUrl(String p1)
    {
        super(p1);
        return;
    }
}
