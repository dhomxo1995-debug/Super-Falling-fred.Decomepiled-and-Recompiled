package com.google.api.client.auth.oauth;
public class OAuthAuthorizeTemporaryTokenUrl extends com.google.api.client.http.GenericUrl {
    public String temporaryToken;

    public OAuthAuthorizeTemporaryTokenUrl(String p1)
    {
        super(p1);
        return;
    }
}
