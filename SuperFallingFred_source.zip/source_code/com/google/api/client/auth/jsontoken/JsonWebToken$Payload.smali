.class public Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
.super Lcom/google/api/client/json/GenericJson;

.field private audience:Ljava/lang/String;
.field private final clock:Lcom/google/api/client/util/Clock;
.field private expirationTimeSeconds:Ljava/lang/Long;
.field private issuedAtTimeSeconds:Ljava/lang/Long;
.field private issuer:Ljava/lang/String;
.field private jwtId:Ljava/lang/String;
.field private notBeforeTimeSeconds:Ljava/lang/Long;
.field private principal:Ljava/lang/String;
.field private type:Ljava/lang/String;

.method public constructor <init>()V
    .registers 2
    sget-object v0, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    invoke-direct v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;-><init>(Lcom/google/api/client/util/Clock;)V
    return-void
.end method

.method public constructor <init>(Lcom/google/api/client/util/Clock;)V
    .registers 3
    invoke-direct v1, Lcom/google/api/client/json/GenericJson;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/Clock;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->clock Lcom/google/api/client/util/Clock;
    return-void
.end method

.method public getAudience()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->audience Ljava/lang/String;
    return-object v0
.end method

.method public getExpirationTimeSeconds()Ljava/lang/Long;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->expirationTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public getIssuedAtTimeSeconds()Ljava/lang/Long;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuedAtTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public getIssuer()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuer Ljava/lang/String;
    return-object v0
.end method

.method public getJwtId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->jwtId Ljava/lang/String;
    return-object v0
.end method

.method public getNotBeforeTimeSeconds()Ljava/lang/Long;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->notBeforeTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public getPrincipal()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->principal Ljava/lang/String;
    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->type Ljava/lang/String;
    return-object v0
.end method

.method public isValidTime(J)Z
    .registers 9
    const-wide/16 v4, 1000
    iget-object v2, v6, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->clock Lcom/google/api/client/util/Clock;
    invoke-interface v2, Lcom/google/api/client/util/Clock;->currentTimeMillis()J
    move-result-wide v0
    iget-object v2, v6, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->expirationTimeSeconds Ljava/lang/Long;
    if-eqz v2, +00eh
    iget-object v2, v6, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->expirationTimeSeconds Ljava/lang/Long;
    invoke-virtual v2, Ljava/lang/Long;->longValue()J
    move-result-wide v2
    add-long/2addr v2, v7
    mul-long/2addr v2, v4
    cmp-long v2, v0, v2
    if-gtz v2, +014h
    iget-object v2, v6, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuedAtTimeSeconds Ljava/lang/Long;
    if-eqz v2, +00eh
    iget-object v2, v6, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuedAtTimeSeconds Ljava/lang/Long;
    invoke-virtual v2, Ljava/lang/Long;->longValue()J
    move-result-wide v2
    sub-long/2addr v2, v7
    mul-long/2addr v2, v4
    cmp-long v2, v0, v2
    if-ltz v2, +004h
    const/4 v2, 1
    return v2
    const/4 v2, 0
    goto -2h
.end method

.method public setAudience(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->audience Ljava/lang/String;
    return-object v0
.end method

.method public setExpirationTimeSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->expirationTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public setIssuedAtTimeSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuedAtTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public setIssuer(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->issuer Ljava/lang/String;
    return-object v0
.end method

.method public setJwtId(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->jwtId Ljava/lang/String;
    return-object v0
.end method

.method public setNotBeforeTimeSeconds(Ljava/lang/Long;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->notBeforeTimeSeconds Ljava/lang/Long;
    return-object v0
.end method

.method public setPrincipal(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->principal Ljava/lang/String;
    return-object v0
.end method

.method public setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;->type Ljava/lang/String;
    return-object v0
.end method
