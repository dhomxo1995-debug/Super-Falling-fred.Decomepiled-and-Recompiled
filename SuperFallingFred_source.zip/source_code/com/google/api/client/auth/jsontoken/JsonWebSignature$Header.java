package com.google.api.client.auth.jsontoken;
public class JsonWebSignature$Header extends com.google.api.client.auth.jsontoken.JsonWebToken$Header {
    private String algorithm;
    private String jwkUrl;
    private String keyId;
    private String x509Thumbprint;
    private String x509Url;

    public JsonWebSignature$Header()
    {
        return;
    }

    public final String getAlgorithm()
    {
        return this.algorithm;
    }

    public String getJwkUrl()
    {
        return this.jwkUrl;
    }

    public String getKeyId()
    {
        return this.keyId;
    }

    public String getX509Thumbprint()
    {
        return this.x509Thumbprint;
    }

    public String getX509Url()
    {
        return this.x509Url;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setAlgorithm(String p1)
    {
        this.algorithm = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setJwkUrl(String p1)
    {
        this.jwkUrl = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setKeyId(String p1)
    {
        this.keyId = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setType(String p1)
    {
        super.setType(p1);
        return this;
    }

    public bridge synthetic com.google.api.client.auth.jsontoken.JsonWebToken$Header setType(String p2)
    {
        return this.setType(p2);
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setX509Thumbprint(String p1)
    {
        this.x509Thumbprint = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header setX509Url(String p1)
    {
        this.x509Url = p1;
        return this;
    }
}
