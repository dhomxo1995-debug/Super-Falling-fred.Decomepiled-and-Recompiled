.class public Lcom/google/api/client/auth/jsontoken/JsonWebSignature;
.super Lcom/google/api/client/auth/jsontoken/JsonWebToken;

.field private final signatureBytes:[B
.field private final signedContentBytes:[B

.method public constructor <init>(Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header; Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload; [B [B)V
    .registers 5
    invoke-direct v0, v1, v2, Lcom/google/api/client/auth/jsontoken/JsonWebToken;-><init>(Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header; Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;)V
    iput-object v3, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->signatureBytes [B
    iput-object v4, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->signedContentBytes [B
    return-void
.end method

.method public static parse(Lcom/google/api/client/json/JsonFactory; Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature;
    .registers 3
    invoke-static v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->parser(Lcom/google/api/client/json/JsonFactory;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
    move-result-object v0
    invoke-virtual v0, v2, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->parse(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature;
    move-result-object v0
    return-object v0
.end method

.method public static parser(Lcom/google/api/client/json/JsonFactory;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
    .registers 2
    new-instance v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
    invoke-direct v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;-><init>(Lcom/google/api/client/json/JsonFactory;)V
    return-object v0
.end method

.method public getHeader()Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    invoke-super v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken;->getHeader()Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    return-object v0
.end method

.method public bridge synthetic getHeader()Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->getHeader()Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    move-result-object v0
    return-object v0
.end method

.method public final getSignatureBytes()[B
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->signatureBytes [B
    return-object v0
.end method

.method public final getSignedContentBytes()[B
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;->signedContentBytes [B
    return-object v0
.end method
