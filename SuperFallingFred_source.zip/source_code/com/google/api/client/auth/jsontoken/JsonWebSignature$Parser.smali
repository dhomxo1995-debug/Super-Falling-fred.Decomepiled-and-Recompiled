.class public final Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
.super Ljava/lang/Object;

.field private headerClass:Ljava/lang/Class;
.field private final jsonFactory:Lcom/google/api/client/json/JsonFactory;
.field private payloadClass:Ljava/lang/Class;

.method public constructor <init>(Lcom/google/api/client/json/JsonFactory;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    const-class v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->headerClass Ljava/lang/Class;
    const-class v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->payloadClass Ljava/lang/Class;
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/json/JsonFactory;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-void
.end method

.method public getHeaderClass()Ljava/lang/Class;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->headerClass Ljava/lang/Class;
    return-object v0
.end method

.method public getJsonFactory()Lcom/google/api/client/json/JsonFactory;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    return-object v0
.end method

.method public getPayloadClass()Ljava/lang/Class;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->payloadClass Ljava/lang/Class;
    return-object v0
.end method

.method public parse(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature;
    .registers 15
    const/16 v12, 46
    const/4 v11, -1
    const/4 v9, 1
    const/4 v10, 0
    invoke-virtual v14, v12, Ljava/lang/String;->indexOf(I)I
    move-result v0
    if-eq v0, v11, +06fh
    move v8, v9
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    invoke-virtual v14, v10, v0, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v8
    invoke-static v8, Lcom/google/api/client/util/Base64;->decodeBase64(Ljava/lang/String;)[B
    move-result-object v2
    add-int/lit8 v8, v0, 1
    invoke-virtual v14, v12, v8, Ljava/lang/String;->indexOf(I I)I
    move-result v5
    if-eq v5, v11, +05dh
    move v8, v9
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    add-int/lit8 v8, v5, 1
    invoke-virtual v14, v12, v8, Ljava/lang/String;->indexOf(I I)I
    move-result v8
    if-ne v8, v11, +053h
    move v8, v9
    invoke-static v8, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    add-int/lit8 v8, v0, 1
    invoke-virtual v14, v8, v5, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v8
    invoke-static v8, Lcom/google/api/client/util/Base64;->decodeBase64(Ljava/lang/String;)[B
    move-result-object v4
    add-int/lit8 v8, v5, 1
    invoke-virtual v14, v8, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v8
    invoke-static v8, Lcom/google/api/client/util/Base64;->decodeBase64(Ljava/lang/String;)[B
    move-result-object v6
    invoke-virtual v14, v10, v5, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v8
    invoke-static v8, Lcom/google/api/client/util/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v7
    iget-object v8, v13, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    new-instance v11, Ljava/io/ByteArrayInputStream;
    invoke-direct v11, v2, Ljava/io/ByteArrayInputStream;-><init>([B)V
    iget-object v12, v13, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->headerClass Ljava/lang/Class;
    invoke-virtual v8, v11, v12, Lcom/google/api/client/json/JsonFactory;->fromInputStream(Ljava/io/InputStream; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    invoke-virtual v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->getAlgorithm()Ljava/lang/String;
    move-result-object v8
    if-eqz v8, +020h
    invoke-static v9, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    iget-object v8, v13, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->jsonFactory Lcom/google/api/client/json/JsonFactory;
    new-instance v9, Ljava/io/ByteArrayInputStream;
    invoke-direct v9, v4, Ljava/io/ByteArrayInputStream;-><init>([B)V
    iget-object v10, v13, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->payloadClass Ljava/lang/Class;
    invoke-virtual v8, v9, v10, Lcom/google/api/client/json/JsonFactory;->fromInputStream(Ljava/io/InputStream; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v3
    check-cast v3, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    new-instance v8, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;
    invoke-direct v8, v1, v3, v6, v7, Lcom/google/api/client/auth/jsontoken/JsonWebSignature;-><init>(Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header; Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload; [B [B)V
    return-object v8
    move v8, v10
    goto -6dh
    move v8, v10
    goto -5bh
    move v8, v10
    goto -51h
    move v9, v10
    goto -1fh
.end method

.method public setHeaderClass(Ljava/lang/Class;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->headerClass Ljava/lang/Class;
    return-object v0
.end method

.method public setPayloadClass(Ljava/lang/Class;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Parser;->payloadClass Ljava/lang/Class;
    return-object v0
.end method
