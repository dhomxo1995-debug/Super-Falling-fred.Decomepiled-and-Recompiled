package com.google.api.client.auth.jsontoken;
public final class JsonWebSignature$Parser {
    private Class headerClass;
    private final com.google.api.client.json.JsonFactory jsonFactory;
    private Class payloadClass;

    public JsonWebSignature$Parser(com.google.api.client.json.JsonFactory p2)
    {
        this.headerClass = com.google.api.client.auth.jsontoken.JsonWebSignature$Header;
        this.payloadClass = com.google.api.client.auth.jsontoken.JsonWebToken$Payload;
        this.jsonFactory = ((com.google.api.client.json.JsonFactory) com.google.common.base.Preconditions.checkNotNull(p2));
        return;
    }

    public Class getHeaderClass()
    {
        return this.headerClass;
    }

    public com.google.api.client.json.JsonFactory getJsonFactory()
    {
        return this.jsonFactory;
    }

    public Class getPayloadClass()
    {
        return this.payloadClass;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature parse(String p14)
    {
        com.google.api.client.auth.jsontoken.JsonWebSignature v8_16;
        Class v9_0 = 1;
        int v0 = p14.indexOf(46);
        if (v0 == -1) {
            v8_16 = 0;
        } else {
            v8_16 = 1;
        }
        com.google.api.client.auth.jsontoken.JsonWebSignature v8_2;
        com.google.common.base.Preconditions.checkArgument(v8_16);
        byte[] v2 = com.google.api.client.util.Base64.decodeBase64(p14.substring(0, v0));
        int v5 = p14.indexOf(46, (v0 + 1));
        if (v5 == -1) {
            v8_2 = 0;
        } else {
            v8_2 = 1;
        }
        com.google.api.client.auth.jsontoken.JsonWebSignature v8_5;
        com.google.common.base.Preconditions.checkArgument(v8_2);
        if (p14.indexOf(46, (v5 + 1)) != -1) {
            v8_5 = 0;
        } else {
            v8_5 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v8_5);
        byte[] v4 = com.google.api.client.util.Base64.decodeBase64(p14.substring((v0 + 1), v5));
        byte[] v6 = com.google.api.client.util.Base64.decodeBase64(p14.substring((v5 + 1)));
        byte[] v7 = com.google.api.client.util.StringUtils.getBytesUtf8(p14.substring(0, v5));
        com.google.api.client.auth.jsontoken.JsonWebSignature$Header v1_1 = ((com.google.api.client.auth.jsontoken.JsonWebSignature$Header) this.jsonFactory.fromInputStream(new java.io.ByteArrayInputStream(v2), this.headerClass));
        if (v1_1.getAlgorithm() == null) {
            v9_0 = 0;
        }
        com.google.common.base.Preconditions.checkArgument(v9_0);
        return new com.google.api.client.auth.jsontoken.JsonWebSignature(v1_1, ((com.google.api.client.auth.jsontoken.JsonWebToken$Payload) this.jsonFactory.fromInputStream(new java.io.ByteArrayInputStream(v4), this.payloadClass)), v6, v7);
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Parser setHeaderClass(Class p1)
    {
        this.headerClass = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Parser setPayloadClass(Class p1)
    {
        this.payloadClass = p1;
        return this;
    }
}
