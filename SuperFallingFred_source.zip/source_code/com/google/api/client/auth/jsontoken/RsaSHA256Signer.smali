.class public Lcom/google/api/client/auth/jsontoken/RsaSHA256Signer;
.super Ljava/lang/Object;


.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static sign(Ljava/security/PrivateKey; Lcom/google/api/client/json/JsonFactory; Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header; Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;)Ljava/lang/String;
    .registers 10
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v7, v8, Lcom/google/api/client/json/JsonFactory;->toByteArray(Ljava/lang/Object;)[B
    move-result-object v5
    invoke-static v5, Lcom/google/api/client/util/Base64;->encodeBase64URLSafeString([B)Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, "."
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v7, v9, Lcom/google/api/client/json/JsonFactory;->toByteArray(Ljava/lang/Object;)[B
    move-result-object v5
    invoke-static v5, Lcom/google/api/client/util/Base64;->encodeBase64URLSafeString([B)Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/util/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v1
    const-string v4, "SHA256withRSA"
    invoke-static v4, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;
    move-result-object v3
    invoke-virtual v3, v6, Ljava/security/Signature;->initSign(Ljava/security/PrivateKey;)V
    invoke-virtual v3, v1, Ljava/security/Signature;->update([B)V
    invoke-virtual v3, Ljava/security/Signature;->sign()[B
    move-result-object v2
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v4, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, "."
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-static v2, Lcom/google/api/client/util/Base64;->encodeBase64URLSafeString([B)Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    return-object v4
.end method
