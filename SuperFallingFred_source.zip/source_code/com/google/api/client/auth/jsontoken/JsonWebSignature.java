package com.google.api.client.auth.jsontoken;
public class JsonWebSignature extends com.google.api.client.auth.jsontoken.JsonWebToken {
    private final byte[] signatureBytes;
    private final byte[] signedContentBytes;

    public JsonWebSignature(com.google.api.client.auth.jsontoken.JsonWebSignature$Header p1, com.google.api.client.auth.jsontoken.JsonWebToken$Payload p2, byte[] p3, byte[] p4)
    {
        super(p1, p2);
        super.signatureBytes = p3;
        super.signedContentBytes = p4;
        return;
    }

    public static com.google.api.client.auth.jsontoken.JsonWebSignature parse(com.google.api.client.json.JsonFactory p1, String p2)
    {
        return com.google.api.client.auth.jsontoken.JsonWebSignature.parser(p1).parse(p2);
    }

    public static com.google.api.client.auth.jsontoken.JsonWebSignature$Parser parser(com.google.api.client.json.JsonFactory p1)
    {
        return new com.google.api.client.auth.jsontoken.JsonWebSignature$Parser(p1);
    }

    public com.google.api.client.auth.jsontoken.JsonWebSignature$Header getHeader()
    {
        return ((com.google.api.client.auth.jsontoken.JsonWebSignature$Header) super.getHeader());
    }

    public bridge synthetic com.google.api.client.auth.jsontoken.JsonWebToken$Header getHeader()
    {
        return this.getHeader();
    }

    public final byte[] getSignatureBytes()
    {
        return this.signatureBytes;
    }

    public final byte[] getSignedContentBytes()
    {
        return this.signedContentBytes;
    }
}
