.class public Lcom/google/api/client/auth/jsontoken/JsonWebToken;
.super Ljava/lang/Object;

.field private final header:Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
.field private final payload:Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;

.method public constructor <init>(Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header; Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;)V
    .registers 4
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken;->header Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    iput-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken;->payload Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    return-void
.end method

.method public getHeader()Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken;->header Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    return-object v0
.end method

.method public getPayload()Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken;->payload Lcom/google/api/client/auth/jsontoken/JsonWebToken$Payload;
    return-object v0
.end method
