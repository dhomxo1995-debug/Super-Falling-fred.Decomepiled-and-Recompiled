package com.google.api.client.auth.jsontoken;
public class RsaSHA256Signer {

    private RsaSHA256Signer()
    {
        return;
    }

    public static String sign(java.security.PrivateKey p6, com.google.api.client.json.JsonFactory p7, com.google.api.client.auth.jsontoken.JsonWebSignature$Header p8, com.google.api.client.auth.jsontoken.JsonWebToken$Payload p9)
    {
        String v0 = new StringBuilder().append(com.google.api.client.util.Base64.encodeBase64URLSafeString(p7.toByteArray(p8))).append(".").append(com.google.api.client.util.Base64.encodeBase64URLSafeString(p7.toByteArray(p9))).toString();
        byte[] v1 = com.google.api.client.util.StringUtils.getBytesUtf8(v0);
        java.security.Signature v3 = java.security.Signature.getInstance("SHA256withRSA");
        v3.initSign(p6);
        v3.update(v1);
        return new StringBuilder().append(v0).append(".").append(com.google.api.client.util.Base64.encodeBase64URLSafeString(v3.sign())).toString();
    }
}
