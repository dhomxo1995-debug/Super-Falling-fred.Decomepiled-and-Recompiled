package com.google.api.client.auth.jsontoken;
public class JsonWebToken {
    private final com.google.api.client.auth.jsontoken.JsonWebToken$Header header;
    private final com.google.api.client.auth.jsontoken.JsonWebToken$Payload payload;

    public JsonWebToken(com.google.api.client.auth.jsontoken.JsonWebToken$Header p2, com.google.api.client.auth.jsontoken.JsonWebToken$Payload p3)
    {
        this.header = ((com.google.api.client.auth.jsontoken.JsonWebToken$Header) com.google.common.base.Preconditions.checkNotNull(p2));
        this.payload = ((com.google.api.client.auth.jsontoken.JsonWebToken$Payload) com.google.common.base.Preconditions.checkNotNull(p3));
        return;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Header getHeader()
    {
        return this.header;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload getPayload()
    {
        return this.payload;
    }
}
