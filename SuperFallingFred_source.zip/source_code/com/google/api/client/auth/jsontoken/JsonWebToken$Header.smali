.class public Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
.super Lcom/google/api/client/json/GenericJson;

.field private type:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/json/GenericJson;-><init>()V
    return-void
.end method

.method public final getType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;->type Ljava/lang/String;
    return-object v0
.end method

.method public setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;->type Ljava/lang/String;
    return-object v0
.end method
