.class public Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
.super Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;

.field private algorithm:Ljava/lang/String;
.field private jwkUrl:Ljava/lang/String;
.field private keyId:Ljava/lang/String;
.field private x509Thumbprint:Ljava/lang/String;
.field private x509Url:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;-><init>()V
    return-void
.end method

.method public final getAlgorithm()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->algorithm Ljava/lang/String;
    return-object v0
.end method

.method public getJwkUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->jwkUrl Ljava/lang/String;
    return-object v0
.end method

.method public getKeyId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->keyId Ljava/lang/String;
    return-object v0
.end method

.method public getX509Thumbprint()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->x509Thumbprint Ljava/lang/String;
    return-object v0
.end method

.method public getX509Url()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->x509Url Ljava/lang/String;
    return-object v0
.end method

.method public setAlgorithm(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->algorithm Ljava/lang/String;
    return-object v0
.end method

.method public setJwkUrl(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->jwkUrl Ljava/lang/String;
    return-object v0
.end method

.method public setKeyId(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->keyId Ljava/lang/String;
    return-object v0
.end method

.method public setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    invoke-super v0, v1, Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;->setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    return-object v0
.end method

.method public bridge synthetic setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebToken$Header;
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->setType(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    move-result-object v0
    return-object v0
.end method

.method public setX509Thumbprint(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->x509Thumbprint Ljava/lang/String;
    return-object v0
.end method

.method public setX509Url(Ljava/lang/String;)Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/auth/jsontoken/JsonWebSignature$Header;->x509Url Ljava/lang/String;
    return-object v0
.end method
