package com.google.api.client.auth.jsontoken;
public class JsonWebToken$Header extends com.google.api.client.json.GenericJson {
    private String type;

    public JsonWebToken$Header()
    {
        return;
    }

    public final String getType()
    {
        return this.type;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Header setType(String p1)
    {
        this.type = p1;
        return this;
    }
}
