package com.google.api.client.auth.jsontoken;
public class JsonWebToken$Payload extends com.google.api.client.json.GenericJson {
    private String audience;
    private final com.google.api.client.util.Clock clock;
    private Long expirationTimeSeconds;
    private Long issuedAtTimeSeconds;
    private String issuer;
    private String jwtId;
    private Long notBeforeTimeSeconds;
    private String principal;
    private String type;

    public JsonWebToken$Payload()
    {
        this(com.google.api.client.util.Clock.SYSTEM);
        return;
    }

    public JsonWebToken$Payload(com.google.api.client.util.Clock p2)
    {
        this.clock = ((com.google.api.client.util.Clock) com.google.common.base.Preconditions.checkNotNull(p2));
        return;
    }

    public String getAudience()
    {
        return this.audience;
    }

    public Long getExpirationTimeSeconds()
    {
        return this.expirationTimeSeconds;
    }

    public Long getIssuedAtTimeSeconds()
    {
        return this.issuedAtTimeSeconds;
    }

    public String getIssuer()
    {
        return this.issuer;
    }

    public String getJwtId()
    {
        return this.jwtId;
    }

    public Long getNotBeforeTimeSeconds()
    {
        return this.notBeforeTimeSeconds;
    }

    public String getPrincipal()
    {
        return this.principal;
    }

    public String getType()
    {
        return this.type;
    }

    public boolean isValidTime(long p7)
    {
        int v2_9;
        long v0 = this.clock.currentTimeMillis();
        if (((this.expirationTimeSeconds != null) && (v0 > ((this.expirationTimeSeconds.longValue() + p7) * 1000))) || ((this.issuedAtTimeSeconds != null) && (v0 < ((this.issuedAtTimeSeconds.longValue() - p7) * 1000)))) {
            v2_9 = 0;
        } else {
            v2_9 = 1;
        }
        return v2_9;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setAudience(String p1)
    {
        this.audience = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setExpirationTimeSeconds(Long p1)
    {
        this.expirationTimeSeconds = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setIssuedAtTimeSeconds(Long p1)
    {
        this.issuedAtTimeSeconds = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setIssuer(String p1)
    {
        this.issuer = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setJwtId(String p1)
    {
        this.jwtId = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setNotBeforeTimeSeconds(Long p1)
    {
        this.notBeforeTimeSeconds = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setPrincipal(String p1)
    {
        this.principal = p1;
        return this;
    }

    public com.google.api.client.auth.jsontoken.JsonWebToken$Payload setType(String p1)
    {
        this.type = p1;
        return this;
    }
}
