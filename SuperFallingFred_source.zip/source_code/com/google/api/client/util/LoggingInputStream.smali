.class public Lcom/google/api/client/util/LoggingInputStream;
.super Ljava/io/FilterInputStream;

.field private final logStream:Lcom/google/api/client/util/LoggingByteArrayOutputStream;

.method public constructor <init>(Ljava/io/InputStream; Ljava/util/logging/Logger; Ljava/util/logging/Level; I)V
    .registers 6
    invoke-direct v1, v2, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V
    new-instance v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-direct v0, v3, v4, v5, Lcom/google/api/client/util/LoggingByteArrayOutputStream;-><init>(Ljava/util/logging/Logger; Ljava/util/logging/Level; I)V
    iput-object v0, v1, Lcom/google/api/client/util/LoggingInputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    return-void
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/LoggingInputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->close()V
    invoke-super v1, Ljava/io/FilterInputStream;->close()V
    return-void
.end method

.method public final getLogStream()Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/LoggingInputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    return-object v0
.end method

.method public read()I
    .registers 3
    invoke-super v2, Ljava/io/FilterInputStream;->read()I
    move-result v0
    iget-object v1, v2, Lcom/google/api/client/util/LoggingInputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v1, v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->write(I)V
    return v0
.end method

.method public read([B I I)I
    .registers 6
    invoke-super v2, v3, v4, v5, Ljava/io/FilterInputStream;->read([B I I)I
    move-result v0
    if-lez v0, +007h
    iget-object v1, v2, Lcom/google/api/client/util/LoggingInputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v1, v3, v4, v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->write([B I I)V
    return v0
.end method
