package com.google.api.client.util;
final class DataMap extends java.util.AbstractMap {
    final com.google.api.client.util.ClassInfo classInfo;
    final Object object;

    DataMap(Object p2, boolean p3)
    {
        int v0_0;
        this.object = p2;
        this.classInfo = com.google.api.client.util.ClassInfo.of(p2.getClass(), p3);
        if (this.classInfo.isEnum()) {
            v0_0 = 0;
        } else {
            v0_0 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_0);
        return;
    }

    public boolean containsKey(Object p2)
    {
        int v0_1;
        if (this.get(p2) == null) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }

    public com.google.api.client.util.DataMap$EntrySet entrySet()
    {
        return new com.google.api.client.util.DataMap$EntrySet(this);
    }

    public bridge synthetic java.util.Set entrySet()
    {
        return this.entrySet();
    }

    public Object get(Object p4)
    {
        Object v1_0 = 0;
        if ((p4 instanceof String)) {
            com.google.api.client.util.FieldInfo v0 = this.classInfo.getFieldInfo(((String) p4));
            if (v0 != null) {
                v1_0 = v0.getValue(this.object);
            }
        }
        return v1_0;
    }

    public bridge synthetic Object put(Object p2, Object p3)
    {
        return this.put(((String) p2), p3);
    }

    public Object put(String p5, Object p6)
    {
        com.google.api.client.util.FieldInfo v0 = this.classInfo.getFieldInfo(p5);
        com.google.common.base.Preconditions.checkNotNull(v0, new StringBuilder().append("no field of key ").append(p5).toString());
        Object v1 = v0.getValue(this.object);
        v0.setValue(this.object, com.google.common.base.Preconditions.checkNotNull(p6));
        return v1;
    }
}
