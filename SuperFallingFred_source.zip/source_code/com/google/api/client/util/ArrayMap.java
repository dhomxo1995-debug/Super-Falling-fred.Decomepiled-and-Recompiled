package com.google.api.client.util;
public class ArrayMap extends java.util.AbstractMap implements java.lang.Cloneable {
    private Object[] data;
    int size;

    public ArrayMap()
    {
        return;
    }

    public static com.google.api.client.util.ArrayMap create()
    {
        return new com.google.api.client.util.ArrayMap();
    }

    public static com.google.api.client.util.ArrayMap create(int p1)
    {
        com.google.api.client.util.ArrayMap v0 = com.google.api.client.util.ArrayMap.create();
        v0.ensureCapacity(p1);
        return v0;
    }

    private int getDataIndexOfKey(Object p6)
    {
        int v2 = 0;
        while (v2 < (this.size << 1)) {
            Object v3 = this.data[v2];
            if (p6 != null) {
                if (p6.equals(v3)) {
                    return v2;
                }
            } else {
                if (v3 == null) {
                    return v2;
                }
            }
            v2 += 2;
        }
        v2 = -2;
        return v2;
    }

    public static varargs com.google.api.client.util.ArrayMap of(Object[] p6)
    {
        com.google.api.client.util.ArrayMap v2 = com.google.api.client.util.ArrayMap.create(1);
        int v1 = p6.length;
        if (1 != (v1 % 2)) {
            v2.size = (p6.length / 2);
            Object[] v0 = new Object[v1];
            v2.data = v0;
            System.arraycopy(p6, 0, v0, 0, v1);
            return v2;
        } else {
            throw new IllegalArgumentException(new StringBuilder().append("missing value for last key: ").append(p6[(v1 - 1)]).toString());
        }
    }

    private Object removeFromDataIndexOfKey(int p7)
    {
        Object v3;
        int v1 = (this.size << 1);
        if ((p7 >= 0) && (p7 < v1)) {
            v3 = this.valueAtDataIndex((p7 + 1));
            int v2 = ((v1 - p7) - 2);
            if (v2 != 0) {
                System.arraycopy(this.data, (p7 + 2), this.data, p7, v2);
            }
            this.size = (this.size - 1);
            this.setData((v1 - 2), 0, 0);
        } else {
            v3 = 0;
        }
        return v3;
    }

    private void setData(int p3, Object p4, Object p5)
    {
        Object[] v0 = this.data;
        v0[p3] = p4;
        v0[(p3 + 1)] = p5;
        return;
    }

    private void setDataCapacity(int p6)
    {
        if (p6 != 0) {
            int v2 = this.size;
            Object[] v1 = this.data;
            if ((v2 == 0) || (p6 != v1.length)) {
                Object[] v0 = new Object[p6];
                this.data = v0;
                if (v2 != 0) {
                    System.arraycopy(v1, 0, v0, 0, (v2 << 1));
                }
            }
        } else {
            this.data = 0;
        }
        return;
    }

    private Object valueAtDataIndex(int p3)
    {
        Object v0;
        if (p3 >= 0) {
            v0 = this.data[p3];
        } else {
            v0 = 0;
        }
        return v0;
    }

    public final void add(Object p2, Object p3)
    {
        this.set(this.size, p2, p3);
        return;
    }

    public void clear()
    {
        this.size = 0;
        this.data = 0;
        return;
    }

    public com.google.api.client.util.ArrayMap clone()
    {
        try {
            int v3_1 = ((com.google.api.client.util.ArrayMap) super.clone());
            Object[] v0 = this.data;
        } catch (CloneNotSupportedException v1) {
            v3_1 = 0;
            return v3_1;
        }
        if (v0 == null) {
            return v3_1;
        } else {
            int v2 = v0.length;
            Object[] v4 = new Object[v2];
            v3_1.data = v4;
            System.arraycopy(v0, 0, v4, 0, v2);
            return v3_1;
        }
    }

    public bridge synthetic Object clone()
    {
        return this.clone();
    }

    public final boolean containsKey(Object p3)
    {
        int v0_1;
        if (-2 == this.getDataIndexOfKey(p3)) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }

    public final boolean containsValue(Object p6)
    {
        int v2 = 1;
        while (v2 < (this.size << 1)) {
            Object v3 = this.data[v2];
            if (p6 != null) {
                if (!p6.equals(v3)) {
                    v2 += 2;
                }
            } else {
                if (v3 != null) {
                }
            }
            int v4_1 = 1;
            return v4_1;
        }
        v4_1 = 0;
        return v4_1;
    }

    public final void ensureCapacity(int p7)
    {
        int v3;
        Object[] v0 = this.data;
        int v1 = (p7 << 1);
        if (v0 != null) {
            v3 = v0.length;
        } else {
            v3 = 0;
        }
        if (v1 > v3) {
            int v2 = (((v3 / 2) * 3) + 1);
            if ((v2 % 2) == 1) {
                v2++;
            }
            if (v2 < v1) {
                v2 = v1;
            }
            this.setDataCapacity(v2);
        }
        return;
    }

    public final java.util.Set entrySet()
    {
        return new com.google.api.client.util.ArrayMap$EntrySet(this);
    }

    public final Object get(Object p2)
    {
        return this.valueAtDataIndex((this.getDataIndexOfKey(p2) + 1));
    }

    public final int getIndexOfKey(Object p2)
    {
        return (this.getDataIndexOfKey(p2) >> 1);
    }

    public final Object getKey(int p4)
    {
        if ((p4 >= 0) && (p4 < this.size)) {
            Object v0 = this.data[(p4 << 1)];
        } else {
            v0 = 0;
        }
        return v0;
    }

    public final Object getValue(int p2)
    {
        if ((p2 >= 0) && (p2 < this.size)) {
            Object v0_3 = this.valueAtDataIndex(((p2 << 1) + 1));
        } else {
            v0_3 = 0;
        }
        return v0_3;
    }

    public final Object put(Object p3, Object p4)
    {
        int v0 = this.getIndexOfKey(p3);
        if (v0 == -1) {
            v0 = this.size;
        }
        return this.set(v0, p3, p4);
    }

    public final Object remove(int p2)
    {
        return this.removeFromDataIndexOfKey((p2 << 1));
    }

    public final Object remove(Object p2)
    {
        return this.removeFromDataIndexOfKey(this.getDataIndexOfKey(p2));
    }

    public final Object set(int p5, Object p6)
    {
        if ((p5 >= 0) && (p5 < this.size)) {
            int v2 = ((p5 << 1) + 1);
            Object v0 = this.valueAtDataIndex(v2);
            this.data[v2] = p6;
            return v0;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    public final Object set(int p5, Object p6, Object p7)
    {
        if (p5 >= 0) {
            int v1 = (p5 + 1);
            this.ensureCapacity(v1);
            int v0 = (p5 << 1);
            Object v2 = this.valueAtDataIndex((v0 + 1));
            this.setData(v0, p6, p7);
            if (v1 > this.size) {
                this.size = v1;
            }
            return v2;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    public final int size()
    {
        return this.size;
    }

    public final void trim()
    {
        this.setDataCapacity((this.size << 1));
        return;
    }
}
