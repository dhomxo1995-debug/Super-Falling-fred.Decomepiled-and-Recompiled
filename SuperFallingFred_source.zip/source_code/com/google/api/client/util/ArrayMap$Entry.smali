.class final Lcom/google/api/client/util/ArrayMap$Entry;
.super Ljava/lang/Object;
.implements Ljava/util/Map$Entry;

.field private index:I
.field final synthetic this$0:Lcom/google/api/client/util/ArrayMap;

.method constructor <init>(Lcom/google/api/client/util/ArrayMap; I)V
    .registers 3
    iput-object v1, v0, Lcom/google/api/client/util/ArrayMap$Entry;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput v2, v0, Lcom/google/api/client/util/ArrayMap$Entry;->index I
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7
    const/4 v1, 1
    const/4 v2, 0
    if-ne v5, v6, +003h
    return v1
    instance-of v3, v6, Ljava/util/Map$Entry;
    if-nez v3, +004h
    move v1, v2
    goto -6h
    move-object v0, v6
    check-cast v0, Ljava/util/Map$Entry;
    invoke-virtual v5, Lcom/google/api/client/util/ArrayMap$Entry;->getKey()Ljava/lang/Object;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v4
    invoke-static v3, v4, Lcom/google/common/base/Objects;->equal(Ljava/lang/Object; Ljava/lang/Object;)Z
    move-result v3
    if-eqz v3, +010h
    invoke-virtual v5, Lcom/google/api/client/util/ArrayMap$Entry;->getValue()Ljava/lang/Object;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v4
    invoke-static v3, v4, Lcom/google/common/base/Objects;->equal(Ljava/lang/Object; Ljava/lang/Object;)Z
    move-result v3
    if-nez v3, -024h
    move v1, v2
    goto -27h
.end method

.method public getKey()Ljava/lang/Object;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/util/ArrayMap$Entry;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v1, v2, Lcom/google/api/client/util/ArrayMap$Entry;->index I
    invoke-virtual v0, v1, Lcom/google/api/client/util/ArrayMap;->getKey(I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public getValue()Ljava/lang/Object;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/util/ArrayMap$Entry;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v1, v2, Lcom/google/api/client/util/ArrayMap$Entry;->index I
    invoke-virtual v0, v1, Lcom/google/api/client/util/ArrayMap;->getValue(I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public hashCode()I
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/util/ArrayMap$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Object;->hashCode()I
    move-result v0
    invoke-virtual v2, Lcom/google/api/client/util/ArrayMap$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Object;->hashCode()I
    move-result v1
    xor-int/2addr v0, v1
    return v0
.end method

.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    iget-object v0, v2, Lcom/google/api/client/util/ArrayMap$Entry;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v1, v2, Lcom/google/api/client/util/ArrayMap$Entry;->index I
    invoke-virtual v0, v1, v3, Lcom/google/api/client/util/ArrayMap;->set(I Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
