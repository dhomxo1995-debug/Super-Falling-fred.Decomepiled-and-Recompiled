.class final Lcom/google/api/client/util/ArrayMap$EntryIterator;
.super Ljava/lang/Object;
.implements Ljava/util/Iterator;

.field private nextIndex:I
.field private removed:Z
.field final synthetic this$0:Lcom/google/api/client/util/ArrayMap;

.method constructor <init>(Lcom/google/api/client/util/ArrayMap;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/ArrayMap$EntryIterator;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public hasNext()Z
    .registers 3
    iget v0, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->nextIndex I
    iget-object v1, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v1, v1, Lcom/google/api/client/util/ArrayMap;->size I
    if-ge v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/ArrayMap$EntryIterator;->next()Ljava/util/Map$Entry;
    move-result-object v0
    return-object v0
.end method

.method public next()Ljava/util/Map$Entry;
    .registers 4
    iget v0, v3, Lcom/google/api/client/util/ArrayMap$EntryIterator;->nextIndex I
    iget-object v1, v3, Lcom/google/api/client/util/ArrayMap$EntryIterator;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v1, v1, Lcom/google/api/client/util/ArrayMap;->size I
    if-ne v0, v1, +008h
    new-instance v1, Ljava/util/NoSuchElementException;
    invoke-direct v1, Ljava/util/NoSuchElementException;-><init>()V
    throw v1
    iget v1, v3, Lcom/google/api/client/util/ArrayMap$EntryIterator;->nextIndex I
    add-int/lit8 v1, v1, 1
    iput v1, v3, Lcom/google/api/client/util/ArrayMap$EntryIterator;->nextIndex I
    new-instance v1, Lcom/google/api/client/util/ArrayMap$Entry;
    iget-object v2, v3, Lcom/google/api/client/util/ArrayMap$EntryIterator;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-direct v1, v2, v0, Lcom/google/api/client/util/ArrayMap$Entry;-><init>(Lcom/google/api/client/util/ArrayMap; I)V
    return-object v1
.end method

.method public remove()V
    .registers 3
    iget v1, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->nextIndex I
    add-int/lit8 v0, v1, -1
    iget-boolean v1, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->removed Z
    if-nez v1, +004h
    if-gez v0, +008h
    new-instance v1, Ljava/lang/IllegalArgumentException;
    invoke-direct v1, Ljava/lang/IllegalArgumentException;-><init>()V
    throw v1
    iget-object v1, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-virtual v1, v0, Lcom/google/api/client/util/ArrayMap;->remove(I)Ljava/lang/Object;
    const/4 v1, 1
    iput-boolean v1, v2, Lcom/google/api/client/util/ArrayMap$EntryIterator;->removed Z
    return-void
.end method
