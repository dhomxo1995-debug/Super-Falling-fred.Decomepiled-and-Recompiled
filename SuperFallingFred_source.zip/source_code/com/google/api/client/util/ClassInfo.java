package com.google.api.client.util;
public final class ClassInfo {
    private static final java.util.Map CACHE;
    private static final java.util.Map CACHE_IGNORE_CASE;
    private final Class clazz;
    private final boolean ignoreCase;
    private final java.util.IdentityHashMap nameToFieldInfoMap;
    final java.util.List names;

    static ClassInfo()
    {
        com.google.api.client.util.ClassInfo.CACHE = new java.util.WeakHashMap();
        com.google.api.client.util.ClassInfo.CACHE_IGNORE_CASE = new java.util.WeakHashMap();
        return;
    }

    private ClassInfo(Class p18, boolean p19)
    {
        java.util.IdentityHashMap v12_3;
        com.google.api.client.util.ClassInfo v17_1 = ;
v17_1.nameToFieldInfoMap = new java.util.IdentityHashMap();
        v17_1.clazz = p18;
        v17_1.ignoreCase = p19;
        if ((p19) && (p18.isEnum())) {
            v12_3 = 0;
        } else {
            v12_3 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v12_3, new StringBuilder().append("cannot ignore case on an enum: ").append(p18).toString());
        java.util.TreeSet v9_1 = new java.util.TreeSet(new com.google.api.client.util.ClassInfo$1(v17_1));
        Class v10 = p18.getSuperclass();
        if (v10 != null) {
            com.google.api.client.util.ClassInfo v11 = com.google.api.client.util.ClassInfo.of(v10, p19);
            v17_1.nameToFieldInfoMap.putAll(v11.nameToFieldInfoMap);
            v9_1.addAll(v11.names);
        }
        reflect.Field[] v2 = p18.getDeclaredFields();
        int v8 = v2.length;
        int v7 = 0;
        while (v7 < v8) {
            reflect.Field v4 = v2[v7];
            com.google.api.client.util.FieldInfo v5 = com.google.api.client.util.FieldInfo.of(v4);
            if (v5 != null) {
                String v6 = v5.getName();
                if (p19) {
                    v6 = v6.toLowerCase().intern();
                }
                java.util.IdentityHashMap v12_15;
                com.google.api.client.util.FieldInfo v3_1 = ((com.google.api.client.util.FieldInfo) v17_1.nameToFieldInfoMap.get(v6));
                if (v3_1 != null) {
                    v12_15 = 0;
                } else {
                    v12_15 = 1;
                }
                reflect.Field v13_7;
                Object[] v15 = new Object[4];
                if (!p19) {
                    v13_7 = "";
                } else {
                    v13_7 = "case-insensitive ";
                }
                reflect.Field v13_10;
                v15[0] = v13_7;
                v15[1] = v6;
                v15[2] = v4;
                if (v3_1 != null) {
                    v13_10 = v3_1.getField();
                } else {
                    v13_10 = 0;
                }
                v15[3] = v13_10;
                com.google.common.base.Preconditions.checkArgument(v12_15, "two fields have the same %sname <%s>: %s and %s", v15);
                v17_1.nameToFieldInfoMap.put(v6, v5);
                v9_1.add(v6);
            }
            v7++;
        }
        java.util.IdentityHashMap v12_12;
        if (!v9_1.isEmpty()) {
            v12_12 = java.util.Collections.unmodifiableList(new java.util.ArrayList(v9_1));
        } else {
            v12_12 = java.util.Collections.emptyList();
        }
        v17_1.names = v12_12;
        return;
    }

    public static com.google.api.client.util.ClassInfo of(Class p1)
    {
        return com.google.api.client.util.ClassInfo.of(p1, 0);
    }

    public static com.google.api.client.util.ClassInfo of(Class p3, boolean p4)
    {
        com.google.api.client.util.ClassInfo v1_0;
        if (p3 != null) {
            java.util.Map v0;
            if (!p4) {
                v0 = com.google.api.client.util.ClassInfo.CACHE;
            } else {
                v0 = com.google.api.client.util.ClassInfo.CACHE_IGNORE_CASE;
            }
            try {
                v1_0 = ((com.google.api.client.util.ClassInfo) v0.get(p3));
            } catch (Throwable v2) {
                throw v2;
            }
            if (v1_0 == null) {
                v1_0 = new com.google.api.client.util.ClassInfo(p3, p4);
                v0.put(p3, v1_0);
            }
        } else {
            v1_0 = 0;
        }
        return v1_0;
    }

    public reflect.Field getField(String p3)
    {
        reflect.Field v1;
        com.google.api.client.util.FieldInfo v0 = this.getFieldInfo(p3);
        if (v0 != null) {
            v1 = v0.getField();
        } else {
            v1 = 0;
        }
        return v1;
    }

    public com.google.api.client.util.FieldInfo getFieldInfo(String p2)
    {
        if (p2 != null) {
            if (this.ignoreCase) {
                p2 = p2.toLowerCase();
            }
            p2 = p2.intern();
        }
        return ((com.google.api.client.util.FieldInfo) this.nameToFieldInfoMap.get(p2));
    }

    public final boolean getIgnoreCase()
    {
        return this.ignoreCase;
    }

    public java.util.Collection getNames()
    {
        return this.names;
    }

    public Class getUnderlyingClass()
    {
        return this.clazz;
    }

    public boolean isEnum()
    {
        return this.clazz.isEnum();
    }
}
