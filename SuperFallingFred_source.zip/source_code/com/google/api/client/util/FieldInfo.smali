.class public Lcom/google/api/client/util/FieldInfo;
.super Ljava/lang/Object;

.field private static final CACHE:Ljava/util/Map;
.field private final field:Ljava/lang/reflect/Field;
.field private final isPrimitive:Z
.field private final name:Ljava/lang/String;

.method static constructor <clinit>()V
    .registers 1
    new-instance v0, Ljava/util/WeakHashMap;
    invoke-direct v0, Ljava/util/WeakHashMap;-><init>()V
    sput-object v0, Lcom/google/api/client/util/FieldInfo;->CACHE Ljava/util/Map;
    return-void
.end method

.method constructor <init>(Ljava/lang/reflect/Field; Ljava/lang/String;)V
    .registers 4
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    iput-object v2, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    if-nez v3, +010h
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/util/FieldInfo;->name Ljava/lang/String;
    invoke-virtual v1, Lcom/google/api/client/util/FieldInfo;->getType()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/util/Data;->isPrimitive(Ljava/lang/reflect/Type;)Z
    move-result v0
    iput-boolean v0, v1, Lcom/google/api/client/util/FieldInfo;->isPrimitive Z
    return-void
    invoke-virtual v3, Ljava/lang/String;->intern()Ljava/lang/String;
    move-result-object v0
    goto -11h
.end method

.method public static getFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    invoke-virtual v2, v3, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    return-object v1
    move-exception v0
    new-instance v1, Ljava/lang/IllegalArgumentException;
    invoke-direct v1, v0, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    throw v1
.end method

.method public static of(Ljava/lang/Enum;)Lcom/google/api/client/util/FieldInfo;
    .registers 7
    const/4 v2, 1
    const/4 v3, 0
    invoke-virtual v6, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v4
    invoke-virtual v6, Ljava/lang/Enum;->name()Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    move-result-object v4
    invoke-static v4, Lcom/google/api/client/util/FieldInfo;->of(Ljava/lang/reflect/Field;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v1
    if-eqz v1, +00eh
    const-string v3, "enum constant missing @Value or @NullValue annotation: %s"
    const/4 v4, 1
    new-array v4, v4, [Ljava/lang/Object;
    const/4 v5, 0
    aput-object v6, v4, v5
    invoke-static v2, v3, v4, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    return-object v1
    move v2, v3
    goto -dh
    move-exception v0
    new-instance v2, Ljava/lang/RuntimeException;
    invoke-direct v2, v0, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    throw v2
.end method

.method public static of(Ljava/lang/reflect/Field;)Lcom/google/api/client/util/FieldInfo;
    .registers 10
    const/4 v6, 0
    if-nez v9, +004h
    move-object v0, v6
    return-object v0
    sget-object v7, Lcom/google/api/client/util/FieldInfo;->CACHE Ljava/util/Map;
    monitor-enter v7
    sget-object v8, Lcom/google/api/client/util/FieldInfo;->CACHE Ljava/util/Map;
    invoke-interface v8, v9, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/FieldInfo;
    invoke-virtual v9, Ljava/lang/reflect/Field;->isEnumConstant()Z
    move-result v2
    if-nez v0, +034h
    if-nez v2, +00ch
    invoke-virtual v9, Ljava/lang/reflect/Field;->getModifiers()I
    move-result v8
    invoke-static v8, Ljava/lang/reflect/Modifier;->isStatic(I)Z
    move-result v8
    if-nez v8, +028h
    if-eqz v2, +03ah
    const-class v8, Lcom/google/api/client/util/Value;
    invoke-virtual v9, v8, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v5
    check-cast v5, Lcom/google/api/client/util/Value;
    if-eqz v5, +021h
    invoke-interface v5, Lcom/google/api/client/util/Value;->value()Ljava/lang/String;
    move-result-object v1
    const-string v6, "##default"
    invoke-virtual v6, v1, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v6
    if-eqz v6, +006h
    invoke-virtual v9, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;
    move-result-object v1
    new-instance v0, Lcom/google/api/client/util/FieldInfo;
    invoke-direct v0, v9, v1, Lcom/google/api/client/util/FieldInfo;-><init>(Ljava/lang/reflect/Field; Ljava/lang/String;)V
    sget-object v6, Lcom/google/api/client/util/FieldInfo;->CACHE Ljava/util/Map;
    invoke-interface v6, v9, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    monitor-exit v7
    goto -45h
    move-exception v6
    monitor-exit v7
    throw v6
    const-class v8, Lcom/google/api/client/util/NullValue;
    invoke-virtual v9, v8, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v4
    check-cast v4, Lcom/google/api/client/util/NullValue;
    if-eqz v4, +004h
    const/4 v1, 0
    goto -26h
    monitor-exit v7
    move-object v0, v6
    goto -57h
    const-class v8, Lcom/google/api/client/util/Key;
    invoke-virtual v9, v8, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    move-result-object v3
    check-cast v3, Lcom/google/api/client/util/Key;
    if-nez v3, +005h
    monitor-exit v7
    move-object v0, v6
    goto -64h
    invoke-interface v3, Lcom/google/api/client/util/Key;->value()Ljava/lang/String;
    move-result-object v1
    const/4 v6, 1
    invoke-virtual v9, v6, Ljava/lang/reflect/Field;->setAccessible(Z)V
    goto -3fh
.end method

.method public static setFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 8
    invoke-virtual v5, Ljava/lang/reflect/Field;->getModifiers()I
    move-result v2
    invoke-static v2, Ljava/lang/reflect/Modifier;->isFinal(I)Z
    move-result v2
    if-eqz v2, +054h
    invoke-static v5, v6, Lcom/google/api/client/util/FieldInfo;->getFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    if-nez v7, +047h
    if-eqz v1, +04bh
    new-instance v2, Ljava/lang/IllegalArgumentException;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "expected final value <"
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "> but was <"
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "> on "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v5, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, " field in "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v6, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/Class;->getName()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-direct v2, v3, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v2
    invoke-virtual v7, v1, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, -047h
    return-void
    invoke-virtual v5, v6, v7, Ljava/lang/reflect/Field;->set(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -4h
    move-exception v0
    new-instance v2, Ljava/lang/IllegalArgumentException;
    invoke-direct v2, v0, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    throw v2
    move-exception v0
    new-instance v2, Ljava/lang/IllegalArgumentException;
    invoke-direct v2, v0, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    throw v2
.end method

.method public enumValue()Ljava/lang/Enum;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v0, Ljava/lang/reflect/Field;->getDeclaringClass()Ljava/lang/Class;
    move-result-object v0
    iget-object v1, v2, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v1, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Ljava/lang/Enum;->valueOf(Ljava/lang/Class; Ljava/lang/String;)Ljava/lang/Enum;
    move-result-object v0
    return-object v0
.end method

.method public getClassInfo()Lcom/google/api/client/util/ClassInfo;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v0, Ljava/lang/reflect/Field;->getDeclaringClass()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v0
    return-object v0
.end method

.method public getField()Ljava/lang/reflect/Field;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    return-object v0
.end method

.method public getGenericType()Ljava/lang/reflect/Type;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v0, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;
    move-result-object v0
    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->name Ljava/lang/String;
    return-object v0
.end method

.method public getType()Ljava/lang/Class;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v0, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;
    move-result-object v0
    return-object v0
.end method

.method public getValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-static v0, v2, Lcom/google/api/client/util/FieldInfo;->getFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public isFinal()Z
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-virtual v0, Ljava/lang/reflect/Field;->getModifiers()I
    move-result v0
    invoke-static v0, Ljava/lang/reflect/Modifier;->isFinal(I)Z
    move-result v0
    return v0
.end method

.method public isPrimitive()Z
    .registers 2
    iget-boolean v0, v1, Lcom/google/api/client/util/FieldInfo;->isPrimitive Z
    return v0
.end method

.method public setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/util/FieldInfo;->field Ljava/lang/reflect/Field;
    invoke-static v0, v2, v3, Lcom/google/api/client/util/FieldInfo;->setFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object; Ljava/lang/Object;)V
    return-void
.end method
