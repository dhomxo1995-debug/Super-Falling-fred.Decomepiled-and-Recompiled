.class public interface abstract Lcom/google/api/client/util/ObjectParser;
.super Ljava/lang/Object;


.method public abstract parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/Class;)Ljava/lang/Object;
    # abstract or native method
.end method

.method public abstract parseAndClose(Ljava/io/InputStream; Ljava/nio/charset/Charset; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    # abstract or native method
.end method

.method public abstract parseAndClose(Ljava/io/Reader; Ljava/lang/Class;)Ljava/lang/Object;
    # abstract or native method
.end method

.method public abstract parseAndClose(Ljava/io/Reader; Ljava/lang/reflect/Type;)Ljava/lang/Object;
    # abstract or native method
.end method
