package com.google.api.client.util;
public class GenericData extends java.util.AbstractMap implements java.lang.Cloneable {
    final com.google.api.client.util.ClassInfo classInfo;
    java.util.Map unknownFields;

    public GenericData()
    {
        this(java.util.EnumSet.noneOf(com.google.api.client.util.GenericData$Flags));
        return;
    }

    public GenericData(java.util.EnumSet p3)
    {
        this.unknownFields = com.google.api.client.util.ArrayMap.create();
        this.classInfo = com.google.api.client.util.ClassInfo.of(this.getClass(), p3.contains(com.google.api.client.util.GenericData$Flags.IGNORE_CASE));
        return;
    }

    public com.google.api.client.util.GenericData clone()
    {
        try {
            com.google.api.client.util.GenericData v1_1 = ((com.google.api.client.util.GenericData) super.clone());
            com.google.api.client.util.Data.deepCopy(this, v1_1);
            v1_1.unknownFields = ((java.util.Map) com.google.api.client.util.Data.clone(this.unknownFields));
            return v1_1;
        } catch (CloneNotSupportedException v0) {
            throw new IllegalStateException(v0);
        }
    }

    public bridge synthetic Object clone()
    {
        return this.clone();
    }

    public java.util.Set entrySet()
    {
        return new com.google.api.client.util.GenericData$EntrySet(this);
    }

    public final Object get(Object p4)
    {
        Object v2_3;
        if ((p4 instanceof String)) {
            String v1_0 = ((String) p4);
            com.google.api.client.util.FieldInfo v0 = this.classInfo.getFieldInfo(((String) p4));
            if (v0 == null) {
                if (this.classInfo.getIgnoreCase()) {
                    v1_0 = ((String) p4).toLowerCase();
                }
                v2_3 = this.unknownFields.get(v1_0);
            } else {
                v2_3 = v0.getValue(this);
            }
        } else {
            v2_3 = 0;
        }
        return v2_3;
    }

    public final com.google.api.client.util.ClassInfo getClassInfo()
    {
        return this.classInfo;
    }

    public final java.util.Map getUnknownKeys()
    {
        return this.unknownFields;
    }

    public bridge synthetic Object put(Object p2, Object p3)
    {
        return this.put(((String) p2), p3);
    }

    public final Object put(String p4, Object p5)
    {
        Object v1;
        com.google.api.client.util.FieldInfo v0 = this.classInfo.getFieldInfo(p4);
        if (v0 == null) {
            if (this.classInfo.getIgnoreCase()) {
                p4 = p4.toLowerCase();
            }
            v1 = this.unknownFields.put(p4, p5);
        } else {
            v1 = v0.getValue(this);
            v0.setValue(this, p5);
        }
        return v1;
    }

    public final void putAll(java.util.Map p5)
    {
        java.util.Iterator v1 = p5.entrySet().iterator();
        while (v1.hasNext()) {
            java.util.Map$Entry v0_0 = ((java.util.Map$Entry) v1.next());
            this.set(((String) v0_0.getKey()), v0_0.getValue());
        }
        return;
    }

    public final Object remove(Object p4)
    {
        Object v2_3;
        if ((p4 instanceof String)) {
            String v1_0 = ((String) p4);
            if (this.classInfo.getFieldInfo(((String) p4)) == null) {
                if (this.classInfo.getIgnoreCase()) {
                    v1_0 = ((String) p4).toLowerCase();
                }
                v2_3 = this.unknownFields.remove(v1_0);
            } else {
                throw new UnsupportedOperationException();
            }
        } else {
            v2_3 = 0;
        }
        return v2_3;
    }

    public final void set(String p3, Object p4)
    {
        com.google.api.client.util.FieldInfo v0 = this.classInfo.getFieldInfo(p3);
        if (v0 == null) {
            if (this.classInfo.getIgnoreCase()) {
                p3 = p3.toLowerCase();
            }
            this.unknownFields.put(p3, p4);
        } else {
            v0.setValue(this, p4);
        }
        return;
    }

    public final void setUnknownKeys(java.util.Map p1)
    {
        this.unknownFields = p1;
        return;
    }
}
