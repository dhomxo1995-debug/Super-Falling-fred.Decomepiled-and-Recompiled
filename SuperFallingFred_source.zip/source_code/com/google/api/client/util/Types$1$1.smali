.class 0x0 Lcom/google/api/client/util/Types$1$1;
.super Ljava/lang/Object;
.implements Ljava/util/Iterator;

.field  index:I
.field final length:I
.field final synthetic this$0:Lcom/google/api/client/util/Types$1;

.method constructor <init>(Lcom/google/api/client/util/Types$1;)V
    .registers 3
    iput-object v2, v1, Lcom/google/api/client/util/Types$1$1;->this$0 Lcom/google/api/client/util/Types$1;
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    iget-object v0, v1, Lcom/google/api/client/util/Types$1$1;->this$0 Lcom/google/api/client/util/Types$1;
    iget-object v0, v0, Lcom/google/api/client/util/Types$1;->val$value Ljava/lang/Object;
    invoke-static v0, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    move-result v0
    iput v0, v1, Lcom/google/api/client/util/Types$1$1;->length I
    const/4 v0, 0
    iput v0, v1, Lcom/google/api/client/util/Types$1$1;->index I
    return-void
.end method

.method public hasNext()Z
    .registers 3
    iget v0, v2, Lcom/google/api/client/util/Types$1$1;->index I
    iget v1, v2, Lcom/google/api/client/util/Types$1$1;->length I
    if-ge v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public next()Ljava/lang/Object;
    .registers 4
    invoke-virtual v3, Lcom/google/api/client/util/Types$1$1;->hasNext()Z
    move-result v0
    if-nez v0, +008h
    new-instance v0, Ljava/util/NoSuchElementException;
    invoke-direct v0, Ljava/util/NoSuchElementException;-><init>()V
    throw v0
    iget-object v0, v3, Lcom/google/api/client/util/Types$1$1;->this$0 Lcom/google/api/client/util/Types$1;
    iget-object v0, v0, Lcom/google/api/client/util/Types$1;->val$value Ljava/lang/Object;
    iget v1, v3, Lcom/google/api/client/util/Types$1$1;->index I
    add-int/lit8 v2, v1, 1
    iput v2, v3, Lcom/google/api/client/util/Types$1$1;->index I
    invoke-static v0, v1, Ljava/lang/reflect/Array;->get(Ljava/lang/Object; I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public remove()V
    .registers 2
    new-instance v0, Ljava/lang/UnsupportedOperationException;
    invoke-direct v0, Ljava/lang/UnsupportedOperationException;-><init>()V
    throw v0
.end method
