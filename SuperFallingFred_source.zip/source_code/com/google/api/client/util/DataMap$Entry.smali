.class final Lcom/google/api/client/util/DataMap$Entry;
.super Ljava/lang/Object;
.implements Ljava/util/Map$Entry;

.field private final fieldInfo:Lcom/google/api/client/util/FieldInfo;
.field private fieldValue:Ljava/lang/Object;
.field final synthetic this$0:Lcom/google/api/client/util/DataMap;

.method constructor <init>(Lcom/google/api/client/util/DataMap; Lcom/google/api/client/util/FieldInfo; Ljava/lang/Object;)V
    .registers 5
    iput-object v2, v1, Lcom/google/api/client/util/DataMap$Entry;->this$0 Lcom/google/api/client/util/DataMap;
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    iput-object v3, v1, Lcom/google/api/client/util/DataMap$Entry;->fieldInfo Lcom/google/api/client/util/FieldInfo;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/DataMap$Entry;->fieldValue Ljava/lang/Object;
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7
    const/4 v1, 1
    const/4 v2, 0
    if-ne v5, v6, +003h
    return v1
    instance-of v3, v6, Ljava/util/Map$Entry;
    if-nez v3, +004h
    move v1, v2
    goto -6h
    move-object v0, v6
    check-cast v0, Ljava/util/Map$Entry;
    invoke-virtual v5, Lcom/google/api/client/util/DataMap$Entry;->getKey()Ljava/lang/String;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v3
    if-eqz v3, +010h
    invoke-virtual v5, Lcom/google/api/client/util/DataMap$Entry;->getValue()Ljava/lang/Object;
    move-result-object v3
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v3
    if-nez v3, -024h
    move v1, v2
    goto -27h
.end method

.method public bridge synthetic getKey()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/DataMap$Entry;->getKey()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public getKey()Ljava/lang/String;
    .registers 3
    iget-object v1, v2, Lcom/google/api/client/util/DataMap$Entry;->fieldInfo Lcom/google/api/client/util/FieldInfo;
    invoke-virtual v1, Lcom/google/api/client/util/FieldInfo;->getName()Ljava/lang/String;
    move-result-object v0
    iget-object v1, v2, Lcom/google/api/client/util/DataMap$Entry;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v1, v1, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v1, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v1
    if-eqz v1, +006h
    invoke-virtual v0, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public getValue()Ljava/lang/Object;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/DataMap$Entry;->fieldValue Ljava/lang/Object;
    return-object v0
.end method

.method public hashCode()I
    .registers 3
    invoke-virtual v2, Lcom/google/api/client/util/DataMap$Entry;->getKey()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/String;->hashCode()I
    move-result v0
    invoke-virtual v2, Lcom/google/api/client/util/DataMap$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Object;->hashCode()I
    move-result v1
    xor-int/2addr v0, v1
    return v0
.end method

.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    iget-object v0, v3, Lcom/google/api/client/util/DataMap$Entry;->fieldValue Ljava/lang/Object;
    invoke-static v4, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    iput-object v1, v3, Lcom/google/api/client/util/DataMap$Entry;->fieldValue Ljava/lang/Object;
    iget-object v1, v3, Lcom/google/api/client/util/DataMap$Entry;->fieldInfo Lcom/google/api/client/util/FieldInfo;
    iget-object v2, v3, Lcom/google/api/client/util/DataMap$Entry;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v1, v2, v4, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    return-object v0
.end method
