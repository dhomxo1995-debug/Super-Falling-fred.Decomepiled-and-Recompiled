.class public Lcom/google/api/client/util/StringUtils;
.super Ljava/lang/Object;

.field public static final LINE_SEPARATOR:Ljava/lang/String;

.method static constructor <clinit>()V
    .registers 1
    const-string v0, "line.separator"
    invoke-static v0, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/util/StringUtils;->LINE_SEPARATOR Ljava/lang/String;
    return-void
.end method

.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static getBytesUtf8(Ljava/lang/String;)[B
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/StringUtils;->getBytesUtf8(Ljava/lang/String;)[B
    move-result-object v0
    return-object v0
.end method

.method public static newStringUtf8([B)Ljava/lang/String;
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/StringUtils;->newStringUtf8([B)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
