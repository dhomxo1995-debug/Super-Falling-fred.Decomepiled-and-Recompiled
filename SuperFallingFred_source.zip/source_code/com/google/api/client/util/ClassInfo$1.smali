.class 0x0 Lcom/google/api/client/util/ClassInfo$1;
.super Ljava/lang/Object;
.implements Ljava/util/Comparator;

.field final synthetic this$0:Lcom/google/api/client/util/ClassInfo;

.method constructor <init>(Lcom/google/api/client/util/ClassInfo;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/ClassInfo$1;->this$0 Lcom/google/api/client/util/ClassInfo;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public bridge synthetic compare(Ljava/lang/Object; Ljava/lang/Object;)I
    .registers 4
    check-cast v2, Ljava/lang/String;
    check-cast v3, Ljava/lang/String;
    invoke-virtual v1, v2, v3, Lcom/google/api/client/util/ClassInfo$1;->compare(Ljava/lang/String; Ljava/lang/String;)I
    move-result v0
    return v0
.end method

.method public compare(Ljava/lang/String; Ljava/lang/String;)I
    .registers 4
    if-ne v2, v3, +004h
    const/4 v0, 0
    return v0
    if-nez v2, +004h
    const/4 v0, -1
    goto -4h
    if-nez v3, +004h
    const/4 v0, 1
    goto -8h
    invoke-virtual v2, v3, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    move-result v0
    goto -dh
.end method
