.class public interface abstract Lcom/google/api/client/util/Clock;
.super Ljava/lang/Object;

.field public static final SYSTEM:Lcom/google/api/client/util/Clock;

.method static constructor <clinit>()V
    .registers 1
    new-instance v0, Lcom/google/api/client/util/Clock$1;
    invoke-direct v0, Lcom/google/api/client/util/Clock$1;-><init>()V
    sput-object v0, Lcom/google/api/client/util/Clock;->SYSTEM Lcom/google/api/client/util/Clock;
    return-void
.end method

.method public abstract currentTimeMillis()J
    # abstract or native method
.end method
