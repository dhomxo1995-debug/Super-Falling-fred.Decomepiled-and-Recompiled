.class public Lcom/google/api/client/util/Types;
.super Ljava/lang/Object;


.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private static getActualParameterAtPosition(Ljava/lang/reflect/Type; Ljava/lang/Class; I)Ljava/lang/reflect/Type;
    .registers 8
    invoke-static v5, v6, Lcom/google/api/client/util/Types;->getSuperParameterizedType(Ljava/lang/reflect/Type; Ljava/lang/Class;)Ljava/lang/reflect/ParameterizedType;
    move-result-object v0
    invoke-interface v0, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;
    move-result-object v3
    aget-object v2, v3, v7
    instance-of v3, v2, Ljava/lang/reflect/TypeVariable;
    if-eqz v3, +016h
    const/4 v3, 1
    new-array v3, v3, [Ljava/lang/reflect/Type;
    const/4 v4, 0
    aput-object v5, v3, v4
    invoke-static v3, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v4
    move-object v3, v2
    check-cast v3, Ljava/lang/reflect/TypeVariable;
    invoke-static v4, v3, Lcom/google/api/client/util/Types;->resolveTypeVariable(Ljava/util/List; Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type;
    move-result-object v1
    if-eqz v1, +003h
    return-object v1
    move-object v1, v2
    goto -2h
.end method

.method public static getArrayComponentType(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .registers 2
    instance-of v0, v1, Ljava/lang/reflect/GenericArrayType;
    if-eqz v0, +009h
    check-cast v1, Ljava/lang/reflect/GenericArrayType;
    invoke-interface v1, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;
    move-result-object v0
    return-object v0
    check-cast v1, Ljava/lang/Class;
    invoke-virtual v1, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v0
    goto -7h
.end method

.method public static getBound(Ljava/lang/reflect/WildcardType;)Ljava/lang/reflect/Type;
    .registers 4
    const/4 v2, 0
    invoke-interface v3, Ljava/lang/reflect/WildcardType;->getLowerBounds()[Ljava/lang/reflect/Type;
    move-result-object v0
    array-length v1, v0
    if-eqz v1, +005h
    aget-object v1, v0, v2
    return-object v1
    invoke-interface v3, Ljava/lang/reflect/WildcardType;->getUpperBounds()[Ljava/lang/reflect/Type;
    move-result-object v1
    aget-object v1, v1, v2
    goto -7h
.end method

.method public static getIterableParameter(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .registers 3
    const-class v0, Ljava/lang/Iterable;
    const/4 v1, 0
    invoke-static v2, v0, v1, Lcom/google/api/client/util/Types;->getActualParameterAtPosition(Ljava/lang/reflect/Type; Ljava/lang/Class; I)Ljava/lang/reflect/Type;
    move-result-object v0
    return-object v0
.end method

.method public static getMapValueParameter(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .registers 3
    const-class v0, Ljava/util/Map;
    const/4 v1, 1
    invoke-static v2, v0, v1, Lcom/google/api/client/util/Types;->getActualParameterAtPosition(Ljava/lang/reflect/Type; Ljava/lang/Class; I)Ljava/lang/reflect/Type;
    move-result-object v0
    return-object v0
.end method

.method public static getRawArrayComponentType(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/Class;
    .registers 7
    const/4 v2, 1
    const/4 v3, 0
    instance-of v1, v6, Ljava/lang/reflect/TypeVariable;
    if-eqz v1, +008h
    check-cast v6, Ljava/lang/reflect/TypeVariable;
    invoke-static v5, v6, Lcom/google/api/client/util/Types;->resolveTypeVariable(Ljava/util/List; Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type;
    move-result-object v6
    instance-of v1, v6, Ljava/lang/reflect/GenericArrayType;
    if-eqz v1, +013h
    invoke-static v6, Lcom/google/api/client/util/Types;->getArrayComponentType(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    move-result-object v1
    invoke-static v5, v1, Lcom/google/api/client/util/Types;->getRawArrayComponentType(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, v3, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v6
    return-object v6
    instance-of v1, v6, Ljava/lang/Class;
    if-eqz v1, +005h
    check-cast v6, Ljava/lang/Class;
    goto -7h
    instance-of v1, v6, Ljava/lang/reflect/ParameterizedType;
    if-eqz v1, +009h
    check-cast v6, Ljava/lang/reflect/ParameterizedType;
    invoke-static v6, Lcom/google/api/client/util/Types;->getRawClass(Ljava/lang/reflect/ParameterizedType;)Ljava/lang/Class;
    move-result-object v6
    goto -12h
    if-nez v6, +00fh
    move v1, v2
    const-string v4, "wildcard type is not supported: %s"
    new-array v2, v2, [Ljava/lang/Object;
    aput-object v6, v2, v3
    invoke-static v1, v4, v2, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    const-class v6, Ljava/lang/Object;
    goto -21h
    move v1, v3
    goto -dh
.end method

.method public static getRawClass(Ljava/lang/reflect/ParameterizedType;)Ljava/lang/Class;
    .registers 2
    invoke-interface v1, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;
    move-result-object v0
    check-cast v0, Ljava/lang/Class;
    return-object v0
.end method

.method public static getSuperParameterizedType(Ljava/lang/reflect/Type; Ljava/lang/Class;)Ljava/lang/reflect/ParameterizedType;
    .registers 10
    instance-of v7, v8, Ljava/lang/Class;
    if-nez v7, +006h
    instance-of v7, v8, Ljava/lang/reflect/ParameterizedType;
    if-eqz v7, +049h
    if-eqz v8, +047h
    const-class v7, Ljava/lang/Object;
    if-eq v8, v7, +043h
    instance-of v7, v8, Ljava/lang/Class;
    if-eqz v7, +00ah
    move-object v6, v8
    check-cast v6, Ljava/lang/Class;
    invoke-virtual v6, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;
    move-result-object v8
    goto -11h
    move-object v5, v8
    check-cast v5, Ljava/lang/reflect/ParameterizedType;
    invoke-static v5, Lcom/google/api/client/util/Types;->getRawClass(Ljava/lang/reflect/ParameterizedType;)Ljava/lang/Class;
    move-result-object v6
    if-ne v6, v9, +003h
    return-object v5
    invoke-virtual v9, Ljava/lang/Class;->isInterface()Z
    move-result v7
    if-eqz v7, -013h
    invoke-virtual v6, Ljava/lang/Class;->getGenericInterfaces()[Ljava/lang/reflect/Type;
    move-result-object v0
    array-length v4, v0
    const/4 v1, 0
    if-ge v1, v4, -01bh
    aget-object v3, v0, v1
    instance-of v7, v3, Ljava/lang/Class;
    if-eqz v7, +00eh
    move-object v7, v3
    check-cast v7, Ljava/lang/Class;
    move-object v2, v7
    invoke-virtual v9, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v7
    if-eqz v7, +00ch
    move-object v8, v3
    goto -3bh
    move-object v7, v3
    check-cast v7, Ljava/lang/reflect/ParameterizedType;
    invoke-static v7, Lcom/google/api/client/util/Types;->getRawClass(Ljava/lang/reflect/ParameterizedType;)Ljava/lang/Class;
    move-result-object v2
    goto -fh
    add-int/lit8 v1, v1, 1
    goto -1eh
    const/4 v5, 0
    goto -2dh
.end method

.method private static handleExceptionForNewInstance(Ljava/lang/Exception; Ljava/lang/Class;)Ljava/lang/IllegalArgumentException;
    .registers 10
    new-instance v6, Ljava/lang/StringBuilder;
    const-string v7, "unable to create new instance of class "
    invoke-direct v6, v7, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v9, Ljava/lang/Class;->getName()Ljava/lang/String;
    move-result-object v7
    invoke-virtual v6, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    new-instance v5, Ljava/util/ArrayList;
    invoke-direct v5, Ljava/util/ArrayList;-><init>()V
    invoke-virtual v9, Ljava/lang/Class;->isArray()Z
    move-result v6
    if-eqz v6, +029h
    const-string v6, "because it is an array"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    const/4 v0, 0
    invoke-virtual v5, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v6
    if-eqz v6, +085h
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Ljava/lang/String;
    if-eqz v0, +07bh
    const-string v6, " and"
    invoke-virtual v1, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6, " "
    invoke-virtual v1, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v6
    invoke-virtual v6, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -1ch
    invoke-virtual v9, Ljava/lang/Class;->isPrimitive()Z
    move-result v6
    if-eqz v6, +008h
    const-string v6, "because it is primitive"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto -2dh
    const-class v6, Ljava/lang/Void;
    if-ne v9, v6, +008h
    const-string v6, "because it is void"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto -37h
    invoke-virtual v9, Ljava/lang/Class;->getModifiers()I
    move-result v6
    invoke-static v6, Ljava/lang/reflect/Modifier;->isInterface(I)Z
    move-result v6
    if-eqz v6, +02ch
    const-string v6, "because it is an interface"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    invoke-virtual v9, Ljava/lang/Class;->getEnclosingClass()Ljava/lang/Class;
    move-result-object v6
    if-eqz v6, +011h
    invoke-virtual v9, Ljava/lang/Class;->getModifiers()I
    move-result v6
    invoke-static v6, Ljava/lang/reflect/Modifier;->isStatic(I)Z
    move-result v6
    if-nez v6, +007h
    const-string v6, "because it is not static"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    invoke-virtual v9, Ljava/lang/Class;->getModifiers()I
    move-result v6
    invoke-static v6, Ljava/lang/reflect/Modifier;->isPublic(I)Z
    move-result v6
    if-nez v6, +018h
    const-string v6, "possibly because it is not public"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto -6bh
    invoke-virtual v9, Ljava/lang/Class;->getModifiers()I
    move-result v6
    invoke-static v6, Ljava/lang/reflect/Modifier;->isAbstract(I)Z
    move-result v6
    if-eqz v6, -02dh
    const-string v6, "because it is abstract"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto -34h
    const/4 v6, 0
    new-array v6, v6, [Ljava/lang/Class;
    invoke-virtual v9, v6, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    goto/16 -082h
    move-exception v2
    const-string v6, "because it has no accessible default constructor"
    invoke-virtual v5, v6, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto/16 -08ah
    const/4 v0, 1
    goto -75h
    new-instance v6, Ljava/lang/IllegalArgumentException;
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v7
    invoke-direct v6, v7, v8, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String; Ljava/lang/Throwable;)V
    return-object v6
.end method

.method public static isArray(Ljava/lang/reflect/Type;)Z
    .registers 2
    instance-of v0, v1, Ljava/lang/reflect/GenericArrayType;
    if-nez v0, +00eh
    instance-of v0, v1, Ljava/lang/Class;
    if-eqz v0, +00ch
    check-cast v1, Ljava/lang/Class;
    invoke-virtual v1, Ljava/lang/Class;->isArray()Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static isAssignableToOrFrom(Ljava/lang/Class; Ljava/lang/Class;)Z
    .registers 3
    invoke-virtual v1, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v0
    if-nez v0, +008h
    invoke-virtual v2, v1, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static iterableOf(Ljava/lang/Object;)Ljava/lang/Iterable;
    .registers 7
    instance-of v2, v6, Ljava/lang/Iterable;
    if-eqz v2, +005h
    check-cast v6, Ljava/lang/Iterable;
    return-object v6
    invoke-virtual v6, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Class;->isArray()Z
    move-result v2
    const-string v3, "not an array or Iterable: %s"
    const/4 v4, 1
    new-array v4, v4, [Ljava/lang/Object;
    const/4 v5, 0
    aput-object v1, v4, v5
    invoke-static v2, v3, v4, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    invoke-virtual v1, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Class;->isPrimitive()Z
    move-result v2
    if-nez v2, +00bh
    check-cast v6, [Ljava/lang/Object;
    check-cast v6, [Ljava/lang/Object;
    invoke-static v6, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;
    move-result-object v6
    goto -26h
    new-instance v2, Lcom/google/api/client/util/Types$1;
    invoke-direct v2, v6, Lcom/google/api/client/util/Types$1;-><init>(Ljava/lang/Object;)V
    move-object v6, v2
    goto -2dh
.end method

.method public static newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    .registers 3
    invoke-virtual v2, Ljava/lang/Class;->newInstance()Ljava/lang/Object;
    move-result-object v1
    return-object v1
    move-exception v0
    invoke-static v0, v2, Lcom/google/api/client/util/Types;->handleExceptionForNewInstance(Ljava/lang/Exception; Ljava/lang/Class;)Ljava/lang/IllegalArgumentException;
    move-result-object v1
    throw v1
    move-exception v0
    invoke-static v0, v2, Lcom/google/api/client/util/Types;->handleExceptionForNewInstance(Ljava/lang/Exception; Ljava/lang/Class;)Ljava/lang/IllegalArgumentException;
    move-result-object v1
    throw v1
.end method

.method public static resolveTypeVariable(Ljava/util/List; Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type;
    .registers 12
    invoke-interface v11, Ljava/lang/reflect/TypeVariable;->getGenericDeclaration()Ljava/lang/reflect/GenericDeclaration;
    move-result-object v1
    instance-of v9, v1, Ljava/lang/Class;
    if-eqz v9, +046h
    move-object v4, v1
    check-cast v4, Ljava/lang/Class;
    invoke-interface v10, Ljava/util/List;->size()I
    move-result v0
    const/4 v3, 0
    if-nez v3, +011h
    add-int/lit8 v0, v0, -1
    if-ltz v0, +00dh
    invoke-interface v10, v0, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v9
    check-cast v9, Ljava/lang/reflect/Type;
    invoke-static v9, v4, Lcom/google/api/client/util/Types;->getSuperParameterizedType(Ljava/lang/reflect/Type; Ljava/lang/Class;)Ljava/lang/reflect/ParameterizedType;
    move-result-object v3
    goto -10h
    if-eqz v3, +02bh
    invoke-interface v1, Ljava/lang/reflect/GenericDeclaration;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;
    move-result-object v8
    const/4 v2, 0
    array-length v9, v8
    if-ge v2, v9, +00ah
    aget-object v7, v8, v2
    invoke-virtual v7, v11, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v9
    if-eqz v9, +016h
    invoke-interface v3, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;
    move-result-object v9
    aget-object v6, v9, v2
    instance-of v9, v6, Ljava/lang/reflect/TypeVariable;
    if-eqz v9, +00fh
    move-object v9, v6
    check-cast v9, Ljava/lang/reflect/TypeVariable;
    invoke-static v10, v9, Lcom/google/api/client/util/Types;->resolveTypeVariable(Ljava/util/List; Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type;
    move-result-object v5
    if-eqz v5, +006h
    return-object v5
    add-int/lit8 v2, v2, 1
    goto -21h
    move-object v5, v6
    goto -5h
    const/4 v5, 0
    goto -7h
.end method

.method public static toArray(Ljava/util/Collection; Ljava/lang/Class;)Ljava/lang/Object;
    .registers 8
    invoke-virtual v7, Ljava/lang/Class;->isPrimitive()Z
    move-result v5
    if-eqz v5, +020h
    invoke-interface v6, Ljava/util/Collection;->size()I
    move-result v5
    invoke-static v7, v5, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v0
    const/4 v2, 0
    invoke-interface v6, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v5
    if-eqz v5, +01dh
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v4
    add-int/lit8 v3, v2, 1
    invoke-static v0, v2, v4, Ljava/lang/reflect/Array;->set(Ljava/lang/Object; I Ljava/lang/Object;)V
    move v2, v3
    goto -10h
    invoke-interface v6, Ljava/util/Collection;->size()I
    move-result v5
    invoke-static v7, v5, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v5
    check-cast v5, [Ljava/lang/Object;
    check-cast v5, [Ljava/lang/Object;
    invoke-interface v6, v5, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
