package com.google.api.client.util;
 class ArrayValueMap$ArrayValue {
    final Class componentType;
    final java.util.ArrayList values;

    ArrayValueMap$ArrayValue(Class p2)
    {
        this.values = new java.util.ArrayList();
        this.componentType = p2;
        return;
    }

    void addValue(Class p2, Object p3)
    {
        java.util.ArrayList v0_1;
        if (p2 != this.componentType) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v0_1);
        this.values.add(p3);
        return;
    }

    Object toArray()
    {
        return com.google.api.client.util.Types.toArray(this.values, this.componentType);
    }
}
