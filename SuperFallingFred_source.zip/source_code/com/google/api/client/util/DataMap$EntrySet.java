package com.google.api.client.util;
final class DataMap$EntrySet extends java.util.AbstractSet {
    final synthetic com.google.api.client.util.DataMap this$0;

    DataMap$EntrySet(com.google.api.client.util.DataMap p1)
    {
        this.this$0 = p1;
        return;
    }

    public void clear()
    {
        java.util.Iterator v0 = this.this$0.classInfo.names.iterator();
        while (v0.hasNext()) {
            this.this$0.classInfo.getFieldInfo(((String) v0.next())).setValue(this.this$0.object, 0);
        }
        return;
    }

    public boolean isEmpty()
    {
        java.util.Iterator v0 = this.this$0.classInfo.names.iterator();
        while (v0.hasNext()) {
            if (this.this$0.classInfo.getFieldInfo(((String) v0.next())).getValue(this.this$0.object) != null) {
                int v2_7 = 0;
            }
            return v2_7;
        }
        v2_7 = 1;
        return v2_7;
    }

    public com.google.api.client.util.DataMap$EntryIterator iterator()
    {
        return new com.google.api.client.util.DataMap$EntryIterator(this.this$0);
    }

    public bridge synthetic java.util.Iterator iterator()
    {
        return this.iterator();
    }

    public int size()
    {
        int v2 = 0;
        java.util.Iterator v0 = this.this$0.classInfo.names.iterator();
        while (v0.hasNext()) {
            if (this.this$0.classInfo.getFieldInfo(((String) v0.next())).getValue(this.this$0.object) != null) {
                v2++;
            }
        }
        return v2;
    }
}
