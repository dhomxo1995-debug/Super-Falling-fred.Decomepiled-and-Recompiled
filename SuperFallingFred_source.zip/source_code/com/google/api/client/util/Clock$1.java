package com.google.api.client.util;
final class Clock$1 implements com.google.api.client.util.Clock {

    Clock$1()
    {
        return;
    }

    public long currentTimeMillis()
    {
        return System.currentTimeMillis();
    }
}
