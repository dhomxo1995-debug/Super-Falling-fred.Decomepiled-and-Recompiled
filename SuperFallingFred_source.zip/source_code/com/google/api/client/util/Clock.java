package com.google.api.client.util;
public interface Clock {
    public static final com.google.api.client.util.Clock SYSTEM;

    static Clock()
    {
        com.google.api.client.util.Clock.SYSTEM = new com.google.api.client.util.Clock$1();
        return;
    }

    public abstract long currentTimeMillis();
}
