package com.google.api.client.util;
final class GenericData$EntryIterator implements java.util.Iterator {
    private final java.util.Iterator fieldIterator;
    private boolean startedUnknown;
    final synthetic com.google.api.client.util.GenericData this$0;
    private final java.util.Iterator unknownIterator;

    GenericData$EntryIterator(com.google.api.client.util.GenericData p2, com.google.api.client.util.DataMap$EntrySet p3)
    {
        this.this$0 = p2;
        this.fieldIterator = p3.iterator();
        this.unknownIterator = p2.unknownFields.entrySet().iterator();
        return;
    }

    public boolean hasNext()
    {
        if ((!this.fieldIterator.hasNext()) && (!this.unknownIterator.hasNext())) {
            int v0_4 = 0;
        } else {
            v0_4 = 1;
        }
        return v0_4;
    }

    public bridge synthetic Object next()
    {
        return this.next();
    }

    public java.util.Map$Entry next()
    {
        int v0_2;
        if (this.startedUnknown) {
            v0_2 = ((java.util.Map$Entry) this.unknownIterator.next());
        } else {
            if (!this.fieldIterator.hasNext()) {
                this.startedUnknown = 1;
            } else {
                v0_2 = ((java.util.Map$Entry) this.fieldIterator.next());
            }
        }
        return v0_2;
    }

    public void remove()
    {
        if (this.startedUnknown) {
            this.unknownIterator.remove();
        }
        this.fieldIterator.remove();
        return;
    }
}
