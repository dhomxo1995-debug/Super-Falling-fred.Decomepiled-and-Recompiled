package com.google.api.client.util;
 class ClassInfo$1 implements java.util.Comparator {
    final synthetic com.google.api.client.util.ClassInfo this$0;

    ClassInfo$1(com.google.api.client.util.ClassInfo p1)
    {
        this.this$0 = p1;
        return;
    }

    public bridge synthetic int compare(Object p2, Object p3)
    {
        return this.compare(((String) p2), ((String) p3));
    }

    public int compare(String p2, String p3)
    {
        int v0;
        if (p2 != p3) {
            if (p2 != null) {
                if (p3 != null) {
                    v0 = p2.compareTo(p3);
                } else {
                    v0 = 1;
                }
            } else {
                v0 = -1;
            }
        } else {
            v0 = 0;
        }
        return v0;
    }
}
