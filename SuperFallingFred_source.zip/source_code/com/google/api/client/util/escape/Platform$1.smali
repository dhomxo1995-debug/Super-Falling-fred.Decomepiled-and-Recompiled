.class final Lcom/google/api/client/util/escape/Platform$1;
.super Ljava/lang/ThreadLocal;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/ThreadLocal;-><init>()V
    return-void
.end method

.method protected bridge synthetic initialValue()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/escape/Platform$1;->initialValue()[C
    move-result-object v0
    return-object v0
.end method

.method protected initialValue()[C
    .registers 2
    const/16 v0, 1024
    new-array v0, v0, [C
    return-object v0
.end method
