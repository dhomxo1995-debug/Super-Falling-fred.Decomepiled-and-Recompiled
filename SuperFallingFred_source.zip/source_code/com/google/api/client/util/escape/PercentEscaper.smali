.class public Lcom/google/api/client/util/escape/PercentEscaper;
.super Lcom/google/api/client/util/escape/UnicodeEscaper;

.field public static final SAFECHARS_URLENCODER:Ljava/lang/String;
.field public static final SAFEPATHCHARS_URLENCODER:Ljava/lang/String;
.field public static final SAFEQUERYSTRINGCHARS_URLENCODER:Ljava/lang/String;
.field private static final UPPER_HEX_DIGITS:[C
.field private static final URI_ESCAPED_SPACE:[C
.field private final plusForSpace:Z
.field private final safeOctets:[Z

.method static constructor <clinit>()V
    .registers 3
    const/4 v0, 1
    new-array v0, v0, [C
    const/4 v1, 0
    const/16 v2, 43
    aput-char v2, v0, v1
    sput-object v0, Lcom/google/api/client/util/escape/PercentEscaper;->URI_ESCAPED_SPACE [C
    const-string v0, "0123456789ABCDEF"
    invoke-virtual v0, Ljava/lang/String;->toCharArray()[C
    move-result-object v0
    sput-object v0, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    return-void
.end method

.method public constructor <init>(Ljava/lang/String; Z)V
    .registers 5
    invoke-direct v2, Lcom/google/api/client/util/escape/UnicodeEscaper;-><init>()V
    const-string v0, ".*[0-9A-Za-z].*"
    invoke-virtual v3, v0, Ljava/lang/String;->matches(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "Alphanumeric characters are always 'safe' and should not be explicitly specified"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    if-eqz v4, +012h
    const-string v0, " "
    invoke-virtual v3, v0, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v0
    if-eqz v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "plusForSpace cannot be specified when space is a 'safe' character"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    const-string v0, "%"
    invoke-virtual v3, v0, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v0
    if-eqz v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "The '%' character cannot be specified as 'safe'"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    iput-boolean v4, v2, Lcom/google/api/client/util/escape/PercentEscaper;->plusForSpace Z
    invoke-static v3, Lcom/google/api/client/util/escape/PercentEscaper;->createSafeOctets(Ljava/lang/String;)[Z
    move-result-object v0
    iput-object v0, v2, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    return-void
.end method

.method private static createSafeOctets(Ljava/lang/String;)[Z
    .registers 10
    const/4 v8, 1
    const/16 v4, 122
    invoke-virtual v9, Ljava/lang/String;->toCharArray()[C
    move-result-object v6
    move-object v0, v6
    array-length v3, v0
    const/4 v2, 0
    if-ge v2, v3, +00bh
    aget-char v1, v0, v2
    invoke-static v1, v4, Ljava/lang/Math;->max(I I)I
    move-result v4
    add-int/lit8 v2, v2, 1
    goto -ah
    add-int/lit8 v7, v4, 1
    new-array v5, v7, [Z
    const/16 v1, 48
    const/16 v7, 57
    if-gt v1, v7, +007h
    aput-boolean v8, v5, v1
    add-int/lit8 v1, v1, 1
    goto -8h
    const/16 v1, 65
    const/16 v7, 90
    if-gt v1, v7, +007h
    aput-boolean v8, v5, v1
    add-int/lit8 v1, v1, 1
    goto -8h
    const/16 v1, 97
    const/16 v7, 122
    if-gt v1, v7, +007h
    aput-boolean v8, v5, v1
    add-int/lit8 v1, v1, 1
    goto -8h
    move-object v0, v6
    array-length v3, v0
    const/4 v2, 0
    if-ge v2, v3, +009h
    aget-char v1, v0, v2
    aput-boolean v8, v5, v1
    add-int/lit8 v2, v2, 1
    goto -8h
    return-object v5
.end method

.method public escape(Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    invoke-virtual v5, Ljava/lang/String;->length()I
    move-result v2
    const/4 v1, 0
    if-ge v1, v2, +015h
    invoke-virtual v5, v1, Ljava/lang/String;->charAt(I)C
    move-result v0
    iget-object v3, v4, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    array-length v3, v3
    if-ge v0, v3, +008h
    iget-object v3, v4, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    aget-boolean v3, v3, v0
    if-nez v3, +007h
    invoke-virtual v4, v5, v1, Lcom/google/api/client/util/escape/PercentEscaper;->escapeSlow(Ljava/lang/String; I)Ljava/lang/String;
    move-result-object v5
    return-object v5
    add-int/lit8 v1, v1, 1
    goto -18h
.end method

.method protected escape(I)[C
    .registers 9
    const/4 v6, 3
    const/4 v5, 2
    const/4 v4, 1
    const/4 v3, 0
    const/16 v2, 37
    iget-object v1, v7, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    array-length v1, v1
    if-ge v8, v1, +00ah
    iget-object v1, v7, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    aget-boolean v1, v1, v8
    if-eqz v1, +004h
    const/4 v0, 0
    return-object v0
    const/16 v1, 32
    if-ne v8, v1, +009h
    iget-boolean v1, v7, Lcom/google/api/client/util/escape/PercentEscaper;->plusForSpace Z
    if-eqz v1, +005h
    sget-object v0, Lcom/google/api/client/util/escape/PercentEscaper;->URI_ESCAPED_SPACE [C
    goto -bh
    const/16 v1, 127
    if-gt v8, v1, +017h
    new-array v0, v6, [C
    aput-char v2, v0, v3
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v2, v8, 15
    aget-char v1, v1, v2
    aput-char v1, v0, v5
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    ushr-int/lit8 v2, v8, 4
    aget-char v1, v1, v2
    aput-char v1, v0, v4
    goto -24h
    const/16 v1, 2047
    if-gt v8, v1, +034h
    const/4 v1, 6
    new-array v0, v1, [C
    aput-char v2, v0, v3
    aput-char v2, v0, v6
    const/4 v1, 5
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/4 v1, 4
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v2, v8, 15
    aget-char v1, v1, v2
    aput-char v1, v0, v5
    ushr-int/lit8 v8, v8, 4
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    or-int/lit8 v2, v8, 12
    aget-char v1, v1, v2
    aput-char v1, v0, v4
    goto -5ah
    const v1, 65535
    if-gt v8, v1, +04ah
    const/16 v1, 9
    new-array v0, v1, [C
    aput-char v2, v0, v3
    const/16 v1, 69
    aput-char v1, v0, v4
    aput-char v2, v0, v6
    const/4 v1, 6
    aput-char v2, v0, v1
    const/16 v1, 8
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/4 v1, 7
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    const/4 v1, 5
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/4 v1, 4
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    aget-char v1, v1, v8
    aput-char v1, v0, v5
    goto/16 -0a6h
    const v1, 1114111
    if-gt v8, v1, +06ah
    const/16 v1, 12
    new-array v0, v1, [C
    aput-char v2, v0, v3
    const/16 v1, 70
    aput-char v1, v0, v4
    aput-char v2, v0, v6
    const/4 v1, 6
    aput-char v2, v0, v1
    const/16 v1, 9
    aput-char v2, v0, v1
    const/16 v1, 11
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/16 v1, 10
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    const/16 v1, 8
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/4 v1, 7
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    const/4 v1, 5
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 15
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 4
    const/4 v1, 4
    sget-object v2, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v3, v8, 3
    or-int/lit8 v3, v3, 8
    aget-char v2, v2, v3
    aput-char v2, v0, v1
    ushr-int/lit8 v8, v8, 2
    sget-object v1, Lcom/google/api/client/util/escape/PercentEscaper;->UPPER_HEX_DIGITS [C
    and-int/lit8 v2, v8, 7
    aget-char v1, v1, v2
    aput-char v1, v0, v5
    goto/16 -113h
    new-instance v1, Ljava/lang/IllegalArgumentException;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "Invalid unicode character value "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v8, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-direct v1, v2, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v1
.end method

.method protected nextEscapeIndex(Ljava/lang/CharSequence; I I)I
    .registers 6
    if-ge v4, v5, +011h
    invoke-interface v3, v4, Ljava/lang/CharSequence;->charAt(I)C
    move-result v0
    iget-object v1, v2, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    array-length v1, v1
    if-ge v0, v1, +008h
    iget-object v1, v2, Lcom/google/api/client/util/escape/PercentEscaper;->safeOctets [Z
    aget-boolean v1, v1, v0
    if-nez v1, +003h
    return v4
    add-int/lit8 v4, v4, 1
    goto -14h
.end method
