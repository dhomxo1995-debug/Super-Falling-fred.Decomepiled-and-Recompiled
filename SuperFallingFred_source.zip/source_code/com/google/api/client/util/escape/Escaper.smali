.class public abstract Lcom/google/api/client/util/escape/Escaper;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public abstract escape(Ljava/lang/String;)Ljava/lang/String;
    # abstract or native method
.end method
