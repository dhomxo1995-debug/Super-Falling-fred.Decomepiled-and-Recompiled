.class public final Lcom/google/api/client/util/escape/CharEscapers;
.super Ljava/lang/Object;

.field private static final URI_ESCAPER:Lcom/google/api/client/util/escape/Escaper;
.field private static final URI_PATH_ESCAPER:Lcom/google/api/client/util/escape/Escaper;
.field private static final URI_QUERY_STRING_ESCAPER:Lcom/google/api/client/util/escape/Escaper;

.method static constructor <clinit>()V
    .registers 4
    const/4 v3, 0
    new-instance v0, Lcom/google/api/client/util/escape/PercentEscaper;
    const-string v1, "-_.*"
    const/4 v2, 1
    invoke-direct v0, v1, v2, Lcom/google/api/client/util/escape/PercentEscaper;-><init>(Ljava/lang/String; Z)V
    sput-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    new-instance v0, Lcom/google/api/client/util/escape/PercentEscaper;
    const-string v1, "-_.!~*'()@:$&,;="
    invoke-direct v0, v1, v3, Lcom/google/api/client/util/escape/PercentEscaper;-><init>(Ljava/lang/String; Z)V
    sput-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_PATH_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    new-instance v0, Lcom/google/api/client/util/escape/PercentEscaper;
    const-string v1, "-_.!~*'()@:$,;/?:"
    invoke-direct v0, v1, v3, Lcom/google/api/client/util/escape/PercentEscaper;-><init>(Ljava/lang/String; Z)V
    sput-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_QUERY_STRING_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    return-void
.end method

.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static decodeUri(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    const-string v1, "UTF-8"
    invoke-static v2, v1, Ljava/net/URLDecoder;->decode(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    return-object v1
    move-exception v0
    new-instance v1, Ljava/lang/RuntimeException;
    invoke-direct v1, v0, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    throw v1
.end method

.method public static escapeUri(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    sget-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    invoke-virtual v0, v1, Lcom/google/api/client/util/escape/Escaper;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public static escapeUriPath(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    sget-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_PATH_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    invoke-virtual v0, v1, Lcom/google/api/client/util/escape/Escaper;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public static escapeUriQuery(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    sget-object v0, Lcom/google/api/client/util/escape/CharEscapers;->URI_QUERY_STRING_ESCAPER Lcom/google/api/client/util/escape/Escaper;
    invoke-virtual v0, v1, Lcom/google/api/client/util/escape/Escaper;->escape(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
