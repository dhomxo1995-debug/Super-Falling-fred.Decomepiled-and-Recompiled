.class public abstract Lcom/google/api/client/util/escape/UnicodeEscaper;
.super Lcom/google/api/client/util/escape/Escaper;

.field private static final DEST_PAD:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Lcom/google/api/client/util/escape/Escaper;-><init>()V
    return-void
.end method

.method protected static codePointAt(Ljava/lang/CharSequence; I I)I
    .registers 9
    if-ge v7, v8, +087h
    add-int/lit8 v2, v7, 1
    invoke-interface v6, v7, Ljava/lang/CharSequence;->charAt(I)C
    move-result v0
    const v3, 55296
    if-lt v0, v3, +007h
    const v3, 57343
    if-le v0, v3, +003h
    return v0
    const v3, 56319
    if-gt v0, v3, +042h
    if-ne v2, v8, +004h
    neg-int v0, v0
    goto -9h
    invoke-interface v6, v2, Ljava/lang/CharSequence;->charAt(I)C
    move-result v1
    invoke-static v1, Ljava/lang/Character;->isLowSurrogate(C)Z
    move-result v3
    if-eqz v3, +007h
    invoke-static v0, v1, Ljava/lang/Character;->toCodePoint(C C)I
    move-result v0
    goto -18h
    new-instance v3, Ljava/lang/IllegalArgumentException;
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Expected low surrogate but got char '"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, "' with value "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, " at index "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-direct v3, v4, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v3
    new-instance v3, Ljava/lang/IllegalArgumentException;
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Unexpected low surrogate character '"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v0, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, "' with value "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v0, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, " at index "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    add-int/lit8 v5, v2, -1
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-direct v3, v4, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v3
    new-instance v3, Ljava/lang/IndexOutOfBoundsException;
    const-string v4, "Index exceeds specified range"
    invoke-direct v3, v4, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    throw v3
.end method

.method private static growBuffer([C I I)[C
    .registers 5
    const/4 v1, 0
    new-array v0, v4, [C
    if-lez v3, +005h
    invoke-static v2, v1, v0, v1, v3, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    return-object v0
.end method

.method public abstract escape(Ljava/lang/String;)Ljava/lang/String;
    # abstract or native method
.end method

.method protected abstract escape(I)[C
    # abstract or native method
.end method

.method protected final escapeSlow(Ljava/lang/String; I)Ljava/lang/String;
    .registers 16
    invoke-virtual v14, Ljava/lang/String;->length()I
    move-result v5
    invoke-static Lcom/google/api/client/util/escape/Platform;->charBufferFromThreadLocal()[C
    move-result-object v2
    const/4 v3, 0
    const/4 v10, 0
    if-ge v15, v5, +04ah
    invoke-static v14, v15, v5, Lcom/google/api/client/util/escape/UnicodeEscaper;->codePointAt(Ljava/lang/CharSequence; I I)I
    move-result v1
    if-gez v1, +00ah
    new-instance v11, Ljava/lang/IllegalArgumentException;
    const-string v12, "Trailing high surrogate at end of input"
    invoke-direct v11, v12, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v11
    invoke-virtual v13, v1, Lcom/google/api/client/util/escape/UnicodeEscaper;->escape(I)[C
    move-result-object v7
    invoke-static v1, Ljava/lang/Character;->isSupplementaryCodePoint(I)Z
    move-result v11
    if-eqz v11, +030h
    const/4 v11, 2
    add-int v8, v15, v11
    if-eqz v7, +026h
    sub-int v0, v15, v10
    add-int v11, v3, v0
    array-length v12, v7
    add-int v9, v11, v12
    array-length v11, v2
    if-ge v11, v9, +00bh
    add-int v11, v9, v5
    sub-int/2addr v11, v15
    add-int/lit8 v4, v11, 32
    invoke-static v2, v3, v4, Lcom/google/api/client/util/escape/UnicodeEscaper;->growBuffer([C I I)[C
    move-result-object v2
    if-lez v0, +006h
    invoke-virtual v14, v10, v15, v2, v3, Ljava/lang/String;->getChars(I I [C I)V
    add-int/2addr v3, v0
    array-length v11, v7
    if-lez v11, +009h
    const/4 v11, 0
    array-length v12, v7
    invoke-static v7, v11, v2, v3, v12, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    array-length v11, v7
    add-int/2addr v3, v11
    move v10, v8
    invoke-virtual v13, v14, v8, v5, Lcom/google/api/client/util/escape/UnicodeEscaper;->nextEscapeIndex(Ljava/lang/CharSequence; I I)I
    move-result v15
    goto -47h
    const/4 v11, 1
    goto -2eh
    sub-int v0, v5, v10
    if-lez v0, +00fh
    add-int v6, v3, v0
    array-length v11, v2
    if-ge v11, v6, +006h
    invoke-static v2, v3, v6, Lcom/google/api/client/util/escape/UnicodeEscaper;->growBuffer([C I I)[C
    move-result-object v2
    invoke-virtual v14, v10, v5, v2, v3, Ljava/lang/String;->getChars(I I [C I)V
    move v3, v6
    new-instance v11, Ljava/lang/String;
    const/4 v12, 0
    invoke-direct v11, v2, v12, v3, Ljava/lang/String;-><init>([C I I)V
    return-object v11
.end method

.method protected abstract nextEscapeIndex(Ljava/lang/CharSequence; I I)I
    # abstract or native method
.end method
