package com.google.api.client.util;
public final class ArrayValueMap {
    private final Object destination;
    private final java.util.Map fieldMap;
    private final java.util.Map keyMap;

    public ArrayValueMap(Object p2)
    {
        this.keyMap = com.google.api.client.util.ArrayMap.create();
        this.fieldMap = com.google.api.client.util.ArrayMap.create();
        this.destination = p2;
        return;
    }

    public void put(String p3, Class p4, Object p5)
    {
        com.google.api.client.util.ArrayValueMap$ArrayValue v0_1 = ((com.google.api.client.util.ArrayValueMap$ArrayValue) this.keyMap.get(p3));
        if (v0_1 == null) {
            v0_1 = new com.google.api.client.util.ArrayValueMap$ArrayValue(p4);
            this.keyMap.put(p3, v0_1);
        }
        v0_1.addValue(p4, p5);
        return;
    }

    public void put(reflect.Field p3, Class p4, Object p5)
    {
        com.google.api.client.util.ArrayValueMap$ArrayValue v0_1 = ((com.google.api.client.util.ArrayValueMap$ArrayValue) this.fieldMap.get(p3));
        if (v0_1 == null) {
            v0_1 = new com.google.api.client.util.ArrayValueMap$ArrayValue(p4);
            this.fieldMap.put(p3, v0_1);
        }
        v0_1.addValue(p4, p5);
        return;
    }

    public void setValues()
    {
        java.util.Iterator v3_1 = this.keyMap.entrySet().iterator();
        while (v3_1.hasNext()) {
            java.util.Map$Entry v1_1 = ((java.util.Map$Entry) v3_1.next());
            ((java.util.Map) this.destination).put(v1_1.getKey(), ((com.google.api.client.util.ArrayValueMap$ArrayValue) v1_1.getValue()).toArray());
        }
        java.util.Iterator v3_0 = this.fieldMap.entrySet().iterator();
        while (v3_0.hasNext()) {
            java.util.Map$Entry v2_1 = ((java.util.Map$Entry) v3_0.next());
            com.google.api.client.util.FieldInfo.setFieldValue(((reflect.Field) v2_1.getKey()), this.destination, ((com.google.api.client.util.ArrayValueMap$ArrayValue) v2_1.getValue()).toArray());
        }
        return;
    }
}
