.class public final Lcom/google/api/client/util/DateTime;
.super Ljava/lang/Object;
.implements Ljava/io/Serializable;

.field private static final GMT:Ljava/util/TimeZone;
.field private static final serialVersionUID:J
.field private final dateOnly:Z
.field private final tzShift:Ljava/lang/Integer;
.field private final value:J

.method static constructor <clinit>()V
    .registers 1
    const-string v0, "GMT"
    invoke-static v0, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/util/DateTime;->GMT Ljava/util/TimeZone;
    return-void
.end method

.method public constructor <init>(J)V
    .registers 5
    const/4 v0, 0
    const/4 v1, 0
    invoke-direct v2, v0, v3, v4, v1, Lcom/google/api/client/util/DateTime;-><init>(Z J Ljava/lang/Integer;)V
    return-void
.end method

.method public constructor <init>(J Ljava/lang/Integer;)V
    .registers 5
    const/4 v0, 0
    invoke-direct v1, v0, v2, v3, v4, Lcom/google/api/client/util/DateTime;-><init>(Z J Ljava/lang/Integer;)V
    return-void
.end method

.method public constructor <init>(Ljava/util/Date;)V
    .registers 4
    invoke-virtual v3, Ljava/util/Date;->getTime()J
    move-result-wide v0
    invoke-direct v2, v0, v1, Lcom/google/api/client/util/DateTime;-><init>(J)V
    return-void
.end method

.method public constructor <init>(Ljava/util/Date; Ljava/util/TimeZone;)V
    .registers 7
    invoke-direct v4, Ljava/lang/Object;-><init>()V
    invoke-virtual v5, Ljava/util/Date;->getTime()J
    move-result-wide v0
    const/4 v2, 0
    iput-boolean v2, v4, Lcom/google/api/client/util/DateTime;->dateOnly Z
    iput-wide v0, v4, Lcom/google/api/client/util/DateTime;->value J
    invoke-virtual v6, v0, v1, Ljava/util/TimeZone;->getOffset(J)I
    move-result v2
    const v3, 60000
    div-int/2addr v2, v3
    invoke-static v2, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v2
    iput-object v2, v4, Lcom/google/api/client/util/DateTime;->tzShift Ljava/lang/Integer;
    return-void
.end method

.method public constructor <init>(Z J Ljava/lang/Integer;)V
    .registers 5
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-boolean v1, v0, Lcom/google/api/client/util/DateTime;->dateOnly Z
    iput-wide v2, v0, Lcom/google/api/client/util/DateTime;->value J
    iput-object v4, v0, Lcom/google/api/client/util/DateTime;->tzShift Ljava/lang/Integer;
    return-void
.end method

.method private static appendInt(Ljava/lang/StringBuilder; I I)V
    .registers 6
    if-gez v4, +008h
    const/16 v2, 45
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    neg-int v4, v4
    move v1, v4
    if-lez v1, +007h
    div-int/lit8 v1, v1, 10
    add-int/lit8 v5, v5, -1
    goto -6h
    const/4 v0, 0
    if-ge v0, v5, +00ah
    const/16 v2, 48
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    add-int/lit8 v0, v0, 1
    goto -9h
    if-eqz v4, +005h
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    return-void
.end method

.method public static parseRfc3339(Ljava/lang/String;)Lcom/google/api/client/util/DateTime;
    .registers 24
    new-instance v4, Ljava/util/GregorianCalendar;
    sget-object v20, Lcom/google/api/client/util/DateTime;->GMT Ljava/util/TimeZone;
    move-object/from16 v0, v20
    invoke-direct v4, v0, Ljava/util/GregorianCalendar;-><init>(Ljava/util/TimeZone;)V
    const/16 v20, 0
    const/16 v21, 4
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v5
    const/16 v20, 5
    const/16 v21, 7
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v20
    add-int/lit8 v6, v20, -1
    const/16 v20, 8
    const/16 v21, 10
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v7
    invoke-virtual/range v23, Ljava/lang/String;->length()I
    move-result v13
    const/16 v20, 10
    move/from16 v0, v20
    if-le v13, v0, +018h
    const/16 v20, 10
    move-object/from16 v0, v23
    move/from16 v1, v20
    invoke-virtual v0, v1, Ljava/lang/String;->charAt(I)C
    move-result v20
    invoke-static/range v20, Ljava/lang/Character;->toUpperCase(C)C
    move-result v20
    const/16 v21, 84
    move/from16 v0, v20
    move/from16 v1, v21
    if-eq v0, v1, +036h
    const/4 v11, 1
    if-eqz v11, +035h
    invoke-virtual v4, v5, v6, v7, Ljava/util/Calendar;->set(I I I)V
    const/16 v15, 10
    const/16 v17, 0
    invoke-virtual v4, Ljava/util/Calendar;->getTimeInMillis()J
    move-result-wide v18
    if-le v13, v15, +01ah
    move-object/from16 v0, v23
    invoke-virtual v0, v15, Ljava/lang/String;->charAt(I)C
    move-result v20
    invoke-static/range v20, Ljava/lang/Character;->toUpperCase(C)C
    move-result v20
    const/16 v21, 90
    move/from16 v0, v20
    move/from16 v1, v21
    if-ne v0, v1, +08dh
    const/16 v16, 0
    invoke-static/range v16, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v17
    new-instance v20, Lcom/google/api/client/util/DateTime;
    move-object/from16 v0, v20
    move-wide/from16 v1, v18
    move-object/from16 v3, v17
    invoke-direct v0, v11, v1, v2, v3, Lcom/google/api/client/util/DateTime;-><init>(Z J Ljava/lang/Integer;)V
    return-object v20
    const/4 v11, 0
    goto -34h
    const/16 v20, 11
    const/16 v21, 13
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v8
    const/16 v20, 14
    const/16 v21, 16
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v9
    const/16 v20, 17
    const/16 v21, 19
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v10
    invoke-virtual/range v4 ... v10, Ljava/util/Calendar;->set(I I I I I I)V
    const/16 v20, 19
    move-object/from16 v0, v23
    move/from16 v1, v20
    invoke-virtual v0, v1, Ljava/lang/String;->charAt(I)C
    move-result v20
    const/16 v21, 46
    move/from16 v0, v20
    move/from16 v1, v21
    if-ne v0, v1, +01fh
    const/16 v20, 20
    const/16 v21, 23
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v14
    const/16 v20, 14
    move/from16 v0, v20
    invoke-virtual v4, v0, v14, Ljava/util/Calendar;->set(I I)V
    const/16 v15, 23
    goto/16 -094h
    const/16 v20, 14
    const/16 v21, 0
    move/from16 v0, v20
    move/from16 v1, v21
    invoke-virtual v4, v0, v1, Ljava/util/Calendar;->set(I I)V
    const/16 v15, 19
    goto/16 -0a3h
    add-int/lit8 v20, v15, 1
    add-int/lit8 v21, v15, 3
    move-object/from16 v0, v23
    move/from16 v1, v20
    move/from16 v2, v21
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v20
    invoke-static/range v20, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v20
    mul-int/lit8 v20, v20, 60
    add-int/lit8 v21, v15, 4
    add-int/lit8 v22, v15, 6
    move-object/from16 v0, v23
    move/from16 v1, v21
    move/from16 v2, v22
    invoke-virtual v0, v1, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v21
    invoke-static/range v21, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v21
    add-int v16, v20, v21
    move-object/from16 v0, v23
    invoke-virtual v0, v15, Ljava/lang/String;->charAt(I)C
    move-result v20
    const/16 v21, 45
    move/from16 v0, v20
    move/from16 v1, v21
    if-ne v0, v1, +007h
    move/from16 v0, v16
    neg-int v0, v0
    move/from16 v16, v0
    const v20, 60000
    mul-int v20, v20, v16
    move/from16 v0, v20
    int-to-long v0, v0
    move-wide/from16 v20, v0
    sub-long v18, v18, v20
    goto/16 -0d0h
    move-exception v12
    new-instance v20, Ljava/lang/NumberFormatException;
    const-string v21, "Invalid date/time format."
    invoke-direct/range v20 ... v21, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V
    throw v20
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9
    const/4 v1, 1
    const/4 v2, 0
    if-ne v8, v7, +003h
    return v1
    instance-of v3, v8, Lcom/google/api/client/util/DateTime;
    if-nez v3, +004h
    move v1, v2
    goto -6h
    move-object v0, v8
    check-cast v0, Lcom/google/api/client/util/DateTime;
    iget-boolean v3, v7, Lcom/google/api/client/util/DateTime;->dateOnly Z
    iget-boolean v4, v0, Lcom/google/api/client/util/DateTime;->dateOnly Z
    if-ne v3, v4, +00ah
    iget-wide v3, v7, Lcom/google/api/client/util/DateTime;->value J
    iget-wide v5, v0, Lcom/google/api/client/util/DateTime;->value J
    cmp-long v3, v3, v5
    if-eqz v3, -016h
    move v1, v2
    goto -19h
.end method

.method public getTimeZoneShift()Ljava/lang/Integer;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/DateTime;->tzShift Ljava/lang/Integer;
    return-object v0
.end method

.method public getValue()J
    .registers 3
    iget-wide v0, v2, Lcom/google/api/client/util/DateTime;->value J
    return-wide v0
.end method

.method public isDateOnly()Z
    .registers 2
    iget-boolean v0, v1, Lcom/google/api/client/util/DateTime;->dateOnly Z
    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/DateTime;->toStringRfc3339()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public toStringRfc3339()Ljava/lang/String;
    .registers 13
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    new-instance v1, Ljava/util/GregorianCalendar;
    sget-object v8, Lcom/google/api/client/util/DateTime;->GMT Ljava/util/TimeZone;
    invoke-direct v1, v8, Ljava/util/GregorianCalendar;-><init>(Ljava/util/TimeZone;)V
    iget-wide v2, v12, Lcom/google/api/client/util/DateTime;->value J
    iget-object v7, v12, Lcom/google/api/client/util/DateTime;->tzShift Ljava/lang/Integer;
    if-eqz v7, +00bh
    invoke-virtual v7, Ljava/lang/Integer;->longValue()J
    move-result-wide v8
    const-wide/32 v10, 60000
    mul-long/2addr v8, v10
    add-long/2addr v2, v8
    invoke-virtual v1, v2, v3, Ljava/util/Calendar;->setTimeInMillis(J)V
    const/4 v8, 1
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 4
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 45
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/4 v8, 2
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    add-int/lit8 v8, v8, 1
    const/4 v9, 2
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 45
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/4 v8, 5
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 2
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    iget-boolean v8, v12, Lcom/google/api/client/util/DateTime;->dateOnly Z
    if-nez v8, +046h
    const/16 v8, 84
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/16 v8, 11
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 2
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 58
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/16 v8, 12
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 2
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 58
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/16 v8, 13
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 2
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 14
    invoke-virtual v1, v8, Ljava/util/Calendar;->isSet(I)Z
    move-result v8
    if-eqz v8, +011h
    const/16 v8, 46
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/16 v8, 14
    invoke-virtual v1, v8, Ljava/util/Calendar;->get(I)I
    move-result v8
    const/4 v9, 3
    invoke-static v4, v8, v9, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    if-eqz v7, +00dh
    invoke-virtual v7, Ljava/lang/Integer;->intValue()I
    move-result v8
    if-nez v8, +00ch
    const/16 v8, 90
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v8
    return-object v8
    invoke-virtual v7, Ljava/lang/Integer;->intValue()I
    move-result v0
    invoke-virtual v7, Ljava/lang/Integer;->intValue()I
    move-result v8
    if-lez v8, +019h
    const/16 v8, 43
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    div-int/lit8 v5, v0, 60
    rem-int/lit8 v6, v0, 60
    const/4 v8, 2
    invoke-static v4, v5, v8, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    const/16 v8, 58
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    const/4 v8, 2
    invoke-static v4, v6, v8, Lcom/google/api/client/util/DateTime;->appendInt(Ljava/lang/StringBuilder; I I)V
    goto -25h
    const/16 v8, 45
    invoke-virtual v4, v8, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    neg-int v0, v0
    goto -18h
.end method
