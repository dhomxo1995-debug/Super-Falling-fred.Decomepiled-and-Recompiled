.class public Lcom/google/api/client/util/Data;
.super Ljava/lang/Object;

.field public static final NULL_BIG_DECIMAL:Ljava/math/BigDecimal;
.field public static final NULL_BIG_INTEGER:Ljava/math/BigInteger;
.field public static final NULL_BOOLEAN:Ljava/lang/Boolean;
.field public static final NULL_BYTE:Ljava/lang/Byte;
.field private static final NULL_CACHE:Ljava/util/concurrent/ConcurrentHashMap;
.field public static final NULL_CHARACTER:Ljava/lang/Character;
.field public static final NULL_DATE_TIME:Lcom/google/api/client/util/DateTime;
.field public static final NULL_DOUBLE:Ljava/lang/Double;
.field public static final NULL_FLOAT:Ljava/lang/Float;
.field public static final NULL_INTEGER:Ljava/lang/Integer;
.field public static final NULL_LONG:Ljava/lang/Long;
.field public static final NULL_SHORT:Ljava/lang/Short;
.field public static final NULL_STRING:Ljava/lang/String;
.field public static final NULL_UNSIGNED_INTEGER:Lcom/google/common/primitives/UnsignedInteger;
.field public static final NULL_UNSIGNED_LONG:Lcom/google/common/primitives/UnsignedLong;

.method static constructor <clinit>()V
    .registers 6
    const-wide/16 v4, 0
    const/4 v3, 0
    new-instance v0, Ljava/lang/Boolean;
    const/4 v1, 1
    invoke-direct v0, v1, Ljava/lang/Boolean;-><init>(Z)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_BOOLEAN Ljava/lang/Boolean;
    new-instance v0, Ljava/lang/String;
    invoke-direct v0, Ljava/lang/String;-><init>()V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_STRING Ljava/lang/String;
    new-instance v0, Ljava/lang/Character;
    invoke-direct v0, v3, Ljava/lang/Character;-><init>(C)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_CHARACTER Ljava/lang/Character;
    new-instance v0, Ljava/lang/Byte;
    invoke-direct v0, v3, Ljava/lang/Byte;-><init>(B)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_BYTE Ljava/lang/Byte;
    new-instance v0, Ljava/lang/Short;
    invoke-direct v0, v3, Ljava/lang/Short;-><init>(S)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_SHORT Ljava/lang/Short;
    new-instance v0, Ljava/lang/Integer;
    invoke-direct v0, v3, Ljava/lang/Integer;-><init>(I)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_INTEGER Ljava/lang/Integer;
    new-instance v0, Ljava/lang/Float;
    const/4 v1, 0
    invoke-direct v0, v1, Ljava/lang/Float;-><init>(F)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_FLOAT Ljava/lang/Float;
    new-instance v0, Ljava/lang/Long;
    invoke-direct v0, v4, v5, Ljava/lang/Long;-><init>(J)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_LONG Ljava/lang/Long;
    new-instance v0, Ljava/lang/Double;
    const-wide/16 v1, 0
    invoke-direct v0, v1, v2, Ljava/lang/Double;-><init>(D)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_DOUBLE Ljava/lang/Double;
    new-instance v0, Ljava/math/BigInteger;
    const-string v1, "0"
    invoke-direct v0, v1, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_BIG_INTEGER Ljava/math/BigInteger;
    invoke-static v3, Lcom/google/common/primitives/UnsignedInteger;->asUnsigned(I)Lcom/google/common/primitives/UnsignedInteger;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_UNSIGNED_INTEGER Lcom/google/common/primitives/UnsignedInteger;
    invoke-static v4, v5, Lcom/google/common/primitives/UnsignedLong;->asUnsigned(J)Lcom/google/common/primitives/UnsignedLong;
    move-result-object v0
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_UNSIGNED_LONG Lcom/google/common/primitives/UnsignedLong;
    new-instance v0, Ljava/math/BigDecimal;
    const-string v1, "0"
    invoke-direct v0, v1, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_BIG_DECIMAL Ljava/math/BigDecimal;
    new-instance v0, Lcom/google/api/client/util/DateTime;
    invoke-direct v0, v4, v5, Lcom/google/api/client/util/DateTime;-><init>(J)V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_DATE_TIME Lcom/google/api/client/util/DateTime;
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;
    invoke-direct v0, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V
    sput-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Boolean;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_BOOLEAN Ljava/lang/Boolean;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/String;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_STRING Ljava/lang/String;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Character;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_CHARACTER Ljava/lang/Character;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Byte;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_BYTE Ljava/lang/Byte;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Short;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_SHORT Ljava/lang/Short;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Integer;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_INTEGER Ljava/lang/Integer;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Float;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_FLOAT Ljava/lang/Float;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Long;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_LONG Ljava/lang/Long;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/lang/Double;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_DOUBLE Ljava/lang/Double;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/math/BigInteger;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_BIG_INTEGER Ljava/math/BigInteger;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Lcom/google/common/primitives/UnsignedInteger;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_UNSIGNED_INTEGER Lcom/google/common/primitives/UnsignedInteger;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Lcom/google/common/primitives/UnsignedLong;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_UNSIGNED_LONG Lcom/google/common/primitives/UnsignedLong;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Ljava/math/BigDecimal;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_BIG_DECIMAL Ljava/math/BigDecimal;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    const-class v1, Lcom/google/api/client/util/DateTime;
    sget-object v2, Lcom/google/api/client/util/Data;->NULL_DATE_TIME Lcom/google/api/client/util/DateTime;
    invoke-virtual v0, v1, v2, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static clone(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    if-eqz v4, +00ch
    invoke-virtual v4, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v2
    invoke-static v2, Lcom/google/api/client/util/Data;->isPrimitive(Ljava/lang/reflect/Type;)Z
    move-result v2
    if-eqz v2, +004h
    move-object v0, v4
    return-object v0
    instance-of v2, v4, Lcom/google/api/client/util/GenericData;
    if-eqz v2, +009h
    check-cast v4, Lcom/google/api/client/util/GenericData;
    invoke-virtual v4, Lcom/google/api/client/util/GenericData;->clone()Lcom/google/api/client/util/GenericData;
    move-result-object v0
    goto -bh
    invoke-virtual v4, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Class;->isArray()Z
    move-result v2
    if-eqz v2, +012h
    invoke-virtual v1, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v2
    invoke-static v4, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    move-result v3
    invoke-static v2, v3, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v0
    invoke-static v4, v0, Lcom/google/api/client/util/Data;->deepCopy(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -25h
    instance-of v2, v4, Lcom/google/api/client/util/ArrayMap;
    if-eqz v2, +00ah
    move-object v2, v4
    check-cast v2, Lcom/google/api/client/util/ArrayMap;
    invoke-virtual v2, Lcom/google/api/client/util/ArrayMap;->clone()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    goto -fh
    invoke-static v1, Lcom/google/api/client/util/Types;->newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v0
    goto -14h
.end method

.method public static deepCopy(Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 26
    invoke-virtual/range v24, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v15
    invoke-static v15, Lcom/google/api/client/util/Data;->isPrimitive(Ljava/lang/reflect/Type;)Z
    move-result v22
    if-nez v22, +04fh
    const/16 v22, 1
    invoke-static/range v22, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    invoke-virtual/range v25, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v22
    move-object/from16 v0, v22
    if-ne v15, v0, +045h
    const/16 v22, 1
    invoke-static/range v22, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    invoke-virtual v15, Ljava/lang/Class;->isArray()Z
    move-result v22
    if-eqz v22, +040h
    invoke-static/range v24, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    move-result v22
    invoke-static/range v25, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    move-result v23
    move/from16 v0, v22
    move/from16 v1, v23
    if-ne v0, v1, +02fh
    const/16 v22, 1
    invoke-static/range v22, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    const/4 v11, 0
    invoke-static/range v24, Lcom/google/api/client/util/Types;->iterableOf(Ljava/lang/Object;)Ljava/lang/Iterable;
    move-result-object v22
    invoke-interface/range v22, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    move-result-object v10
    invoke-interface v10, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +117h
    invoke-interface v10, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v21
    add-int/lit8 v12, v11, 1
    invoke-static/range v21, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v22
    move-object/from16 v0, v25
    move-object/from16 v1, v22
    invoke-static v0, v11, v1, Ljava/lang/reflect/Array;->set(Ljava/lang/Object; I Ljava/lang/Object;)V
    move v11, v12
    goto -18h
    const/16 v22, 0
    goto -4dh
    const/16 v22, 0
    goto -43h
    const/16 v22, 0
    goto -2dh
    const-class v22, Ljava/util/Collection;
    move-object/from16 v0, v22
    invoke-virtual v0, v15, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v22
    if-eqz v22, +039h
    move-object/from16 v16, v24
    check-cast v16, Ljava/util/Collection;
    const-class v22, Ljava/util/ArrayList;
    move-object/from16 v0, v22
    invoke-virtual v0, v15, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v22
    if-eqz v22, +00fh
    move-object/from16 v3, v25
    check-cast v3, Ljava/util/ArrayList;
    invoke-interface/range v16, Ljava/util/Collection;->size()I
    move-result v22
    move/from16 v0, v22
    invoke-virtual v3, v0, Ljava/util/ArrayList;->ensureCapacity(I)V
    move-object/from16 v4, v25
    check-cast v4, Ljava/util/Collection;
    invoke-interface/range v16, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    move-result-object v10
    invoke-interface v10, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +0c8h
    invoke-interface v10, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v20
    invoke-static/range v20, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-interface v4, v0, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    goto -13h
    const-class v22, Lcom/google/api/client/util/GenericData;
    move-object/from16 v0, v22
    invoke-virtual v0, v15, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v13
    if-nez v13, +00ch
    const-class v22, Ljava/util/Map;
    move-object/from16 v0, v22
    invoke-virtual v0, v15, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v22
    if-nez v22, +04bh
    if-eqz v13, +044h
    move-object/from16 v22, v24
    check-cast v22, Lcom/google/api/client/util/GenericData;
    move-object/from16 v0, v22
    iget-object v2, v0, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v0, v2, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    move-object/from16 v22, v0
    invoke-interface/range v22, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v10
    invoke-interface v10, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +08eh
    invoke-interface v10, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v8
    check-cast v8, Ljava/lang/String;
    invoke-virtual v2, v8, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v7
    invoke-virtual v7, Lcom/google/api/client/util/FieldInfo;->isFinal()Z
    move-result v22
    if-nez v22, -014h
    if-eqz v13, +008h
    invoke-virtual v7, Lcom/google/api/client/util/FieldInfo;->isPrimitive()Z
    move-result v22
    if-nez v22, -01ch
    move-object/from16 v0, v24
    invoke-virtual v7, v0, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v20
    if-eqz v20, -024h
    invoke-static/range v20, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v22
    move-object/from16 v0, v25
    move-object/from16 v1, v22
    invoke-virtual v7, v0, v1, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -31h
    invoke-static v15, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v2
    goto -3eh
    const-class v22, Lcom/google/api/client/util/ArrayMap;
    move-object/from16 v0, v22
    invoke-virtual v0, v15, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v22
    if-eqz v22, +023h
    move-object/from16 v5, v25
    check-cast v5, Lcom/google/api/client/util/ArrayMap;
    move-object/from16 v18, v24
    check-cast v18, Lcom/google/api/client/util/ArrayMap;
    invoke-virtual/range v18, Lcom/google/api/client/util/ArrayMap;->size()I
    move-result v14
    const/4 v9, 0
    if-ge v9, v14, +044h
    move-object/from16 v0, v18
    invoke-virtual v0, v9, Lcom/google/api/client/util/ArrayMap;->getValue(I)Ljava/lang/Object;
    move-result-object v20
    invoke-static/range v20, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v22
    move-object/from16 v0, v22
    invoke-virtual v5, v9, v0, Lcom/google/api/client/util/ArrayMap;->set(I Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v9, v9, 1
    goto -13h
    move-object/from16 v6, v25
    check-cast v6, Ljava/util/Map;
    move-object/from16 v19, v24
    check-cast v19, Ljava/util/Map;
    invoke-interface/range v19, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v22
    invoke-interface/range v22, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v10
    invoke-interface v10, Ljava/util/Iterator;->hasNext()Z
    move-result v22
    if-eqz v22, +01ch
    invoke-interface v10, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v17
    check-cast v17, Ljava/util/Map$Entry;
    invoke-interface/range v17, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v22
    invoke-interface/range v17, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v23
    invoke-static/range v23, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v23
    move-object/from16 v0, v22
    move-object/from16 v1, v23
    invoke-interface v6, v0, v1, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -1fh
    return-void
.end method

.method public static isNull(Ljava/lang/Object;)Z
    .registers 3
    if-eqz v2, +010h
    sget-object v0, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    invoke-virtual v2, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    if-ne v2, v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static isPrimitive(Ljava/lang/reflect/Type;)Z
    .registers 4
    const/4 v1, 0
    instance-of v2, v3, Ljava/lang/reflect/WildcardType;
    if-eqz v2, +008h
    check-cast v3, Ljava/lang/reflect/WildcardType;
    invoke-static v3, Lcom/google/api/client/util/Types;->getBound(Ljava/lang/reflect/WildcardType;)Ljava/lang/reflect/Type;
    move-result-object v3
    instance-of v2, v3, Ljava/lang/Class;
    if-nez v2, +003h
    return v1
    move-object v0, v3
    check-cast v0, Ljava/lang/Class;
    invoke-virtual v0, Ljava/lang/Class;->isPrimitive()Z
    move-result v2
    if-nez v2, +03ah
    const-class v2, Ljava/lang/Character;
    if-eq v0, v2, +036h
    const-class v2, Ljava/lang/String;
    if-eq v0, v2, +032h
    const-class v2, Ljava/lang/Integer;
    if-eq v0, v2, +02eh
    const-class v2, Ljava/lang/Long;
    if-eq v0, v2, +02ah
    const-class v2, Ljava/lang/Short;
    if-eq v0, v2, +026h
    const-class v2, Ljava/lang/Byte;
    if-eq v0, v2, +022h
    const-class v2, Ljava/lang/Float;
    if-eq v0, v2, +01eh
    const-class v2, Ljava/lang/Double;
    if-eq v0, v2, +01ah
    const-class v2, Ljava/math/BigInteger;
    if-eq v0, v2, +016h
    const-class v2, Lcom/google/common/primitives/UnsignedInteger;
    if-eq v0, v2, +012h
    const-class v2, Lcom/google/common/primitives/UnsignedLong;
    if-eq v0, v2, +00eh
    const-class v2, Ljava/math/BigDecimal;
    if-eq v0, v2, +00ah
    const-class v2, Lcom/google/api/client/util/DateTime;
    if-eq v0, v2, +006h
    const-class v2, Ljava/lang/Boolean;
    if-ne v0, v2, -040h
    const/4 v1, 1
    goto -43h
.end method

.method public static isValueOfPrimitiveType(Ljava/lang/Object;)Z
    .registers 2
    if-eqz v1, +00ch
    invoke-virtual v1, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, Lcom/google/api/client/util/Data;->isPrimitive(Ljava/lang/reflect/Type;)Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static mapOf(Ljava/lang/Object;)Ljava/util/Map;
    .registers 3
    if-eqz v2, +008h
    invoke-static v2, Lcom/google/api/client/util/Data;->isNull(Ljava/lang/Object;)Z
    move-result v1
    if-eqz v1, +007h
    invoke-static Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    move-result-object v0
    return-object v0
    instance-of v1, v2, Ljava/util/Map;
    if-eqz v1, +006h
    move-object v0, v2
    check-cast v0, Ljava/util/Map;
    goto -8h
    new-instance v0, Lcom/google/api/client/util/DataMap;
    const/4 v1, 0
    invoke-direct v0, v2, v1, Lcom/google/api/client/util/DataMap;-><init>(Ljava/lang/Object; Z)V
    goto -fh
.end method

.method public static newCollectionInstance(Ljava/lang/reflect/Type;)Ljava/util/Collection;
    .registers 4
    instance-of v2, v3, Ljava/lang/reflect/WildcardType;
    if-eqz v2, +008h
    check-cast v3, Ljava/lang/reflect/WildcardType;
    invoke-static v3, Lcom/google/api/client/util/Types;->getBound(Ljava/lang/reflect/WildcardType;)Ljava/lang/reflect/Type;
    move-result-object v3
    instance-of v2, v3, Ljava/lang/reflect/ParameterizedType;
    if-eqz v2, +008h
    check-cast v3, Ljava/lang/reflect/ParameterizedType;
    invoke-interface v3, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;
    move-result-object v3
    instance-of v2, v3, Ljava/lang/Class;
    if-eqz v2, +022h
    move-object v2, v3
    check-cast v2, Ljava/lang/Class;
    move-object v0, v2
    if-eqz v3, +016h
    instance-of v2, v3, Ljava/lang/reflect/GenericArrayType;
    if-nez v2, +012h
    if-eqz v0, +018h
    invoke-virtual v0, Ljava/lang/Class;->isArray()Z
    move-result v2
    if-nez v2, +00ah
    const-class v2, Ljava/util/ArrayList;
    invoke-virtual v0, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v2
    if-eqz v2, +00ah
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct v1, Ljava/util/ArrayList;-><init>()V
    return-object v1
    const/4 v0, 0
    goto -1dh
    const-class v2, Ljava/util/HashSet;
    invoke-virtual v0, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v2
    if-eqz v2, +008h
    new-instance v1, Ljava/util/HashSet;
    invoke-direct v1, Ljava/util/HashSet;-><init>()V
    goto -10h
    const-class v2, Ljava/util/TreeSet;
    invoke-virtual v0, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v2
    if-eqz v2, +008h
    new-instance v1, Ljava/util/TreeSet;
    invoke-direct v1, Ljava/util/TreeSet;-><init>()V
    goto -1eh
    invoke-static v0, Lcom/google/api/client/util/Types;->newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/util/Collection;
    goto -25h
.end method

.method public static newMapInstance(Ljava/lang/Class;)Ljava/util/Map;
    .registers 3
    if-eqz v2, +00ah
    const-class v1, Lcom/google/api/client/util/ArrayMap;
    invoke-virtual v2, v1, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v1
    if-eqz v1, +007h
    invoke-static Lcom/google/api/client/util/ArrayMap;->create()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    return-object v0
    const-class v1, Ljava/util/TreeMap;
    invoke-virtual v2, v1, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v1
    if-eqz v1, +008h
    new-instance v0, Ljava/util/TreeMap;
    invoke-direct v0, Ljava/util/TreeMap;-><init>()V
    goto -eh
    invoke-static v2, Lcom/google/api/client/util/Types;->newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map;
    goto -15h
.end method

.method public static nullOf(Ljava/lang/Class;)Ljava/lang/Object;
    .registers 11
    sget-object v6, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    invoke-virtual v6, v10, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v4
    if-nez v4, +059h
    sget-object v7, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    monitor-enter v7
    sget-object v6, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    invoke-virtual v6, v10, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v4
    if-nez v4, +04ch
    invoke-virtual v10, Ljava/lang/Class;->isArray()Z
    move-result v6
    if-eqz v6, +01eh
    const/4 v1, 0
    move-object v0, v10
    invoke-virtual v0, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v0
    add-int/lit8 v1, v1, 1
    invoke-virtual v0, Ljava/lang/Class;->isArray()Z
    move-result v6
    if-nez v6, -00ah
    new-array v6, v1, [I
    invoke-static v0, v6, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; [I)Ljava/lang/Object;
    move-result-object v4
    sget-object v6, Lcom/google/api/client/util/Data;->NULL_CACHE Ljava/util/concurrent/ConcurrentHashMap;
    invoke-virtual v6, v10, v4, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    move-object v5, v4
    monitor-exit v7
    return-object v5
    invoke-virtual v10, Ljava/lang/Class;->isEnum()Z
    move-result v6
    if-eqz v6, +01ch
    invoke-static v10, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v6
    const/4 v8, 0
    invoke-virtual v6, v8, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v3
    const-string v6, "enum missing constant with @NullValue annotation: %s"
    const/4 v8, 1
    new-array v8, v8, [Ljava/lang/Object;
    const/4 v9, 0
    aput-object v10, v8, v9
    invoke-static v3, v6, v8, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object; Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v3, Lcom/google/api/client/util/FieldInfo;->enumValue()Ljava/lang/Enum;
    move-result-object v2
    move-object v4, v2
    goto -27h
    invoke-static v10, Lcom/google/api/client/util/Types;->newInstance(Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v4
    goto -2ch
    move-exception v6
    monitor-exit v7
    throw v6
    move-object v5, v4
    goto -2bh
    move-object v5, v4
    goto -2ch
.end method

.method public static parsePrimitiveValue(Ljava/lang/reflect/Type; Ljava/lang/String;)Ljava/lang/Object;
    .registers 7
    instance-of v2, v5, Ljava/lang/Class;
    if-eqz v2, +018h
    move-object v2, v5
    check-cast v2, Ljava/lang/Class;
    move-object v0, v2
    if-eqz v5, +004h
    if-eqz v0, +0e9h
    if-eqz v6, +00ch
    if-eqz v0, +00ah
    const-class v2, Ljava/lang/String;
    invoke-virtual v0, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v2
    if-eqz v2, +006h
    move-object v1, v6
    return-object v1
    const/4 v0, 0
    goto -13h
    const-class v2, Ljava/lang/Character;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Character;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +02ch
    invoke-virtual v6, Ljava/lang/String;->length()I
    move-result v2
    const/4 v3, 1
    if-eq v2, v3, +01bh
    new-instance v2, Ljava/lang/IllegalArgumentException;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "expected type Character/char but got "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-direct v2, v3, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v2
    const/4 v2, 0
    invoke-virtual v6, v2, Ljava/lang/String;->charAt(I)C
    move-result v2
    invoke-static v2, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;
    move-result-object v1
    goto -34h
    const-class v2, Ljava/lang/Boolean;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Boolean;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +007h
    invoke-static v6, Ljava/lang/Boolean;->valueOf(Ljava/lang/String;)Ljava/lang/Boolean;
    move-result-object v1
    goto -41h
    const-class v2, Ljava/lang/Byte;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Byte;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +007h
    invoke-static v6, Ljava/lang/Byte;->valueOf(Ljava/lang/String;)Ljava/lang/Byte;
    move-result-object v1
    goto -4eh
    const-class v2, Ljava/lang/Short;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Short;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +007h
    invoke-static v6, Ljava/lang/Short;->valueOf(Ljava/lang/String;)Ljava/lang/Short;
    move-result-object v1
    goto -5bh
    const-class v2, Ljava/lang/Integer;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Integer;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +007h
    invoke-static v6, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v1
    goto -68h
    const-class v2, Ljava/lang/Long;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Long;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +007h
    invoke-static v6, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;
    move-result-object v1
    goto -75h
    const-class v2, Ljava/lang/Float;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Float;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +008h
    invoke-static v6, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;
    move-result-object v1
    goto/16 -082h
    const-class v2, Ljava/lang/Double;
    if-eq v0, v2, +006h
    sget-object v2, Ljava/lang/Double;->TYPE Ljava/lang/Class;
    if-ne v0, v2, +008h
    invoke-static v6, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;
    move-result-object v1
    goto/16 -090h
    const-class v2, Lcom/google/api/client/util/DateTime;
    if-ne v0, v2, +008h
    invoke-static v6, Lcom/google/api/client/util/DateTime;->parseRfc3339(Ljava/lang/String;)Lcom/google/api/client/util/DateTime;
    move-result-object v1
    goto/16 -09ah
    const-class v2, Ljava/math/BigInteger;
    if-ne v0, v2, +009h
    new-instance v1, Ljava/math/BigInteger;
    invoke-direct v1, v6, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V
    goto/16 -0a5h
    const-class v2, Lcom/google/common/primitives/UnsignedInteger;
    if-ne v0, v2, +008h
    invoke-static v6, Lcom/google/common/primitives/UnsignedInteger;->valueOf(Ljava/lang/String;)Lcom/google/common/primitives/UnsignedInteger;
    move-result-object v1
    goto/16 -0afh
    const-class v2, Lcom/google/common/primitives/UnsignedLong;
    if-ne v0, v2, +008h
    invoke-static v6, Lcom/google/common/primitives/UnsignedLong;->valueOf(Ljava/lang/String;)Lcom/google/common/primitives/UnsignedLong;
    move-result-object v1
    goto/16 -0b9h
    const-class v2, Ljava/math/BigDecimal;
    if-ne v0, v2, +009h
    new-instance v1, Ljava/math/BigDecimal;
    invoke-direct v1, v6, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V
    goto/16 -0c4h
    invoke-virtual v0, Ljava/lang/Class;->isEnum()Z
    move-result v2
    if-eqz v2, +010h
    invoke-static v0, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    move-result-object v2
    invoke-virtual v2, v6, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v2
    invoke-virtual v2, Lcom/google/api/client/util/FieldInfo;->enumValue()Ljava/lang/Enum;
    move-result-object v1
    goto/16 -0d8h
    new-instance v2, Ljava/lang/IllegalArgumentException;
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "expected primitive class, but got: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-direct v2, v3, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v2
.end method

.method public static resolveWildcardTypeOrTypeVariable(Ljava/util/List; Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .registers 5
    instance-of v1, v4, Ljava/lang/reflect/WildcardType;
    if-eqz v1, +008h
    check-cast v4, Ljava/lang/reflect/WildcardType;
    invoke-static v4, Lcom/google/api/client/util/Types;->getBound(Ljava/lang/reflect/WildcardType;)Ljava/lang/reflect/Type;
    move-result-object v4
    instance-of v1, v4, Ljava/lang/reflect/TypeVariable;
    if-eqz v1, +01ah
    move-object v1, v4
    check-cast v1, Ljava/lang/reflect/TypeVariable;
    invoke-static v3, v1, Lcom/google/api/client/util/Types;->resolveTypeVariable(Ljava/util/List; Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type;
    move-result-object v0
    if-eqz v0, +003h
    move-object v4, v0
    instance-of v1, v4, Ljava/lang/reflect/TypeVariable;
    if-eqz v1, -010h
    check-cast v4, Ljava/lang/reflect/TypeVariable;
    invoke-interface v4, Ljava/lang/reflect/TypeVariable;->getBounds()[Ljava/lang/reflect/Type;
    move-result-object v1
    const/4 v2, 0
    aget-object v4, v1, v2
    goto -1bh
    return-object v4
.end method
