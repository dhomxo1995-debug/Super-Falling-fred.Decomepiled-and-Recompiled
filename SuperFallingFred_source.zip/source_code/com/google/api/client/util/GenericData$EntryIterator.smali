.class final Lcom/google/api/client/util/GenericData$EntryIterator;
.super Ljava/lang/Object;
.implements Ljava/util/Iterator;

.field private final fieldIterator:Ljava/util/Iterator;
.field private startedUnknown:Z
.field final synthetic this$0:Lcom/google/api/client/util/GenericData;
.field private final unknownIterator:Ljava/util/Iterator;

.method constructor <init>(Lcom/google/api/client/util/GenericData; Lcom/google/api/client/util/DataMap$EntrySet;)V
    .registers 4
    iput-object v2, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->this$0 Lcom/google/api/client/util/GenericData;
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-virtual v3, Lcom/google/api/client/util/DataMap$EntrySet;->iterator()Lcom/google/api/client/util/DataMap$EntryIterator;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->fieldIterator Ljava/util/Iterator;
    iget-object v0, v2, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->unknownIterator Ljava/util/Iterator;
    return-void
.end method

.method public hasNext()Z
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->fieldIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-nez v0, +00ah
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->unknownIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/GenericData$EntryIterator;->next()Ljava/util/Map$Entry;
    move-result-object v0
    return-object v0
.end method

.method public next()Ljava/util/Map$Entry;
    .registers 2
    iget-boolean v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->startedUnknown Z
    if-nez v0, +016h
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->fieldIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00bh
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->fieldIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    return-object v0
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->startedUnknown Z
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->unknownIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    goto -ch
.end method

.method public remove()V
    .registers 2
    iget-boolean v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->startedUnknown Z
    if-eqz v0, +007h
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->unknownIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->remove()V
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntryIterator;->fieldIterator Ljava/util/Iterator;
    invoke-interface v0, Ljava/util/Iterator;->remove()V
    return-void
.end method
