package com.google.api.client.util;
public final class DateTime implements java.io.Serializable {
    private static final java.util.TimeZone GMT = None;
    private static final long serialVersionUID = 1;
    private final boolean dateOnly;
    private final Integer tzShift;
    private final long value;

    static DateTime()
    {
        com.google.api.client.util.DateTime.GMT = java.util.TimeZone.getTimeZone("GMT");
        return;
    }

    public DateTime(long p3)
    {
        this(0, p3, 0);
        return;
    }

    public DateTime(long p2, Integer p4)
    {
        this(0, p2, p4);
        return;
    }

    public DateTime(java.util.Date p3)
    {
        this(p3.getTime());
        return;
    }

    public DateTime(java.util.Date p5, java.util.TimeZone p6)
    {
        long v0 = p5.getTime();
        this.dateOnly = 0;
        this.value = v0;
        this.tzShift = Integer.valueOf((p6.getOffset(v0) / 60000));
        return;
    }

    public DateTime(boolean p1, long p2, Integer p4)
    {
        this.dateOnly = p1;
        this.value = p2;
        this.tzShift = p4;
        return;
    }

    private static void appendInt(StringBuilder p3, int p4, int p5)
    {
        if (p4 < 0) {
            p3.append(45);
            p4 = (- p4);
        }
        int v1 = p4;
        while (v1 > 0) {
            v1 /= 10;
            p5--;
        }
        int v0 = 0;
        while (v0 < p5) {
            p3.append(48);
            v0++;
        }
        if (p4 != 0) {
            p3.append(p4);
        }
        return;
    }

    public static com.google.api.client.util.DateTime parseRfc3339(String p23)
    {
        try {
            int v11;
            java.util.GregorianCalendar v4_1 = new java.util.GregorianCalendar(com.google.api.client.util.DateTime.GMT);
            int v5 = Integer.parseInt(p23.substring(0, 4));
            int v6 = (Integer.parseInt(p23.substring(5, 7)) - 1);
            int v7 = Integer.parseInt(p23.substring(8, 10));
            int v13 = p23.length();
        } catch (StringIndexOutOfBoundsException v12) {
            throw new NumberFormatException("Invalid date/time format.");
        }
        if ((v13 > 10) && (Character.toUpperCase(p23.charAt(10)) == 84)) {
            v11 = 0;
        } else {
            v11 = 1;
        }
        int v15;
        if (v11 == 0) {
            v4_1.set(v5, v6, v7, Integer.parseInt(p23.substring(11, 13)), Integer.parseInt(p23.substring(14, 16)), Integer.parseInt(p23.substring(17, 19)));
            if (p23.charAt(19) != 46) {
                v4_1.set(14, 0);
                v15 = 19;
            } else {
                v4_1.set(14, Integer.parseInt(p23.substring(20, 23)));
                v15 = 23;
            }
        } else {
            v4_1.set(v5, v6, v7);
            v15 = 10;
        }
        Integer v17 = 0;
        long v18 = v4_1.getTimeInMillis();
        if (v13 > v15) {
            int v16;
            if (Character.toUpperCase(p23.charAt(v15)) != 90) {
                v16 = ((Integer.parseInt(p23.substring((v15 + 1), (v15 + 3))) * 60) + Integer.parseInt(p23.substring((v15 + 4), (v15 + 6))));
                if (p23.charAt(v15) == 45) {
                    v16 = (- v16);
                }
                v18 -= ((long) (60000 * v16));
            } else {
                v16 = 0;
            }
            v17 = Integer.valueOf(v16);
        }
        long v20_15 = new com.google.api.client.util.DateTime;
        v20_15(v11, v18, v17);
        return v20_15;
    }

    public boolean equals(Object p8)
    {
        int v1 = 1;
        if (p8 != this) {
            if ((p8 instanceof com.google.api.client.util.DateTime)) {
                if ((this.dateOnly != ((com.google.api.client.util.DateTime) p8).dateOnly) || (this.value != ((com.google.api.client.util.DateTime) p8).value)) {
                    v1 = 0;
                }
            } else {
                v1 = 0;
            }
        }
        return v1;
    }

    public Integer getTimeZoneShift()
    {
        return this.tzShift;
    }

    public long getValue()
    {
        return this.value;
    }

    public boolean isDateOnly()
    {
        return this.dateOnly;
    }

    public String toString()
    {
        return this.toStringRfc3339();
    }

    public String toStringRfc3339()
    {
        StringBuilder v4_1 = new StringBuilder();
        java.util.GregorianCalendar v1_1 = new java.util.GregorianCalendar(com.google.api.client.util.DateTime.GMT);
        long v2 = this.value;
        Integer v7 = this.tzShift;
        if (v7 != null) {
            v2 += (v7.longValue() * 60000);
        }
        v1_1.setTimeInMillis(v2);
        com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(1), 4);
        v4_1.append(45);
        com.google.api.client.util.DateTime.appendInt(v4_1, (v1_1.get(2) + 1), 2);
        v4_1.append(45);
        com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(5), 2);
        if (!this.dateOnly) {
            v4_1.append(84);
            com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(11), 2);
            v4_1.append(58);
            com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(12), 2);
            v4_1.append(58);
            com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(13), 2);
            if (v1_1.isSet(14)) {
                v4_1.append(46);
                com.google.api.client.util.DateTime.appendInt(v4_1, v1_1.get(14), 3);
            }
        }
        if (v7 != null) {
            if (v7.intValue() != 0) {
                int v0 = v7.intValue();
                if (v7.intValue() <= 0) {
                    v4_1.append(45);
                    v0 = (- v0);
                } else {
                    v4_1.append(43);
                }
                int v6 = (v0 % 60);
                com.google.api.client.util.DateTime.appendInt(v4_1, (v0 / 60), 2);
                v4_1.append(58);
                com.google.api.client.util.DateTime.appendInt(v4_1, v6, 2);
            } else {
                v4_1.append(90);
            }
        }
        return v4_1.toString();
    }
}
