package com.google.api.client.util;
final class ArrayMap$EntryIterator implements java.util.Iterator {
    private int nextIndex;
    private boolean removed;
    final synthetic com.google.api.client.util.ArrayMap this$0;

    ArrayMap$EntryIterator(com.google.api.client.util.ArrayMap p1)
    {
        this.this$0 = p1;
        return;
    }

    public boolean hasNext()
    {
        int v0_1;
        if (this.nextIndex >= this.this$0.size) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }

    public bridge synthetic Object next()
    {
        return this.next();
    }

    public java.util.Map$Entry next()
    {
        int v0 = this.nextIndex;
        if (v0 != this.this$0.size) {
            this.nextIndex = (this.nextIndex + 1);
            return new com.google.api.client.util.ArrayMap$Entry(this.this$0, v0);
        } else {
            throw new java.util.NoSuchElementException();
        }
    }

    public void remove()
    {
        int v0 = (this.nextIndex - 1);
        if ((!this.removed) && (v0 >= 0)) {
            this.this$0.remove(v0);
            this.removed = 1;
            return;
        } else {
            throw new IllegalArgumentException();
        }
    }
}
