package com.google.api.client.util;
public class Data {
    public static final java.math.BigDecimal NULL_BIG_DECIMAL;
    public static final java.math.BigInteger NULL_BIG_INTEGER;
    public static final Boolean NULL_BOOLEAN;
    public static final Byte NULL_BYTE;
    private static final java.util.concurrent.ConcurrentHashMap NULL_CACHE;
    public static final Character NULL_CHARACTER;
    public static final com.google.api.client.util.DateTime NULL_DATE_TIME;
    public static final Double NULL_DOUBLE;
    public static final Float NULL_FLOAT;
    public static final Integer NULL_INTEGER;
    public static final Long NULL_LONG;
    public static final Short NULL_SHORT;
    public static final String NULL_STRING;
    public static final com.google.common.primitives.UnsignedInteger NULL_UNSIGNED_INTEGER;
    public static final com.google.common.primitives.UnsignedLong NULL_UNSIGNED_LONG;

    static Data()
    {
        com.google.api.client.util.Data.NULL_BOOLEAN = new Boolean(1);
        com.google.api.client.util.Data.NULL_STRING = new String();
        com.google.api.client.util.Data.NULL_CHARACTER = new Character(0);
        com.google.api.client.util.Data.NULL_BYTE = new Byte(0);
        com.google.api.client.util.Data.NULL_SHORT = new Short(0);
        com.google.api.client.util.Data.NULL_INTEGER = new Integer(0);
        com.google.api.client.util.Data.NULL_FLOAT = new Float(0);
        com.google.api.client.util.Data.NULL_LONG = new Long(0);
        com.google.api.client.util.Data.NULL_DOUBLE = new Double(0);
        com.google.api.client.util.Data.NULL_BIG_INTEGER = new java.math.BigInteger("0");
        com.google.api.client.util.Data.NULL_UNSIGNED_INTEGER = com.google.common.primitives.UnsignedInteger.asUnsigned(0);
        com.google.api.client.util.Data.NULL_UNSIGNED_LONG = com.google.common.primitives.UnsignedLong.asUnsigned(0);
        com.google.api.client.util.Data.NULL_BIG_DECIMAL = new java.math.BigDecimal("0");
        com.google.api.client.util.Data.NULL_DATE_TIME = new com.google.api.client.util.DateTime(0);
        com.google.api.client.util.Data.NULL_CACHE = new java.util.concurrent.ConcurrentHashMap();
        com.google.api.client.util.Data.NULL_CACHE.put(Boolean, com.google.api.client.util.Data.NULL_BOOLEAN);
        com.google.api.client.util.Data.NULL_CACHE.put(String, com.google.api.client.util.Data.NULL_STRING);
        com.google.api.client.util.Data.NULL_CACHE.put(Character, com.google.api.client.util.Data.NULL_CHARACTER);
        com.google.api.client.util.Data.NULL_CACHE.put(Byte, com.google.api.client.util.Data.NULL_BYTE);
        com.google.api.client.util.Data.NULL_CACHE.put(Short, com.google.api.client.util.Data.NULL_SHORT);
        com.google.api.client.util.Data.NULL_CACHE.put(Integer, com.google.api.client.util.Data.NULL_INTEGER);
        com.google.api.client.util.Data.NULL_CACHE.put(Float, com.google.api.client.util.Data.NULL_FLOAT);
        com.google.api.client.util.Data.NULL_CACHE.put(Long, com.google.api.client.util.Data.NULL_LONG);
        com.google.api.client.util.Data.NULL_CACHE.put(Double, com.google.api.client.util.Data.NULL_DOUBLE);
        com.google.api.client.util.Data.NULL_CACHE.put(java.math.BigInteger, com.google.api.client.util.Data.NULL_BIG_INTEGER);
        com.google.api.client.util.Data.NULL_CACHE.put(com.google.common.primitives.UnsignedInteger, com.google.api.client.util.Data.NULL_UNSIGNED_INTEGER);
        com.google.api.client.util.Data.NULL_CACHE.put(com.google.common.primitives.UnsignedLong, com.google.api.client.util.Data.NULL_UNSIGNED_LONG);
        com.google.api.client.util.Data.NULL_CACHE.put(java.math.BigDecimal, com.google.api.client.util.Data.NULL_BIG_DECIMAL);
        com.google.api.client.util.Data.NULL_CACHE.put(com.google.api.client.util.DateTime, com.google.api.client.util.Data.NULL_DATE_TIME);
        return;
    }

    public Data()
    {
        return;
    }

    public static Object clone(Object p4)
    {
        if ((p4 != null) && (!com.google.api.client.util.Data.isPrimitive(p4.getClass()))) {
            if (!(p4 instanceof com.google.api.client.util.GenericData)) {
                Object v0;
                Class v1 = p4.getClass();
                if (!v1.isArray()) {
                    if (!(p4 instanceof com.google.api.client.util.ArrayMap)) {
                        v0 = com.google.api.client.util.Types.newInstance(v1);
                    } else {
                        v0 = ((com.google.api.client.util.ArrayMap) p4).clone();
                    }
                } else {
                    v0 = reflect.Array.newInstance(v1.getComponentType(), reflect.Array.getLength(p4));
                }
                com.google.api.client.util.Data.deepCopy(p4, v0);
            } else {
                v0 = ((com.google.api.client.util.GenericData) p4).clone();
            }
        } else {
            v0 = p4;
        }
        return v0;
    }

    public static void deepCopy(Object p24, Object p25)
    {
        Object v22_24;
        Class v15 = p24.getClass();
        if (com.google.api.client.util.Data.isPrimitive(v15)) {
            v22_24 = 0;
        } else {
            v22_24 = 1;
        }
        Object v22_4;
        com.google.common.base.Preconditions.checkArgument(v22_24);
        if (v15 != p25.getClass()) {
            v22_4 = 0;
        } else {
            v22_4 = 1;
        }
        com.google.common.base.Preconditions.checkArgument(v22_4);
        if (!v15.isArray()) {
            if (!java.util.Collection.isAssignableFrom(v15)) {
                boolean v13 = com.google.api.client.util.GenericData.isAssignableFrom(v15);
                if ((!v13) && (java.util.Map.isAssignableFrom(v15))) {
                    if (!com.google.api.client.util.ArrayMap.isAssignableFrom(v15)) {
                        java.util.Iterator v10_2 = ((java.util.Map) p24).entrySet().iterator();
                        while (v10_2.hasNext()) {
                            java.util.Map$Entry v17_1 = ((java.util.Map$Entry) v10_2.next());
                            ((java.util.Map) p25).put(v17_1.getKey(), com.google.api.client.util.Data.clone(v17_1.getValue()));
                        }
                    } else {
                        int v14 = ((com.google.api.client.util.ArrayMap) p24).size();
                        int v9 = 0;
                        while (v9 < v14) {
                            ((com.google.api.client.util.ArrayMap) p25).set(v9, com.google.api.client.util.Data.clone(((com.google.api.client.util.ArrayMap) p24).getValue(v9)));
                            v9++;
                        }
                    }
                } else {
                    com.google.api.client.util.ClassInfo v2;
                    if (!v13) {
                        v2 = com.google.api.client.util.ClassInfo.of(v15);
                    } else {
                        v2 = ((com.google.api.client.util.GenericData) p24).classInfo;
                    }
                    java.util.Iterator v10_3 = v2.names.iterator();
                    while (v10_3.hasNext()) {
                        com.google.api.client.util.FieldInfo v7 = v2.getFieldInfo(((String) v10_3.next()));
                        if ((!v7.isFinal()) && ((!v13) || (!v7.isPrimitive()))) {
                            Object v20_0 = v7.getValue(p24);
                            if (v20_0 != null) {
                                v7.setValue(p25, com.google.api.client.util.Data.clone(v20_0));
                            }
                        }
                    }
                }
            } else {
                if (java.util.ArrayList.isAssignableFrom(v15)) {
                    ((java.util.ArrayList) p25).ensureCapacity(((java.util.Collection) p24).size());
                }
                java.util.Iterator v10_0 = ((java.util.Collection) p24).iterator();
                while (v10_0.hasNext()) {
                    ((java.util.Collection) p25).add(com.google.api.client.util.Data.clone(v10_0.next()));
                }
            }
        } else {
            Object v22_9;
            if (reflect.Array.getLength(p24) != reflect.Array.getLength(p25)) {
                v22_9 = 0;
            } else {
                v22_9 = 1;
            }
            com.google.common.base.Preconditions.checkArgument(v22_9);
            int v11 = 0;
            java.util.Iterator v10_1 = com.google.api.client.util.Types.iterableOf(p24).iterator();
            while (v10_1.hasNext()) {
                int v12 = (v11 + 1);
                reflect.Array.set(p25, v11, com.google.api.client.util.Data.clone(v10_1.next()));
                v11 = v12;
            }
        }
        return;
    }

    public static boolean isNull(Object p2)
    {
        if ((p2 == null) || (p2 != com.google.api.client.util.Data.NULL_CACHE.get(p2.getClass()))) {
            int v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        return v0_2;
    }

    public static boolean isPrimitive(reflect.Type p3)
    {
        int v1 = 0;
        if ((p3 instanceof reflect.WildcardType)) {
            p3 = com.google.api.client.util.Types.getBound(((reflect.WildcardType) p3));
        }
        if (((p3 instanceof Class)) && ((((Class) p3).isPrimitive()) || ((((Class) p3) == Character) || ((((Class) p3) == String) || ((((Class) p3) == Integer) || ((((Class) p3) == Long) || ((((Class) p3) == Short) || ((((Class) p3) == Byte) || ((((Class) p3) == Float) || ((((Class) p3) == Double) || ((((Class) p3) == java.math.BigInteger) || ((((Class) p3) == com.google.common.primitives.UnsignedInteger) || ((((Class) p3) == com.google.common.primitives.UnsignedLong) || ((((Class) p3) == java.math.BigDecimal) || ((((Class) p3) == com.google.api.client.util.DateTime) || (((Class) p3) == Boolean)))))))))))))))) {
            v1 = 1;
        }
        return v1;
    }

    public static boolean isValueOfPrimitiveType(Object p1)
    {
        if ((p1 != null) && (!com.google.api.client.util.Data.isPrimitive(p1.getClass()))) {
            int v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        return v0_2;
    }

    public static java.util.Map mapOf(Object p2)
    {
        if ((p2 != null) && (!com.google.api.client.util.Data.isNull(p2))) {
            if (!(p2 instanceof java.util.Map)) {
                com.google.api.client.util.DataMap v0_0 = new com.google.api.client.util.DataMap(p2, 0);
            } else {
                v0_0 = ((java.util.Map) p2);
            }
        } else {
            v0_0 = java.util.Collections.emptyMap();
        }
        return v0_0;
    }

    public static java.util.Collection newCollectionInstance(reflect.Type p3)
    {
        if ((p3 instanceof reflect.WildcardType)) {
            p3 = com.google.api.client.util.Types.getBound(((reflect.WildcardType) p3));
        }
        if ((p3 instanceof reflect.ParameterizedType)) {
            p3 = ((reflect.ParameterizedType) p3).getRawType();
        }
        int v0;
        if (!(p3 instanceof Class)) {
            v0 = 0;
        } else {
            v0 = ((Class) p3);
        }
        if ((p3 != null) && ((!(p3 instanceof reflect.GenericArrayType)) && ((v0 == 0) || ((!v0.isArray()) && (!v0.isAssignableFrom(java.util.ArrayList)))))) {
            if (!v0.isAssignableFrom(java.util.HashSet)) {
                if (!v0.isAssignableFrom(java.util.TreeSet)) {
                    java.util.Collection v1_1 = ((java.util.Collection) com.google.api.client.util.Types.newInstance(v0));
                } else {
                    v1_1 = new java.util.TreeSet();
                }
            } else {
                v1_1 = new java.util.HashSet();
            }
        } else {
            v1_1 = new java.util.ArrayList();
        }
        return v1_1;
    }

    public static java.util.Map newMapInstance(Class p2)
    {
        if ((p2 != null) && (!p2.isAssignableFrom(com.google.api.client.util.ArrayMap))) {
            if (!p2.isAssignableFrom(java.util.TreeMap)) {
                java.util.Map v0_1 = ((java.util.Map) com.google.api.client.util.Types.newInstance(p2));
            } else {
                v0_1 = new java.util.TreeMap();
            }
        } else {
            v0_1 = com.google.api.client.util.ArrayMap.create();
        }
        return v0_1;
    }

    public static Object nullOf(Class p10)
    {
        Object v5;
        Object v4_1 = com.google.api.client.util.Data.NULL_CACHE.get(p10);
        try {
            if (v4_1 != null) {
                v5 = v4_1;
            } else {
                Object v4_2 = com.google.api.client.util.Data.NULL_CACHE.get(p10);
                if (v4_2 != null) {
                    v5 = v4_2;
                } else {
                    Object v4_0;
                    if (!p10.isArray()) {
                        if (!p10.isEnum()) {
                            v4_0 = com.google.api.client.util.Types.newInstance(p10);
                        } else {
                            com.google.api.client.util.FieldInfo v3 = com.google.api.client.util.ClassInfo.of(p10).getFieldInfo(0);
                            Object[] v8_2 = new Object[1];
                            v8_2[0] = p10;
                            com.google.common.base.Preconditions.checkNotNull(v3, "enum missing constant with @NullValue annotation: %s", v8_2);
                            v4_0 = v3.enumValue();
                        }
                    } else {
                        int v1 = 0;
                        Class v0 = p10;
                        do {
                            v0 = v0.getComponentType();
                            v1++;
                        } while(v0.isArray());
                        java.util.concurrent.ConcurrentHashMap v6_6 = new int[v1];
                        v4_0 = reflect.Array.newInstance(v0, v6_6);
                    }
                    com.google.api.client.util.Data.NULL_CACHE.put(p10, v4_0);
                    v5 = v4_0;
                }
            }
        } catch (java.util.concurrent.ConcurrentHashMap v6_8) {
            throw v6_8;
        }
        return v5;
    }

    public static Object parsePrimitiveValue(reflect.Type p5, String p6)
    {
        int v0;
        if (!(p5 instanceof Class)) {
            v0 = 0;
        } else {
            v0 = ((Class) p5);
        }
        if ((p5 == null) || (v0 != 0)) {
            if ((p6 != null) && ((v0 != 0) && (!v0.isAssignableFrom(String)))) {
                if ((v0 != Character) && (v0 != Character.TYPE)) {
                    if ((v0 != Boolean) && (v0 != Boolean.TYPE)) {
                        if ((v0 != Byte) && (v0 != Byte.TYPE)) {
                            if ((v0 != Short) && (v0 != Short.TYPE)) {
                                if ((v0 != Integer) && (v0 != Integer.TYPE)) {
                                    if ((v0 != Long) && (v0 != Long.TYPE)) {
                                        if ((v0 != Float) && (v0 != Float.TYPE)) {
                                            if ((v0 != Double) && (v0 != Double.TYPE)) {
                                                if (v0 != com.google.api.client.util.DateTime) {
                                                    if (v0 != java.math.BigInteger) {
                                                        if (v0 != com.google.common.primitives.UnsignedInteger) {
                                                            if (v0 != com.google.common.primitives.UnsignedLong) {
                                                                if (v0 != java.math.BigDecimal) {
                                                                    if (!v0.isEnum()) {
                                                                        throw new IllegalArgumentException(new StringBuilder().append("expected primitive class, but got: ").append(p5).toString());
                                                                    } else {
                                                                        Enum v1_0 = com.google.api.client.util.ClassInfo.of(v0).getFieldInfo(p6).enumValue();
                                                                    }
                                                                } else {
                                                                    v1_0 = new java.math.BigDecimal(p6);
                                                                }
                                                            } else {
                                                                v1_0 = com.google.common.primitives.UnsignedLong.valueOf(p6);
                                                            }
                                                        } else {
                                                            v1_0 = com.google.common.primitives.UnsignedInteger.valueOf(p6);
                                                        }
                                                    } else {
                                                        v1_0 = new java.math.BigInteger(p6);
                                                    }
                                                } else {
                                                    v1_0 = com.google.api.client.util.DateTime.parseRfc3339(p6);
                                                }
                                            } else {
                                                v1_0 = Double.valueOf(p6);
                                            }
                                        } else {
                                            v1_0 = Float.valueOf(p6);
                                        }
                                    } else {
                                        v1_0 = Long.valueOf(p6);
                                    }
                                } else {
                                    v1_0 = Integer.valueOf(p6);
                                }
                            } else {
                                v1_0 = Short.valueOf(p6);
                            }
                        } else {
                            v1_0 = Byte.valueOf(p6);
                        }
                    } else {
                        v1_0 = Boolean.valueOf(p6);
                    }
                } else {
                    if (p6.length() == 1) {
                        v1_0 = Character.valueOf(p6.charAt(0));
                    } else {
                        throw new IllegalArgumentException(new StringBuilder().append("expected type Character/char but got ").append(v0).toString());
                    }
                }
            } else {
                v1_0 = p6;
            }
            return v1_0;
        }
    }

    public static reflect.Type resolveWildcardTypeOrTypeVariable(java.util.List p3, reflect.Type p4)
    {
        if ((p4 instanceof reflect.WildcardType)) {
            p4 = com.google.api.client.util.Types.getBound(((reflect.WildcardType) p4));
        }
        while ((p4 instanceof reflect.TypeVariable)) {
            reflect.Type v0 = com.google.api.client.util.Types.resolveTypeVariable(p3, ((reflect.TypeVariable) p4));
            if (v0 != null) {
                p4 = v0;
            }
            if ((p4 instanceof reflect.TypeVariable)) {
                p4 = ((reflect.TypeVariable) p4).getBounds()[0];
            }
        }
        return p4;
    }
}
