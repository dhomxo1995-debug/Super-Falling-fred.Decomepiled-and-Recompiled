.class public Lcom/google/api/client/util/Base64;
.super Ljava/lang/Object;


.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static decodeBase64(Ljava/lang/String;)[B
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->decodeBase64(Ljava/lang/String;)[B
    move-result-object v0
    return-object v0
.end method

.method public static decodeBase64([B)[B
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->decodeBase64([B)[B
    move-result-object v0
    return-object v0
.end method

.method public static encodeBase64([B)[B
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->encodeBase64([B)[B
    move-result-object v0
    return-object v0
.end method

.method public static encodeBase64String([B)Ljava/lang/String;
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->encodeBase64String([B)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public static encodeBase64URLSafe([B)[B
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->encodeBase64URLSafe([B)[B
    move-result-object v0
    return-object v0
.end method

.method public static encodeBase64URLSafeString([B)Ljava/lang/String;
    .registers 2
    invoke-static v1, Lcom/google/api/client/repackaged/org/apache/commons/codec/binary/Base64;->encodeBase64URLSafeString([B)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
