.class public Lcom/google/api/client/util/LoggingByteArrayOutputStream;
.super Ljava/io/ByteArrayOutputStream;

.field private bytesWritten:I
.field private closed:Z
.field private final logger:Ljava/util/logging/Logger;
.field private final loggingLevel:Ljava/util/logging/Level;
.field private final maximumBytesToLog:I

.method public constructor <init>(Ljava/util/logging/Logger; Ljava/util/logging/Level; I)V
    .registers 5
    invoke-direct v1, Ljava/io/ByteArrayOutputStream;-><init>()V
    invoke-static v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/logging/Logger;
    iput-object v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->logger Ljava/util/logging/Logger;
    invoke-static v3, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/logging/Level;
    iput-object v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->loggingLevel Ljava/util/logging/Level;
    if-ltz v4, +009h
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    iput v4, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    return-void
    const/4 v0, 0
    goto -7h
.end method

.method private static appendBytes(Ljava/lang/StringBuilder; I)V
    .registers 5
    const/4 v0, 1
    if-ne v4, v0, +008h
    const-string v0, "1 byte"
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    return-void
    invoke-static Ljava/text/NumberFormat;->getInstance()Ljava/text/NumberFormat;
    move-result-object v0
    int-to-long v1, v4
    invoke-virtual v0, v1, v2, Ljava/text/NumberFormat;->format(J)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, " bytes"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -13h
.end method

.method public synchronized close()V
    .registers 7
    monitor-enter v6
    iget-boolean v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->closed Z
    if-nez v1, +054h
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    if-eqz v1, +04dh
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Total: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    invoke-static v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->appendBytes(Ljava/lang/StringBuilder; I)V
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    if-eqz v1, +017h
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    iget v2, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    if-ge v1, v2, +011h
    const-string v1, " (logging first "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    invoke-static v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->appendBytes(Ljava/lang/StringBuilder; I)V
    const-string v1, ")"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget-object v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->logger Ljava/util/logging/Logger;
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/util/logging/Logger;->config(Ljava/lang/String;)V
    iget v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    if-eqz v1, +017h
    iget-object v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->logger Ljava/util/logging/Logger;
    iget-object v2, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->loggingLevel Ljava/util/logging/Level;
    const-string v3, "UTF-8"
    invoke-virtual v6, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    const-string v4, "[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]"
    const-string v5, " "
    invoke-virtual v3, v4, v5, Ljava/lang/String;->replaceAll(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    invoke-virtual v1, v2, v3, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level; Ljava/lang/String;)V
    const/4 v1, 1
    iput-boolean v1, v6, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->closed Z
    monitor-exit v6
    return-void
    move-exception v1
    monitor-exit v6
    throw v1
.end method

.method public final synchronized getBytesWritten()I
    .registers 2
    monitor-enter v1
    iget v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    monitor-exit v1
    return v0
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public final getMaximumBytesToLog()I
    .registers 2
    iget v0, v1, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    return v0
.end method

.method public synchronized write(I)V
    .registers 4
    monitor-enter v2
    iget-boolean v0, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->closed Z
    if-nez v0, +017h
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    iget v0, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    add-int/lit8 v0, v0, 1
    iput v0, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    iget v0, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    iget v1, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    if-ge v0, v1, +005h
    invoke-super v2, v3, Ljava/io/ByteArrayOutputStream;->write(I)V
    monitor-exit v2
    return-void
    const/4 v0, 0
    goto -15h
    move-exception v0
    monitor-exit v2
    throw v0
.end method

.method public synchronized write([B I I)V
    .registers 7
    monitor-enter v3
    iget-boolean v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->closed Z
    if-nez v1, +022h
    const/4 v1, 1
    invoke-static v1, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    iget v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    add-int/2addr v1, v6
    iput v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->bytesWritten I
    iget v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    iget v2, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    if-ge v1, v2, +011h
    iget v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->count I
    add-int v0, v1, v6
    iget v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    if-le v0, v1, +006h
    iget v1, v3, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->maximumBytesToLog I
    sub-int/2addr v1, v0
    add-int/2addr v6, v1
    invoke-super v3, v4, v5, v6, Ljava/io/ByteArrayOutputStream;->write([B I I)V
    monitor-exit v3
    return-void
    const/4 v1, 0
    goto -20h
    move-exception v1
    monitor-exit v3
    throw v1
.end method
