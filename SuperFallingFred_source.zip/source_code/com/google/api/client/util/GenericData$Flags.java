package com.google.api.client.util;
public final enum class GenericData$Flags extends java.lang.Enum {
    private static final synthetic com.google.api.client.util.GenericData$Flags[] $VALUES;
    public static final enum com.google.api.client.util.GenericData$Flags IGNORE_CASE;

    static GenericData$Flags()
    {
        com.google.api.client.util.GenericData$Flags.IGNORE_CASE = new com.google.api.client.util.GenericData$Flags("IGNORE_CASE", 0);
        com.google.api.client.util.GenericData$Flags[] v0_3 = new com.google.api.client.util.GenericData$Flags[1];
        v0_3[0] = com.google.api.client.util.GenericData$Flags.IGNORE_CASE;
        com.google.api.client.util.GenericData$Flags.$VALUES = v0_3;
        return;
    }

    private GenericData$Flags(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static com.google.api.client.util.GenericData$Flags valueOf(String p1)
    {
        return ((com.google.api.client.util.GenericData$Flags) Enum.valueOf(com.google.api.client.util.GenericData$Flags, p1));
    }

    public static com.google.api.client.util.GenericData$Flags[] values()
    {
        return ((com.google.api.client.util.GenericData$Flags[]) com.google.api.client.util.GenericData$Flags.$VALUES.clone());
    }
}
