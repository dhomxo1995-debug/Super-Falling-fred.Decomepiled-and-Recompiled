package com.google.api.client.util;
public interface ObjectParser {

    public abstract Object parseAndClose(java.io.InputStream p0, java.nio.charset.Charset p1, Class p2);

    public abstract Object parseAndClose(java.io.InputStream p0, java.nio.charset.Charset p1, reflect.Type p2);

    public abstract Object parseAndClose(java.io.Reader p0, Class p1);

    public abstract Object parseAndClose(java.io.Reader p0, reflect.Type p1);
}
