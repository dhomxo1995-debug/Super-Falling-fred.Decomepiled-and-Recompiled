.class public interface abstract Lcom/google/api/client/util/NullValue;
.super Ljava/lang/Object;
.implements Ljava/lang/annotation/Annotation;
