.class public final Lcom/google/api/client/util/ArrayValueMap;
.super Ljava/lang/Object;

.field private final destination:Ljava/lang/Object;
.field private final fieldMap:Ljava/util/Map;
.field private final keyMap:Ljava/util/Map;

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    invoke-static Lcom/google/api/client/util/ArrayMap;->create()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/ArrayValueMap;->keyMap Ljava/util/Map;
    invoke-static Lcom/google/api/client/util/ArrayMap;->create()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/ArrayValueMap;->fieldMap Ljava/util/Map;
    iput-object v2, v1, Lcom/google/api/client/util/ArrayValueMap;->destination Ljava/lang/Object;
    return-void
.end method

.method public put(Ljava/lang/String; Ljava/lang/Class; Ljava/lang/Object;)V
    .registers 6
    iget-object v1, v2, Lcom/google/api/client/util/ArrayValueMap;->keyMap Ljava/util/Map;
    invoke-interface v1, v3, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    if-nez v0, +00ch
    new-instance v0, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    invoke-direct v0, v4, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;-><init>(Ljava/lang/Class;)V
    iget-object v1, v2, Lcom/google/api/client/util/ArrayValueMap;->keyMap Ljava/util/Map;
    invoke-interface v1, v3, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v0, v4, v5, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->addValue(Ljava/lang/Class; Ljava/lang/Object;)V
    return-void
.end method

.method public put(Ljava/lang/reflect/Field; Ljava/lang/Class; Ljava/lang/Object;)V
    .registers 6
    iget-object v1, v2, Lcom/google/api/client/util/ArrayValueMap;->fieldMap Ljava/util/Map;
    invoke-interface v1, v3, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    if-nez v0, +00ch
    new-instance v0, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    invoke-direct v0, v4, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;-><init>(Ljava/lang/Class;)V
    iget-object v1, v2, Lcom/google/api/client/util/ArrayValueMap;->fieldMap Ljava/util/Map;
    invoke-interface v1, v3, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v0, v4, v5, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->addValue(Ljava/lang/Class; Ljava/lang/Object;)V
    return-void
.end method

.method public setValues()V
    .registers 8
    iget-object v4, v7, Lcom/google/api/client/util/ArrayValueMap;->keyMap Ljava/util/Map;
    invoke-interface v4, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v4
    invoke-interface v4, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v4
    if-eqz v4, +01eh
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/util/Map$Entry;
    iget-object v0, v7, Lcom/google/api/client/util/ArrayValueMap;->destination Ljava/lang/Object;
    check-cast v0, Ljava/util/Map;
    invoke-interface v1, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v5
    invoke-interface v1, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    invoke-virtual v4, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->toArray()Ljava/lang/Object;
    move-result-object v4
    invoke-interface v0, v5, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -21h
    iget-object v4, v7, Lcom/google/api/client/util/ArrayValueMap;->fieldMap Ljava/util/Map;
    invoke-interface v4, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v4
    invoke-interface v4, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v3
    invoke-interface v3, Ljava/util/Iterator;->hasNext()Z
    move-result v4
    if-eqz v4, +01eh
    invoke-interface v3, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Ljava/util/Map$Entry;
    invoke-interface v2, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Ljava/lang/reflect/Field;
    iget-object v6, v7, Lcom/google/api/client/util/ArrayValueMap;->destination Ljava/lang/Object;
    invoke-interface v2, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v5
    check-cast v5, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
    invoke-virtual v5, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->toArray()Ljava/lang/Object;
    move-result-object v5
    invoke-static v4, v6, v5, Lcom/google/api/client/util/FieldInfo;->setFieldValue(Ljava/lang/reflect/Field; Ljava/lang/Object; Ljava/lang/Object;)V
    goto -21h
    return-void
.end method
