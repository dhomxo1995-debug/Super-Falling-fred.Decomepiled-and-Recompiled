.class public Lcom/google/api/client/util/GenericData;
.super Ljava/util/AbstractMap;
.implements Ljava/lang/Cloneable;

.field final classInfo:Lcom/google/api/client/util/ClassInfo;
.field  unknownFields:Ljava/util/Map;

.method public constructor <init>()V
    .registers 2
    const-class v0, Lcom/google/api/client/util/GenericData$Flags;
    invoke-static v0, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;
    move-result-object v0
    invoke-direct v1, v0, Lcom/google/api/client/util/GenericData;-><init>(Ljava/util/EnumSet;)V
    return-void
.end method

.method public constructor <init>(Ljava/util/EnumSet;)V
    .registers 4
    invoke-direct v2, Ljava/util/AbstractMap;-><init>()V
    invoke-static Lcom/google/api/client/util/ArrayMap;->create()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    iput-object v0, v2, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-virtual v2, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    sget-object v1, Lcom/google/api/client/util/GenericData$Flags;->IGNORE_CASE Lcom/google/api/client/util/GenericData$Flags;
    invoke-virtual v3, v1, Ljava/util/EnumSet;->contains(Ljava/lang/Object;)Z
    move-result v1
    invoke-static v0, v1, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class; Z)Lcom/google/api/client/util/ClassInfo;
    move-result-object v0
    iput-object v0, v2, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    return-void
.end method

.method public clone()Lcom/google/api/client/util/GenericData;
    .registers 4
    invoke-super v3, Ljava/util/AbstractMap;->clone()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Lcom/google/api/client/util/GenericData;
    invoke-static v3, v1, Lcom/google/api/client/util/Data;->deepCopy(Ljava/lang/Object; Ljava/lang/Object;)V
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-static v2, Lcom/google/api/client/util/Data;->clone(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Ljava/util/Map;
    iput-object v2, v1, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    return-object v1
    move-exception v0
    new-instance v2, Ljava/lang/IllegalStateException;
    invoke-direct v2, v0, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V
    throw v2
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/GenericData;->clone()Lcom/google/api/client/util/GenericData;
    move-result-object v0
    return-object v0
.end method

.method public entrySet()Ljava/util/Set;
    .registers 2
    new-instance v0, Lcom/google/api/client/util/GenericData$EntrySet;
    invoke-direct v0, v1, Lcom/google/api/client/util/GenericData$EntrySet;-><init>(Lcom/google/api/client/util/GenericData;)V
    return-object v0
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    instance-of v2, v4, Ljava/lang/String;
    if-nez v2, +004h
    const/4 v2, 0
    return-object v2
    move-object v1, v4
    check-cast v1, Ljava/lang/String;
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v1, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-eqz v0, +007h
    invoke-virtual v0, v3, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    goto -10h
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v2
    if-eqz v2, +006h
    invoke-virtual v1, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v2, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    goto -23h
.end method

.method public final getClassInfo()Lcom/google/api/client/util/ClassInfo;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    return-object v0
.end method

.method public final getUnknownKeys()Ljava/util/Map;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    return-object v0
.end method

.method public bridge synthetic put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    check-cast v2, Ljava/lang/String;
    invoke-virtual v1, v2, v3, Lcom/google/api/client/util/GenericData;->put(Ljava/lang/String; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final put(Ljava/lang/String; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v4, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-eqz v0, +00ah
    invoke-virtual v0, v3, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    invoke-virtual v0, v3, v5, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    return-object v1
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v2
    if-eqz v2, +006h
    invoke-virtual v4, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v4
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v2, v4, v5, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    goto -13h
.end method

.method public final putAll(Ljava/util/Map;)V
    .registers 6
    invoke-interface v5, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v2
    invoke-interface v2, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v2
    if-eqz v2, +016h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Ljava/lang/String;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v3
    invoke-virtual v4, v2, v3, Lcom/google/api/client/util/GenericData;->set(Ljava/lang/String; Ljava/lang/Object;)V
    goto -19h
    return-void
.end method

.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    instance-of v2, v4, Ljava/lang/String;
    if-nez v2, +004h
    const/4 v2, 0
    return-object v2
    move-object v1, v4
    check-cast v1, Ljava/lang/String;
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v1, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-eqz v0, +008h
    new-instance v2, Ljava/lang/UnsupportedOperationException;
    invoke-direct v2, Ljava/lang/UnsupportedOperationException;-><init>()V
    throw v2
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v2
    if-eqz v2, +006h
    invoke-virtual v1, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v1
    iget-object v2, v3, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v2, v1, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    goto -24h
.end method

.method public final set(Ljava/lang/String; Ljava/lang/Object;)V
    .registers 5
    iget-object v1, v2, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v1, v3, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-eqz v0, +006h
    invoke-virtual v0, v2, v4, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    return-void
    iget-object v1, v2, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v1, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v1
    if-eqz v1, +006h
    invoke-virtual v3, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v3
    iget-object v1, v2, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v1, v3, v4, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    goto -12h
.end method

.method public final setUnknownKeys(Ljava/util/Map;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    return-void
.end method
