package com.google.api.client.util;
public class FieldInfo {
    private static final java.util.Map CACHE;
    private final reflect.Field field;
    private final boolean isPrimitive;
    private final String name;

    static FieldInfo()
    {
        com.google.api.client.util.FieldInfo.CACHE = new java.util.WeakHashMap();
        return;
    }

    FieldInfo(reflect.Field p2, String p3)
    {
        boolean v0_1;
        this.field = p2;
        if (p3 != null) {
            v0_1 = p3.intern();
        } else {
            v0_1 = 0;
        }
        this.name = v0_1;
        this.isPrimitive = com.google.api.client.util.Data.isPrimitive(this.getType());
        return;
    }

    public static Object getFieldValue(reflect.Field p2, Object p3)
    {
        try {
            return p2.get(p3);
        } catch (IllegalAccessException v0) {
            throw new IllegalArgumentException(v0);
        }
    }

    public static com.google.api.client.util.FieldInfo of(Enum p6)
    {
        String v2_0 = 1;
        try {
            com.google.api.client.util.FieldInfo v1 = com.google.api.client.util.FieldInfo.of(p6.getClass().getField(p6.name()));
        } catch (NoSuchFieldException v0) {
            throw new RuntimeException(v0);
        }
        if (v1 == null) {
            v2_0 = 0;
        }
        Object[] v4_1 = new Object[1];
        v4_1[0] = p6;
        com.google.common.base.Preconditions.checkArgument(v2_0, "enum constant missing @Value or @NullValue annotation: %s", v4_1);
        return v1;
    }

    public static com.google.api.client.util.FieldInfo of(reflect.Field p9)
    {
        com.google.api.client.util.FieldInfo v0_0;
        if (p9 != null) {
            try {
                v0_0 = ((com.google.api.client.util.FieldInfo) com.google.api.client.util.FieldInfo.CACHE.get(p9));
                boolean v2 = p9.isEnumConstant();
            } catch (java.util.Map v6_5) {
                throw v6_5;
            }
            if ((v0_0 == null) && ((v2) || (!reflect.Modifier.isStatic(p9.getModifiers())))) {
                String v1;
                if (!v2) {
                    com.google.api.client.util.Key v3_1 = ((com.google.api.client.util.Key) p9.getAnnotation(com.google.api.client.util.Key));
                    if (v3_1 != null) {
                        v1 = v3_1.value();
                        p9.setAccessible(1);
                    } else {
                        v0_0 = 0;
                        return v0_0;
                    }
                } else {
                    com.google.api.client.util.Value v5_1 = ((com.google.api.client.util.Value) p9.getAnnotation(com.google.api.client.util.Value));
                    if (v5_1 == null) {
                        if (((com.google.api.client.util.NullValue) p9.getAnnotation(com.google.api.client.util.NullValue)) == null) {
                            v0_0 = 0;
                            return v0_0;
                        } else {
                            v1 = 0;
                        }
                    } else {
                        v1 = v5_1.value();
                    }
                }
                if ("##default".equals(v1)) {
                    v1 = p9.getName();
                }
                v0_0 = new com.google.api.client.util.FieldInfo(p9, v1);
                com.google.api.client.util.FieldInfo.CACHE.put(p9, v0_0);
            }
        } else {
            v0_0 = 0;
        }
        return v0_0;
    }

    public static void setFieldValue(reflect.Field p5, Object p6, Object p7)
    {
        if (!reflect.Modifier.isFinal(p5.getModifiers())) {
            try {
                p5.set(p6, p7);
            } catch (IllegalAccessException v0_0) {
                throw new IllegalArgumentException(v0_0);
            } catch (IllegalAccessException v0_1) {
                throw new IllegalArgumentException(v0_1);
            }
        } else {
            Object v1 = com.google.api.client.util.FieldInfo.getFieldValue(p5, p6);
            if (p7 != null) {
                if (p7.equals(v1)) {
                    return;
                }
            } else {
                if (v1 == null) {
                    return;
                }
            }
            throw new IllegalArgumentException(new StringBuilder().append("expected final value <").append(v1).append("> but was <").append(p7).append("> on ").append(p5.getName()).append(" field in ").append(p6.getClass().getName()).toString());
        }
        return;
    }

    public Enum enumValue()
    {
        return Enum.valueOf(this.field.getDeclaringClass(), this.field.getName());
    }

    public com.google.api.client.util.ClassInfo getClassInfo()
    {
        return com.google.api.client.util.ClassInfo.of(this.field.getDeclaringClass());
    }

    public reflect.Field getField()
    {
        return this.field;
    }

    public reflect.Type getGenericType()
    {
        return this.field.getGenericType();
    }

    public String getName()
    {
        return this.name;
    }

    public Class getType()
    {
        return this.field.getType();
    }

    public Object getValue(Object p2)
    {
        return com.google.api.client.util.FieldInfo.getFieldValue(this.field, p2);
    }

    public boolean isFinal()
    {
        return reflect.Modifier.isFinal(this.field.getModifiers());
    }

    public boolean isPrimitive()
    {
        return this.isPrimitive;
    }

    public void setValue(Object p2, Object p3)
    {
        com.google.api.client.util.FieldInfo.setFieldValue(this.field, p2, p3);
        return;
    }
}
