.class public Lcom/google/api/client/util/LoggingOutputStream;
.super Ljava/io/FilterOutputStream;

.field private final logStream:Lcom/google/api/client/util/LoggingByteArrayOutputStream;

.method public constructor <init>(Ljava/io/OutputStream; Ljava/util/logging/Logger; Ljava/util/logging/Level; I)V
    .registers 6
    invoke-direct v1, v2, Ljava/io/FilterOutputStream;-><init>(Ljava/io/OutputStream;)V
    new-instance v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-direct v0, v3, v4, v5, Lcom/google/api/client/util/LoggingByteArrayOutputStream;-><init>(Ljava/util/logging/Logger; Ljava/util/logging/Level; I)V
    iput-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    return-void
.end method

.method public close()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v0, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->close()V
    invoke-super v1, Ljava/io/FilterOutputStream;->close()V
    return-void
.end method

.method public final getLogStream()Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    return-object v0
.end method

.method public write(I)V
    .registers 3
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->out Ljava/io/OutputStream;
    invoke-virtual v0, v2, Ljava/io/OutputStream;->write(I)V
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v0, v2, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->write(I)V
    return-void
.end method

.method public write([B I I)V
    .registers 5
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->out Ljava/io/OutputStream;
    invoke-virtual v0, v2, v3, v4, Ljava/io/OutputStream;->write([B I I)V
    iget-object v0, v1, Lcom/google/api/client/util/LoggingOutputStream;->logStream Lcom/google/api/client/util/LoggingByteArrayOutputStream;
    invoke-virtual v0, v2, v3, v4, Lcom/google/api/client/util/LoggingByteArrayOutputStream;->write([B I I)V
    return-void
.end method
