.class final Lcom/google/api/client/util/DataMap;
.super Ljava/util/AbstractMap;

.field final classInfo:Lcom/google/api/client/util/ClassInfo;
.field final object:Ljava/lang/Object;

.method constructor <init>(Ljava/lang/Object; Z)V
    .registers 4
    invoke-direct v1, Ljava/util/AbstractMap;-><init>()V
    iput-object v2, v1, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v2, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, v3, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class; Z)Lcom/google/api/client/util/ClassInfo;
    move-result-object v0
    iput-object v0, v1, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v0, v1, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v0, Lcom/google/api/client/util/ClassInfo;->isEnum()Z
    move-result v0
    if-nez v0, +007h
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    return-void
    const/4 v0, 0
    goto -5h
.end method

.method public containsKey(Ljava/lang/Object;)Z
    .registers 3
    invoke-virtual v1, v2, Lcom/google/api/client/util/DataMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public entrySet()Lcom/google/api/client/util/DataMap$EntrySet;
    .registers 2
    new-instance v0, Lcom/google/api/client/util/DataMap$EntrySet;
    invoke-direct v0, v1, Lcom/google/api/client/util/DataMap$EntrySet;-><init>(Lcom/google/api/client/util/DataMap;)V
    return-object v0
.end method

.method public bridge synthetic entrySet()Ljava/util/Set;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/DataMap;->entrySet()Lcom/google/api/client/util/DataMap$EntrySet;
    move-result-object v0
    return-object v0
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    const/4 v1, 0
    instance-of v2, v4, Ljava/lang/String;
    if-nez v2, +003h
    return-object v1
    iget-object v2, v3, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    check-cast v4, Ljava/lang/String;
    invoke-virtual v2, v4, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-eqz v0, -009h
    iget-object v1, v3, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v0, v1, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    goto -11h
.end method

.method public bridge synthetic put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    check-cast v2, Ljava/lang/String;
    invoke-virtual v1, v2, v3, Lcom/google/api/client/util/DataMap;->put(Ljava/lang/String; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public put(Ljava/lang/String; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    iget-object v2, v4, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v5, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "no field of key "
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v0, v2, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    iget-object v2, v4, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v0, v2, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    iget-object v2, v4, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-static v6, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v3
    invoke-virtual v0, v2, v3, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    return-object v1
.end method
