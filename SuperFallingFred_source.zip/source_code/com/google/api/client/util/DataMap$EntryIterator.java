package com.google.api.client.util;
final class DataMap$EntryIterator implements java.util.Iterator {
    private com.google.api.client.util.FieldInfo currentFieldInfo;
    private boolean isComputed;
    private boolean isRemoved;
    private com.google.api.client.util.FieldInfo nextFieldInfo;
    private Object nextFieldValue;
    private int nextKeyIndex;
    final synthetic com.google.api.client.util.DataMap this$0;

    DataMap$EntryIterator(com.google.api.client.util.DataMap p2)
    {
        this.this$0 = p2;
        this.nextKeyIndex = -1;
        return;
    }

    public boolean hasNext()
    {
        if (!this.isComputed) {
            this.isComputed = 1;
            this.nextFieldValue = 0;
            while (this.nextFieldValue == null) {
                Object v0_15 = (this.nextKeyIndex + 1);
                this.nextKeyIndex = v0_15;
                if (v0_15 >= this.this$0.classInfo.names.size()) {
                    break;
                }
                this.nextFieldInfo = this.this$0.classInfo.getFieldInfo(((String) this.this$0.classInfo.names.get(this.nextKeyIndex)));
                this.nextFieldValue = this.nextFieldInfo.getValue(this.this$0.object);
            }
        }
        Object v0_2;
        if (this.nextFieldValue == null) {
            v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        return v0_2;
    }

    public bridge synthetic Object next()
    {
        return this.next();
    }

    public java.util.Map$Entry next()
    {
        if (this.hasNext()) {
            this.currentFieldInfo = this.nextFieldInfo;
            Object v0 = this.nextFieldValue;
            this.isComputed = 0;
            this.isRemoved = 0;
            this.nextFieldInfo = 0;
            this.nextFieldValue = 0;
            return new com.google.api.client.util.DataMap$Entry(this.this$0, this.currentFieldInfo, v0);
        } else {
            throw new java.util.NoSuchElementException();
        }
    }

    public void remove()
    {
        if ((this.currentFieldInfo == null) || (this.isRemoved)) {
            com.google.api.client.util.FieldInfo v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        com.google.common.base.Preconditions.checkState(v0_2);
        this.isRemoved = 1;
        this.currentFieldInfo.setValue(this.this$0.object, 0);
        return;
    }
}
