.class 0x0 Lcom/google/api/client/util/ArrayValueMap$ArrayValue;
.super Ljava/lang/Object;

.field final componentType:Ljava/lang/Class;
.field final values:Ljava/util/ArrayList;

.method constructor <init>(Ljava/lang/Class;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    iput-object v0, v1, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->values Ljava/util/ArrayList;
    iput-object v2, v1, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->componentType Ljava/lang/Class;
    return-void
.end method

.method  addValue(Ljava/lang/Class; Ljava/lang/Object;)V
    .registers 4
    iget-object v0, v1, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->componentType Ljava/lang/Class;
    if-ne v2, v0, +00ch
    const/4 v0, 1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkArgument(Z)V
    iget-object v0, v1, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->values Ljava/util/ArrayList;
    invoke-virtual v0, v3, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    return-void
    const/4 v0, 0
    goto -ah
.end method

.method  toArray()Ljava/lang/Object;
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->values Ljava/util/ArrayList;
    iget-object v1, v2, Lcom/google/api/client/util/ArrayValueMap$ArrayValue;->componentType Ljava/lang/Class;
    invoke-static v0, v1, Lcom/google/api/client/util/Types;->toArray(Ljava/util/Collection; Ljava/lang/Class;)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method
