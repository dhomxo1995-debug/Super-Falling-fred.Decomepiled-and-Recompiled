package com.google.api.client.util;
public class Base64 {

    private Base64()
    {
        return;
    }

    public static byte[] decodeBase64(String p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.decodeBase64(p1);
    }

    public static byte[] decodeBase64(byte[] p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.decodeBase64(p1);
    }

    public static byte[] encodeBase64(byte[] p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.encodeBase64(p1);
    }

    public static String encodeBase64String(byte[] p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.encodeBase64String(p1);
    }

    public static byte[] encodeBase64URLSafe(byte[] p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(p1);
    }

    public static String encodeBase64URLSafeString(byte[] p1)
    {
        return com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(p1);
    }
}
