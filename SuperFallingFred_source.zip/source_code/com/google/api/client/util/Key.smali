.class public interface abstract Lcom/google/api/client/util/Key;
.super Ljava/lang/Object;
.implements Ljava/lang/annotation/Annotation;


.method public abstract value()Ljava/lang/String;
    # abstract or native method
.end method
