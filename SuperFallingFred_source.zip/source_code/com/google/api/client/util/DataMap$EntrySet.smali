.class final Lcom/google/api/client/util/DataMap$EntrySet;
.super Ljava/util/AbstractSet;

.field final synthetic this$0:Lcom/google/api/client/util/DataMap;

.method constructor <init>(Lcom/google/api/client/util/DataMap;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    invoke-direct v0, Ljava/util/AbstractSet;-><init>()V
    return-void
.end method

.method public clear()V
    .registers 6
    iget-object v2, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v2, v2, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    invoke-interface v2, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v0
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v2
    if-eqz v2, +019h
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    iget-object v2, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v1, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v2
    iget-object v3, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v3, v3, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    const/4 v4, 0
    invoke-virtual v2, v3, v4, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    goto -1ch
    return-void
.end method

.method public isEmpty()Z
    .registers 5
    iget-object v2, v4, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v2, v2, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    invoke-interface v2, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v0
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v2
    if-eqz v2, +01ch
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    iget-object v2, v4, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v2, v1, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v2
    iget-object v3, v4, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v3, v3, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v2, v3, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v2
    if-eqz v2, -01ch
    const/4 v2, 0
    return v2
    const/4 v2, 1
    goto -2h
.end method

.method public iterator()Lcom/google/api/client/util/DataMap$EntryIterator;
    .registers 3
    new-instance v0, Lcom/google/api/client/util/DataMap$EntryIterator;
    iget-object v1, v2, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    invoke-direct v0, v1, Lcom/google/api/client/util/DataMap$EntryIterator;-><init>(Lcom/google/api/client/util/DataMap;)V
    return-object v0
.end method

.method public bridge synthetic iterator()Ljava/util/Iterator;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/DataMap$EntrySet;->iterator()Lcom/google/api/client/util/DataMap$EntryIterator;
    move-result-object v0
    return-object v0
.end method

.method public size()I
    .registers 6
    const/4 v2, 0
    iget-object v3, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v3, v3, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v3, v3, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    invoke-interface v3, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v0
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v3
    if-eqz v3, +01dh
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    iget-object v3, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v3, v3, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v3, v1, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v3
    iget-object v4, v5, Lcom/google/api/client/util/DataMap$EntrySet;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v4, v4, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v3, v4, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v3
    if-eqz v3, -01ch
    add-int/lit8 v2, v2, 1
    goto -20h
    return v2
.end method
