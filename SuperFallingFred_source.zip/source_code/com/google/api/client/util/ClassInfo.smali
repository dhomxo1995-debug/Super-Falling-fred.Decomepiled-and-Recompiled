.class public final Lcom/google/api/client/util/ClassInfo;
.super Ljava/lang/Object;

.field private static final CACHE:Ljava/util/Map;
.field private static final CACHE_IGNORE_CASE:Ljava/util/Map;
.field private final clazz:Ljava/lang/Class;
.field private final ignoreCase:Z
.field private final nameToFieldInfoMap:Ljava/util/IdentityHashMap;
.field final names:Ljava/util/List;

.method static constructor <clinit>()V
    .registers 1
    new-instance v0, Ljava/util/WeakHashMap;
    invoke-direct v0, Ljava/util/WeakHashMap;-><init>()V
    sput-object v0, Lcom/google/api/client/util/ClassInfo;->CACHE Ljava/util/Map;
    new-instance v0, Ljava/util/WeakHashMap;
    invoke-direct v0, Ljava/util/WeakHashMap;-><init>()V
    sput-object v0, Lcom/google/api/client/util/ClassInfo;->CACHE_IGNORE_CASE Ljava/util/Map;
    return-void
.end method

.method private constructor <init>(Ljava/lang/Class; Z)V
    .registers 20
    invoke-direct/range v17, Ljava/lang/Object;-><init>()V
    new-instance v12, Ljava/util/IdentityHashMap;
    invoke-direct v12, Ljava/util/IdentityHashMap;-><init>()V
    move-object/from16 v0, v17
    iput-object v12, v0, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    move-object/from16 v0, v18
    move-object/from16 v1, v17
    iput-object v0, v1, Lcom/google/api/client/util/ClassInfo;->clazz Ljava/lang/Class;
    move/from16 v0, v19
    move-object/from16 v1, v17
    iput-boolean v0, v1, Lcom/google/api/client/util/ClassInfo;->ignoreCase Z
    if-eqz v19, +008h
    invoke-virtual/range v18, Ljava/lang/Class;->isEnum()Z
    move-result v12
    if-nez v12, +054h
    const/4 v12, 1
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    const-string v14, "cannot ignore case on an enum: "
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    move-object/from16 v0, v18
    invoke-virtual v13, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-static v12, v13, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/Object;)V
    new-instance v9, Ljava/util/TreeSet;
    new-instance v12, Lcom/google/api/client/util/ClassInfo$1;
    move-object/from16 v0, v17
    invoke-direct v12, v0, Lcom/google/api/client/util/ClassInfo$1;-><init>(Lcom/google/api/client/util/ClassInfo;)V
    invoke-direct v9, v12, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V
    invoke-virtual/range v18, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    move-result-object v10
    if-eqz v10, +016h
    move/from16 v0, v19
    invoke-static v10, v0, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class; Z)Lcom/google/api/client/util/ClassInfo;
    move-result-object v11
    move-object/from16 v0, v17
    iget-object v12, v0, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    iget-object v13, v11, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    invoke-virtual v12, v13, Ljava/util/IdentityHashMap;->putAll(Ljava/util/Map;)V
    iget-object v12, v11, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    invoke-virtual v9, v12, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z
    invoke-virtual/range v18, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;
    move-result-object v2
    array-length v8, v2
    const/4 v7, 0
    if-ge v7, v8, +05ch
    aget-object v4, v2, v7
    invoke-static v4, Lcom/google/api/client/util/FieldInfo;->of(Ljava/lang/reflect/Field;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v5
    if-nez v5, +007h
    add-int/lit8 v7, v7, 1
    goto -ch
    const/4 v12, 0
    goto -52h
    invoke-virtual v5, Lcom/google/api/client/util/FieldInfo;->getName()Ljava/lang/String;
    move-result-object v6
    if-eqz v19, +00ah
    invoke-virtual v6, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v12
    invoke-virtual v12, Ljava/lang/String;->intern()Ljava/lang/String;
    move-result-object v6
    move-object/from16 v0, v17
    iget-object v12, v0, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    invoke-virtual v12, v6, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v3
    check-cast v3, Lcom/google/api/client/util/FieldInfo;
    if-nez v3, +02bh
    const/4 v12, 1
    const-string v14, "two fields have the same %sname <%s>: %s and %s"
    const/4 v13, 4
    new-array v15, v13, [Ljava/lang/Object;
    const/16 v16, 0
    if-eqz v19, +023h
    const-string v13, "case-insensitive "
    aput-object v13, v15, v16
    const/4 v13, 1
    aput-object v6, v15, v13
    const/4 v13, 2
    aput-object v4, v15, v13
    const/16 v16, 3
    if-nez v3, +018h
    const/4 v13, 0
    aput-object v13, v15, v16
    invoke-static v12, v14, v15, Lcom/google/common/base/Preconditions;->checkArgument(Z Ljava/lang/String; [Ljava/lang/Object;)V
    move-object/from16 v0, v17
    iget-object v12, v0, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    invoke-virtual v12, v6, v5, Ljava/util/IdentityHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v9, v6, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z
    goto -47h
    const/4 v12, 0
    goto -29h
    const-string v13, ""
    goto -21h
    invoke-virtual v3, Lcom/google/api/client/util/FieldInfo;->getField()Ljava/lang/reflect/Field;
    move-result-object v13
    goto -19h
    invoke-virtual v9, Ljava/util/TreeSet;->isEmpty()Z
    move-result v12
    if-eqz v12, +00bh
    invoke-static Ljava/util/Collections;->emptyList()Ljava/util/List;
    move-result-object v12
    move-object/from16 v0, v17
    iput-object v12, v0, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    return-void
    new-instance v12, Ljava/util/ArrayList;
    invoke-direct v12, v9, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    invoke-static v12, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    move-result-object v12
    goto -eh
.end method

.method public static of(Ljava/lang/Class;)Lcom/google/api/client/util/ClassInfo;
    .registers 2
    const/4 v0, 0
    invoke-static v1, v0, Lcom/google/api/client/util/ClassInfo;->of(Ljava/lang/Class; Z)Lcom/google/api/client/util/ClassInfo;
    move-result-object v0
    return-object v0
.end method

.method public static of(Ljava/lang/Class; Z)Lcom/google/api/client/util/ClassInfo;
    .registers 5
    if-nez v3, +004h
    const/4 v1, 0
    return-object v1
    if-eqz v4, +01ah
    sget-object v0, Lcom/google/api/client/util/ClassInfo;->CACHE_IGNORE_CASE Ljava/util/Map;
    monitor-enter v0
    invoke-interface v0, v3, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Lcom/google/api/client/util/ClassInfo;
    if-nez v1, +00ah
    new-instance v1, Lcom/google/api/client/util/ClassInfo;
    invoke-direct v1, v3, v4, Lcom/google/api/client/util/ClassInfo;-><init>(Ljava/lang/Class; Z)V
    invoke-interface v0, v3, v1, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    monitor-exit v0
    goto -17h
    move-exception v2
    monitor-exit v0
    throw v2
    sget-object v0, Lcom/google/api/client/util/ClassInfo;->CACHE Ljava/util/Map;
    goto -18h
.end method

.method public getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 4
    invoke-virtual v2, v3, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    if-nez v0, +004h
    const/4 v1, 0
    return-object v1
    invoke-virtual v0, Lcom/google/api/client/util/FieldInfo;->getField()Ljava/lang/reflect/Field;
    move-result-object v1
    goto -5h
.end method

.method public getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    .registers 3
    if-eqz v2, +00eh
    iget-boolean v0, v1, Lcom/google/api/client/util/ClassInfo;->ignoreCase Z
    if-eqz v0, +006h
    invoke-virtual v2, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/String;->intern()Ljava/lang/String;
    move-result-object v2
    iget-object v0, v1, Lcom/google/api/client/util/ClassInfo;->nameToFieldInfoMap Ljava/util/IdentityHashMap;
    invoke-virtual v0, v2, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/google/api/client/util/FieldInfo;
    return-object v0
.end method

.method public final getIgnoreCase()Z
    .registers 2
    iget-boolean v0, v1, Lcom/google/api/client/util/ClassInfo;->ignoreCase Z
    return v0
.end method

.method public getNames()Ljava/util/Collection;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    return-object v0
.end method

.method public getUnderlyingClass()Ljava/lang/Class;
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/ClassInfo;->clazz Ljava/lang/Class;
    return-object v0
.end method

.method public isEnum()Z
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/ClassInfo;->clazz Ljava/lang/Class;
    invoke-virtual v0, Ljava/lang/Class;->isEnum()Z
    move-result v0
    return v0
.end method
