package com.google.api.client.util;
final class ArrayMap$Entry implements java.util.Map$Entry {
    private int index;
    final synthetic com.google.api.client.util.ArrayMap this$0;

    ArrayMap$Entry(com.google.api.client.util.ArrayMap p1, int p2)
    {
        this.this$0 = p1;
        this.index = p2;
        return;
    }

    public boolean equals(Object p6)
    {
        int v1 = 1;
        if (this != p6) {
            if ((p6 instanceof java.util.Map$Entry)) {
                if ((!com.google.common.base.Objects.equal(this.getKey(), ((java.util.Map$Entry) p6).getKey())) || (!com.google.common.base.Objects.equal(this.getValue(), ((java.util.Map$Entry) p6).getValue()))) {
                    v1 = 0;
                }
            } else {
                v1 = 0;
            }
        }
        return v1;
    }

    public Object getKey()
    {
        return this.this$0.getKey(this.index);
    }

    public Object getValue()
    {
        return this.this$0.getValue(this.index);
    }

    public int hashCode()
    {
        return (this.getKey().hashCode() ^ this.getValue().hashCode());
    }

    public Object setValue(Object p3)
    {
        return this.this$0.set(this.index, p3);
    }
}
