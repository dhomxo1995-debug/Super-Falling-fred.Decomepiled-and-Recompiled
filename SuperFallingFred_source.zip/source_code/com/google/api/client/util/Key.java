package com.google.api.client.util;
public interface annotation Key implements java.lang.annotation.Annotation {

    public abstract String value();
}
