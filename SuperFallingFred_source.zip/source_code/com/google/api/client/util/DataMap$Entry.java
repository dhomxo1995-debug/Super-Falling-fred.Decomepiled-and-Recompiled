package com.google.api.client.util;
final class DataMap$Entry implements java.util.Map$Entry {
    private final com.google.api.client.util.FieldInfo fieldInfo;
    private Object fieldValue;
    final synthetic com.google.api.client.util.DataMap this$0;

    DataMap$Entry(com.google.api.client.util.DataMap p2, com.google.api.client.util.FieldInfo p3, Object p4)
    {
        this.this$0 = p2;
        this.fieldInfo = p3;
        this.fieldValue = com.google.common.base.Preconditions.checkNotNull(p4);
        return;
    }

    public boolean equals(Object p6)
    {
        int v1 = 1;
        if (this != p6) {
            if ((p6 instanceof java.util.Map$Entry)) {
                if ((!this.getKey().equals(((java.util.Map$Entry) p6).getKey())) || (!this.getValue().equals(((java.util.Map$Entry) p6).getValue()))) {
                    v1 = 0;
                }
            } else {
                v1 = 0;
            }
        }
        return v1;
    }

    public bridge synthetic Object getKey()
    {
        return this.getKey();
    }

    public String getKey()
    {
        String v0 = this.fieldInfo.getName();
        if (this.this$0.classInfo.getIgnoreCase()) {
            v0 = v0.toLowerCase();
        }
        return v0;
    }

    public Object getValue()
    {
        return this.fieldValue;
    }

    public int hashCode()
    {
        return (this.getKey().hashCode() ^ this.getValue().hashCode());
    }

    public Object setValue(Object p4)
    {
        Object v0 = this.fieldValue;
        this.fieldValue = com.google.common.base.Preconditions.checkNotNull(p4);
        this.fieldInfo.setValue(this.this$0.object, p4);
        return v0;
    }
}
