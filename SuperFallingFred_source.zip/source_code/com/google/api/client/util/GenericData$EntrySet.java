package com.google.api.client.util;
final class GenericData$EntrySet extends java.util.AbstractSet {
    private final com.google.api.client.util.DataMap$EntrySet dataEntrySet;
    final synthetic com.google.api.client.util.GenericData this$0;

    GenericData$EntrySet(com.google.api.client.util.GenericData p3)
    {
        this.this$0 = p3;
        this.dataEntrySet = new com.google.api.client.util.DataMap(p3, p3.classInfo.getIgnoreCase()).entrySet();
        return;
    }

    public void clear()
    {
        this.this$0.unknownFields.clear();
        this.dataEntrySet.clear();
        return;
    }

    public java.util.Iterator iterator()
    {
        return new com.google.api.client.util.GenericData$EntryIterator(this.this$0, this.dataEntrySet);
    }

    public int size()
    {
        return (this.this$0.unknownFields.size() + this.dataEntrySet.size());
    }
}
