.class final Lcom/google/api/client/util/Clock$1;
.super Ljava/lang/Object;
.implements Lcom/google/api/client/util/Clock;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public currentTimeMillis()J
    .registers 3
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    return-wide v0
.end method
