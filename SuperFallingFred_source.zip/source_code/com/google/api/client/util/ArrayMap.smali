.class public Lcom/google/api/client/util/ArrayMap;
.super Ljava/util/AbstractMap;
.implements Ljava/lang/Cloneable;

.field private data:[Ljava/lang/Object;
.field  size:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/util/AbstractMap;-><init>()V
    return-void
.end method

.method public static create()Lcom/google/api/client/util/ArrayMap;
    .registers 1
    new-instance v0, Lcom/google/api/client/util/ArrayMap;
    invoke-direct v0, Lcom/google/api/client/util/ArrayMap;-><init>()V
    return-object v0
.end method

.method public static create(I)Lcom/google/api/client/util/ArrayMap;
    .registers 2
    invoke-static Lcom/google/api/client/util/ArrayMap;->create()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    invoke-virtual v0, v1, Lcom/google/api/client/util/ArrayMap;->ensureCapacity(I)V
    return-object v0
.end method

.method private getDataIndexOfKey(Ljava/lang/Object;)I
    .registers 7
    iget v4, v5, Lcom/google/api/client/util/ArrayMap;->size I
    shl-int/lit8 v1, v4, 1
    iget-object v0, v5, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    const/4 v2, 0
    if-ge v2, v1, +012h
    aget-object v3, v0, v2
    if-nez v6, +005h
    if-nez v3, +009h
    return v2
    invoke-virtual v6, v3, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v4
    if-nez v4, -005h
    add-int/lit8 v2, v2, 2
    goto -11h
    const/4 v2, -2
    goto -bh
.end method

.method public static varargs of([Ljava/lang/Object;)Lcom/google/api/client/util/ArrayMap;
    .registers 7
    const/4 v5, 1
    const/4 v4, 0
    invoke-static v5, Lcom/google/api/client/util/ArrayMap;->create(I)Lcom/google/api/client/util/ArrayMap;
    move-result-object v2
    array-length v1, v6
    rem-int/lit8 v3, v1, 2
    if-ne v5, v3, +01fh
    new-instance v3, Ljava/lang/IllegalArgumentException;
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "missing value for last key: "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    add-int/lit8 v5, v1, -1
    aget-object v5, v6, v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-direct v3, v4, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v3
    array-length v3, v6
    div-int/lit8 v3, v3, 2
    iput v3, v2, Lcom/google/api/client/util/ArrayMap;->size I
    new-array v0, v1, [Ljava/lang/Object;
    iput-object v0, v2, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    invoke-static v6, v4, v0, v4, v1, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    return-object v2
.end method

.method private removeFromDataIndexOfKey(I)Ljava/lang/Object;
    .registers 8
    const/4 v4, 0
    iget v5, v6, Lcom/google/api/client/util/ArrayMap;->size I
    shl-int/lit8 v1, v5, 1
    if-ltz v7, +004h
    if-lt v7, v1, +004h
    move-object v3, v4
    return-object v3
    add-int/lit8 v5, v7, 1
    invoke-direct v6, v5, Lcom/google/api/client/util/ArrayMap;->valueAtDataIndex(I)Ljava/lang/Object;
    move-result-object v3
    iget-object v0, v6, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    sub-int v5, v1, v7
    add-int/lit8 v2, v5, -2
    if-eqz v2, +007h
    add-int/lit8 v5, v7, 2
    invoke-static v0, v5, v0, v7, v2, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    iget v5, v6, Lcom/google/api/client/util/ArrayMap;->size I
    add-int/lit8 v5, v5, -1
    iput v5, v6, Lcom/google/api/client/util/ArrayMap;->size I
    add-int/lit8 v5, v1, -2
    invoke-direct v6, v5, v4, v4, Lcom/google/api/client/util/ArrayMap;->setData(I Ljava/lang/Object; Ljava/lang/Object;)V
    goto -1fh
.end method

.method private setData(I Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 6
    iget-object v0, v2, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    aput-object v4, v0, v3
    add-int/lit8 v1, v3, 1
    aput-object v5, v0, v1
    return-void
.end method

.method private setDataCapacity(I)V
    .registers 7
    const/4 v4, 0
    if-nez v6, +006h
    const/4 v3, 0
    iput-object v3, v5, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    return-void
    iget v2, v5, Lcom/google/api/client/util/ArrayMap;->size I
    iget-object v1, v5, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    if-eqz v2, +005h
    array-length v3, v1
    if-eq v6, v3, -008h
    new-array v0, v6, [Ljava/lang/Object;
    iput-object v0, v5, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    if-eqz v2, -00eh
    shl-int/lit8 v3, v2, 1
    invoke-static v1, v4, v0, v4, v3, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    goto -15h
.end method

.method private valueAtDataIndex(I)Ljava/lang/Object;
    .registers 4
    if-gez v3, +004h
    const/4 v0, 0
    return-object v0
    iget-object v1, v2, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    aget-object v0, v1, v3
    goto -5h
.end method

.method public final add(Ljava/lang/Object; Ljava/lang/Object;)V
    .registers 4
    iget v0, v1, Lcom/google/api/client/util/ArrayMap;->size I
    invoke-virtual v1, v0, v2, v3, Lcom/google/api/client/util/ArrayMap;->set(I Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    return-void
.end method

.method public clear()V
    .registers 2
    const/4 v0, 0
    iput v0, v1, Lcom/google/api/client/util/ArrayMap;->size I
    const/4 v0, 0
    iput-object v0, v1, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    return-void
.end method

.method public clone()Lcom/google/api/client/util/ArrayMap;
    .registers 8
    invoke-super v7, Ljava/util/AbstractMap;->clone()Ljava/lang/Object;
    move-result-object v3
    check-cast v3, Lcom/google/api/client/util/ArrayMap;
    iget-object v0, v7, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    if-eqz v0, +00ch
    array-length v2, v0
    new-array v4, v2, [Ljava/lang/Object;
    iput-object v4, v3, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    const/4 v5, 0
    const/4 v6, 0
    invoke-static v0, v5, v4, v6, v2, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    return-object v3
    move-exception v1
    const/4 v3, 0
    goto -3h
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/ArrayMap;->clone()Lcom/google/api/client/util/ArrayMap;
    move-result-object v0
    return-object v0
.end method

.method public final containsKey(Ljava/lang/Object;)Z
    .registers 4
    const/4 v0, -2
    invoke-direct v2, v3, Lcom/google/api/client/util/ArrayMap;->getDataIndexOfKey(Ljava/lang/Object;)I
    move-result v1
    if-eq v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public final containsValue(Ljava/lang/Object;)Z
    .registers 7
    iget v4, v5, Lcom/google/api/client/util/ArrayMap;->size I
    shl-int/lit8 v1, v4, 1
    iget-object v0, v5, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    const/4 v2, 1
    if-ge v2, v1, +013h
    aget-object v3, v0, v2
    if-nez v6, +006h
    if-nez v3, +00ah
    const/4 v4, 1
    return v4
    invoke-virtual v6, v3, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v4
    if-nez v4, -006h
    add-int/lit8 v2, v2, 2
    goto -12h
    const/4 v4, 0
    goto -bh
.end method

.method public final ensureCapacity(I)V
    .registers 8
    iget-object v0, v6, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    shl-int/lit8 v1, v7, 1
    if-nez v0, +019h
    const/4 v3, 0
    if-le v1, v3, +015h
    div-int/lit8 v4, v3, 2
    mul-int/lit8 v4, v4, 3
    add-int/lit8 v2, v4, 1
    rem-int/lit8 v4, v2, 2
    const/4 v5, 1
    if-ne v4, v5, +004h
    add-int/lit8 v2, v2, 1
    if-ge v2, v1, +003h
    move v2, v1
    invoke-direct v6, v2, Lcom/google/api/client/util/ArrayMap;->setDataCapacity(I)V
    return-void
    array-length v3, v0
    goto -17h
.end method

.method public final entrySet()Ljava/util/Set;
    .registers 2
    new-instance v0, Lcom/google/api/client/util/ArrayMap$EntrySet;
    invoke-direct v0, v1, Lcom/google/api/client/util/ArrayMap$EntrySet;-><init>(Lcom/google/api/client/util/ArrayMap;)V
    return-object v0
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    invoke-direct v1, v2, Lcom/google/api/client/util/ArrayMap;->getDataIndexOfKey(Ljava/lang/Object;)I
    move-result v0
    add-int/lit8 v0, v0, 1
    invoke-direct v1, v0, Lcom/google/api/client/util/ArrayMap;->valueAtDataIndex(I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final getIndexOfKey(Ljava/lang/Object;)I
    .registers 3
    invoke-direct v1, v2, Lcom/google/api/client/util/ArrayMap;->getDataIndexOfKey(Ljava/lang/Object;)I
    move-result v0
    shr-int/lit8 v0, v0, 1
    return v0
.end method

.method public final getKey(I)Ljava/lang/Object;
    .registers 5
    if-ltz v4, +006h
    iget v1, v3, Lcom/google/api/client/util/ArrayMap;->size I
    if-lt v4, v1, +004h
    const/4 v0, 0
    return-object v0
    iget-object v1, v3, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    shl-int/lit8 v2, v4, 1
    aget-object v0, v1, v2
    goto -7h
.end method

.method public final getValue(I)Ljava/lang/Object;
    .registers 3
    if-ltz v2, +006h
    iget v0, v1, Lcom/google/api/client/util/ArrayMap;->size I
    if-lt v2, v0, +004h
    const/4 v0, 0
    return-object v0
    shl-int/lit8 v0, v2, 1
    add-int/lit8 v0, v0, 1
    invoke-direct v1, v0, Lcom/google/api/client/util/ArrayMap;->valueAtDataIndex(I)Ljava/lang/Object;
    move-result-object v0
    goto -9h
.end method

.method public final put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    invoke-virtual v2, v3, Lcom/google/api/client/util/ArrayMap;->getIndexOfKey(Ljava/lang/Object;)I
    move-result v0
    const/4 v1, -1
    if-ne v0, v1, +004h
    iget v0, v2, Lcom/google/api/client/util/ArrayMap;->size I
    invoke-virtual v2, v0, v3, v4, Lcom/google/api/client/util/ArrayMap;->set(I Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    return-object v1
.end method

.method public final remove(I)Ljava/lang/Object;
    .registers 3
    shl-int/lit8 v0, v2, 1
    invoke-direct v1, v0, Lcom/google/api/client/util/ArrayMap;->removeFromDataIndexOfKey(I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    invoke-direct v1, v2, Lcom/google/api/client/util/ArrayMap;->getDataIndexOfKey(Ljava/lang/Object;)I
    move-result v0
    invoke-direct v1, v0, Lcom/google/api/client/util/ArrayMap;->removeFromDataIndexOfKey(I)Ljava/lang/Object;
    move-result-object v0
    return-object v0
.end method

.method public final set(I Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    iget v1, v4, Lcom/google/api/client/util/ArrayMap;->size I
    if-ltz v5, +004h
    if-lt v5, v1, +008h
    new-instance v3, Ljava/lang/IndexOutOfBoundsException;
    invoke-direct v3, Ljava/lang/IndexOutOfBoundsException;-><init>()V
    throw v3
    shl-int/lit8 v3, v5, 1
    add-int/lit8 v2, v3, 1
    invoke-direct v4, v2, Lcom/google/api/client/util/ArrayMap;->valueAtDataIndex(I)Ljava/lang/Object;
    move-result-object v0
    iget-object v3, v4, Lcom/google/api/client/util/ArrayMap;->data [Ljava/lang/Object;
    aput-object v6, v3, v2
    return-object v0
.end method

.method public final set(I Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8
    if-gez v5, +008h
    new-instance v3, Ljava/lang/IndexOutOfBoundsException;
    invoke-direct v3, Ljava/lang/IndexOutOfBoundsException;-><init>()V
    throw v3
    add-int/lit8 v1, v5, 1
    invoke-virtual v4, v1, Lcom/google/api/client/util/ArrayMap;->ensureCapacity(I)V
    shl-int/lit8 v0, v5, 1
    add-int/lit8 v3, v0, 1
    invoke-direct v4, v3, Lcom/google/api/client/util/ArrayMap;->valueAtDataIndex(I)Ljava/lang/Object;
    move-result-object v2
    invoke-direct v4, v0, v6, v7, Lcom/google/api/client/util/ArrayMap;->setData(I Ljava/lang/Object; Ljava/lang/Object;)V
    iget v3, v4, Lcom/google/api/client/util/ArrayMap;->size I
    if-le v1, v3, +004h
    iput v1, v4, Lcom/google/api/client/util/ArrayMap;->size I
    return-object v2
.end method

.method public final size()I
    .registers 2
    iget v0, v1, Lcom/google/api/client/util/ArrayMap;->size I
    return v0
.end method

.method public final trim()V
    .registers 2
    iget v0, v1, Lcom/google/api/client/util/ArrayMap;->size I
    shl-int/lit8 v0, v0, 1
    invoke-direct v1, v0, Lcom/google/api/client/util/ArrayMap;->setDataCapacity(I)V
    return-void
.end method
