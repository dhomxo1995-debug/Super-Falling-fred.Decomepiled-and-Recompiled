package com.google.api.client.util;
final class ArrayMap$EntrySet extends java.util.AbstractSet {
    final synthetic com.google.api.client.util.ArrayMap this$0;

    ArrayMap$EntrySet(com.google.api.client.util.ArrayMap p1)
    {
        this.this$0 = p1;
        return;
    }

    public java.util.Iterator iterator()
    {
        return new com.google.api.client.util.ArrayMap$EntryIterator(this.this$0);
    }

    public int size()
    {
        return this.this$0.size;
    }
}
