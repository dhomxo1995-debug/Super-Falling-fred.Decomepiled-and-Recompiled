.class final Lcom/google/api/client/util/ArrayMap$EntrySet;
.super Ljava/util/AbstractSet;

.field final synthetic this$0:Lcom/google/api/client/util/ArrayMap;

.method constructor <init>(Lcom/google/api/client/util/ArrayMap;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/ArrayMap$EntrySet;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-direct v0, Ljava/util/AbstractSet;-><init>()V
    return-void
.end method

.method public iterator()Ljava/util/Iterator;
    .registers 3
    new-instance v0, Lcom/google/api/client/util/ArrayMap$EntryIterator;
    iget-object v1, v2, Lcom/google/api/client/util/ArrayMap$EntrySet;->this$0 Lcom/google/api/client/util/ArrayMap;
    invoke-direct v0, v1, Lcom/google/api/client/util/ArrayMap$EntryIterator;-><init>(Lcom/google/api/client/util/ArrayMap;)V
    return-object v0
.end method

.method public size()I
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/ArrayMap$EntrySet;->this$0 Lcom/google/api/client/util/ArrayMap;
    iget v0, v0, Lcom/google/api/client/util/ArrayMap;->size I
    return v0
.end method
