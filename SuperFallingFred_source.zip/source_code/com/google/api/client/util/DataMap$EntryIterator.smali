.class final Lcom/google/api/client/util/DataMap$EntryIterator;
.super Ljava/lang/Object;
.implements Ljava/util/Iterator;

.field private currentFieldInfo:Lcom/google/api/client/util/FieldInfo;
.field private isComputed:Z
.field private isRemoved:Z
.field private nextFieldInfo:Lcom/google/api/client/util/FieldInfo;
.field private nextFieldValue:Ljava/lang/Object;
.field private nextKeyIndex:I
.field final synthetic this$0:Lcom/google/api/client/util/DataMap;

.method constructor <init>(Lcom/google/api/client/util/DataMap;)V
    .registers 3
    iput-object v2, v1, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    const/4 v0, -1
    iput v0, v1, Lcom/google/api/client/util/DataMap$EntryIterator;->nextKeyIndex I
    return-void
.end method

.method public hasNext()Z
    .registers 5
    const/4 v1, 1
    iget-boolean v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->isComputed Z
    if-nez v0, +042h
    iput-boolean v1, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->isComputed Z
    const/4 v0, 0
    iput-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    if-nez v0, +039h
    iget v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextKeyIndex I
    add-int/lit8 v0, v0, 1
    iput v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextKeyIndex I
    iget-object v2, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v2, v2, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    invoke-interface v2, Ljava/util/List;->size()I
    move-result v2
    if-ge v0, v2, +027h
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v0, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v0, v0, Lcom/google/api/client/util/DataMap;->classInfo Lcom/google/api/client/util/ClassInfo;
    iget-object v0, v0, Lcom/google/api/client/util/ClassInfo;->names Ljava/util/List;
    iget v3, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextKeyIndex I
    invoke-interface v0, v3, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-virtual v2, v0, Lcom/google/api/client/util/ClassInfo;->getFieldInfo(Ljava/lang/String;)Lcom/google/api/client/util/FieldInfo;
    move-result-object v0
    iput-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldInfo Lcom/google/api/client/util/FieldInfo;
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldInfo Lcom/google/api/client/util/FieldInfo;
    iget-object v2, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v2, v2, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    invoke-virtual v0, v2, Lcom/google/api/client/util/FieldInfo;->getValue(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    iput-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    goto -3ah
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    if-eqz v0, +004h
    move v0, v1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .registers 2
    invoke-virtual v1, Lcom/google/api/client/util/DataMap$EntryIterator;->next()Ljava/util/Map$Entry;
    move-result-object v0
    return-object v0
.end method

.method public next()Ljava/util/Map$Entry;
    .registers 5
    const/4 v3, 0
    const/4 v2, 0
    invoke-virtual v4, Lcom/google/api/client/util/DataMap$EntryIterator;->hasNext()Z
    move-result v1
    if-nez v1, +008h
    new-instance v1, Ljava/util/NoSuchElementException;
    invoke-direct v1, Ljava/util/NoSuchElementException;-><init>()V
    throw v1
    iget-object v1, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldInfo Lcom/google/api/client/util/FieldInfo;
    iput-object v1, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->currentFieldInfo Lcom/google/api/client/util/FieldInfo;
    iget-object v0, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    iput-boolean v2, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->isComputed Z
    iput-boolean v2, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->isRemoved Z
    iput-object v3, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldInfo Lcom/google/api/client/util/FieldInfo;
    iput-object v3, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->nextFieldValue Ljava/lang/Object;
    new-instance v1, Lcom/google/api/client/util/DataMap$Entry;
    iget-object v2, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v3, v4, Lcom/google/api/client/util/DataMap$EntryIterator;->currentFieldInfo Lcom/google/api/client/util/FieldInfo;
    invoke-direct v1, v2, v3, v0, Lcom/google/api/client/util/DataMap$Entry;-><init>(Lcom/google/api/client/util/DataMap; Lcom/google/api/client/util/FieldInfo; Ljava/lang/Object;)V
    return-object v1
.end method

.method public remove()V
    .registers 4
    const/4 v1, 1
    iget-object v0, v3, Lcom/google/api/client/util/DataMap$EntryIterator;->currentFieldInfo Lcom/google/api/client/util/FieldInfo;
    if-eqz v0, +017h
    iget-boolean v0, v3, Lcom/google/api/client/util/DataMap$EntryIterator;->isRemoved Z
    if-nez v0, +013h
    move v0, v1
    invoke-static v0, Lcom/google/common/base/Preconditions;->checkState(Z)V
    iput-boolean v1, v3, Lcom/google/api/client/util/DataMap$EntryIterator;->isRemoved Z
    iget-object v0, v3, Lcom/google/api/client/util/DataMap$EntryIterator;->currentFieldInfo Lcom/google/api/client/util/FieldInfo;
    iget-object v1, v3, Lcom/google/api/client/util/DataMap$EntryIterator;->this$0 Lcom/google/api/client/util/DataMap;
    iget-object v1, v1, Lcom/google/api/client/util/DataMap;->object Ljava/lang/Object;
    const/4 v2, 0
    invoke-virtual v0, v1, v2, Lcom/google/api/client/util/FieldInfo;->setValue(Ljava/lang/Object; Ljava/lang/Object;)V
    return-void
    const/4 v0, 0
    goto -11h
.end method
