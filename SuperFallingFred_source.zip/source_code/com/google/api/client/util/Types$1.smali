.class final Lcom/google/api/client/util/Types$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Iterable;

.field final synthetic val$value:Ljava/lang/Object;

.method constructor <init>(Ljava/lang/Object;)V
    .registers 2
    iput-object v1, v0, Lcom/google/api/client/util/Types$1;->val$value Ljava/lang/Object;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public iterator()Ljava/util/Iterator;
    .registers 2
    new-instance v0, Lcom/google/api/client/util/Types$1$1;
    invoke-direct v0, v1, Lcom/google/api/client/util/Types$1$1;-><init>(Lcom/google/api/client/util/Types$1;)V
    return-object v0
.end method
