.class final Lcom/google/api/client/util/GenericData$EntrySet;
.super Ljava/util/AbstractSet;

.field private final dataEntrySet:Lcom/google/api/client/util/DataMap$EntrySet;
.field final synthetic this$0:Lcom/google/api/client/util/GenericData;

.method constructor <init>(Lcom/google/api/client/util/GenericData;)V
    .registers 4
    iput-object v3, v2, Lcom/google/api/client/util/GenericData$EntrySet;->this$0 Lcom/google/api/client/util/GenericData;
    invoke-direct v2, Ljava/util/AbstractSet;-><init>()V
    new-instance v0, Lcom/google/api/client/util/DataMap;
    iget-object v1, v3, Lcom/google/api/client/util/GenericData;->classInfo Lcom/google/api/client/util/ClassInfo;
    invoke-virtual v1, Lcom/google/api/client/util/ClassInfo;->getIgnoreCase()Z
    move-result v1
    invoke-direct v0, v3, v1, Lcom/google/api/client/util/DataMap;-><init>(Ljava/lang/Object; Z)V
    invoke-virtual v0, Lcom/google/api/client/util/DataMap;->entrySet()Lcom/google/api/client/util/DataMap$EntrySet;
    move-result-object v0
    iput-object v0, v2, Lcom/google/api/client/util/GenericData$EntrySet;->dataEntrySet Lcom/google/api/client/util/DataMap$EntrySet;
    return-void
.end method

.method public clear()V
    .registers 2
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntrySet;->this$0 Lcom/google/api/client/util/GenericData;
    iget-object v0, v0, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->clear()V
    iget-object v0, v1, Lcom/google/api/client/util/GenericData$EntrySet;->dataEntrySet Lcom/google/api/client/util/DataMap$EntrySet;
    invoke-virtual v0, Lcom/google/api/client/util/DataMap$EntrySet;->clear()V
    return-void
.end method

.method public iterator()Ljava/util/Iterator;
    .registers 4
    new-instance v0, Lcom/google/api/client/util/GenericData$EntryIterator;
    iget-object v1, v3, Lcom/google/api/client/util/GenericData$EntrySet;->this$0 Lcom/google/api/client/util/GenericData;
    iget-object v2, v3, Lcom/google/api/client/util/GenericData$EntrySet;->dataEntrySet Lcom/google/api/client/util/DataMap$EntrySet;
    invoke-direct v0, v1, v2, Lcom/google/api/client/util/GenericData$EntryIterator;-><init>(Lcom/google/api/client/util/GenericData; Lcom/google/api/client/util/DataMap$EntrySet;)V
    return-object v0
.end method

.method public size()I
    .registers 3
    iget-object v0, v2, Lcom/google/api/client/util/GenericData$EntrySet;->this$0 Lcom/google/api/client/util/GenericData;
    iget-object v0, v0, Lcom/google/api/client/util/GenericData;->unknownFields Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->size()I
    move-result v0
    iget-object v1, v2, Lcom/google/api/client/util/GenericData$EntrySet;->dataEntrySet Lcom/google/api/client/util/DataMap$EntrySet;
    invoke-virtual v1, Lcom/google/api/client/util/DataMap$EntrySet;->size()I
    move-result v1
    add-int/2addr v0, v1
    return v0
.end method
