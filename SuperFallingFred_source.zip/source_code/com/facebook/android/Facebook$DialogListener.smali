.class public interface abstract Lcom/facebook/android/Facebook$DialogListener;
.super Ljava/lang/Object;


.method public abstract onCancel()V
    # abstract or native method
.end method

.method public abstract onComplete(Landroid/os/Bundle;)V
    # abstract or native method
.end method

.method public abstract onError(Lcom/facebook/android/DialogError;)V
    # abstract or native method
.end method

.method public abstract onFacebookError(Lcom/facebook/android/FacebookError;)V
    # abstract or native method
.end method
