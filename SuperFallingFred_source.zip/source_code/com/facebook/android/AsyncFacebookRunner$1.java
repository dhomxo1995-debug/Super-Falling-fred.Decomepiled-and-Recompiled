package com.facebook.android;
 class AsyncFacebookRunner$1 extends java.lang.Thread {
    final synthetic com.facebook.android.AsyncFacebookRunner this$0;
    final synthetic android.content.Context val$context;
    final synthetic com.facebook.android.AsyncFacebookRunner$RequestListener val$listener;
    final synthetic Object val$state;

    AsyncFacebookRunner$1(com.facebook.android.AsyncFacebookRunner p1, android.content.Context p2, com.facebook.android.AsyncFacebookRunner$RequestListener p3, Object p4)
    {
        this.this$0 = p1;
        this.val$context = p2;
        this.val$listener = p3;
        this.val$state = p4;
        return;
    }

    public void run()
    {
        try {
            String v1 = this.this$0.fb.logout(this.val$context);
        } catch (java.io.IOException v0_2) {
            this.val$listener.onFileNotFoundException(v0_2, this.val$state);
            return;
        } catch (java.io.IOException v0_1) {
            this.val$listener.onMalformedURLException(v0_1, this.val$state);
            return;
        } catch (java.io.IOException v0_0) {
            this.val$listener.onIOException(v0_0, this.val$state);
            return;
        }
        if ((v1.length() != 0) && (!v1.equals("false"))) {
            this.val$listener.onComplete(v1, this.val$state);
            return;
        } else {
            this.val$listener.onFacebookError(new com.facebook.android.FacebookError("auth.expireSession failed"), this.val$state);
            return;
        }
    }
}
