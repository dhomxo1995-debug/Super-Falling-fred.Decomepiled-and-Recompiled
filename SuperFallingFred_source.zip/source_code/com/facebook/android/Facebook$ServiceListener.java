package com.facebook.android;
public interface Facebook$ServiceListener {

    public abstract void onComplete(android.os.Bundle p0);

    public abstract void onError(Error p0);

    public abstract void onFacebookError(com.facebook.android.FacebookError p0);
}
