package com.facebook.android;
 class Facebook$1 implements com.facebook.android.Facebook$DialogListener {
    final synthetic com.facebook.android.Facebook this$0;

    Facebook$1(com.facebook.android.Facebook p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onCancel()
    {
        com.facebook.android.Util.logd("Facebook-authorize", "Login canceled");
        com.facebook.android.Facebook.access$000(this.this$0).onCancel();
        return;
    }

    public void onComplete(android.os.Bundle p5)
    {
        android.webkit.CookieSyncManager.getInstance().sync();
        this.this$0.setAccessToken(p5.getString("access_token"));
        this.this$0.setAccessExpiresIn(p5.getString("expires_in"));
        if (!this.this$0.isSessionValid()) {
            com.facebook.android.Facebook.access$000(this.this$0).onFacebookError(new com.facebook.android.FacebookError("Failed to receive access token."));
        } else {
            com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login Success! access_token=").append(this.this$0.getAccessToken()).append(" expires=").append(this.this$0.getAccessExpires()).toString());
            com.facebook.android.Facebook.access$000(this.this$0).onComplete(p5);
        }
        return;
    }

    public void onError(com.facebook.android.DialogError p4)
    {
        com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login failed: ").append(p4).toString());
        com.facebook.android.Facebook.access$000(this.this$0).onError(p4);
        return;
    }

    public void onFacebookError(com.facebook.android.FacebookError p4)
    {
        com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login failed: ").append(p4).toString());
        com.facebook.android.Facebook.access$000(this.this$0).onFacebookError(p4);
        return;
    }
}
