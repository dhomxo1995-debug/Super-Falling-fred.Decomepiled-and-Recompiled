package com.facebook.android;
public final class R$attr {

    public R$attr()
    {
        return;
    }
}
