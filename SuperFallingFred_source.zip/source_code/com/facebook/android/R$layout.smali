.class public final Lcom/facebook/android/R$layout;
.super Ljava/lang/Object;

.field public static final main:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
