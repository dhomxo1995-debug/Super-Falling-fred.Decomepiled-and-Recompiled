.class 0x0 Lcom/facebook/android/FbDialog$FbWebViewClient;
.super Landroid/webkit/WebViewClient;

.field final synthetic this$0:Lcom/facebook/android/FbDialog;

.method private constructor <init>(Lcom/facebook/android/FbDialog;)V
    .registers 2
    iput-object v1, v0, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-direct v0, Landroid/webkit/WebViewClient;-><init>()V
    return-void
.end method

.method synthetic constructor <init>(Lcom/facebook/android/FbDialog; Lcom/facebook/android/FbDialog$1;)V
    .registers 3
    invoke-direct v0, v1, Lcom/facebook/android/FbDialog$FbWebViewClient;-><init>(Lcom/facebook/android/FbDialog;)V
    return-void
.end method

.method public onPageFinished(Landroid/webkit/WebView; Ljava/lang/String;)V
    .registers 5
    const/4 v1, 0
    invoke-super v2, v3, v4, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView; Ljava/lang/String;)V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$200(Lcom/facebook/android/FbDialog;)Landroid/app/ProgressDialog;
    move-result-object v0
    invoke-virtual v0, Landroid/app/ProgressDialog;->dismiss()V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$300(Lcom/facebook/android/FbDialog;)Landroid/widget/FrameLayout;
    move-result-object v0
    invoke-virtual v0, v1, Landroid/widget/FrameLayout;->setBackgroundColor(I)V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$400(Lcom/facebook/android/FbDialog;)Landroid/webkit/WebView;
    move-result-object v0
    invoke-virtual v0, v1, Landroid/webkit/WebView;->setVisibility(I)V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$500(Lcom/facebook/android/FbDialog;)Landroid/widget/ImageView;
    move-result-object v0
    invoke-virtual v0, v1, Landroid/widget/ImageView;->setVisibility(I)V
    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView; Ljava/lang/String; Landroid/graphics/Bitmap;)V
    .registers 7
    const-string v0, "Facebook-WebView"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Webview loading URL: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    invoke-super v3, v4, v5, v6, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView; Ljava/lang/String; Landroid/graphics/Bitmap;)V
    iget-object v0, v3, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$200(Lcom/facebook/android/FbDialog;)Landroid/app/ProgressDialog;
    move-result-object v0
    invoke-virtual v0, Landroid/app/ProgressDialog;->show()V
    return-void
.end method

.method public onReceivedError(Landroid/webkit/WebView; I Ljava/lang/String; Ljava/lang/String;)V
    .registers 7
    invoke-super v2, v3, v4, v5, v6, Landroid/webkit/WebViewClient;->onReceivedError(Landroid/webkit/WebView; I Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    new-instance v1, Lcom/facebook/android/DialogError;
    invoke-direct v1, v5, v4, v6, Lcom/facebook/android/DialogError;-><init>(Ljava/lang/String; I Ljava/lang/String;)V
    invoke-interface v0, v1, Lcom/facebook/android/Facebook$DialogListener;->onError(Lcom/facebook/android/DialogError;)V
    iget-object v0, v2, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-virtual v0, Lcom/facebook/android/FbDialog;->dismiss()V
    return-void
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView; Ljava/lang/String;)Z
    .registers 10
    const/4 v2, 1
    const-string v3, "Facebook-WebView"
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Redirect URL: "
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v9, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-static v3, v4, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    const-string v3, "fbconnect://success"
    invoke-virtual v9, v3, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v3
    if-eqz v3, +04eh
    invoke-static v9, Lcom/facebook/android/Util;->parseUrl(Ljava/lang/String;)Landroid/os/Bundle;
    move-result-object v1
    const-string v3, "error"
    invoke-virtual v1, v3, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    if-nez v0, +008h
    const-string v3, "error_type"
    invoke-virtual v1, v3, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    if-nez v0, +011h
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v3, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v3
    invoke-interface v3, v1, Lcom/facebook/android/Facebook$DialogListener;->onComplete(Landroid/os/Bundle;)V
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-virtual v3, Lcom/facebook/android/FbDialog;->dismiss()V
    return v2
    const-string v3, "access_denied"
    invoke-virtual v0, v3, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v3
    if-nez v3, +00ah
    const-string v3, "OAuthAccessDeniedException"
    invoke-virtual v0, v3, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v3
    if-eqz v3, +00ch
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v3, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v3
    invoke-interface v3, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    goto -1fh
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v3, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v3
    new-instance v4, Lcom/facebook/android/FacebookError;
    invoke-direct v4, v0, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    invoke-interface v3, v4, Lcom/facebook/android/Facebook$DialogListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    goto -2eh
    const-string v3, "fbconnect://cancel"
    invoke-virtual v9, v3, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v3
    if-eqz v3, +011h
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v3, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v3
    invoke-interface v3, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-virtual v3, Lcom/facebook/android/FbDialog;->dismiss()V
    goto -40h
    const-string v3, "touch"
    invoke-virtual v9, v3, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v3
    if-eqz v3, +004h
    const/4 v2, 0
    goto -4ah
    iget-object v3, v7, Lcom/facebook/android/FbDialog$FbWebViewClient;->this$0 Lcom/facebook/android/FbDialog;
    invoke-virtual v3, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v3
    new-instance v4, Landroid/content/Intent;
    const-string v5, "android.intent.action.VIEW"
    invoke-static v9, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v6
    invoke-direct v4, v5, v6, Landroid/content/Intent;-><init>(Ljava/lang/String; Landroid/net/Uri;)V
    invoke-virtual v3, v4, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    goto -5fh
.end method
