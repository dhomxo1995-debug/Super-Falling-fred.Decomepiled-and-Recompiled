.class public Lcom/facebook/android/DialogError;
.super Ljava/lang/Throwable;

.field private static final serialVersionUID:J
.field private mErrorCode:I
.field private mFailingUrl:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String; I Ljava/lang/String;)V
    .registers 4
    invoke-direct v0, v1, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V
    iput v2, v0, Lcom/facebook/android/DialogError;->mErrorCode I
    iput-object v3, v0, Lcom/facebook/android/DialogError;->mFailingUrl Ljava/lang/String;
    return-void
.end method

.method  getErrorCode()I
    .registers 2
    iget v0, v1, Lcom/facebook/android/DialogError;->mErrorCode I
    return v0
.end method

.method  getFailingUrl()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/DialogError;->mFailingUrl Ljava/lang/String;
    return-object v0
.end method
