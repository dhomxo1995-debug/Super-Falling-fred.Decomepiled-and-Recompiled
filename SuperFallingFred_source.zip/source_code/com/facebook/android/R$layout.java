package com.facebook.android;
public final class R$layout {
    public static final int main = 2130903040;

    public R$layout()
    {
        return;
    }
}
