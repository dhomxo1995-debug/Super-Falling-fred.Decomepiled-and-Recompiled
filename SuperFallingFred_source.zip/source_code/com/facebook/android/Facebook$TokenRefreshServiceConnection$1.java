package com.facebook.android;
 class Facebook$TokenRefreshServiceConnection$1 extends android.os.Handler {
    final synthetic com.facebook.android.Facebook$TokenRefreshServiceConnection this$1;

    Facebook$TokenRefreshServiceConnection$1(com.facebook.android.Facebook$TokenRefreshServiceConnection p1)
    {
        this.this$1 = p1;
        return;
    }

    public void handleMessage(android.os.Message p11)
    {
        String v5 = p11.getData().getString("access_token");
        long v2 = (p11.getData().getLong("expires_in") * 1000);
        android.os.Bundle v4_1 = ((android.os.Bundle) p11.getData().clone());
        v4_1.putLong("expires_in", v2);
        if (v5 == null) {
            if (this.this$1.serviceListener != null) {
                String v0 = p11.getData().getString("error");
                if (!p11.getData().containsKey("error_code")) {
                    if (v0 == null) {
                        v0 = "Unknown service error";
                    }
                    this.this$1.serviceListener.onError(new Error(v0));
                } else {
                    this.this$1.serviceListener.onFacebookError(new com.facebook.android.FacebookError(v0, 0, p11.getData().getInt("error_code")));
                }
            }
        } else {
            this.this$1.this$0.setAccessToken(v5);
            this.this$1.this$0.setAccessExpires(v2);
            if (this.this$1.serviceListener != null) {
                this.this$1.serviceListener.onComplete(v4_1);
            }
        }
        this.this$1.applicationsContext.unbindService(this.this$1);
        return;
    }
}
