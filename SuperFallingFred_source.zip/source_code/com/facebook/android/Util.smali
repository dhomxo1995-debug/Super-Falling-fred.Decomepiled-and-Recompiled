.class public final Lcom/facebook/android/Util;
.super Ljava/lang/Object;

.field private static ENABLE_LOG:Z

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/facebook/android/Util;->ENABLE_LOG Z
    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static clearCookies(Landroid/content/Context;)V
    .registers 3
    invoke-static v2, Landroid/webkit/CookieSyncManager;->createInstance(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
    move-result-object v1
    invoke-static Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;
    move-result-object v0
    invoke-virtual v0, Landroid/webkit/CookieManager;->removeAllCookie()V
    return-void
.end method

.method public static decodeUrl(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 10
    new-instance v5, Landroid/os/Bundle;
    invoke-direct v5, Landroid/os/Bundle;-><init>()V
    if-eqz v9, +02dh
    const-string v7, "&"
    invoke-virtual v9, v7, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    move-result-object v1
    move-object v0, v1
    array-length v3, v0
    const/4 v2, 0
    if-ge v2, v3, +022h
    aget-object v4, v0, v2
    const-string v7, "="
    invoke-virtual v4, v7, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    move-result-object v6
    array-length v7, v6
    const/4 v8, 2
    if-ne v7, v8, +013h
    const/4 v7, 0
    aget-object v7, v6, v7
    invoke-static v7, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v7
    const/4 v8, 1
    aget-object v8, v6, v8
    invoke-static v8, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v8
    invoke-virtual v5, v7, v8, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    add-int/lit8 v2, v2, 1
    goto -21h
    return-object v5
.end method

.method public static encodePostBody(Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    if-nez v6, +005h
    const-string v4, ""
    return-object v4
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v6, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    move-result-object v4
    invoke-interface v4, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v0
    invoke-interface v0, Ljava/util/Iterator;->hasNext()Z
    move-result v4
    if-eqz v4, +04fh
    invoke-interface v0, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v6, v1, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v2
    instance-of v4, v2, Ljava/lang/String;
    if-eqz v4, -012h
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "Content-Disposition: form-data; name=""
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, ""

"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    check-cast v2, Ljava/lang/String;
    invoke-virtual v4, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const-string v5, "
--"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, v7, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    const-string v5, "
"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -52h
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v4
    goto -65h
.end method

.method public static encodeUrl(Landroid/os/Bundle;)Ljava/lang/String;
    .registers 8
    if-nez v7, +005h
    const-string v5, ""
    return-object v5
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    const/4 v0, 1
    invoke-virtual v7, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    move-result-object v5
    invoke-interface v5, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v5
    if-eqz v5, +040h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Ljava/lang/String;
    invoke-virtual v7, v2, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v3
    instance-of v5, v3, Ljava/lang/String;
    if-eqz v5, -012h
    if-eqz v0, +02ah
    const/4 v0, 0
    new-instance v5, Ljava/lang/StringBuilder;
    invoke-direct v5, Ljava/lang/StringBuilder;-><init>()V
    invoke-static v2, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-virtual v5, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v5
    const-string v6, "="
    invoke-virtual v5, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v5
    invoke-virtual v7, v2, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-static v6, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-virtual v5, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v5
    invoke-virtual v5, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -3dh
    const-string v5, "&"
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -2ch
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v5
    goto -57h
.end method

.method public static logd(Ljava/lang/String; Ljava/lang/String;)V
    .registers 3
    sget-boolean v0, Lcom/facebook/android/Util;->ENABLE_LOG Z
    if-eqz v0, +005h
    invoke-static v1, v2, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method

.method public static openUrl(Ljava/lang/String; Ljava/lang/String; Landroid/os/Bundle;)Ljava/lang/String;
    .registers 20
    const-string v12, "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f"
    const-string v6, "
"
    const-string v13, "GET"
    move-object/from16 v0, v18
    invoke-virtual v0, v13, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v13
    if-eqz v13, +01fh
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    move-object/from16 v0, v17
    invoke-virtual v13, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    const-string v14, "?"
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-static/range v19, Lcom/facebook/android/Util;->encodeUrl(Landroid/os/Bundle;)Ljava/lang/String;
    move-result-object v14
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v17
    const-string v13, "Facebook-Util"
    new-instance v14, Ljava/lang/StringBuilder;
    invoke-direct v14, Ljava/lang/StringBuilder;-><init>()V
    move-object/from16 v0, v18
    invoke-virtual v14, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    const-string v15, " URL: "
    invoke-virtual v14, v15, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    move-object/from16 v0, v17
    invoke-virtual v14, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    invoke-virtual v14, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v14
    invoke-static v13, v14, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    new-instance v13, Ljava/net/URL;
    move-object/from16 v0, v17
    invoke-direct v13, v0, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    invoke-virtual v13, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    move-result-object v2
    check-cast v2, Ljava/net/HttpURLConnection;
    const-string v13, "User-Agent"
    new-instance v14, Ljava/lang/StringBuilder;
    invoke-direct v14, Ljava/lang/StringBuilder;-><init>()V
    invoke-static Ljava/lang/System;->getProperties()Ljava/util/Properties;
    move-result-object v15
    const-string v16, "http.agent"
    invoke-virtual/range v15 ... v16, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v15
    invoke-virtual v14, v15, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    const-string v15, " FacebookAndroidSDK"
    invoke-virtual v14, v15, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    invoke-virtual v14, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v14
    invoke-virtual v2, v13, v14, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String; Ljava/lang/String;)V
    const-string v13, "GET"
    move-object/from16 v0, v18
    invoke-virtual v0, v13, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v13
    if-nez v13, +16bh
    new-instance v3, Landroid/os/Bundle;
    invoke-direct v3, Landroid/os/Bundle;-><init>()V
    invoke-virtual/range v19, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    move-result-object v13
    invoke-interface v13, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v7
    invoke-interface v7, Ljava/util/Iterator;->hasNext()Z
    move-result v13
    if-eqz v13, +01ah
    invoke-interface v7, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v8
    check-cast v8, Ljava/lang/String;
    move-object/from16 v0, v19
    invoke-virtual v0, v8, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v10
    instance-of v13, v10, [B
    if-eqz v13, -014h
    check-cast v10, [B
    check-cast v10, [B
    invoke-virtual v3, v8, v10, Landroid/os/Bundle;->putByteArray(Ljava/lang/String; [B)V
    goto -1dh
    const-string v13, "method"
    move-object/from16 v0, v19
    invoke-virtual v0, v13, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    move-result v13
    if-nez v13, +00bh
    const-string v13, "method"
    move-object/from16 v0, v19
    move-object/from16 v1, v18
    invoke-virtual v0, v13, v1, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v13, "access_token"
    move-object/from16 v0, v19
    invoke-virtual v0, v13, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    move-result v13
    if-eqz v13, +015h
    const-string v13, "access_token"
    move-object/from16 v0, v19
    invoke-virtual v0, v13, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v13
    invoke-static v13, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4
    const-string v13, "access_token"
    move-object/from16 v0, v19
    invoke-virtual v0, v13, v4, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v13, "POST"
    invoke-virtual v2, v13, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    const-string v13, "Content-Type"
    new-instance v14, Ljava/lang/StringBuilder;
    invoke-direct v14, Ljava/lang/StringBuilder;-><init>()V
    const-string v15, "multipart/form-data;boundary="
    invoke-virtual v14, v15, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    invoke-virtual v14, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v14
    invoke-virtual v14, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v14
    invoke-virtual v2, v13, v14, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String; Ljava/lang/String;)V
    const/4 v13, 1
    invoke-virtual v2, v13, Ljava/net/HttpURLConnection;->setDoOutput(Z)V
    const/4 v13, 1
    invoke-virtual v2, v13, Ljava/net/HttpURLConnection;->setDoInput(Z)V
    const-string v13, "Connection"
    const-string v14, "Keep-Alive"
    invoke-virtual v2, v13, v14, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v2, Ljava/net/HttpURLConnection;->connect()V
    new-instance v9, Ljava/io/BufferedOutputStream;
    invoke-virtual v2, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;
    move-result-object v13
    invoke-direct v9, v13, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    const-string v14, "--"
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    move-object/from16 v0, v19
    invoke-static v0, v12, Lcom/facebook/android/Util;->encodePostBody(Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    const-string v14, "--"
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    invoke-virtual v3, Landroid/os/Bundle;->isEmpty()Z
    move-result v13
    if-nez v13, +082h
    invoke-virtual v3, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    move-result-object v13
    invoke-interface v13, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v7
    invoke-interface v7, Ljava/util/Iterator;->hasNext()Z
    move-result v13
    if-eqz v13, +074h
    invoke-interface v7, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v8
    check-cast v8, Ljava/lang/String;
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    const-string v14, "Content-Disposition: form-data; filename=""
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v8, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    const-string v14, """
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    const-string v14, "Content-Type: content/unknown"
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    invoke-virtual v3, v8, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    new-instance v13, Ljava/lang/StringBuilder;
    invoke-direct v13, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    const-string v14, "--"
    invoke-virtual v13, v14, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v13
    invoke-virtual v13, Ljava/lang/String;->getBytes()[B
    move-result-object v13
    invoke-virtual v9, v13, Ljava/io/OutputStream;->write([B)V
    goto -77h
    invoke-virtual v9, Ljava/io/OutputStream;->flush()V
    const-string v11, ""
    invoke-virtual v2, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;
    move-result-object v13
    invoke-static v13, Lcom/facebook/android/Util;->read(Ljava/io/InputStream;)Ljava/lang/String;
    move-result-object v11
    return-object v11
    move-exception v5
    invoke-virtual v2, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;
    move-result-object v13
    invoke-static v13, Lcom/facebook/android/Util;->read(Ljava/io/InputStream;)Ljava/lang/String;
    move-result-object v11
    goto -ah
.end method

.method public static parseJson(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 7
    const-string v2, "false"
    invoke-virtual v6, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +00ah
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "request failed"
    invoke-direct v2, v3, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    throw v2
    const-string v2, "true"
    invoke-virtual v6, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +004h
    const-string v6, "{value : true}"
    new-instance v1, Lorg/json/JSONObject;
    invoke-direct v1, v6, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    const-string v2, "error"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +01bh
    const-string v2, "error"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    move-result-object v0
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "message"
    invoke-virtual v0, v3, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    const-string v4, "type"
    invoke-virtual v0, v4, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4
    const/4 v5, 0
    invoke-direct v2, v3, v4, v5, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String; Ljava/lang/String; I)V
    throw v2
    const-string v2, "error_code"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +022h
    const-string v2, "error_msg"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +01ah
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "error_msg"
    invoke-virtual v1, v3, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    const-string v4, ""
    const-string v5, "error_code"
    invoke-virtual v1, v5, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5
    invoke-static v5, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v5
    invoke-direct v2, v3, v4, v5, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String; Ljava/lang/String; I)V
    throw v2
    const-string v2, "error_code"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +016h
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "request failed"
    const-string v4, ""
    const-string v5, "error_code"
    invoke-virtual v1, v5, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5
    invoke-static v5, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v5
    invoke-direct v2, v3, v4, v5, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String; Ljava/lang/String; I)V
    throw v2
    const-string v2, "error_msg"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +00eh
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "error_msg"
    invoke-virtual v1, v3, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    invoke-direct v2, v3, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    throw v2
    const-string v2, "error_reason"
    invoke-virtual v1, v2, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +00eh
    new-instance v2, Lcom/facebook/android/FacebookError;
    const-string v3, "error_reason"
    invoke-virtual v1, v3, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    invoke-direct v2, v3, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    throw v2
    return-object v1
.end method

.method public static parseUrl(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 6
    const-string v3, "fbconnect"
    const-string v4, "http"
    invoke-virtual v5, v3, v4, Ljava/lang/String;->replace(Ljava/lang/CharSequence; Ljava/lang/CharSequence;)Ljava/lang/String;
    move-result-object v5
    new-instance v2, Ljava/net/URL;
    invoke-direct v2, v5, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, Ljava/net/URL;->getQuery()Ljava/lang/String;
    move-result-object v3
    invoke-static v3, Lcom/facebook/android/Util;->decodeUrl(Ljava/lang/String;)Landroid/os/Bundle;
    move-result-object v0
    invoke-virtual v2, Ljava/net/URL;->getRef()Ljava/lang/String;
    move-result-object v3
    invoke-static v3, Lcom/facebook/android/Util;->decodeUrl(Ljava/lang/String;)Landroid/os/Bundle;
    move-result-object v3
    invoke-virtual v0, v3, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V
    return-object v0
    move-exception v1
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    goto -7h
.end method

.method private static read(Ljava/io/InputStream;)Ljava/lang/String;
    .registers 6
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    new-instance v1, Ljava/io/BufferedReader;
    new-instance v3, Ljava/io/InputStreamReader;
    invoke-direct v3, v5, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V
    const/16 v4, 1000
    invoke-direct v1, v3, v4, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader; I)V
    invoke-virtual v1, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +00ah
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v1, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    move-result-object v0
    goto -9h
    invoke-virtual v5, Ljava/io/InputStream;->close()V
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    return-object v3
.end method

.method public static showAlert(Landroid/content/Context; Ljava/lang/String; Ljava/lang/String;)V
    .registers 5
    new-instance v0, Landroid/app/AlertDialog$Builder;
    invoke-direct v0, v2, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V
    invoke-virtual v0, v3, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    invoke-virtual v0, v4, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    invoke-virtual v0, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
    move-result-object v1
    invoke-virtual v1, Landroid/app/AlertDialog;->show()V
    return-void
.end method
