package com.facebook.android;
public class Facebook {
    public static final String CANCEL_URI = "fbconnect://cancel";
    private static final int DEFAULT_AUTH_ACTIVITY_CODE = 32665;
    protected static String DIALOG_BASE_URL = "";
    public static final String EXPIRES = "expires_in";
    public static final String FB_APP_SIGNATURE = "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2";
    public static final int FORCE_DIALOG_AUTH = 255;
    protected static String GRAPH_BASE_URL = "";
    private static final String LOGIN = "oauth";
    public static final String REDIRECT_URI = "fbconnect://success";
    protected static String RESTSERVER_URL = "";
    public static final String SINGLE_SIGN_ON_DISABLED = "service_disabled";
    public static final String TOKEN = "access_token";
    private final long REFRESH_TOKEN_BARRIER;
    private long mAccessExpires;
    private String mAccessToken;
    private String mAppId;
    private android.app.Activity mAuthActivity;
    private int mAuthActivityCode;
    private com.facebook.android.Facebook$DialogListener mAuthDialogListener;
    private String[] mAuthPermissions;
    private long mLastAccessUpdate;

    static Facebook()
    {
        com.facebook.android.Facebook.DIALOG_BASE_URL = "https://m.facebook.com/dialog/";
        com.facebook.android.Facebook.GRAPH_BASE_URL = "https://graph.facebook.com/";
        com.facebook.android.Facebook.RESTSERVER_URL = "https://api.facebook.com/restserver.php";
        return;
    }

    public Facebook(String p4)
    {
        this.mAccessToken = 0;
        this.mLastAccessUpdate = 0;
        this.mAccessExpires = 0;
        this.REFRESH_TOKEN_BARRIER = 86400000;
        if (p4 != null) {
            this.mAppId = p4;
            return;
        } else {
            throw new IllegalArgumentException("You must specify your application ID when instantiating a Facebook object. See README for details.");
        }
    }

    static synthetic com.facebook.android.Facebook$DialogListener access$000(com.facebook.android.Facebook p1)
    {
        return p1.mAuthDialogListener;
    }

    static synthetic String access$100(com.facebook.android.Facebook p1)
    {
        return p1.mAccessToken;
    }

    private void startDialogAuth(android.app.Activity p4, String[] p5)
    {
        android.os.Bundle v0_1 = new android.os.Bundle();
        if (p5.length > 0) {
            v0_1.putString("scope", android.text.TextUtils.join(",", p5));
        }
        android.webkit.CookieSyncManager.createInstance(p4);
        this.dialog(p4, "oauth", v0_1, new com.facebook.android.Facebook$1(this));
        return;
    }

    private boolean startSingleSignOn(android.app.Activity p6, String p7, String[] p8, int p9)
    {
        int v0 = 1;
        android.content.Intent v2_1 = new android.content.Intent();
        v2_1.setClassName("com.facebook.katana", "com.facebook.katana.ProxyAuth");
        v2_1.putExtra("client_id", p7);
        if (p8.length > 0) {
            v2_1.putExtra("scope", android.text.TextUtils.join(",", p8));
        }
        int v3_2;
        if (this.validateActivityIntent(p6, v2_1)) {
            this.mAuthActivity = p6;
            this.mAuthPermissions = p8;
            this.mAuthActivityCode = p9;
            try {
                p6.startActivityForResult(v2_1, p9);
            } catch (android.content.ActivityNotFoundException v1) {
                v0 = 0;
            }
            v3_2 = v0;
        } else {
            v3_2 = 0;
        }
        return v3_2;
    }

    private boolean validateActivityIntent(android.content.Context p4, android.content.Intent p5)
    {
        boolean v1_0 = 0;
        android.content.pm.ResolveInfo v0 = p4.getPackageManager().resolveActivity(p5, 0);
        if (v0 != null) {
            v1_0 = this.validateAppSignatureForPackage(p4, v0.activityInfo.packageName);
        }
        return v1_0;
    }

    private boolean validateAppSignatureForPackage(android.content.Context p10, String p11)
    {
        int v6 = 0;
        try {
            android.content.pm.Signature[] v0 = p10.getPackageManager().getPackageInfo(p11, 64).signatures;
            int v2 = 0;
        } catch (android.content.pm.PackageManager$NameNotFoundException v1) {
            return v6;
        }
        while (v2 < v0.length) {
            if (!v0[v2].toCharsString().equals("30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2")) {
                v2++;
            } else {
                v6 = 1;
                break;
            }
        }
        return v6;
    }

    private boolean validateServiceIntent(android.content.Context p4, android.content.Intent p5)
    {
        boolean v1_0 = 0;
        android.content.pm.ResolveInfo v0 = p4.getPackageManager().resolveService(p5, 0);
        if (v0 != null) {
            v1_0 = this.validateAppSignatureForPackage(p4, v0.serviceInfo.packageName);
        }
        return v1_0;
    }

    public void authorize(android.app.Activity p3, com.facebook.android.Facebook$DialogListener p4)
    {
        String[] v0_1 = new String[0];
        this.authorize(p3, v0_1, 32665, p4);
        return;
    }

    public void authorize(android.app.Activity p3, String[] p4, int p5, com.facebook.android.Facebook$DialogListener p6)
    {
        boolean v0 = 0;
        this.mAuthDialogListener = p6;
        if (p5 >= 0) {
            v0 = this.startSingleSignOn(p3, this.mAppId, p4, p5);
        }
        if (!v0) {
            this.startDialogAuth(p3, p4);
        }
        return;
    }

    public void authorize(android.app.Activity p2, String[] p3, com.facebook.android.Facebook$DialogListener p4)
    {
        this.authorize(p2, p3, 32665, p4);
        return;
    }

    public void authorizeCallback(int p8, int p9, android.content.Intent p10)
    {
        if (p8 == this.mAuthActivityCode) {
            if (p9 != -1) {
                if (p9 == 0) {
                    if (p10 == null) {
                        com.facebook.android.Util.logd("Facebook-authorize", "Login canceled by user.");
                        this.mAuthDialogListener.onCancel();
                    } else {
                        com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login failed: ").append(p10.getStringExtra("error")).toString());
                        this.mAuthDialogListener.onError(new com.facebook.android.DialogError(p10.getStringExtra("error"), p10.getIntExtra("error_code", -1), p10.getStringExtra("failing_url")));
                    }
                }
            } else {
                String v1 = p10.getStringExtra("error");
                if (v1 == null) {
                    v1 = p10.getStringExtra("error_type");
                }
                if (v1 == null) {
                    this.setAccessToken(p10.getStringExtra("access_token"));
                    this.setAccessExpiresIn(p10.getStringExtra("expires_in"));
                    if (!this.isSessionValid()) {
                        this.mAuthDialogListener.onFacebookError(new com.facebook.android.FacebookError("Failed to receive access token."));
                    } else {
                        com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login Success! access_token=").append(this.getAccessToken()).append(" expires=").append(this.getAccessExpires()).toString());
                        this.mAuthDialogListener.onComplete(p10.getExtras());
                    }
                } else {
                    if ((!v1.equals("service_disabled")) && (!v1.equals("AndroidAuthKillSwitchException"))) {
                        if ((!v1.equals("access_denied")) && (!v1.equals("OAuthAccessDeniedException"))) {
                            String v0 = p10.getStringExtra("error_description");
                            if (v0 != null) {
                                v1 = new StringBuilder().append(v1).append(":").append(v0).toString();
                            }
                            com.facebook.android.Util.logd("Facebook-authorize", new StringBuilder().append("Login failed: ").append(v1).toString());
                            this.mAuthDialogListener.onFacebookError(new com.facebook.android.FacebookError(v1));
                        } else {
                            com.facebook.android.Util.logd("Facebook-authorize", "Login canceled by user.");
                            this.mAuthDialogListener.onCancel();
                        }
                    } else {
                        com.facebook.android.Util.logd("Facebook-authorize", "Hosted auth currently disabled. Retrying dialog auth...");
                        this.startDialogAuth(this.mAuthActivity, this.mAuthPermissions);
                    }
                }
            }
        }
        return;
    }

    public void dialog(android.content.Context p5, String p6, android.os.Bundle p7, com.facebook.android.Facebook$DialogListener p8)
    {
        String v0 = new StringBuilder().append(com.facebook.android.Facebook.DIALOG_BASE_URL).append(p6).toString();
        p7.putString("display", "touch");
        p7.putString("redirect_uri", "fbconnect://success");
        if (!p6.equals("oauth")) {
            p7.putString("app_id", this.mAppId);
        } else {
            p7.putString("type", "user_agent");
            p7.putString("client_id", this.mAppId);
        }
        if (this.isSessionValid()) {
            p7.putString("access_token", this.getAccessToken());
        }
        String v1 = new StringBuilder().append(v0).append("?").append(com.facebook.android.Util.encodeUrl(p7)).toString();
        if (p5.checkCallingOrSelfPermission("android.permission.INTERNET") == 0) {
            new com.facebook.android.FbDialog(p5, v1, p8).show();
        } else {
            com.facebook.android.Util.showAlert(p5, "Error", "Application requires permission to access the Internet");
        }
        return;
    }

    public void dialog(android.content.Context p2, String p3, com.facebook.android.Facebook$DialogListener p4)
    {
        this.dialog(p2, p3, new android.os.Bundle(), p4);
        return;
    }

    public boolean extendAccessToken(android.content.Context p4, com.facebook.android.Facebook$ServiceListener p5)
    {
        boolean v1_0;
        android.content.Intent v0_1 = new android.content.Intent();
        v0_1.setClassName("com.facebook.katana", "com.facebook.katana.platform.TokenRefreshService");
        if (this.validateServiceIntent(p4, v0_1)) {
            v1_0 = p4.bindService(v0_1, new com.facebook.android.Facebook$TokenRefreshServiceConnection(this, p4, p5), 1);
        } else {
            v1_0 = 0;
        }
        return v1_0;
    }

    public boolean extendAccessTokenIfNeeded(android.content.Context p2, com.facebook.android.Facebook$ServiceListener p3)
    {
        int v0_1;
        if (!this.shouldExtendAccessToken()) {
            v0_1 = 1;
        } else {
            v0_1 = this.extendAccessToken(p2, p3);
        }
        return v0_1;
    }

    public long getAccessExpires()
    {
        return this.mAccessExpires;
    }

    public String getAccessToken()
    {
        return this.mAccessToken;
    }

    public String getAppId()
    {
        return this.mAppId;
    }

    public boolean isSessionValid()
    {
        if ((this.getAccessToken() == null) || ((this.getAccessExpires() != 0) && (System.currentTimeMillis() >= this.getAccessExpires()))) {
            int v0_2 = 0;
        } else {
            v0_2 = 1;
        }
        return v0_2;
    }

    public String logout(android.content.Context p5)
    {
        com.facebook.android.Util.clearCookies(p5);
        android.os.Bundle v0_1 = new android.os.Bundle();
        v0_1.putString("method", "auth.expireSession");
        String v1 = this.request(v0_1);
        this.setAccessToken(0);
        this.setAccessExpires(0);
        return v1;
    }

    public String request(android.os.Bundle p3)
    {
        if (p3.containsKey("method")) {
            return this.request(0, p3, "GET");
        } else {
            throw new IllegalArgumentException("API method must be specified. (parameters must contain key \"method\" and value). See http://developers.facebook.com/docs/reference/rest/");
        }
    }

    public String request(String p3)
    {
        return this.request(p3, new android.os.Bundle(), "GET");
    }

    public String request(String p2, android.os.Bundle p3)
    {
        return this.request(p2, p3, "GET");
    }

    public String request(String p4, android.os.Bundle p5, String p6)
    {
        p5.putString("format", "json");
        if (this.isSessionValid()) {
            p5.putString("access_token", this.getAccessToken());
        }
        String v0;
        if (p4 == null) {
            v0 = com.facebook.android.Facebook.RESTSERVER_URL;
        } else {
            v0 = new StringBuilder().append(com.facebook.android.Facebook.GRAPH_BASE_URL).append(p4).toString();
        }
        return com.facebook.android.Util.openUrl(v0, p6, p5);
    }

    public void setAccessExpires(long p1)
    {
        this.mAccessExpires = p1;
        return;
    }

    public void setAccessExpiresIn(String p9)
    {
        if (p9 != null) {
            long v0;
            if (!p9.equals("0")) {
                v0 = (System.currentTimeMillis() + (Long.parseLong(p9) * 1000));
            } else {
                v0 = 0;
            }
            this.setAccessExpires(v0);
        }
        return;
    }

    public void setAccessToken(String p3)
    {
        this.mAccessToken = p3;
        this.mLastAccessUpdate = System.currentTimeMillis();
        return;
    }

    public void setAppId(String p1)
    {
        this.mAppId = p1;
        return;
    }

    public boolean shouldExtendAccessToken()
    {
        if ((!this.isSessionValid()) || ((System.currentTimeMillis() - this.mLastAccessUpdate) < 86400000)) {
            int v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }
}
