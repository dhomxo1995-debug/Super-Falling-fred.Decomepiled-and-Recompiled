.class public Lcom/facebook/android/FbDialog;
.super Landroid/app/Dialog;

.field static final DIMENSIONS_DIFF_LANDSCAPE:[F
.field static final DIMENSIONS_DIFF_PORTRAIT:[F
.field static final DISPLAY_STRING:Ljava/lang/String;
.field static final FB_BLUE:I
.field static final FB_ICON:Ljava/lang/String;
.field static final FILL:Landroid/widget/FrameLayout$LayoutParams;
.field static final MARGIN:I
.field static final PADDING:I
.field private mContent:Landroid/widget/FrameLayout;
.field private mCrossImage:Landroid/widget/ImageView;
.field private mListener:Lcom/facebook/android/Facebook$DialogListener;
.field private mSpinner:Landroid/app/ProgressDialog;
.field private mUrl:Ljava/lang/String;
.field private mWebView:Landroid/webkit/WebView;

.method static constructor <clinit>()V
    .registers 3
    const/4 v2, 2
    const/4 v1, -1
    new-array v0, v2, [F
    fill-array-data v0, +0000014h
    sput-object v0, Lcom/facebook/android/FbDialog;->DIMENSIONS_DIFF_LANDSCAPE [F
    new-array v0, v2, [F
    fill-array-data v0, +0000015h
    sput-object v0, Lcom/facebook/android/FbDialog;->DIMENSIONS_DIFF_PORTRAIT [F
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;
    invoke-direct v0, v1, v1, Landroid/widget/FrameLayout$LayoutParams;-><init>(I I)V
    sput-object v0, Lcom/facebook/android/FbDialog;->FILL Landroid/widget/FrameLayout$LayoutParams;
    return-void
    fill-array-data-payload b'\x00\x00\xa0A\x00\x00pB' | \x00\x00\xa0\x41\x00\x00\x70\x42
    fill-array-data-payload b'\x00\x00 B\x00\x00pB' | \x00\x00\x20\x42\x00\x00\x70\x42
.end method

.method public constructor <init>(Landroid/content/Context; Ljava/lang/String; Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 5
    const v0, 16973840
    invoke-direct v1, v2, v0, Landroid/app/Dialog;-><init>(Landroid/content/Context; I)V
    iput-object v3, v1, Lcom/facebook/android/FbDialog;->mUrl Ljava/lang/String;
    iput-object v4, v1, Lcom/facebook/android/FbDialog;->mListener Lcom/facebook/android/Facebook$DialogListener;
    return-void
.end method

.method static synthetic access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FbDialog;->mListener Lcom/facebook/android/Facebook$DialogListener;
    return-object v0
.end method

.method static synthetic access$200(Lcom/facebook/android/FbDialog;)Landroid/app/ProgressDialog;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FbDialog;->mSpinner Landroid/app/ProgressDialog;
    return-object v0
.end method

.method static synthetic access$300(Lcom/facebook/android/FbDialog;)Landroid/widget/FrameLayout;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FbDialog;->mContent Landroid/widget/FrameLayout;
    return-object v0
.end method

.method static synthetic access$400(Lcom/facebook/android/FbDialog;)Landroid/webkit/WebView;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    return-object v0
.end method

.method static synthetic access$500(Lcom/facebook/android/FbDialog;)Landroid/widget/ImageView;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    return-object v0
.end method

.method private createCrossImage()V
    .registers 4
    new-instance v1, Landroid/widget/ImageView;
    invoke-virtual v3, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v2
    invoke-direct v1, v2, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    iput-object v1, v3, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    iget-object v1, v3, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    new-instance v2, Lcom/facebook/android/FbDialog$1;
    invoke-direct v2, v3, Lcom/facebook/android/FbDialog$1;-><init>(Lcom/facebook/android/FbDialog;)V
    invoke-virtual v1, v2, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    invoke-virtual v3, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v1
    invoke-virtual v1, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    move-result-object v1
    const/high16 v2, 2130837504
    invoke-virtual v1, v2, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;
    move-result-object v0
    iget-object v1, v3, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    invoke-virtual v1, v0, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    iget-object v1, v3, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    const/4 v2, 4
    invoke-virtual v1, v2, Landroid/widget/ImageView;->setVisibility(I)V
    return-void
.end method

.method private setUpWebView(I)V
    .registers 7
    const/4 v4, 0
    new-instance v0, Landroid/widget/LinearLayout;
    invoke-virtual v5, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v1
    invoke-direct v0, v1, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    new-instance v1, Landroid/webkit/WebView;
    invoke-virtual v5, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v2
    invoke-direct v1, v2, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    iput-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    invoke-virtual v1, v4, Landroid/webkit/WebView;->setVerticalScrollBarEnabled(Z)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    invoke-virtual v1, v4, Landroid/webkit/WebView;->setHorizontalScrollBarEnabled(Z)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    new-instance v2, Lcom/facebook/android/FbDialog$FbWebViewClient;
    const/4 v3, 0
    invoke-direct v2, v5, v3, Lcom/facebook/android/FbDialog$FbWebViewClient;-><init>(Lcom/facebook/android/FbDialog; Lcom/facebook/android/FbDialog$1;)V
    invoke-virtual v1, v2, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    invoke-virtual v1, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v1
    const/4 v2, 1
    invoke-virtual v1, v2, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    iget-object v2, v5, Lcom/facebook/android/FbDialog;->mUrl Ljava/lang/String;
    invoke-virtual v1, v2, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    sget-object v2, Lcom/facebook/android/FbDialog;->FILL Landroid/widget/FrameLayout$LayoutParams;
    invoke-virtual v1, v2, Landroid/webkit/WebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    const/4 v2, 4
    invoke-virtual v1, v2, Landroid/webkit/WebView;->setVisibility(I)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    invoke-virtual v1, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v1
    invoke-virtual v1, v4, Landroid/webkit/WebSettings;->setSavePassword(Z)V
    invoke-virtual v0, v6, v6, v6, v6, Landroid/widget/LinearLayout;->setPadding(I I I I)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mWebView Landroid/webkit/WebView;
    invoke-virtual v0, v1, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    iget-object v1, v5, Lcom/facebook/android/FbDialog;->mContent Landroid/widget/FrameLayout;
    invoke-virtual v1, v0, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 8
    const/4 v3, 1
    const/4 v5, -1
    const/4 v4, -2
    invoke-super v6, v7, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V
    new-instance v1, Landroid/app/ProgressDialog;
    invoke-virtual v6, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v2
    invoke-direct v1, v2, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V
    iput-object v1, v6, Lcom/facebook/android/FbDialog;->mSpinner Landroid/app/ProgressDialog;
    iget-object v1, v6, Lcom/facebook/android/FbDialog;->mSpinner Landroid/app/ProgressDialog;
    invoke-virtual v1, v3, Landroid/app/ProgressDialog;->requestWindowFeature(I)Z
    iget-object v1, v6, Lcom/facebook/android/FbDialog;->mSpinner Landroid/app/ProgressDialog;
    const-string v2, "Loading..."
    invoke-virtual v1, v2, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V
    invoke-virtual v6, v3, Lcom/facebook/android/FbDialog;->requestWindowFeature(I)Z
    new-instance v1, Landroid/widget/FrameLayout;
    invoke-virtual v6, Lcom/facebook/android/FbDialog;->getContext()Landroid/content/Context;
    move-result-object v2
    invoke-direct v1, v2, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    iput-object v1, v6, Lcom/facebook/android/FbDialog;->mContent Landroid/widget/FrameLayout;
    invoke-direct v6, Lcom/facebook/android/FbDialog;->createCrossImage()V
    iget-object v1, v6, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    invoke-virtual v1, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;
    move-result-object v1
    invoke-virtual v1, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I
    move-result v0
    div-int/lit8 v1, v0, 2
    invoke-direct v6, v1, Lcom/facebook/android/FbDialog;->setUpWebView(I)V
    iget-object v1, v6, Lcom/facebook/android/FbDialog;->mContent Landroid/widget/FrameLayout;
    iget-object v2, v6, Lcom/facebook/android/FbDialog;->mCrossImage Landroid/widget/ImageView;
    new-instance v3, Landroid/view/ViewGroup$LayoutParams;
    invoke-direct v3, v4, v4, Landroid/view/ViewGroup$LayoutParams;-><init>(I I)V
    invoke-virtual v1, v2, v3, Landroid/widget/FrameLayout;->addView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    iget-object v1, v6, Lcom/facebook/android/FbDialog;->mContent Landroid/widget/FrameLayout;
    new-instance v2, Landroid/view/ViewGroup$LayoutParams;
    invoke-direct v2, v5, v5, Landroid/view/ViewGroup$LayoutParams;-><init>(I I)V
    invoke-virtual v6, v1, v2, Lcom/facebook/android/FbDialog;->addContentView(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    return-void
.end method
