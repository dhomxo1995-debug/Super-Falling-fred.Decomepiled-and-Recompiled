.class 0x0 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;
.super Landroid/os/Handler;

.field final synthetic this$1:Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;

.method constructor <init>(Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;)V
    .registers 2
    iput-object v1, v0, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    invoke-direct v0, Landroid/os/Handler;-><init>()V
    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .registers 12
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    const-string v7, "access_token"
    invoke-virtual v6, v7, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    const-string v7, "expires_in"
    invoke-virtual v6, v7, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J
    move-result-wide v6
    const-wide/16 v8, 1000
    mul-long v2, v6, v8
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    invoke-virtual v6, Landroid/os/Bundle;->clone()Ljava/lang/Object;
    move-result-object v4
    check-cast v4, Landroid/os/Bundle;
    const-string v6, "expires_in"
    invoke-virtual v4, v6, v2, v3, Landroid/os/Bundle;->putLong(Ljava/lang/String; J)V
    if-eqz v5, +027h
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->this$0 Lcom/facebook/android/Facebook;
    invoke-virtual v6, v5, Lcom/facebook/android/Facebook;->setAccessToken(Ljava/lang/String;)V
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->this$0 Lcom/facebook/android/Facebook;
    invoke-virtual v6, v2, v3, Lcom/facebook/android/Facebook;->setAccessExpires(J)V
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    if-eqz v6, +009h
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    invoke-interface v6, v4, Lcom/facebook/android/Facebook$ServiceListener;->onComplete(Landroid/os/Bundle;)V
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->applicationsContext Landroid/content/Context;
    iget-object v7, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    invoke-virtual v6, v7, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    return-void
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    if-eqz v6, -00eh
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    const-string v7, "error"
    invoke-virtual v6, v7, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    const-string v7, "error_code"
    invoke-virtual v6, v7, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    move-result v6
    if-eqz v6, +01ah
    invoke-virtual v11, Landroid/os/Message;->getData()Landroid/os/Bundle;
    move-result-object v6
    const-string v7, "error_code"
    invoke-virtual v6, v7, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I
    move-result v1
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    new-instance v7, Lcom/facebook/android/FacebookError;
    const/4 v8, 0
    invoke-direct v7, v0, v8, v1, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String; Ljava/lang/String; I)V
    invoke-interface v6, v7, Lcom/facebook/android/Facebook$ServiceListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    goto -3dh
    iget-object v6, v10, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;->this$1 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    iget-object v6, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    new-instance v7, Ljava/lang/Error;
    if-eqz v0, +009h
    invoke-direct v7, v0, Ljava/lang/Error;-><init>(Ljava/lang/String;)V
    invoke-interface v6, v7, Lcom/facebook/android/Facebook$ServiceListener;->onError(Ljava/lang/Error;)V
    goto -4ch
    const-string v0, "Unknown service error"
    goto -9h
.end method
