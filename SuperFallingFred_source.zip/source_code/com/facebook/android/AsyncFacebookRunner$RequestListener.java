package com.facebook.android;
public interface AsyncFacebookRunner$RequestListener {

    public abstract void onComplete(String p0, Object p1);

    public abstract void onFacebookError(com.facebook.android.FacebookError p0, Object p1);

    public abstract void onFileNotFoundException(java.io.FileNotFoundException p0, Object p1);

    public abstract void onIOException(java.io.IOException p0, Object p1);

    public abstract void onMalformedURLException(java.net.MalformedURLException p0, Object p1);
}
