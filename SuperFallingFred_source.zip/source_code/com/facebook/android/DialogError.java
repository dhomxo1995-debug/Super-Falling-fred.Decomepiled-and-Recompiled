package com.facebook.android;
public class DialogError extends java.lang.Throwable {
    private static final long serialVersionUID = 1;
    private int mErrorCode;
    private String mFailingUrl;

    public DialogError(String p1, int p2, String p3)
    {
        super(p1);
        super.mErrorCode = p2;
        super.mFailingUrl = p3;
        return;
    }

    int getErrorCode()
    {
        return this.mErrorCode;
    }

    String getFailingUrl()
    {
        return this.mFailingUrl;
    }
}
