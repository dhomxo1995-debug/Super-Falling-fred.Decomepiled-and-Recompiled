.class 0x0 Lcom/facebook/android/AsyncFacebookRunner$1;
.super Ljava/lang/Thread;

.field final synthetic this$0:Lcom/facebook/android/AsyncFacebookRunner;
.field final synthetic val$context:Landroid/content/Context;
.field final synthetic val$listener:Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
.field final synthetic val$state:Ljava/lang/Object;

.method constructor <init>(Lcom/facebook/android/AsyncFacebookRunner; Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 5
    iput-object v1, v0, Lcom/facebook/android/AsyncFacebookRunner$1;->this$0 Lcom/facebook/android/AsyncFacebookRunner;
    iput-object v2, v0, Lcom/facebook/android/AsyncFacebookRunner$1;->val$context Landroid/content/Context;
    iput-object v3, v0, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iput-object v4, v0, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-direct v0, Ljava/lang/Thread;-><init>()V
    return-void
.end method

.method public run()V
    .registers 6
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->this$0 Lcom/facebook/android/AsyncFacebookRunner;
    iget-object v2, v2, Lcom/facebook/android/AsyncFacebookRunner;->fb Lcom/facebook/android/Facebook;
    iget-object v3, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$context Landroid/content/Context;
    invoke-virtual v2, v3, Lcom/facebook/android/Facebook;->logout(Landroid/content/Context;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/String;->length()I
    move-result v2
    if-eqz v2, +00ah
    const-string v2, "false"
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +011h
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    new-instance v3, Lcom/facebook/android/FacebookError;
    const-string v4, "auth.expireSession failed"
    invoke-direct v3, v4, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    iget-object v4, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-interface v2, v3, v4, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onFacebookError(Lcom/facebook/android/FacebookError; Ljava/lang/Object;)V
    return-void
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-interface v2, v1, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onComplete(Ljava/lang/String; Ljava/lang/Object;)V
    goto -8h
    move-exception v0
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onFileNotFoundException(Ljava/io/FileNotFoundException; Ljava/lang/Object;)V
    goto -11h
    move-exception v0
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onMalformedURLException(Ljava/net/MalformedURLException; Ljava/lang/Object;)V
    goto -1ah
    move-exception v0
    iget-object v2, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v5, Lcom/facebook/android/AsyncFacebookRunner$1;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onIOException(Ljava/io/IOException; Ljava/lang/Object;)V
    goto -23h
.end method
