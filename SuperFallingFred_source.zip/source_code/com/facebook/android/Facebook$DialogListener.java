package com.facebook.android;
public interface Facebook$DialogListener {

    public abstract void onCancel();

    public abstract void onComplete(android.os.Bundle p0);

    public abstract void onError(com.facebook.android.DialogError p0);

    public abstract void onFacebookError(com.facebook.android.FacebookError p0);
}
