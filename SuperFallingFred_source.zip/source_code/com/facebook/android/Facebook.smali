.class public Lcom/facebook/android/Facebook;
.super Ljava/lang/Object;

.field public static final CANCEL_URI:Ljava/lang/String;
.field private static final DEFAULT_AUTH_ACTIVITY_CODE:I
.field protected static DIALOG_BASE_URL:Ljava/lang/String;
.field public static final EXPIRES:Ljava/lang/String;
.field public static final FB_APP_SIGNATURE:Ljava/lang/String;
.field public static final FORCE_DIALOG_AUTH:I
.field protected static GRAPH_BASE_URL:Ljava/lang/String;
.field private static final LOGIN:Ljava/lang/String;
.field public static final REDIRECT_URI:Ljava/lang/String;
.field protected static RESTSERVER_URL:Ljava/lang/String;
.field public static final SINGLE_SIGN_ON_DISABLED:Ljava/lang/String;
.field public static final TOKEN:Ljava/lang/String;
.field private final REFRESH_TOKEN_BARRIER:J
.field private mAccessExpires:J
.field private mAccessToken:Ljava/lang/String;
.field private mAppId:Ljava/lang/String;
.field private mAuthActivity:Landroid/app/Activity;
.field private mAuthActivityCode:I
.field private mAuthDialogListener:Lcom/facebook/android/Facebook$DialogListener;
.field private mAuthPermissions:[Ljava/lang/String;
.field private mLastAccessUpdate:J

.method static constructor <clinit>()V
    .registers 1
    const-string v0, "https://m.facebook.com/dialog/"
    sput-object v0, Lcom/facebook/android/Facebook;->DIALOG_BASE_URL Ljava/lang/String;
    const-string v0, "https://graph.facebook.com/"
    sput-object v0, Lcom/facebook/android/Facebook;->GRAPH_BASE_URL Ljava/lang/String;
    const-string v0, "https://api.facebook.com/restserver.php"
    sput-object v0, Lcom/facebook/android/Facebook;->RESTSERVER_URL Ljava/lang/String;
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 5
    const-wide/16 v1, 0
    invoke-direct v3, Ljava/lang/Object;-><init>()V
    const/4 v0, 0
    iput-object v0, v3, Lcom/facebook/android/Facebook;->mAccessToken Ljava/lang/String;
    iput-wide v1, v3, Lcom/facebook/android/Facebook;->mLastAccessUpdate J
    iput-wide v1, v3, Lcom/facebook/android/Facebook;->mAccessExpires J
    const-wide/32 v0, 86400000
    iput-wide v0, v3, Lcom/facebook/android/Facebook;->REFRESH_TOKEN_BARRIER J
    if-nez v4, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "You must specify your application ID when instantiating a Facebook object. See README for details."
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    iput-object v4, v3, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    return-void
.end method

.method static synthetic access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    return-object v0
.end method

.method static synthetic access$100(Lcom/facebook/android/Facebook;)Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/Facebook;->mAccessToken Ljava/lang/String;
    return-object v0
.end method

.method private startDialogAuth(Landroid/app/Activity; [Ljava/lang/String;)V
    .registers 6
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    array-length v1, v5
    if-lez v1, +00dh
    const-string v1, "scope"
    const-string v2, ","
    invoke-static v2, v5, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    invoke-static v4, Landroid/webkit/CookieSyncManager;->createInstance(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
    const-string v1, "oauth"
    new-instance v2, Lcom/facebook/android/Facebook$1;
    invoke-direct v2, v3, Lcom/facebook/android/Facebook$1;-><init>(Lcom/facebook/android/Facebook;)V
    invoke-virtual v3, v4, v1, v0, v2, Lcom/facebook/android/Facebook;->dialog(Landroid/content/Context; Ljava/lang/String; Landroid/os/Bundle; Lcom/facebook/android/Facebook$DialogListener;)V
    return-void
.end method

.method private startSingleSignOn(Landroid/app/Activity; Ljava/lang/String; [Ljava/lang/String; I)Z
    .registers 10
    const/4 v0, 1
    new-instance v2, Landroid/content/Intent;
    invoke-direct v2, Landroid/content/Intent;-><init>()V
    const-string v3, "com.facebook.katana"
    const-string v4, "com.facebook.katana.ProxyAuth"
    invoke-virtual v2, v3, v4, Landroid/content/Intent;->setClassName(Ljava/lang/String; Ljava/lang/String;)Landroid/content/Intent;
    const-string v3, "client_id"
    invoke-virtual v2, v3, v7, Landroid/content/Intent;->putExtra(Ljava/lang/String; Ljava/lang/String;)Landroid/content/Intent;
    array-length v3, v8
    if-lez v3, +00dh
    const-string v3, "scope"
    const-string v4, ","
    invoke-static v4, v8, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v4
    invoke-virtual v2, v3, v4, Landroid/content/Intent;->putExtra(Ljava/lang/String; Ljava/lang/String;)Landroid/content/Intent;
    invoke-direct v5, v6, v2, Lcom/facebook/android/Facebook;->validateActivityIntent(Landroid/content/Context; Landroid/content/Intent;)Z
    move-result v3
    if-nez v3, +004h
    const/4 v3, 0
    return v3
    iput-object v6, v5, Lcom/facebook/android/Facebook;->mAuthActivity Landroid/app/Activity;
    iput-object v8, v5, Lcom/facebook/android/Facebook;->mAuthPermissions [Ljava/lang/String;
    iput v9, v5, Lcom/facebook/android/Facebook;->mAuthActivityCode I
    invoke-virtual v6, v2, v9, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent; I)V
    move v3, v0
    goto -bh
    move-exception v1
    const/4 v0, 0
    goto -4h
.end method

.method private validateActivityIntent(Landroid/content/Context; Landroid/content/Intent;)Z
    .registers 6
    const/4 v1, 0
    invoke-virtual v4, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v2
    invoke-virtual v2, v5, v1, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent; I)Landroid/content/pm/ResolveInfo;
    move-result-object v0
    if-nez v0, +003h
    return v1
    iget-object v1, v0, Landroid/content/pm/ResolveInfo;->activityInfo Landroid/content/pm/ActivityInfo;
    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->packageName Ljava/lang/String;
    invoke-direct v3, v4, v1, Lcom/facebook/android/Facebook;->validateAppSignatureForPackage(Landroid/content/Context; Ljava/lang/String;)Z
    move-result v1
    goto -9h
.end method

.method private validateAppSignatureForPackage(Landroid/content/Context; Ljava/lang/String;)Z
    .registers 12
    const/4 v6, 0
    invoke-virtual v10, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v7
    const/16 v8, 64
    invoke-virtual v7, v11, v8, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String; I)Landroid/content/pm/PackageInfo;
    move-result-object v4
    iget-object v0, v4, Landroid/content/pm/PackageInfo;->signatures [Landroid/content/pm/Signature;
    array-length v3, v0
    const/4 v2, 0
    if-ge v2, v3, +011h
    aget-object v5, v0, v2
    invoke-virtual v5, Landroid/content/pm/Signature;->toCharsString()Ljava/lang/String;
    move-result-object v7
    const-string v8, "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2"
    invoke-virtual v7, v8, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v7
    if-eqz v7, +006h
    const/4 v6, 1
    return v6
    move-exception v1
    goto -2h
    add-int/lit8 v2, v2, 1
    goto -16h
.end method

.method private validateServiceIntent(Landroid/content/Context; Landroid/content/Intent;)Z
    .registers 6
    const/4 v1, 0
    invoke-virtual v4, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v2
    invoke-virtual v2, v5, v1, Landroid/content/pm/PackageManager;->resolveService(Landroid/content/Intent; I)Landroid/content/pm/ResolveInfo;
    move-result-object v0
    if-nez v0, +003h
    return v1
    iget-object v1, v0, Landroid/content/pm/ResolveInfo;->serviceInfo Landroid/content/pm/ServiceInfo;
    iget-object v1, v1, Landroid/content/pm/ServiceInfo;->packageName Ljava/lang/String;
    invoke-direct v3, v4, v1, Lcom/facebook/android/Facebook;->validateAppSignatureForPackage(Landroid/content/Context; Ljava/lang/String;)Z
    move-result v1
    goto -9h
.end method

.method public authorize(Landroid/app/Activity; Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 5
    const/4 v0, 0
    new-array v0, v0, [Ljava/lang/String;
    const/16 v1, 32665
    invoke-virtual v2, v3, v0, v1, v4, Lcom/facebook/android/Facebook;->authorize(Landroid/app/Activity; [Ljava/lang/String; I Lcom/facebook/android/Facebook$DialogListener;)V
    return-void
.end method

.method public authorize(Landroid/app/Activity; [Ljava/lang/String; I Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 7
    const/4 v0, 0
    iput-object v6, v2, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    if-ltz v5, +008h
    iget-object v1, v2, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    invoke-direct v2, v3, v1, v4, v5, Lcom/facebook/android/Facebook;->startSingleSignOn(Landroid/app/Activity; Ljava/lang/String; [Ljava/lang/String; I)Z
    move-result v0
    if-nez v0, +005h
    invoke-direct v2, v3, v4, Lcom/facebook/android/Facebook;->startDialogAuth(Landroid/app/Activity; [Ljava/lang/String;)V
    return-void
.end method

.method public authorize(Landroid/app/Activity; [Ljava/lang/String; Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 5
    const/16 v0, 32665
    invoke-virtual v1, v2, v3, v0, v4, Lcom/facebook/android/Facebook;->authorize(Landroid/app/Activity; [Ljava/lang/String; I Lcom/facebook/android/Facebook$DialogListener;)V
    return-void
.end method

.method public authorizeCallback(I I Landroid/content/Intent;)V
    .registers 11
    const/4 v6, -1
    iget v2, v7, Lcom/facebook/android/Facebook;->mAuthActivityCode I
    if-ne v8, v2, +032h
    if-ne v9, v6, +0ebh
    const-string v2, "error"
    invoke-virtual v10, v2, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    if-nez v1, +008h
    const-string v2, "error_type"
    invoke-virtual v10, v2, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    if-eqz v1, +080h
    const-string v2, "service_disabled"
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +00ah
    const-string v2, "AndroidAuthKillSwitchException"
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +011h
    const-string v2, "Facebook-authorize"
    const-string v3, "Hosted auth currently disabled. Retrying dialog auth..."
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthActivity Landroid/app/Activity;
    iget-object v3, v7, Lcom/facebook/android/Facebook;->mAuthPermissions [Ljava/lang/String;
    invoke-direct v7, v2, v3, Lcom/facebook/android/Facebook;->startDialogAuth(Landroid/app/Activity; [Ljava/lang/String;)V
    return-void
    const-string v2, "access_denied"
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +00ah
    const-string v2, "OAuthAccessDeniedException"
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +00fh
    const-string v2, "Facebook-authorize"
    const-string v3, "Login canceled by user."
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    invoke-interface v2, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    goto -1dh
    const-string v2, "error_description"
    invoke-virtual v10, v2, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +019h
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ":"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    const-string v2, "Facebook-authorize"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Login failed: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    new-instance v3, Lcom/facebook/android/FacebookError;
    invoke-direct v3, v1, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    invoke-interface v2, v3, Lcom/facebook/android/Facebook$DialogListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    goto -5fh
    const-string v2, "access_token"
    invoke-virtual v10, v2, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v7, v2, Lcom/facebook/android/Facebook;->setAccessToken(Ljava/lang/String;)V
    const-string v2, "expires_in"
    invoke-virtual v10, v2, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v7, v2, Lcom/facebook/android/Facebook;->setAccessExpiresIn(Ljava/lang/String;)V
    invoke-virtual v7, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v2
    if-eqz v2, +037h
    const-string v2, "Facebook-authorize"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Login Success! access_token="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v7, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, " expires="
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v7, Lcom/facebook/android/Facebook;->getAccessExpires()J
    move-result-wide v4
    invoke-virtual v3, v4, v5, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    invoke-virtual v10, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v3
    invoke-interface v2, v3, Lcom/facebook/android/Facebook$DialogListener;->onComplete(Landroid/os/Bundle;)V
    goto/16 -0abh
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    new-instance v3, Lcom/facebook/android/FacebookError;
    const-string v4, "Failed to receive access token."
    invoke-direct v3, v4, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    invoke-interface v2, v3, Lcom/facebook/android/Facebook$DialogListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    goto/16 -0b9h
    if-nez v9, -0bbh
    if-eqz v10, +03eh
    const-string v2, "Facebook-authorize"
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    const-string v4, "Login failed: "
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "error"
    invoke-virtual v10, v4, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    new-instance v3, Lcom/facebook/android/DialogError;
    const-string v4, "error"
    invoke-virtual v10, v4, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4
    const-string v5, "error_code"
    invoke-virtual v10, v5, v6, Landroid/content/Intent;->getIntExtra(Ljava/lang/String; I)I
    move-result v5
    const-string v6, "failing_url"
    invoke-virtual v10, v6, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6
    invoke-direct v3, v4, v5, v6, Lcom/facebook/android/DialogError;-><init>(Ljava/lang/String; I Ljava/lang/String;)V
    invoke-interface v2, v3, Lcom/facebook/android/Facebook$DialogListener;->onError(Lcom/facebook/android/DialogError;)V
    goto/16 -0f9h
    const-string v2, "Facebook-authorize"
    const-string v3, "Login canceled by user."
    invoke-static v2, v3, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v2, v7, Lcom/facebook/android/Facebook;->mAuthDialogListener Lcom/facebook/android/Facebook$DialogListener;
    invoke-interface v2, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    goto/16 -107h
.end method

.method public dialog(Landroid/content/Context; Ljava/lang/String; Landroid/os/Bundle; Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 9
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    sget-object v3, Lcom/facebook/android/Facebook;->DIALOG_BASE_URL Ljava/lang/String;
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    const-string v2, "display"
    const-string v3, "touch"
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v2, "redirect_uri"
    const-string v3, "fbconnect://success"
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v2, "oauth"
    invoke-virtual v6, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +04ah
    const-string v2, "type"
    const-string v3, "user_agent"
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    const-string v2, "client_id"
    iget-object v3, v4, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v4, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v2
    if-eqz v2, +00bh
    const-string v2, "access_token"
    invoke-virtual v4, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "?"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-static v7, Lcom/facebook/android/Util;->encodeUrl(Landroid/os/Bundle;)Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    const-string v2, "android.permission.INTERNET"
    invoke-virtual v5, v2, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    move-result v2
    if-eqz v2, +012h
    const-string v2, "Error"
    const-string v3, "Application requires permission to access the Internet"
    invoke-static v5, v2, v3, Lcom/facebook/android/Util;->showAlert(Landroid/content/Context; Ljava/lang/String; Ljava/lang/String;)V
    return-void
    const-string v2, "app_id"
    iget-object v3, v4, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    invoke-virtual v7, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    goto -41h
    new-instance v2, Lcom/facebook/android/FbDialog;
    invoke-direct v2, v5, v1, v8, Lcom/facebook/android/FbDialog;-><init>(Landroid/content/Context; Ljava/lang/String; Lcom/facebook/android/Facebook$DialogListener;)V
    invoke-virtual v2, Lcom/facebook/android/FbDialog;->show()V
    goto -11h
.end method

.method public dialog(Landroid/content/Context; Ljava/lang/String; Lcom/facebook/android/Facebook$DialogListener;)V
    .registers 5
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    invoke-virtual v1, v2, v3, v0, v4, Lcom/facebook/android/Facebook;->dialog(Landroid/content/Context; Ljava/lang/String; Landroid/os/Bundle; Lcom/facebook/android/Facebook$DialogListener;)V
    return-void
.end method

.method public extendAccessToken(Landroid/content/Context; Lcom/facebook/android/Facebook$ServiceListener;)Z
    .registers 6
    new-instance v0, Landroid/content/Intent;
    invoke-direct v0, Landroid/content/Intent;-><init>()V
    const-string v1, "com.facebook.katana"
    const-string v2, "com.facebook.katana.platform.TokenRefreshService"
    invoke-virtual v0, v1, v2, Landroid/content/Intent;->setClassName(Ljava/lang/String; Ljava/lang/String;)Landroid/content/Intent;
    invoke-direct v3, v4, v0, Lcom/facebook/android/Facebook;->validateServiceIntent(Landroid/content/Context; Landroid/content/Intent;)Z
    move-result v1
    if-nez v1, +004h
    const/4 v1, 0
    return v1
    new-instance v1, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
    invoke-direct v1, v3, v4, v5, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;-><init>(Lcom/facebook/android/Facebook; Landroid/content/Context; Lcom/facebook/android/Facebook$ServiceListener;)V
    const/4 v2, 1
    invoke-virtual v4, v0, v1, v2, Landroid/content/Context;->bindService(Landroid/content/Intent; Landroid/content/ServiceConnection; I)Z
    move-result v1
    goto -bh
.end method

.method public extendAccessTokenIfNeeded(Landroid/content/Context; Lcom/facebook/android/Facebook$ServiceListener;)Z
    .registers 4
    invoke-virtual v1, Lcom/facebook/android/Facebook;->shouldExtendAccessToken()Z
    move-result v0
    if-eqz v0, +007h
    invoke-virtual v1, v2, v3, Lcom/facebook/android/Facebook;->extendAccessToken(Landroid/content/Context; Lcom/facebook/android/Facebook$ServiceListener;)Z
    move-result v0
    return v0
    const/4 v0, 1
    goto -2h
.end method

.method public getAccessExpires()J
    .registers 3
    iget-wide v0, v2, Lcom/facebook/android/Facebook;->mAccessExpires J
    return-wide v0
.end method

.method public getAccessToken()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/Facebook;->mAccessToken Ljava/lang/String;
    return-object v0
.end method

.method public getAppId()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    return-object v0
.end method

.method public isSessionValid()Z
    .registers 5
    invoke-virtual v4, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +01ah
    invoke-virtual v4, Lcom/facebook/android/Facebook;->getAccessExpires()J
    move-result-wide v0
    const-wide/16 v2, 0
    cmp-long v0, v0, v2
    if-eqz v0, +00eh
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    invoke-virtual v4, Lcom/facebook/android/Facebook;->getAccessExpires()J
    move-result-wide v2
    cmp-long v0, v0, v2
    if-gez v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public logout(Landroid/content/Context;)Ljava/lang/String;
    .registers 6
    invoke-static v5, Lcom/facebook/android/Util;->clearCookies(Landroid/content/Context;)V
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    const-string v2, "method"
    const-string v3, "auth.expireSession"
    invoke-virtual v0, v2, v3, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v4, v0, Lcom/facebook/android/Facebook;->request(Landroid/os/Bundle;)Ljava/lang/String;
    move-result-object v1
    const/4 v2, 0
    invoke-virtual v4, v2, Lcom/facebook/android/Facebook;->setAccessToken(Ljava/lang/String;)V
    const-wide/16 v2, 0
    invoke-virtual v4, v2, v3, Lcom/facebook/android/Facebook;->setAccessExpires(J)V
    return-object v1
.end method

.method public request(Landroid/os/Bundle;)Ljava/lang/String;
    .registers 4
    const-string v0, "method"
    invoke-virtual v3, v0, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    move-result v0
    if-nez v0, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "API method must be specified. (parameters must contain key "method" and value). See http://developers.facebook.com/docs/reference/rest/"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    const/4 v0, 0
    const-string v1, "GET"
    invoke-virtual v2, v0, v3, v1, Lcom/facebook/android/Facebook;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public request(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    new-instance v0, Landroid/os/Bundle;
    invoke-direct v0, Landroid/os/Bundle;-><init>()V
    const-string v1, "GET"
    invoke-virtual v2, v3, v0, v1, Lcom/facebook/android/Facebook;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public request(Ljava/lang/String; Landroid/os/Bundle;)Ljava/lang/String;
    .registers 4
    const-string v0, "GET"
    invoke-virtual v1, v2, v3, v0, Lcom/facebook/android/Facebook;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    const-string v1, "format"
    const-string v2, "json"
    invoke-virtual v5, v1, v2, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    invoke-virtual v3, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v1
    if-eqz v1, +00bh
    const-string v1, "access_token"
    invoke-virtual v3, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v5, v1, v2, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    if-eqz v4, +01ah
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    sget-object v2, Lcom/facebook/android/Facebook;->GRAPH_BASE_URL Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, v6, v5, Lcom/facebook/android/Util;->openUrl(Ljava/lang/String; Ljava/lang/String; Landroid/os/Bundle;)Ljava/lang/String;
    move-result-object v1
    return-object v1
    sget-object v0, Lcom/facebook/android/Facebook;->RESTSERVER_URL Ljava/lang/String;
    goto -7h
.end method

.method public setAccessExpires(J)V
    .registers 3
    iput-wide v1, v0, Lcom/facebook/android/Facebook;->mAccessExpires J
    return-void
.end method

.method public setAccessExpiresIn(Ljava/lang/String;)V
    .registers 10
    if-eqz v9, +00fh
    const-string v2, "0"
    invoke-virtual v9, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, +008h
    const-wide/16 v0, 0
    invoke-virtual v8, v0, v1, Lcom/facebook/android/Facebook;->setAccessExpires(J)V
    return-void
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v2
    invoke-static v9, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J
    move-result-wide v4
    const-wide/16 v6, 1000
    mul-long/2addr v4, v6
    add-long v0, v2, v4
    goto -11h
.end method

.method public setAccessToken(Ljava/lang/String;)V
    .registers 4
    iput-object v3, v2, Lcom/facebook/android/Facebook;->mAccessToken Ljava/lang/String;
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    iput-wide v0, v2, Lcom/facebook/android/Facebook;->mLastAccessUpdate J
    return-void
.end method

.method public setAppId(Ljava/lang/String;)V
    .registers 2
    iput-object v1, v0, Lcom/facebook/android/Facebook;->mAppId Ljava/lang/String;
    return-void
.end method

.method public shouldExtendAccessToken()Z
    .registers 5
    invoke-virtual v4, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v0
    if-eqz v0, +012h
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    iget-wide v2, v4, Lcom/facebook/android/Facebook;->mLastAccessUpdate J
    sub-long/2addr v0, v2
    const-wide/32 v2, 86400000
    cmp-long v0, v0, v2
    if-ltz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method
