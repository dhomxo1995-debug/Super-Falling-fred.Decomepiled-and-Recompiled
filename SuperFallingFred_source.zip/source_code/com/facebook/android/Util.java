package com.facebook.android;
public final class Util {
    private static boolean ENABLE_LOG;

    static Util()
    {
        com.facebook.android.Util.ENABLE_LOG = 0;
        return;
    }

    public Util()
    {
        return;
    }

    public static void clearCookies(android.content.Context p2)
    {
        android.webkit.CookieSyncManager.createInstance(p2);
        android.webkit.CookieManager.getInstance().removeAllCookie();
        return;
    }

    public static android.os.Bundle decodeUrl(String p9)
    {
        android.os.Bundle v5_1 = new android.os.Bundle();
        if (p9 != null) {
            String[] v0 = p9.split("&");
            int v3 = v0.length;
            int v2 = 0;
            while (v2 < v3) {
                String[] v6 = v0[v2].split("=");
                if (v6.length == 2) {
                    v5_1.putString(java.net.URLDecoder.decode(v6[0]), java.net.URLDecoder.decode(v6[1]));
                }
                v2++;
            }
        }
        return v5_1;
    }

    public static String encodePostBody(android.os.Bundle p6, String p7)
    {
        String v4_0;
        if (p6 != null) {
            StringBuilder v3_1 = new StringBuilder();
            java.util.Iterator v0 = p6.keySet().iterator();
            while (v0.hasNext()) {
                String v1_1 = ((String) v0.next());
                String v2_0 = p6.get(v1_1);
                if ((v2_0 instanceof String)) {
                    v3_1.append(new StringBuilder().append("Content-Disposition: form-data; name=\"").append(v1_1).append("\"\r\n\r\n").append(((String) v2_0)).toString());
                    v3_1.append(new StringBuilder().append("\r\n--").append(p7).append("\r\n").toString());
                }
            }
            v4_0 = v3_1.toString();
        } else {
            v4_0 = "";
        }
        return v4_0;
    }

    public static String encodeUrl(android.os.Bundle p7)
    {
        String v5_0;
        if (p7 != null) {
            StringBuilder v4_1 = new StringBuilder();
            int v0 = 1;
            java.util.Iterator v1 = p7.keySet().iterator();
            while (v1.hasNext()) {
                String v2_1 = ((String) v1.next());
                if ((p7.get(v2_1) instanceof String)) {
                    if (v0 == 0) {
                        v4_1.append("&");
                    } else {
                        v0 = 0;
                    }
                    v4_1.append(new StringBuilder().append(java.net.URLEncoder.encode(v2_1)).append("=").append(java.net.URLEncoder.encode(p7.getString(v2_1))).toString());
                }
            }
            v5_0 = v4_1.toString();
        } else {
            v5_0 = "";
        }
        return v5_0;
    }

    public static void logd(String p1, String p2)
    {
        if (com.facebook.android.Util.ENABLE_LOG) {
            android.util.Log.d(p1, p2);
        }
        return;
    }

    public static String openUrl(String p17, String p18, android.os.Bundle p19)
    {
        String v6 = "\r\n";
        if (p18.equals("GET")) {
            p17 = new StringBuilder().append(p17).append("?").append(com.facebook.android.Util.encodeUrl(p19)).toString();
        }
        com.facebook.android.Util.logd("Facebook-Util", new StringBuilder().append(p18).append(" URL: ").append(p17).toString());
        java.net.HttpURLConnection v2_1 = ((java.net.HttpURLConnection) new java.net.URL(p17).openConnection());
        v2_1.setRequestProperty("User-Agent", new StringBuilder().append(System.getProperties().getProperty("http.agent")).append(" FacebookAndroidSDK").toString());
        if (!p18.equals("GET")) {
            android.os.Bundle v3_1 = new android.os.Bundle();
            java.util.Iterator v7_1 = p19.keySet().iterator();
            while (v7_1.hasNext()) {
                String v8_3 = ((String) v7_1.next());
                byte[] v10_0 = p19.get(v8_3);
                if ((v10_0 instanceof byte[])) {
                    v3_1.putByteArray(v8_3, ((byte[]) ((byte[]) v10_0)));
                }
            }
            if (!p19.containsKey("method")) {
                p19.putString("method", p18);
            }
            if (p19.containsKey("access_token")) {
                p19.putString("access_token", java.net.URLDecoder.decode(p19.getString("access_token")));
            }
            v2_1.setRequestMethod("POST");
            v2_1.setRequestProperty("Content-Type", new StringBuilder().append("multipart/form-data;boundary=").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").toString());
            v2_1.setDoOutput(1);
            v2_1.setDoInput(1);
            v2_1.setRequestProperty("Connection", "Keep-Alive");
            v2_1.connect();
            java.io.BufferedOutputStream v9_1 = new java.io.BufferedOutputStream(v2_1.getOutputStream());
            v9_1.write(new StringBuilder().append("--").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").append("\r\n").toString().getBytes());
            v9_1.write(com.facebook.android.Util.encodePostBody(p19, "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").getBytes());
            v9_1.write(new StringBuilder().append("\r\n").append("--").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").append("\r\n").toString().getBytes());
            if (!v3_1.isEmpty()) {
                java.util.Iterator v7_0 = v3_1.keySet().iterator();
                while (v7_0.hasNext()) {
                    String v8_1 = ((String) v7_0.next());
                    v9_1.write(new StringBuilder().append("Content-Disposition: form-data; filename=\"").append(v8_1).append("\"").append("\r\n").toString().getBytes());
                    v9_1.write(new StringBuilder().append("Content-Type: content/unknown").append(v6).append(v6).toString().getBytes());
                    v9_1.write(v3_1.getByteArray(v8_1));
                    v9_1.write(new StringBuilder().append("\r\n").append("--").append("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f").append("\r\n").toString().getBytes());
                }
            }
            v9_1.flush();
        }
        try {
            String v11 = com.facebook.android.Util.read(v2_1.getInputStream());
        } catch (java.io.FileNotFoundException v5) {
            v11 = com.facebook.android.Util.read(v2_1.getErrorStream());
        }
        return v11;
    }

    public static org.json.JSONObject parseJson(String p6)
    {
        if (!p6.equals("false")) {
            if (p6.equals("true")) {
                p6 = "{value : true}";
            }
            org.json.JSONObject v1_0 = new org.json.JSONObject(p6);
            if (!v1_0.has("error")) {
                if ((!v1_0.has("error_code")) || (!v1_0.has("error_msg"))) {
                    if (!v1_0.has("error_code")) {
                        if (!v1_0.has("error_msg")) {
                            if (!v1_0.has("error_reason")) {
                                return v1_0;
                            } else {
                                throw new com.facebook.android.FacebookError(v1_0.getString("error_reason"));
                            }
                        } else {
                            throw new com.facebook.android.FacebookError(v1_0.getString("error_msg"));
                        }
                    } else {
                        throw new com.facebook.android.FacebookError("request failed", "", Integer.parseInt(v1_0.getString("error_code")));
                    }
                } else {
                    throw new com.facebook.android.FacebookError(v1_0.getString("error_msg"), "", Integer.parseInt(v1_0.getString("error_code")));
                }
            } else {
                org.json.JSONObject v0 = v1_0.getJSONObject("error");
                throw new com.facebook.android.FacebookError(v0.getString("message"), v0.getString("type"), 0);
            }
        } else {
            throw new com.facebook.android.FacebookError("request failed");
        }
    }

    public static android.os.Bundle parseUrl(String p5)
    {
        try {
            java.net.URL v2_1 = new java.net.URL(p5.replace("fbconnect", "http"));
            android.os.Bundle v0_1 = com.facebook.android.Util.decodeUrl(v2_1.getQuery());
            v0_1.putAll(com.facebook.android.Util.decodeUrl(v2_1.getRef()));
        } catch (java.net.MalformedURLException v1) {
            v0_1 = new android.os.Bundle();
        }
        return v0_1;
    }

    private static String read(java.io.InputStream p5)
    {
        StringBuilder v2_1 = new StringBuilder();
        java.io.BufferedReader v1_1 = new java.io.BufferedReader(new java.io.InputStreamReader(p5), 1000);
        String v0 = v1_1.readLine();
        while (v0 != null) {
            v2_1.append(v0);
            v0 = v1_1.readLine();
        }
        p5.close();
        return v2_1.toString();
    }

    public static void showAlert(android.content.Context p2, String p3, String p4)
    {
        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(p2);
        v0_1.setTitle(p3);
        v0_1.setMessage(p4);
        v0_1.create().show();
        return;
    }
}
