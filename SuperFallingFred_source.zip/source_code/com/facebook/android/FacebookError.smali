.class public Lcom/facebook/android/FacebookError;
.super Ljava/lang/RuntimeException;

.field private static final serialVersionUID:J
.field private mErrorCode:I
.field private mErrorType:Ljava/lang/String;

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3
    invoke-direct v1, v2, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    const/4 v0, 0
    iput v0, v1, Lcom/facebook/android/FacebookError;->mErrorCode I
    return-void
.end method

.method public constructor <init>(Ljava/lang/String; Ljava/lang/String; I)V
    .registers 5
    invoke-direct v1, v2, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    const/4 v0, 0
    iput v0, v1, Lcom/facebook/android/FacebookError;->mErrorCode I
    iput-object v3, v1, Lcom/facebook/android/FacebookError;->mErrorType Ljava/lang/String;
    iput v4, v1, Lcom/facebook/android/FacebookError;->mErrorCode I
    return-void
.end method

.method public getErrorCode()I
    .registers 2
    iget v0, v1, Lcom/facebook/android/FacebookError;->mErrorCode I
    return v0
.end method

.method public getErrorType()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/facebook/android/FacebookError;->mErrorType Ljava/lang/String;
    return-object v0
.end method
