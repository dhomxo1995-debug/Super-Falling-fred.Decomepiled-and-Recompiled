.class public Lcom/facebook/android/AsyncFacebookRunner;
.super Ljava/lang/Object;

.field  fb:Lcom/facebook/android/Facebook;

.method public constructor <init>(Lcom/facebook/android/Facebook;)V
    .registers 2
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-object v1, v0, Lcom/facebook/android/AsyncFacebookRunner;->fb Lcom/facebook/android/Facebook;
    return-void
.end method

.method public logout(Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    .registers 4
    const/4 v0, 0
    invoke-virtual v1, v2, v3, v0, Lcom/facebook/android/AsyncFacebookRunner;->logout(Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public logout(Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 5
    new-instance v0, Lcom/facebook/android/AsyncFacebookRunner$1;
    invoke-direct v0, v1, v2, v3, v4, Lcom/facebook/android/AsyncFacebookRunner$1;-><init>(Lcom/facebook/android/AsyncFacebookRunner; Landroid/content/Context; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    invoke-virtual v0, Lcom/facebook/android/AsyncFacebookRunner$1;->start()V
    return-void
.end method

.method public request(Landroid/os/Bundle; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    .registers 9
    const/4 v1, 0
    const-string v3, "GET"
    move-object v0, v6
    move-object v2, v7
    move-object v4, v8
    move-object v5, v1
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public request(Landroid/os/Bundle; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 10
    const/4 v1, 0
    const-string v3, "GET"
    move-object v0, v6
    move-object v2, v7
    move-object v4, v8
    move-object v5, v9
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public request(Ljava/lang/String; Landroid/os/Bundle; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    .registers 10
    const-string v3, "GET"
    const/4 v5, 0
    move-object v0, v6
    move-object v1, v7
    move-object v2, v8
    move-object v4, v9
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public request(Ljava/lang/String; Landroid/os/Bundle; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 11
    const-string v3, "GET"
    move-object v0, v6
    move-object v1, v7
    move-object v2, v8
    move-object v4, v9
    move-object v5, v10
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 13
    new-instance v0, Lcom/facebook/android/AsyncFacebookRunner$2;
    move-object v1, v7
    move-object v2, v8
    move-object v3, v9
    move-object v4, v10
    move-object v5, v11
    move-object v6, v12
    invoke-direct/range v0 ... v6, Lcom/facebook/android/AsyncFacebookRunner$2;-><init>(Lcom/facebook/android/AsyncFacebookRunner; Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    invoke-virtual v0, Lcom/facebook/android/AsyncFacebookRunner$2;->start()V
    return-void
.end method

.method public request(Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener;)V
    .registers 9
    new-instance v2, Landroid/os/Bundle;
    invoke-direct v2, Landroid/os/Bundle;-><init>()V
    const-string v3, "GET"
    const/4 v5, 0
    move-object v0, v6
    move-object v1, v7
    move-object v4, v8
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method

.method public request(Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 10
    new-instance v2, Landroid/os/Bundle;
    invoke-direct v2, Landroid/os/Bundle;-><init>()V
    const-string v3, "GET"
    move-object v0, v6
    move-object v1, v7
    move-object v4, v8
    move-object v5, v9
    invoke-virtual/range v0 ... v5, Lcom/facebook/android/AsyncFacebookRunner;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    return-void
.end method
