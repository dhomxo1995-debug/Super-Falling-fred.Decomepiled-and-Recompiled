.class 0x0 Lcom/facebook/android/FbDialog$1;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;

.field final synthetic this$0:Lcom/facebook/android/FbDialog;

.method constructor <init>(Lcom/facebook/android/FbDialog;)V
    .registers 2
    iput-object v1, v0, Lcom/facebook/android/FbDialog$1;->this$0 Lcom/facebook/android/FbDialog;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 3
    iget-object v0, v1, Lcom/facebook/android/FbDialog$1;->this$0 Lcom/facebook/android/FbDialog;
    invoke-static v0, Lcom/facebook/android/FbDialog;->access$000(Lcom/facebook/android/FbDialog;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    invoke-interface v0, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    iget-object v0, v1, Lcom/facebook/android/FbDialog$1;->this$0 Lcom/facebook/android/FbDialog;
    invoke-virtual v0, Lcom/facebook/android/FbDialog;->dismiss()V
    return-void
.end method
