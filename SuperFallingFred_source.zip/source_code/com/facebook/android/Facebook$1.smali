.class 0x0 Lcom/facebook/android/Facebook$1;
.super Ljava/lang/Object;
.implements Lcom/facebook/android/Facebook$DialogListener;

.field final synthetic this$0:Lcom/facebook/android/Facebook;

.method constructor <init>(Lcom/facebook/android/Facebook;)V
    .registers 2
    iput-object v1, v0, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onCancel()V
    .registers 3
    const-string v0, "Facebook-authorize"
    const-string v1, "Login canceled"
    invoke-static v0, v1, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v2, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v0, Lcom/facebook/android/Facebook;->access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    invoke-interface v0, Lcom/facebook/android/Facebook$DialogListener;->onCancel()V
    return-void
.end method

.method public onComplete(Landroid/os/Bundle;)V
    .registers 6
    invoke-static Landroid/webkit/CookieSyncManager;->getInstance()Landroid/webkit/CookieSyncManager;
    move-result-object v0
    invoke-virtual v0, Landroid/webkit/CookieSyncManager;->sync()V
    iget-object v0, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    const-string v1, "access_token"
    invoke-virtual v5, v1, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/facebook/android/Facebook;->setAccessToken(Ljava/lang/String;)V
    iget-object v0, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    const-string v1, "expires_in"
    invoke-virtual v5, v1, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/facebook/android/Facebook;->setAccessExpiresIn(Ljava/lang/String;)V
    iget-object v0, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-virtual v0, Lcom/facebook/android/Facebook;->isSessionValid()Z
    move-result v0
    if-eqz v0, +03ah
    const-string v0, "Facebook-authorize"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Login Success! access_token="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-virtual v2, Lcom/facebook/android/Facebook;->getAccessToken()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " expires="
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    iget-object v2, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-virtual v2, Lcom/facebook/android/Facebook;->getAccessExpires()J
    move-result-wide v2
    invoke-virtual v1, v2, v3, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v0, Lcom/facebook/android/Facebook;->access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    invoke-interface v0, v5, Lcom/facebook/android/Facebook$DialogListener;->onComplete(Landroid/os/Bundle;)V
    return-void
    iget-object v0, v4, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v0, Lcom/facebook/android/Facebook;->access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    new-instance v1, Lcom/facebook/android/FacebookError;
    const-string v2, "Failed to receive access token."
    invoke-direct v1, v2, Lcom/facebook/android/FacebookError;-><init>(Ljava/lang/String;)V
    invoke-interface v0, v1, Lcom/facebook/android/Facebook$DialogListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    goto -11h
.end method

.method public onError(Lcom/facebook/android/DialogError;)V
    .registers 5
    const-string v0, "Facebook-authorize"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Login failed: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v3, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v0, Lcom/facebook/android/Facebook;->access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    invoke-interface v0, v4, Lcom/facebook/android/Facebook$DialogListener;->onError(Lcom/facebook/android/DialogError;)V
    return-void
.end method

.method public onFacebookError(Lcom/facebook/android/FacebookError;)V
    .registers 5
    const-string v0, "Facebook-authorize"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "Login failed: "
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/facebook/android/Util;->logd(Ljava/lang/String; Ljava/lang/String;)V
    iget-object v0, v3, Lcom/facebook/android/Facebook$1;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v0, Lcom/facebook/android/Facebook;->access$000(Lcom/facebook/android/Facebook;)Lcom/facebook/android/Facebook$DialogListener;
    move-result-object v0
    invoke-interface v0, v4, Lcom/facebook/android/Facebook$DialogListener;->onFacebookError(Lcom/facebook/android/FacebookError;)V
    return-void
.end method
