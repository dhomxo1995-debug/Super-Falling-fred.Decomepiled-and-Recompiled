.class public final Lcom/facebook/android/R$string;
.super Ljava/lang/Object;

.field public static final app_name:I
.field public static final hello:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
