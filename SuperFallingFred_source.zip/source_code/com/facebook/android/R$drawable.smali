.class public final Lcom/facebook/android/R$drawable;
.super Ljava/lang/Object;

.field public static final close:I
.field public static final facebook_icon:I
.field public static final icon:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method
