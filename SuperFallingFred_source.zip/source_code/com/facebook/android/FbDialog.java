package com.facebook.android;
public class FbDialog extends android.app.Dialog {
    static final float[] DIMENSIONS_DIFF_LANDSCAPE = None;
    static final float[] DIMENSIONS_DIFF_PORTRAIT = None;
    static final String DISPLAY_STRING = "touch";
    static final int FB_BLUE = 4285367476;
    static final String FB_ICON = "icon.png";
    static final android.widget.FrameLayout$LayoutParams FILL = None;
    static final int MARGIN = 4;
    static final int PADDING = 2;
    private android.widget.FrameLayout mContent;
    private android.widget.ImageView mCrossImage;
    private com.facebook.android.Facebook$DialogListener mListener;
    private android.app.ProgressDialog mSpinner;
    private String mUrl;
    private android.webkit.WebView mWebView;

    static FbDialog()
    {
        android.widget.FrameLayout$LayoutParams v0_0 = new float[2];
        v0_0 = {1101004800, 1114636288};
        com.facebook.android.FbDialog.DIMENSIONS_DIFF_LANDSCAPE = v0_0;
        android.widget.FrameLayout$LayoutParams v0_1 = new float[2];
        v0_1 = {1109393408, 1114636288};
        com.facebook.android.FbDialog.DIMENSIONS_DIFF_PORTRAIT = v0_1;
        com.facebook.android.FbDialog.FILL = new android.widget.FrameLayout$LayoutParams(-1, -1);
        return;
    }

    public FbDialog(android.content.Context p2, String p3, com.facebook.android.Facebook$DialogListener p4)
    {
        super(p2, 16973840);
        super.mUrl = p3;
        super.mListener = p4;
        return;
    }

    static synthetic com.facebook.android.Facebook$DialogListener access$000(com.facebook.android.FbDialog p1)
    {
        return p1.mListener;
    }

    static synthetic android.app.ProgressDialog access$200(com.facebook.android.FbDialog p1)
    {
        return p1.mSpinner;
    }

    static synthetic android.widget.FrameLayout access$300(com.facebook.android.FbDialog p1)
    {
        return p1.mContent;
    }

    static synthetic android.webkit.WebView access$400(com.facebook.android.FbDialog p1)
    {
        return p1.mWebView;
    }

    static synthetic android.widget.ImageView access$500(com.facebook.android.FbDialog p1)
    {
        return p1.mCrossImage;
    }

    private void createCrossImage()
    {
        this.mCrossImage = new android.widget.ImageView(this.getContext());
        this.mCrossImage.setOnClickListener(new com.facebook.android.FbDialog$1(this));
        this.mCrossImage.setImageDrawable(this.getContext().getResources().getDrawable(2130837504));
        this.mCrossImage.setVisibility(4);
        return;
    }

    private void setUpWebView(int p6)
    {
        android.widget.LinearLayout v0_1 = new android.widget.LinearLayout(this.getContext());
        this.mWebView = new android.webkit.WebView(this.getContext());
        this.mWebView.setVerticalScrollBarEnabled(0);
        this.mWebView.setHorizontalScrollBarEnabled(0);
        this.mWebView.setWebViewClient(new com.facebook.android.FbDialog$FbWebViewClient(this, 0));
        this.mWebView.getSettings().setJavaScriptEnabled(1);
        this.mWebView.loadUrl(this.mUrl);
        this.mWebView.setLayoutParams(com.facebook.android.FbDialog.FILL);
        this.mWebView.setVisibility(4);
        this.mWebView.getSettings().setSavePassword(0);
        v0_1.setPadding(p6, p6, p6, p6);
        v0_1.addView(this.mWebView);
        this.mContent.addView(v0_1);
        return;
    }

    protected void onCreate(android.os.Bundle p7)
    {
        super.onCreate(p7);
        this.mSpinner = new android.app.ProgressDialog(this.getContext());
        this.mSpinner.requestWindowFeature(1);
        this.mSpinner.setMessage("Loading...");
        this.requestWindowFeature(1);
        this.mContent = new android.widget.FrameLayout(this.getContext());
        this.createCrossImage();
        this.setUpWebView((this.mCrossImage.getDrawable().getIntrinsicWidth() / 2));
        this.mContent.addView(this.mCrossImage, new android.view.ViewGroup$LayoutParams(-2, -2));
        this.addContentView(this.mContent, new android.view.ViewGroup$LayoutParams(-1, -1));
        return;
    }
}
