.class public interface abstract Lcom/facebook/android/Facebook$ServiceListener;
.super Ljava/lang/Object;


.method public abstract onComplete(Landroid/os/Bundle;)V
    # abstract or native method
.end method

.method public abstract onError(Ljava/lang/Error;)V
    # abstract or native method
.end method

.method public abstract onFacebookError(Lcom/facebook/android/FacebookError;)V
    # abstract or native method
.end method
