package com.facebook.android;
 class FbDialog$FbWebViewClient extends android.webkit.WebViewClient {
    final synthetic com.facebook.android.FbDialog this$0;

    private FbDialog$FbWebViewClient(com.facebook.android.FbDialog p1)
    {
        this.this$0 = p1;
        return;
    }

    synthetic FbDialog$FbWebViewClient(com.facebook.android.FbDialog p1, com.facebook.android.FbDialog$1 p2)
    {
        this(p1);
        return;
    }

    public void onPageFinished(android.webkit.WebView p3, String p4)
    {
        super.onPageFinished(p3, p4);
        com.facebook.android.FbDialog.access$200(this.this$0).dismiss();
        com.facebook.android.FbDialog.access$300(this.this$0).setBackgroundColor(0);
        com.facebook.android.FbDialog.access$400(this.this$0).setVisibility(0);
        com.facebook.android.FbDialog.access$500(this.this$0).setVisibility(0);
        return;
    }

    public void onPageStarted(android.webkit.WebView p4, String p5, android.graphics.Bitmap p6)
    {
        com.facebook.android.Util.logd("Facebook-WebView", new StringBuilder().append("Webview loading URL: ").append(p5).toString());
        super.onPageStarted(p4, p5, p6);
        com.facebook.android.FbDialog.access$200(this.this$0).show();
        return;
    }

    public void onReceivedError(android.webkit.WebView p3, int p4, String p5, String p6)
    {
        super.onReceivedError(p3, p4, p5, p6);
        com.facebook.android.FbDialog.access$000(this.this$0).onError(new com.facebook.android.DialogError(p5, p4, p6));
        this.this$0.dismiss();
        return;
    }

    public boolean shouldOverrideUrlLoading(android.webkit.WebView p8, String p9)
    {
        int v2 = 1;
        com.facebook.android.Util.logd("Facebook-WebView", new StringBuilder().append("Redirect URL: ").append(p9).toString());
        if (!p9.startsWith("fbconnect://success")) {
            if (!p9.startsWith("fbconnect://cancel")) {
                if (!p9.contains("touch")) {
                    this.this$0.getContext().startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(p9)));
                } else {
                    v2 = 0;
                }
            } else {
                com.facebook.android.FbDialog.access$000(this.this$0).onCancel();
                this.this$0.dismiss();
            }
        } else {
            android.os.Bundle v1 = com.facebook.android.Util.parseUrl(p9);
            String v0 = v1.getString("error");
            if (v0 == null) {
                v0 = v1.getString("error_type");
            }
            if (v0 != null) {
                if ((!v0.equals("access_denied")) && (!v0.equals("OAuthAccessDeniedException"))) {
                    com.facebook.android.FbDialog.access$000(this.this$0).onFacebookError(new com.facebook.android.FacebookError(v0));
                } else {
                    com.facebook.android.FbDialog.access$000(this.this$0).onCancel();
                }
            } else {
                com.facebook.android.FbDialog.access$000(this.this$0).onComplete(v1);
            }
            this.this$0.dismiss();
        }
        return v2;
    }
}
