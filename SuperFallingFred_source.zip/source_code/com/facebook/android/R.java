package com.facebook.android;
public final class R {

    public R()
    {
        return;
    }
}
