package com.facebook.android;
 class Facebook$TokenRefreshServiceConnection implements android.content.ServiceConnection {
    final android.content.Context applicationsContext;
    final android.os.Messenger messageReceiver;
    android.os.Messenger messageSender;
    final com.facebook.android.Facebook$ServiceListener serviceListener;
    final synthetic com.facebook.android.Facebook this$0;

    public Facebook$TokenRefreshServiceConnection(com.facebook.android.Facebook p3, android.content.Context p4, com.facebook.android.Facebook$ServiceListener p5)
    {
        this.this$0 = p3;
        this.messageReceiver = new android.os.Messenger(new com.facebook.android.Facebook$TokenRefreshServiceConnection$1(this));
        this.messageSender = 0;
        this.applicationsContext = p4;
        this.serviceListener = p5;
        return;
    }

    private void refreshToken()
    {
        android.os.Bundle v2_1 = new android.os.Bundle();
        v2_1.putString("access_token", com.facebook.android.Facebook.access$100(this.this$0));
        android.os.Message v1 = android.os.Message.obtain();
        v1.setData(v2_1);
        v1.replyTo = this.messageReceiver;
        try {
            this.messageSender.send(v1);
        } catch (android.os.RemoteException v0) {
            this.serviceListener.onError(new Error("Service connection error"));
        }
        return;
    }

    public void onServiceConnected(android.content.ComponentName p2, android.os.IBinder p3)
    {
        this.messageSender = new android.os.Messenger(p3);
        this.refreshToken();
        return;
    }

    public void onServiceDisconnected(android.content.ComponentName p4)
    {
        this.serviceListener.onError(new Error("Service disconnected"));
        this.applicationsContext.unbindService(this);
        return;
    }
}
