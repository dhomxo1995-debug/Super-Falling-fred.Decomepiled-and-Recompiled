package com.facebook.android;
public class FacebookError extends java.lang.RuntimeException {
    private static final long serialVersionUID = 1;
    private int mErrorCode;
    private String mErrorType;

    public FacebookError(String p2)
    {
        super(p2);
        super.mErrorCode = 0;
        return;
    }

    public FacebookError(String p2, String p3, int p4)
    {
        super(p2);
        super.mErrorCode = 0;
        super.mErrorType = p3;
        super.mErrorCode = p4;
        return;
    }

    public int getErrorCode()
    {
        return this.mErrorCode;
    }

    public String getErrorType()
    {
        return this.mErrorType;
    }
}
