package com.facebook.android;
 class AsyncFacebookRunner$2 extends java.lang.Thread {
    final synthetic com.facebook.android.AsyncFacebookRunner this$0;
    final synthetic String val$graphPath;
    final synthetic String val$httpMethod;
    final synthetic com.facebook.android.AsyncFacebookRunner$RequestListener val$listener;
    final synthetic android.os.Bundle val$parameters;
    final synthetic Object val$state;

    AsyncFacebookRunner$2(com.facebook.android.AsyncFacebookRunner p1, String p2, android.os.Bundle p3, String p4, com.facebook.android.AsyncFacebookRunner$RequestListener p5, Object p6)
    {
        this.this$0 = p1;
        this.val$graphPath = p2;
        this.val$parameters = p3;
        this.val$httpMethod = p4;
        this.val$listener = p5;
        this.val$state = p6;
        return;
    }

    public void run()
    {
        try {
            this.val$listener.onComplete(this.this$0.fb.request(this.val$graphPath, this.val$parameters, this.val$httpMethod), this.val$state);
        } catch (java.io.IOException v0_2) {
            this.val$listener.onFileNotFoundException(v0_2, this.val$state);
        } catch (java.io.IOException v0_1) {
            this.val$listener.onMalformedURLException(v0_1, this.val$state);
        } catch (java.io.IOException v0_0) {
            this.val$listener.onIOException(v0_0, this.val$state);
        }
        return;
    }
}
