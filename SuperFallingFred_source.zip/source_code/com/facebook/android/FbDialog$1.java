package com.facebook.android;
 class FbDialog$1 implements android.view.View$OnClickListener {
    final synthetic com.facebook.android.FbDialog this$0;

    FbDialog$1(com.facebook.android.FbDialog p1)
    {
        this.this$0 = p1;
        return;
    }

    public void onClick(android.view.View p2)
    {
        com.facebook.android.FbDialog.access$000(this.this$0).onCancel();
        this.this$0.dismiss();
        return;
    }
}
