.class 0x0 Lcom/facebook/android/AsyncFacebookRunner$2;
.super Ljava/lang/Thread;

.field final synthetic this$0:Lcom/facebook/android/AsyncFacebookRunner;
.field final synthetic val$graphPath:Ljava/lang/String;
.field final synthetic val$httpMethod:Ljava/lang/String;
.field final synthetic val$listener:Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
.field final synthetic val$parameters:Landroid/os/Bundle;
.field final synthetic val$state:Ljava/lang/Object;

.method constructor <init>(Lcom/facebook/android/AsyncFacebookRunner; Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String; Lcom/facebook/android/AsyncFacebookRunner$RequestListener; Ljava/lang/Object;)V
    .registers 7
    iput-object v1, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->this$0 Lcom/facebook/android/AsyncFacebookRunner;
    iput-object v2, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->val$graphPath Ljava/lang/String;
    iput-object v3, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->val$parameters Landroid/os/Bundle;
    iput-object v4, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->val$httpMethod Ljava/lang/String;
    iput-object v5, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iput-object v6, v0, Lcom/facebook/android/AsyncFacebookRunner$2;->val$state Ljava/lang/Object;
    invoke-direct v0, Ljava/lang/Thread;-><init>()V
    return-void
.end method

.method public run()V
    .registers 7
    iget-object v2, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->this$0 Lcom/facebook/android/AsyncFacebookRunner;
    iget-object v2, v2, Lcom/facebook/android/AsyncFacebookRunner;->fb Lcom/facebook/android/Facebook;
    iget-object v3, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$graphPath Ljava/lang/String;
    iget-object v4, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$parameters Landroid/os/Bundle;
    iget-object v5, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$httpMethod Ljava/lang/String;
    invoke-virtual v2, v3, v4, v5, Lcom/facebook/android/Facebook;->request(Ljava/lang/String; Landroid/os/Bundle; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    iget-object v2, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$state Ljava/lang/Object;
    invoke-interface v2, v1, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onComplete(Ljava/lang/String; Ljava/lang/Object;)V
    return-void
    move-exception v0
    iget-object v2, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onFileNotFoundException(Ljava/io/FileNotFoundException; Ljava/lang/Object;)V
    goto -9h
    move-exception v0
    iget-object v2, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onMalformedURLException(Ljava/net/MalformedURLException; Ljava/lang/Object;)V
    goto -12h
    move-exception v0
    iget-object v2, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$listener Lcom/facebook/android/AsyncFacebookRunner$RequestListener;
    iget-object v3, v6, Lcom/facebook/android/AsyncFacebookRunner$2;->val$state Ljava/lang/Object;
    invoke-interface v2, v0, v3, Lcom/facebook/android/AsyncFacebookRunner$RequestListener;->onIOException(Ljava/io/IOException; Ljava/lang/Object;)V
    goto -1bh
.end method
