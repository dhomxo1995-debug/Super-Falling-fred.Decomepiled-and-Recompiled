.class 0x0 Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;
.super Ljava/lang/Object;
.implements Landroid/content/ServiceConnection;

.field final applicationsContext:Landroid/content/Context;
.field final messageReceiver:Landroid/os/Messenger;
.field  messageSender:Landroid/os/Messenger;
.field final serviceListener:Lcom/facebook/android/Facebook$ServiceListener;
.field final synthetic this$0:Lcom/facebook/android/Facebook;

.method public constructor <init>(Lcom/facebook/android/Facebook; Landroid/content/Context; Lcom/facebook/android/Facebook$ServiceListener;)V
    .registers 6
    iput-object v3, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->this$0 Lcom/facebook/android/Facebook;
    invoke-direct v2, Ljava/lang/Object;-><init>()V
    new-instance v0, Landroid/os/Messenger;
    new-instance v1, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;
    invoke-direct v1, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection$1;-><init>(Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;)V
    invoke-direct v0, v1, Landroid/os/Messenger;-><init>(Landroid/os/Handler;)V
    iput-object v0, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->messageReceiver Landroid/os/Messenger;
    const/4 v0, 0
    iput-object v0, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->messageSender Landroid/os/Messenger;
    iput-object v4, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->applicationsContext Landroid/content/Context;
    iput-object v5, v2, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    return-void
.end method

.method private refreshToken()V
    .registers 7
    new-instance v2, Landroid/os/Bundle;
    invoke-direct v2, Landroid/os/Bundle;-><init>()V
    const-string v3, "access_token"
    iget-object v4, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->this$0 Lcom/facebook/android/Facebook;
    invoke-static v4, Lcom/facebook/android/Facebook;->access$100(Lcom/facebook/android/Facebook;)Ljava/lang/String;
    move-result-object v4
    invoke-virtual v2, v3, v4, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    invoke-static Landroid/os/Message;->obtain()Landroid/os/Message;
    move-result-object v1
    invoke-virtual v1, v2, Landroid/os/Message;->setData(Landroid/os/Bundle;)V
    iget-object v3, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->messageReceiver Landroid/os/Messenger;
    iput-object v3, v1, Landroid/os/Message;->replyTo Landroid/os/Messenger;
    iget-object v3, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->messageSender Landroid/os/Messenger;
    invoke-virtual v3, v1, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    return-void
    move-exception v0
    iget-object v3, v6, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    new-instance v4, Ljava/lang/Error;
    const-string v5, "Service connection error"
    invoke-direct v4, v5, Ljava/lang/Error;-><init>(Ljava/lang/String;)V
    invoke-interface v3, v4, Lcom/facebook/android/Facebook$ServiceListener;->onError(Ljava/lang/Error;)V
    goto -eh
.end method

.method public onServiceConnected(Landroid/content/ComponentName; Landroid/os/IBinder;)V
    .registers 4
    new-instance v0, Landroid/os/Messenger;
    invoke-direct v0, v3, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V
    iput-object v0, v1, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->messageSender Landroid/os/Messenger;
    invoke-direct v1, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->refreshToken()V
    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 5
    iget-object v0, v3, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->serviceListener Lcom/facebook/android/Facebook$ServiceListener;
    new-instance v1, Ljava/lang/Error;
    const-string v2, "Service disconnected"
    invoke-direct v1, v2, Ljava/lang/Error;-><init>(Ljava/lang/String;)V
    invoke-interface v0, v1, Lcom/facebook/android/Facebook$ServiceListener;->onError(Ljava/lang/Error;)V
    iget-object v0, v3, Lcom/facebook/android/Facebook$TokenRefreshServiceConnection;->applicationsContext Landroid/content/Context;
    invoke-virtual v0, v3, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    return-void
.end method
