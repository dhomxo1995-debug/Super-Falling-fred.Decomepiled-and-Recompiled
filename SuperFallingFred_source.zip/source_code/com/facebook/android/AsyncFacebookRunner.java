package com.facebook.android;
public class AsyncFacebookRunner {
    com.facebook.android.Facebook fb;

    public AsyncFacebookRunner(com.facebook.android.Facebook p1)
    {
        this.fb = p1;
        return;
    }

    public void logout(android.content.Context p2, com.facebook.android.AsyncFacebookRunner$RequestListener p3)
    {
        this.logout(p2, p3, 0);
        return;
    }

    public void logout(android.content.Context p2, com.facebook.android.AsyncFacebookRunner$RequestListener p3, Object p4)
    {
        new com.facebook.android.AsyncFacebookRunner$1(this, p2, p3, p4).start();
        return;
    }

    public void request(android.os.Bundle p7, com.facebook.android.AsyncFacebookRunner$RequestListener p8)
    {
        this.request(0, p7, "GET", p8, 0);
        return;
    }

    public void request(android.os.Bundle p7, com.facebook.android.AsyncFacebookRunner$RequestListener p8, Object p9)
    {
        this.request(0, p7, "GET", p8, p9);
        return;
    }

    public void request(String p7, android.os.Bundle p8, com.facebook.android.AsyncFacebookRunner$RequestListener p9)
    {
        this.request(p7, p8, "GET", p9, 0);
        return;
    }

    public void request(String p7, android.os.Bundle p8, com.facebook.android.AsyncFacebookRunner$RequestListener p9, Object p10)
    {
        this.request(p7, p8, "GET", p9, p10);
        return;
    }

    public void request(String p8, android.os.Bundle p9, String p10, com.facebook.android.AsyncFacebookRunner$RequestListener p11, Object p12)
    {
        new com.facebook.android.AsyncFacebookRunner$2(this, p8, p9, p10, p11, p12).start();
        return;
    }

    public void request(String p7, com.facebook.android.AsyncFacebookRunner$RequestListener p8)
    {
        this.request(p7, new android.os.Bundle(), "GET", p8, 0);
        return;
    }

    public void request(String p7, com.facebook.android.AsyncFacebookRunner$RequestListener p8, Object p9)
    {
        this.request(p7, new android.os.Bundle(), "GET", p8, p9);
        return;
    }
}
