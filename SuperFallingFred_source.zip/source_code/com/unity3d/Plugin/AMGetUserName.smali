.class public Lcom/unity3d/Plugin/AMGetUserName;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static GetUserName(Landroid/app/Activity;)Ljava/lang/String;
    .registers 6
    const/4 v0, 0
    invoke-virtual v5, Landroid/app/Activity;->getApplication()Landroid/app/Application;
    move-result-object v2
    if-nez v2, +003h
    return-object v0
    invoke-static v2, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;
    move-result-object v3
    if-eqz v3, -005h
    const-string v4, "com.google"
    invoke-virtual v3, v4, Landroid/accounts/AccountManager;->getAccountsByType(Ljava/lang/String;)[Landroid/accounts/Account;
    move-result-object v1
    if-eqz v1, -00dh
    const/4 v0, 0
    if-eqz v1, -010h
    array-length v4, v1
    if-lez v4, -013h
    const/4 v4, 0
    aget-object v4, v1, v4
    iget-object v0, v4, Landroid/accounts/Account;->name Ljava/lang/String;
    goto -1ah
.end method

.method public static GetUserNameList(Landroid/app/Activity;)[Ljava/lang/String;
    .registers 8
    const/4 v1, 0
    invoke-virtual v7, Landroid/app/Activity;->getApplication()Landroid/app/Application;
    move-result-object v3
    if-nez v3, +003h
    return-object v1
    invoke-static v3, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;
    move-result-object v5
    if-eqz v5, -005h
    const-string v6, "com.google"
    invoke-virtual v5, v6, Landroid/accounts/AccountManager;->getAccountsByType(Ljava/lang/String;)[Landroid/accounts/Account;
    move-result-object v2
    if-eqz v2, -00dh
    const/4 v0, 0
    const/4 v1, 0
    if-eqz v2, -011h
    array-length v6, v2
    if-lez v6, -014h
    array-length v6, v2
    new-array v1, v6, [Ljava/lang/String;
    const/4 v4, 0
    array-length v6, v2
    if-ge v4, v6, -01bh
    aget-object v6, v2, v4
    iget-object v0, v6, Landroid/accounts/Account;->name Ljava/lang/String;
    aput-object v0, v1, v4
    add-int/lit8 v4, v4, 1
    goto -bh
.end method
