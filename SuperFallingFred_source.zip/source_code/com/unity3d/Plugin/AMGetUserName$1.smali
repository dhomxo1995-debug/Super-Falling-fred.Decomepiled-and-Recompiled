.class final Lcom/unity3d/Plugin/AMGetUserName$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;


.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public run()V
    .registers 1
    return-void
.end method
