.class public final Lcom/unity3d/player/i;
.super Ljava/lang/Object;

.field private a:Ljava/util/LinkedHashMap;

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/LinkedHashMap;
    invoke-direct v0, Ljava/util/LinkedHashMap;-><init>()V
    iput-object v0, v1, Lcom/unity3d/player/i;->a Ljava/util/LinkedHashMap;
    return-void
.end method

.method public static a(Landroid/view/MotionEvent; I)F
    .registers 3
    const/16 v0, 9
    invoke-static v1, v0, v2, Lcom/unity3d/player/i;->a(Landroid/view/MotionEvent; I I)F
    move-result v0
    return v0
.end method

.method private static a(Landroid/view/MotionEvent; I I)F
    .registers 4
    invoke-virtual v1, v2, v3, Landroid/view/MotionEvent;->getAxisValue(I I)F
    move-result v0
    return v0
.end method

.method private static a(Ljava/lang/Object; I)Ljava/lang/Object;
    .registers 4
    const/4 v1, 0
    invoke-static v2, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I
    move-result v0
    if-ge v3, v0, +012h
    invoke-virtual v2, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, v3, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v0
    invoke-static v2, v1, v0, v1, v3, Ljava/lang/System;->arraycopy(Ljava/lang/Object; I Ljava/lang/Object; I I)V
    move-object v2, v0
    return-object v2
.end method

.method private a([I)V
    .registers 10
    const/4 v0, 0
    new-instance v3, Ljava/util/LinkedHashMap;
    invoke-direct v3, Ljava/util/LinkedHashMap;-><init>()V
    array-length v4, v9
    move v1, v0
    if-ge v0, v4, +01eh
    aget v5, v9, v0
    new-instance v6, Lcom/unity3d/player/d;
    add-int/lit8 v2, v1, 1
    invoke-static v5, Lcom/unity3d/player/i;->a(I)[I
    move-result-object v7
    invoke-direct v6, v1, v7, Lcom/unity3d/player/d;-><init>(I [I)V
    iget-object v1, v6, Lcom/unity3d/player/d;->b [I
    if-eqz v1, +009h
    invoke-static v5, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v1
    invoke-virtual v3, v1, v6, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    add-int/lit8 v0, v0, 1
    move v1, v2
    goto -1dh
    iput-object v3, v8, Lcom/unity3d/player/i;->a Ljava/util/LinkedHashMap;
    return-void
.end method

.method public static a(Landroid/view/View; Landroid/view/MotionEvent;)Z
    .registers 3
    invoke-virtual v1, v2, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    move-result v0
    return v0
.end method

.method public static a(I)[I
    .registers 7
    const v5, 16777232
    invoke-static v6, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;
    move-result-object v0
    if-nez v0, +004h
    const/4 v0, 0
    return-object v0
    invoke-virtual v0, Landroid/view/InputDevice;->getMotionRanges()Ljava/util/List;
    move-result-object v1
    invoke-interface v1, Ljava/util/List;->size()I
    move-result v0
    new-array v3, v0, [I
    const/4 v0, 0
    invoke-interface v1, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v4
    move v1, v0
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01ah
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/InputDevice$MotionRange;
    invoke-virtual v0, Landroid/view/InputDevice$MotionRange;->getSource()I
    move-result v2
    and-int/2addr v2, v5
    if-ne v2, v5, +018h
    add-int/lit8 v2, v1, 1
    invoke-virtual v0, Landroid/view/InputDevice$MotionRange;->getAxis()I
    move-result v0
    aput v0, v3, v1
    move v0, v2
    move v1, v0
    goto -1dh
    invoke-static v3, v1, Lcom/unity3d/player/i;->a(Ljava/lang/Object; I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [I
    invoke-static v0, Lcom/unity3d/player/i;->b([I)[I
    move-result-object v0
    goto -39h
    move v0, v1
    goto -eh
.end method

.method public static b(I)Ljava/lang/String;
    .registers 2
    invoke-static v1, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;
    move-result-object v0
    if-eqz v0, +007h
    invoke-virtual v0, Landroid/view/InputDevice;->getName()Ljava/lang/String;
    move-result-object v0
    return-object v0
    const/4 v0, 0
    goto -2h
.end method

.method private static b([I)[I
    .registers 1
    invoke-static v0, Ljava/util/Arrays;->sort([I)V
    return-object v0
.end method

.method private c(I)Lcom/unity3d/player/d;
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/i;->a Ljava/util/LinkedHashMap;
    invoke-static v3, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/unity3d/player/d;
    if-nez v0, +011h
    invoke-virtual v2, Lcom/unity3d/player/i;->a()[I
    iget-object v0, v2, Lcom/unity3d/player/i;->a Ljava/util/LinkedHashMap;
    invoke-static v3, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/unity3d/player/d;
    return-object v0
.end method

.method public final a()[I
    .registers 9
    const v7, 16777232
    const/4 v0, 0
    invoke-static Landroid/view/InputDevice;->getDeviceIds()[I
    move-result-object v3
    array-length v1, v3
    new-array v4, v1, [I
    array-length v5, v3
    move v2, v0
    move v1, v0
    if-ge v2, v5, +01ah
    aget v6, v3, v2
    invoke-static v6, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;
    move-result-object v0
    if-eqz v0, +020h
    invoke-virtual v0, Landroid/view/InputDevice;->getSources()I
    move-result v0
    and-int/2addr v0, v7
    if-ne v0, v7, +019h
    add-int/lit8 v0, v1, 1
    aput v6, v4, v1
    add-int/lit8 v1, v2, 1
    move v2, v1
    move v1, v0
    goto -19h
    invoke-static v4, v1, Lcom/unity3d/player/i;->a(Ljava/lang/Object; I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [I
    invoke-static v0, Lcom/unity3d/player/i;->b([I)[I
    move-result-object v0
    invoke-direct v8, v0, Lcom/unity3d/player/i;->a([I)V
    return-object v0
    move v0, v1
    goto -14h
.end method

.method public final a(Landroid/view/MotionEvent;)[Lcom/unity3d/player/i$a;
    .registers 11
    const/4 v1, 0
    invoke-virtual v10, Landroid/view/MotionEvent;->getPointerCount()I
    move-result v0
    new-array v4, v0, [Lcom/unity3d/player/i$a;
    move v0, v1
    move v2, v1
    array-length v3, v4
    if-ge v0, v3, +035h
    invoke-virtual v10, Landroid/view/MotionEvent;->getDeviceId()I
    move-result v3
    invoke-direct v9, v3, Lcom/unity3d/player/i;->c(I)Lcom/unity3d/player/d;
    move-result-object v5
    if-eqz v5, +028h
    new-instance v6, Lcom/unity3d/player/i$a;
    iget v3, v5, Lcom/unity3d/player/d;->a I
    iget-object v7, v5, Lcom/unity3d/player/d;->b [I
    array-length v7, v7
    new-array v7, v7, [F
    invoke-direct v6, v3, v7, Lcom/unity3d/player/i$a;-><init>(I [F)V
    move v3, v1
    iget-object v7, v5, Lcom/unity3d/player/d;->b [I
    array-length v7, v7
    if-ge v3, v7, +011h
    iget-object v7, v6, Lcom/unity3d/player/i$a;->b [F
    iget-object v8, v5, Lcom/unity3d/player/d;->b [I
    aget v8, v8, v3
    invoke-static v10, v8, v0, Lcom/unity3d/player/i;->a(Landroid/view/MotionEvent; I I)F
    move-result v8
    aput v8, v7, v3
    add-int/lit8 v3, v3, 1
    goto -13h
    add-int/lit8 v3, v2, 1
    aput-object v6, v4, v2
    move v2, v3
    add-int/lit8 v0, v0, 1
    goto -35h
    invoke-static v4, v2, Lcom/unity3d/player/i;->a(Ljava/lang/Object; I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [Lcom/unity3d/player/i$a;
    return-object v0
.end method
