.class final Lcom/unity3d/player/r;
.super Ljava/lang/Object;
.implements Landroid/hardware/SensorEventListener;
.implements Landroid/location/LocationListener;

.field private static final Q:Z
.field private static final e:[I
.field private static final f:[[F
.field private A:Ljava/lang/Runnable;
.field private B:Ljava/lang/Runnable;
.field private C:Ljava/lang/Runnable;
.field private D:Ljava/lang/Runnable;
.field private E:Ljava/lang/Runnable;
.field private F:[F
.field private G:D
.field private H:Ljava/lang/Runnable;
.field private I:[F
.field private J:[F
.field private K:I
.field private L:Ljava/lang/Runnable;
.field private M:Landroid/location/Location;
.field private N:F
.field private O:Z
.field private P:I
.field private R:Z
.field private S:I
.field protected a:Z
.field private final b:Landroid/content/Context;
.field private final c:Lcom/unity3d/player/UnityPlayer;
.field private final d:Landroid/view/WindowManager;
.field private g:[F
.field private h:[F
.field private i:F
.field private j:F
.field private k:F
.field private l:J
.field private m:F
.field private n:F
.field private o:F
.field private p:J
.field private q:F
.field private r:F
.field private s:F
.field private t:J
.field private u:F
.field private v:F
.field private w:F
.field private x:J
.field private y:[F
.field private z:[F

.method static constructor <clinit>()V
    .registers 12
    const/4 v0, 0
    const/high16 v11, 1056964608
    const/4 v10, 0
    const-wide/high16 v8, 4611686018427387904
    const/4 v7, 4
    const/16 v1, 16
    new-array v1, v1, [I
    fill-array-data v1, +000007fh
    sput-object v1, Lcom/unity3d/player/r;->e [I
    new-array v1, v7, [[F
    new-array v2, v7, [F
    fill-array-data v2, +000009ah
    aput-object v2, v1, v0
    const/4 v2, 1
    new-array v3, v7, [F
    aput v10, v3, v0
    const/4 v4, 1
    aput v10, v3, v4
    const/4 v4, 2
    invoke-static v8, v9, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v5
    double-to-float v5, v5
    mul-float/2addr v5, v11
    aput v5, v3, v4
    const/4 v4, 3
    invoke-static v8, v9, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v5
    double-to-float v5, v5
    neg-float v5, v5
    mul-float/2addr v5, v11
    aput v5, v3, v4
    aput-object v3, v1, v2
    const/4 v2, 2
    new-array v3, v7, [F
    fill-array-data v3, +0000081h
    aput-object v3, v1, v2
    const/4 v2, 3
    new-array v3, v7, [F
    aput v10, v3, v0
    const/4 v4, 1
    aput v10, v3, v4
    const/4 v4, 2
    invoke-static v8, v9, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v5
    double-to-float v5, v5
    neg-float v5, v5
    mul-float/2addr v5, v11
    aput v5, v3, v4
    const/4 v4, 3
    invoke-static v8, v9, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v5
    double-to-float v5, v5
    neg-float v5, v5
    mul-float/2addr v5, v11
    aput v5, v3, v4
    aput-object v3, v1, v2
    sput-object v1, Lcom/unity3d/player/r;->f [[F
    sget-object v1, Landroid/os/Build;->MANUFACTURER Ljava/lang/String;
    const-string v2, "Amazon"
    invoke-virtual v1, v2, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v1
    if-eqz v1, +021h
    sget-object v1, Landroid/os/Build;->MODEL Ljava/lang/String;
    const-string v2, "KFTT"
    invoke-virtual v1, v2, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v1
    if-nez v1, +016h
    sget-object v1, Landroid/os/Build;->MODEL Ljava/lang/String;
    const-string v2, "KFJWI"
    invoke-virtual v1, v2, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v1
    if-nez v1, +00ch
    sget-object v1, Landroid/os/Build;->MODEL Ljava/lang/String;
    const-string v2, "KFJWA"
    invoke-virtual v1, v2, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v1
    if-eqz v1, +003h
    const/4 v0, 1
    sput-boolean v0, Lcom/unity3d/player/r;->Q Z
    return-void
    fill-array-data-payload b'\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\xff\xff\xff\xff\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\xff\xff\xff\xff\x01\x00\x00\x00\x00\x00\x00\x00' | \x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\xff\xff\xff\xff\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\xff\xff\xff\xff\x01\x00\x00\x00\x00\x00\x00\x00
    fill-array-data-payload b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80?' | \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x3f
    fill-array-data-payload b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80?\x00\x00\x00\x00' | \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x3f\x00\x00\x00\x00
.end method

.method protected constructor <init>(Landroid/content/Context; Lcom/unity3d/player/UnityPlayer;)V
    .registers 7
    const/4 v3, 4
    const/4 v2, 3
    const/4 v1, 0
    invoke-direct v4, Ljava/lang/Object;-><init>()V
    new-array v0, v2, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->g [F
    new-array v0, v2, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->h [F
    new-array v0, v3, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->y [F
    new-array v0, v3, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->z [F
    new-instance v0, Lcom/unity3d/player/r$1;
    invoke-direct v0, v4, Lcom/unity3d/player/r$1;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->A Ljava/lang/Runnable;
    new-instance v0, Lcom/unity3d/player/r$2;
    invoke-direct v0, v4, Lcom/unity3d/player/r$2;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->B Ljava/lang/Runnable;
    new-instance v0, Lcom/unity3d/player/r$3;
    invoke-direct v0, v4, Lcom/unity3d/player/r$3;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->C Ljava/lang/Runnable;
    new-instance v0, Lcom/unity3d/player/r$4;
    invoke-direct v0, v4, Lcom/unity3d/player/r$4;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->D Ljava/lang/Runnable;
    new-instance v0, Lcom/unity3d/player/r$5;
    invoke-direct v0, v4, Lcom/unity3d/player/r$5;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->E Ljava/lang/Runnable;
    const/4 v0, 5
    new-array v0, v0, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->F [F
    new-instance v0, Lcom/unity3d/player/r$6;
    invoke-direct v0, v4, Lcom/unity3d/player/r$6;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->H Ljava/lang/Runnable;
    const/16 v0, 9
    new-array v0, v0, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->I [F
    new-array v0, v2, [F
    iput-object v0, v4, Lcom/unity3d/player/r;->J [F
    new-instance v0, Lcom/unity3d/player/r$7;
    invoke-direct v0, v4, Lcom/unity3d/player/r$7;-><init>(Lcom/unity3d/player/r;)V
    iput-object v0, v4, Lcom/unity3d/player/r;->L Ljava/lang/Runnable;
    const/4 v0, 0
    iput v0, v4, Lcom/unity3d/player/r;->N F
    iput-boolean v1, v4, Lcom/unity3d/player/r;->O Z
    iput v1, v4, Lcom/unity3d/player/r;->P I
    const/4 v0, 1
    iput-boolean v0, v4, Lcom/unity3d/player/r;->a Z
    iput-boolean v1, v4, Lcom/unity3d/player/r;->R Z
    iput v1, v4, Lcom/unity3d/player/r;->S I
    iput-object v5, v4, Lcom/unity3d/player/r;->b Landroid/content/Context;
    iput-object v6, v4, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v4, Lcom/unity3d/player/r;->b Landroid/content/Context;
    const-string v1, "window"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/WindowManager;
    iput-object v0, v4, Lcom/unity3d/player/r;->d Landroid/view/WindowManager;
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->i F
    return v0
.end method

.method public static a(Landroid/hardware/SensorEvent; I I)I
    .registers 15
    const/high16 v8, -1082130432
    const/4 v4, 3
    const/4 v6, 2
    const/4 v7, 1
    const/4 v2, 0
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    aget v0, v0, v2
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v7
    iget-object v3, v12, Landroid/hardware/SensorEvent;->values [F
    aget v3, v3, v6
    const/high16 v5, 1065353216
    mul-float v9, v0, v0
    mul-float v10, v1, v1
    add-float/2addr v9, v10
    mul-float v10, v3, v3
    add-float/2addr v9, v10
    float-to-double v9, v9
    invoke-static v9, v10, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v9
    double-to-float v9, v9
    div-float/2addr v5, v9
    mul-float/2addr v0, v5
    mul-float/2addr v1, v5
    mul-float/2addr v3, v5
    if-ne v14, v7, +045h
    move v5, v2
    sub-int v5, v13, v5
    and-int/lit8 v5, v5, 3
    if-ne v5, v7, +04eh
    sget-boolean v5, Lcom/unity3d/player/r;->Q Z
    if-eqz v5, +054h
    neg-float v5, v1
    cmpg-float v1, v8, v0
    if-gez v1, +04ch
    move v1, v7
    move v7, v0
    neg-float v8, v0
    cmpg-float v8, v7, v8
    if-gez v8, +042h
    neg-float v1, v0
    move v0, v6
    cmpg-float v6, v1, v5
    if-gez v6, +004h
    move v0, v4
    move v1, v5
    neg-float v4, v5
    cmpg-float v4, v1, v4
    if-gez v4, +004h
    neg-float v1, v5
    const/4 v0, 4
    cmpg-float v4, v1, v3
    if-gez v4, +004h
    const/4 v0, 5
    move v1, v3
    neg-float v4, v3
    cmpg-float v4, v1, v4
    if-gez v4, +004h
    neg-float v1, v3
    const/4 v0, 6
    float-to-double v3, v1
    const-wide/high16 v5, 4602678819172646912
    const-wide/high16 v7, 4613937818241073152
    invoke-static v7, v8, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v7
    mul-double/2addr v5, v7
    cmpg-double v1, v3, v5
    if-gez v1, +003h
    move v0, v2
    return v0
    if-nez v14, +004h
    move v5, v7
    goto -45h
    const/16 v5, 9
    if-ne v14, v5, +004h
    move v5, v6
    goto -4bh
    const/16 v5, 8
    if-ne v14, v5, +014h
    move v5, v4
    goto -51h
    if-ne v5, v4, +00ch
    neg-float v0, v0
    goto -4fh
    move v0, v1
    move v1, v7
    goto -40h
    move v1, v2
    move v7, v8
    goto -4ah
    move v5, v1
    goto -52h
    move v11, v1
    move v1, v0
    move v0, v11
    goto -5bh
    move v5, v2
    goto -63h
.end method

.method private a(I)V
    .registers 3
    iput v2, v1, Lcom/unity3d/player/r;->S I
    iget-object v0, v1, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v0, v2, Lcom/unity3d/player/UnityPlayer;->nativeSetLocationStatus(I)V
    return-void
.end method

.method private a(Landroid/hardware/SensorEvent;)V
    .registers 9
    const v6, -1110387073
    iget-boolean v0, v7, Lcom/unity3d/player/r;->a Z
    if-eqz v0, +070h
    iget-object v0, v7, Lcom/unity3d/player/r;->d Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v0
    iget-object v1, v7, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v1, Lcom/unity3d/player/UnityPlayer;->getOrientation()I
    move-result v1
    sget-object v2, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v3, v0, 4
    add-int/lit8 v3, v3, 0
    aget v2, v2, v3
    int-to-float v2, v2
    sget-object v3, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v4, v0, 4
    add-int/lit8 v4, v4, 1
    aget v3, v3, v4
    int-to-float v3, v3
    sget-object v4, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v5, v0, 4
    add-int/lit8 v5, v5, 2
    aget v4, v4, v5
    sget-object v5, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v0, v0, 4
    add-int/lit8 v0, v0, 3
    aget v0, v5, v0
    mul-float/2addr v2, v6
    iget-object v5, v8, Landroid/hardware/SensorEvent;->values [F
    aget v4, v5, v4
    mul-float/2addr v2, v4
    iput v2, v7, Lcom/unity3d/player/r;->i F
    mul-float v2, v3, v6
    iget-object v3, v8, Landroid/hardware/SensorEvent;->values [F
    aget v0, v3, v0
    mul-float/2addr v0, v2
    iput v0, v7, Lcom/unity3d/player/r;->j F
    iget-object v0, v8, Landroid/hardware/SensorEvent;->values [F
    const/4 v2, 2
    aget v0, v0, v2
    mul-float/2addr v0, v6
    iput v0, v7, Lcom/unity3d/player/r;->k F
    iget-wide v2, v8, Landroid/hardware/SensorEvent;->timestamp J
    iput-wide v2, v7, Lcom/unity3d/player/r;->l J
    iget-object v0, v7, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v2, v7, Lcom/unity3d/player/r;->A Ljava/lang/Runnable;
    invoke-virtual v0, v2, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    iget-object v0, v7, Lcom/unity3d/player/r;->d Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v0
    invoke-static v8, v0, v1, Lcom/unity3d/player/r;->a(Landroid/hardware/SensorEvent; I I)I
    move-result v0
    iput v0, v7, Lcom/unity3d/player/r;->K I
    iget-object v0, v7, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v7, Lcom/unity3d/player/r;->L Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    return-void
    const/4 v0, 0
    goto -65h
.end method

.method private a(Landroid/location/Location;)V
    .registers 11
    if-nez v10, +003h
    return-void
    iget-object v0, v9, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-static v10, v0, Lcom/unity3d/player/r;->a(Landroid/location/Location; Landroid/location/Location;)Z
    move-result v0
    if-eqz v0, -007h
    iput-object v10, v9, Lcom/unity3d/player/r;->M Landroid/location/Location;
    iget-object v0, v9, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v10, Landroid/location/Location;->getLatitude()D
    move-result-wide v1
    double-to-float v1, v1
    invoke-virtual v10, Landroid/location/Location;->getLongitude()D
    move-result-wide v2
    double-to-float v2, v2
    invoke-virtual v10, Landroid/location/Location;->getAltitude()D
    move-result-wide v3
    double-to-float v3, v3
    invoke-virtual v10, Landroid/location/Location;->getAccuracy()F
    move-result v4
    invoke-virtual v10, Landroid/location/Location;->getTime()J
    move-result-wide v5
    long-to-double v5, v5
    const-wide v7, 4652007308841189376
    div-double/2addr v5, v7
    invoke-virtual/range v0 ... v6, Lcom/unity3d/player/UnityPlayer;->nativeSetLocation(F F F F D)V
    goto -2eh
.end method

.method private static a([F [F [F)V
    .registers 10
    const/4 v6, 3
    const/4 v5, 2
    const/4 v4, 1
    const/4 v3, 0
    aget v0, v8, v6
    aget v1, v9, v3
    mul-float/2addr v0, v1
    aget v1, v8, v3
    aget v2, v9, v6
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v4
    aget v2, v9, v5
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v5
    aget v2, v9, v4
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aput v0, v7, v3
    aget v0, v8, v6
    aget v1, v9, v4
    mul-float/2addr v0, v1
    aget v1, v8, v4
    aget v2, v9, v6
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v5
    aget v2, v9, v3
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v3
    aget v2, v9, v5
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aput v0, v7, v4
    aget v0, v8, v6
    aget v1, v9, v5
    mul-float/2addr v0, v1
    aget v1, v8, v5
    aget v2, v9, v6
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v3
    aget v2, v9, v4
    mul-float/2addr v1, v2
    add-float/2addr v0, v1
    aget v1, v8, v4
    aget v2, v9, v3
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aput v0, v7, v5
    aget v0, v8, v6
    aget v1, v9, v6
    mul-float/2addr v0, v1
    aget v1, v8, v3
    aget v2, v9, v3
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aget v1, v8, v4
    aget v2, v9, v4
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aget v1, v8, v5
    aget v2, v9, v5
    mul-float/2addr v1, v2
    sub-float/2addr v0, v1
    aput v0, v7, v6
    return-void
.end method

.method private static a(Landroid/location/Location; Landroid/location/Location;)Z
    .registers 10
    const/4 v2, 0
    const/4 v1, 1
    if-nez v9, +003h
    return v1
    invoke-virtual v8, Landroid/location/Location;->getTime()J
    move-result-wide v3
    invoke-virtual v9, Landroid/location/Location;->getTime()J
    move-result-wide v5
    sub-long v4, v3, v5
    const-wide/32 v6, 120000
    cmp-long v0, v4, v6
    if-lez v0, +018h
    move v3, v1
    const-wide/32 v6, -120000
    cmp-long v0, v4, v6
    if-gez v0, +012h
    move v0, v1
    const-wide/16 v6, 0
    cmp-long v4, v4, v6
    if-lez v4, +00dh
    move v6, v1
    if-nez v3, -022h
    if-eqz v0, +00ah
    move v1, v2
    goto -27h
    move v3, v2
    goto -16h
    move v0, v2
    goto -10h
    move v6, v2
    goto -bh
    invoke-virtual v8, Landroid/location/Location;->getAccuracy()F
    move-result v0
    invoke-virtual v9, Landroid/location/Location;->getAccuracy()F
    move-result v3
    sub-float/2addr v0, v3
    float-to-int v0, v0
    if-lez v0, +030h
    move v5, v1
    if-gez v0, +02fh
    move v4, v1
    const/16 v3, 200
    if-le v0, v3, +02ch
    move v0, v1
    invoke-virtual v8, Landroid/location/Location;->getAccuracy()F
    move-result v3
    const/4 v7, 0
    cmpl-float v3, v3, v7
    if-nez v3, +024h
    move v3, v1
    or-int/2addr v0, v3
    invoke-virtual v8, Landroid/location/Location;->getProvider()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v9, Landroid/location/Location;->getProvider()Ljava/lang/String;
    move-result-object v7
    invoke-static v3, v7, Lcom/unity3d/player/r;->a(Ljava/lang/String; Ljava/lang/String;)Z
    move-result v3
    if-nez v4, -05ah
    if-eqz v6, +004h
    if-eqz v5, -05eh
    if-eqz v6, +006h
    if-nez v0, +004h
    if-nez v3, -064h
    move v1, v2
    goto -67h
    move v5, v2
    goto -2eh
    move v4, v2
    goto -2dh
    move v0, v2
    goto -2ah
    move v3, v2
    goto -22h
.end method

.method private static a(Ljava/lang/String; Ljava/lang/String;)Z
    .registers 3
    if-nez v1, +008h
    if-nez v2, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
    invoke-virtual v1, v2, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    goto -7h
.end method

.method static synthetic b(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->j F
    return v0
.end method

.method static synthetic c(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->k F
    return v0
.end method

.method static synthetic d(Lcom/unity3d/player/r;)J
    .registers 3
    iget-wide v0, v2, Lcom/unity3d/player/r;->l J
    return-wide v0
.end method

.method static synthetic e(Lcom/unity3d/player/r;)Lcom/unity3d/player/UnityPlayer;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    return-object v0
.end method

.method static synthetic f(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->m F
    return v0
.end method

.method static synthetic f()J
    .registers 2
    const-wide/16 v0, 0
    return-wide v0
.end method

.method static synthetic g(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->n F
    return v0
.end method

.method static synthetic h(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->o F
    return v0
.end method

.method static synthetic i(Lcom/unity3d/player/r;)J
    .registers 3
    iget-wide v0, v2, Lcom/unity3d/player/r;->p J
    return-wide v0
.end method

.method static synthetic j(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->q F
    return v0
.end method

.method static synthetic k(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->r F
    return v0
.end method

.method static synthetic l(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->s F
    return v0
.end method

.method static synthetic m(Lcom/unity3d/player/r;)J
    .registers 3
    iget-wide v0, v2, Lcom/unity3d/player/r;->t J
    return-wide v0
.end method

.method static synthetic n(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->u F
    return v0
.end method

.method static synthetic o(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->v F
    return v0
.end method

.method static synthetic p(Lcom/unity3d/player/r;)F
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->w F
    return v0
.end method

.method static synthetic q(Lcom/unity3d/player/r;)J
    .registers 3
    iget-wide v0, v2, Lcom/unity3d/player/r;->x J
    return-wide v0
.end method

.method static synthetic r(Lcom/unity3d/player/r;)[F
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/r;->y [F
    return-object v0
.end method

.method static synthetic s(Lcom/unity3d/player/r;)[F
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/r;->F [F
    return-object v0
.end method

.method static synthetic t(Lcom/unity3d/player/r;)D
    .registers 3
    iget-wide v0, v2, Lcom/unity3d/player/r;->G D
    return-wide v0
.end method

.method static synthetic u(Lcom/unity3d/player/r;)I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/r;->K I
    return v0
.end method

.method public final a(F)V
    .registers 2
    iput v1, v0, Lcom/unity3d/player/r;->N F
    return-void
.end method

.method public final a()Z
    .registers 4
    const/4 v1, 1
    iget-object v0, v3, Lcom/unity3d/player/r;->b Landroid/content/Context;
    const-string v2, "location"
    invoke-virtual v0, v2, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/location/LocationManager;
    new-instance v2, Landroid/location/Criteria;
    invoke-direct v2, Landroid/location/Criteria;-><init>()V
    invoke-virtual v0, v2, v1, Landroid/location/LocationManager;->getProviders(Landroid/location/Criteria; Z)Ljava/util/List;
    move-result-object v0
    invoke-interface v0, Ljava/util/List;->isEmpty()Z
    move-result v0
    if-nez v0, +004h
    move v0, v1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public final b()V
    .registers 11
    const/4 v2, 3
    const/4 v6, 2
    const/4 v9, 1
    const/4 v0, 0
    iput-boolean v0, v10, Lcom/unity3d/player/r;->R Z
    iget-boolean v0, v10, Lcom/unity3d/player/r;->O Z
    if-eqz v0, +009h
    const/4 v0, 5
    const-string v1, "Location_StartUpdatingLocation already started!"
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-void
    invoke-virtual v10, Lcom/unity3d/player/r;->a()Z
    move-result v0
    if-nez v0, +006h
    invoke-direct v10, v2, Lcom/unity3d/player/r;->a(I)V
    goto -ah
    iget-object v0, v10, Lcom/unity3d/player/r;->b Landroid/content/Context;
    const-string v1, "location"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/location/LocationManager;
    invoke-direct v10, v9, Lcom/unity3d/player/r;->a(I)V
    invoke-virtual v0, v9, Landroid/location/LocationManager;->getProviders(Z)Ljava/util/List;
    move-result-object v3
    invoke-interface v3, Ljava/util/List;->isEmpty()Z
    move-result v1
    if-eqz v1, +006h
    invoke-direct v10, v2, Lcom/unity3d/player/r;->a(I)V
    goto -25h
    const/4 v2, 0
    iget v1, v10, Lcom/unity3d/player/r;->P I
    if-ne v1, v6, +051h
    invoke-interface v3, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v1
    if-eqz v1, +047h
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-virtual v0, v1, Landroid/location/LocationManager;->getProvider(Ljava/lang/String;)Landroid/location/LocationProvider;
    move-result-object v1
    invoke-virtual v1, Landroid/location/LocationProvider;->getAccuracy()I
    move-result v5
    if-ne v5, v6, -014h
    move-object v7, v1
    invoke-interface v3, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v8
    invoke-interface v8, Ljava/util/Iterator;->hasNext()Z
    move-result v1
    if-eqz v1, -04eh
    invoke-interface v8, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    if-eqz v7, +00ch
    invoke-virtual v0, v1, Landroid/location/LocationManager;->getProvider(Ljava/lang/String;)Landroid/location/LocationProvider;
    move-result-object v2
    invoke-virtual v2, Landroid/location/LocationProvider;->getAccuracy()I
    move-result v2
    if-eq v2, v9, -016h
    invoke-virtual v0, v1, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;
    move-result-object v2
    invoke-direct v10, v2, Lcom/unity3d/player/r;->a(Landroid/location/Location;)V
    const-wide/16 v2, 0
    iget v4, v10, Lcom/unity3d/player/r;->N F
    iget-object v5, v10, Lcom/unity3d/player/r;->b Landroid/content/Context;
    invoke-virtual v5, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;
    move-result-object v6
    move-object v5, v10
    invoke-virtual/range v0 ... v6, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String; J F Landroid/location/LocationListener; Landroid/os/Looper;)V
    iput-boolean v9, v10, Lcom/unity3d/player/r;->O Z
    goto -2fh
    move-object v7, v2
    goto -35h
.end method

.method public final b(F)V
    .registers 4
    const/4 v1, 1
    const/high16 v0, 1120403456
    cmpg-float v0, v3, v0
    if-gez v0, +005h
    iput v1, v2, Lcom/unity3d/player/r;->P I
    return-void
    const/high16 v0, 1140457472
    cmpg-float v0, v3, v0
    if-gez v0, +005h
    iput v1, v2, Lcom/unity3d/player/r;->P I
    goto -9h
    const/4 v0, 2
    iput v0, v2, Lcom/unity3d/player/r;->P I
    goto -dh
.end method

.method public final c()V
    .registers 4
    const/4 v2, 0
    iget-object v0, v3, Lcom/unity3d/player/r;->b Landroid/content/Context;
    const-string v1, "location"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/location/LocationManager;
    invoke-virtual v0, v3, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V
    iput-boolean v2, v3, Lcom/unity3d/player/r;->O Z
    const/4 v0, 0
    iput-object v0, v3, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-direct v3, v2, Lcom/unity3d/player/r;->a(I)V
    return-void
.end method

.method public final d()V
    .registers 4
    const/4 v2, 1
    iget v0, v3, Lcom/unity3d/player/r;->S I
    if-eq v0, v2, +007h
    iget v0, v3, Lcom/unity3d/player/r;->S I
    const/4 v1, 2
    if-ne v0, v1, +007h
    iput-boolean v2, v3, Lcom/unity3d/player/r;->R Z
    invoke-virtual v3, Lcom/unity3d/player/r;->c()V
    return-void
.end method

.method public final e()V
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/r;->R Z
    if-eqz v0, +005h
    invoke-virtual v1, Lcom/unity3d/player/r;->b()V
    return-void
.end method

.method public final onAccuracyChanged(Landroid/hardware/Sensor; I)V
    .registers 3
    return-void
.end method

.method public final onLocationChanged(Landroid/location/Location;)V
    .registers 3
    const/4 v0, 2
    invoke-direct v1, v0, Lcom/unity3d/player/r;->a(I)V
    invoke-direct v1, v2, Lcom/unity3d/player/r;->a(Landroid/location/Location;)V
    return-void
.end method

.method public final onProviderDisabled(Ljava/lang/String;)V
    .registers 3
    const/4 v0, 0
    iput-object v0, v1, Lcom/unity3d/player/r;->M Landroid/location/Location;
    return-void
.end method

.method public final onProviderEnabled(Ljava/lang/String;)V
    .registers 2
    return-void
.end method

.method public final onSensorChanged(Landroid/hardware/SensorEvent;)V
    .registers 13
    const/4 v10, 1
    const/high16 v9, 1135869952
    const v8, -1110387073
    const/4 v2, 0
    const/4 v7, 2
    iget-boolean v0, v11, Lcom/unity3d/player/r;->a Z
    if-eqz v0, +039h
    iget-object v0, v11, Lcom/unity3d/player/r;->d Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v0
    move v1, v0
    sget-object v0, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v3, v1, 4
    add-int/lit8 v3, v3, 0
    aget v0, v0, v3
    int-to-float v0, v0
    sget-object v3, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v4, v1, 4
    add-int/lit8 v4, v4, 1
    aget v3, v3, v4
    int-to-float v3, v3
    sget-object v4, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v5, v1, 4
    add-int/lit8 v5, v5, 2
    aget v4, v4, v5
    sget-object v5, Lcom/unity3d/player/r;->e [I
    mul-int/lit8 v6, v1, 4
    add-int/lit8 v6, v6, 3
    aget v5, v5, v6
    iget-object v6, v12, Landroid/hardware/SensorEvent;->sensor Landroid/hardware/Sensor;
    invoke-virtual v6, Landroid/hardware/Sensor;->getType()I
    move-result v6
    packed-switch v6, +00001bbh
    return-void
    move v1, v2
    goto -2dh
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    invoke-virtual v0, [F->clone()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [F
    iput-object v0, v11, Lcom/unity3d/player/r;->g [F
    invoke-direct v11, v12, Lcom/unity3d/player/r;->a(Landroid/hardware/SensorEvent;)V
    goto -10h
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    invoke-virtual v0, [F->clone()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [F
    iput-object v0, v11, Lcom/unity3d/player/r;->h [F
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v3
    long-to-double v3, v3
    const-wide v5, 4652007308841189376
    div-double/2addr v3, v5
    iput-wide v3, v11, Lcom/unity3d/player/r;->G D
    iget-object v0, v11, Lcom/unity3d/player/r;->I [F
    const/4 v3, 0
    iget-object v4, v11, Lcom/unity3d/player/r;->g [F
    iget-object v5, v11, Lcom/unity3d/player/r;->h [F
    invoke-static v0, v3, v4, v5, Landroid/hardware/SensorManager;->getRotationMatrix([F [F [F [F)Z
    move-result v0
    if-eqz v0, -033h
    iget-object v0, v11, Lcom/unity3d/player/r;->I [F
    iget-object v3, v11, Lcom/unity3d/player/r;->J [F
    invoke-static v0, v3, Landroid/hardware/SensorManager;->getOrientation([F [F)[F
    iget-object v0, v11, Lcom/unity3d/player/r;->J [F
    aget v0, v0, v2
    float-to-double v3, v0
    invoke-static v3, v4, Ljava/lang/Math;->toDegrees(D)D
    move-result-wide v3
    double-to-float v0, v3
    packed-switch v1, +000018ch
    cmpl-float v1, v0, v9
    if-ltz v1, +0ech
    sub-float/2addr v0, v9
    goto -5h
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v4
    mul-float/2addr v0, v1
    iput v0, v11, Lcom/unity3d/player/r;->m F
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    aget v0, v0, v5
    mul-float/2addr v0, v3
    iput v0, v11, Lcom/unity3d/player/r;->n F
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    aget v0, v0, v7
    iput v0, v11, Lcom/unity3d/player/r;->o F
    iget-wide v0, v12, Landroid/hardware/SensorEvent;->timestamp J
    iput-wide v0, v11, Lcom/unity3d/player/r;->p J
    iget-object v0, v11, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v11, Lcom/unity3d/player/r;->B Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -6eh
    mul-float/2addr v0, v8
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v4
    mul-float/2addr v0, v1
    iput v0, v11, Lcom/unity3d/player/r;->q F
    mul-float v0, v3, v8
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v5
    mul-float/2addr v0, v1
    iput v0, v11, Lcom/unity3d/player/r;->r F
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    aget v0, v0, v7
    mul-float/2addr v0, v8
    iput v0, v11, Lcom/unity3d/player/r;->s F
    iget-wide v0, v12, Landroid/hardware/SensorEvent;->timestamp J
    iput-wide v0, v11, Lcom/unity3d/player/r;->t J
    iget-object v0, v11, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v11, Lcom/unity3d/player/r;->C Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto/16 -092h
    mul-float/2addr v0, v8
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v4
    mul-float/2addr v0, v1
    iput v0, v11, Lcom/unity3d/player/r;->u F
    mul-float v0, v3, v8
    iget-object v1, v12, Landroid/hardware/SensorEvent;->values [F
    aget v1, v1, v5
    mul-float/2addr v0, v1
    iput v0, v11, Lcom/unity3d/player/r;->v F
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    aget v0, v0, v7
    mul-float/2addr v0, v8
    iput v0, v11, Lcom/unity3d/player/r;->w F
    iget-wide v0, v12, Landroid/hardware/SensorEvent;->timestamp J
    iput-wide v0, v11, Lcom/unity3d/player/r;->x J
    iget-object v0, v11, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v11, Lcom/unity3d/player/r;->D Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto/16 -0b7h
    iget-object v0, v11, Lcom/unity3d/player/r;->z [F
    iget-object v3, v12, Landroid/hardware/SensorEvent;->values [F
    aget v3, v3, v2
    aput v3, v0, v2
    iget-object v0, v11, Lcom/unity3d/player/r;->z [F
    iget-object v3, v12, Landroid/hardware/SensorEvent;->values [F
    aget v3, v3, v10
    aput v3, v0, v10
    iget-object v0, v11, Lcom/unity3d/player/r;->z [F
    iget-object v3, v12, Landroid/hardware/SensorEvent;->values [F
    aget v3, v3, v7
    aput v3, v0, v7
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    array-length v0, v0
    const/4 v3, 4
    if-ne v0, v3, +020h
    iget-object v3, v11, Lcom/unity3d/player/r;->z [F
    const/4 v2, 3
    iget-object v0, v12, Landroid/hardware/SensorEvent;->values [F
    const/4 v4, 3
    aget v0, v0, v4
    aput v0, v3, v2
    iget-object v0, v11, Lcom/unity3d/player/r;->y [F
    iget-object v2, v11, Lcom/unity3d/player/r;->z [F
    sget-object v3, Lcom/unity3d/player/r;->f [[F
    aget-object v1, v3, v1
    invoke-static v0, v2, v1, Lcom/unity3d/player/r;->a([F [F [F)V
    iget-object v0, v11, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v11, Lcom/unity3d/player/r;->E Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto/16 -0f3h
    iget-object v0, v11, Lcom/unity3d/player/r;->z [F
    aget v0, v0, v2
    iget-object v3, v11, Lcom/unity3d/player/r;->z [F
    aget v2, v3, v2
    mul-float/2addr v0, v2
    iget-object v2, v11, Lcom/unity3d/player/r;->z [F
    aget v2, v2, v10
    iget-object v3, v11, Lcom/unity3d/player/r;->z [F
    aget v3, v3, v10
    mul-float/2addr v2, v3
    add-float/2addr v0, v2
    iget-object v2, v11, Lcom/unity3d/player/r;->z [F
    aget v2, v2, v7
    iget-object v3, v11, Lcom/unity3d/player/r;->z [F
    aget v3, v3, v7
    mul-float/2addr v2, v3
    add-float/2addr v0, v2
    iget-object v3, v11, Lcom/unity3d/player/r;->z [F
    const/4 v2, 3
    const/high16 v4, 1065353216
    cmpg-float v4, v0, v4
    if-gez v4, +00dh
    const/high16 v4, 1065353216
    sub-float v0, v4, v0
    float-to-double v4, v0
    invoke-static v4, v5, Ljava/lang/Math;->sqrt(D)D
    move-result-wide v4
    double-to-float v0, v4
    goto -46h
    const/4 v0, 0
    goto -48h
    const/high16 v1, 1119092736
    add-float/2addr v0, v1
    goto/16 -0e2h
    const/high16 v1, 1127481344
    add-float/2addr v0, v1
    goto/16 -0e7h
    const/high16 v1, 1132920832
    add-float/2addr v0, v1
    goto/16 -0ech
    const/4 v1, 0
    cmpg-float v1, v0, v1
    if-gez v1, +07bh
    add-float/2addr v0, v9
    move v6, v0
    iget-object v0, v11, Lcom/unity3d/player/r;->F [F
    iget-object v1, v11, Lcom/unity3d/player/r;->h [F
    aget v1, v1, v2
    aput v1, v0, v2
    iget-object v0, v11, Lcom/unity3d/player/r;->F [F
    iget-object v1, v11, Lcom/unity3d/player/r;->h [F
    aget v1, v1, v10
    aput v1, v0, v10
    iget-object v0, v11, Lcom/unity3d/player/r;->F [F
    iget-object v1, v11, Lcom/unity3d/player/r;->h [F
    aget v1, v1, v7
    aput v1, v0, v7
    iget-object v0, v11, Lcom/unity3d/player/r;->F [F
    const/4 v1, 3
    aput v6, v0, v1
    iget-object v0, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    if-eqz v0, +056h
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v0
    iget-object v2, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-virtual v2, Landroid/location/Location;->getTime()J
    move-result-wide v2
    sub-long/2addr v0, v2
    const-wide/32 v2, 1200000
    cmp-long v0, v0, v2
    if-gez v0, +044h
    new-instance v0, Landroid/hardware/GeomagneticField;
    iget-object v1, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-virtual v1, Landroid/location/Location;->getLatitude()D
    move-result-wide v1
    double-to-float v1, v1
    iget-object v2, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-virtual v2, Landroid/location/Location;->getLongitude()D
    move-result-wide v2
    double-to-float v2, v2
    iget-object v3, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-virtual v3, Landroid/location/Location;->getAltitude()D
    move-result-wide v3
    double-to-float v3, v3
    iget-object v4, v11, Lcom/unity3d/player/r;->M Landroid/location/Location;
    invoke-virtual v4, Landroid/location/Location;->getTime()J
    move-result-wide v4
    invoke-direct/range v0 ... v5, Landroid/hardware/GeomagneticField;-><init>(F F F J)V
    invoke-virtual v0, Landroid/hardware/GeomagneticField;->getDeclination()F
    move-result v0
    add-float/2addr v6, v0
    move v0, v6
    cmpl-float v1, v0, v9
    if-ltz v1, +006h
    sub-float v6, v0, v9
    move v0, v6
    goto -7h
    const/4 v1, 0
    cmpg-float v1, v0, v1
    if-gez v1, +003h
    add-float/2addr v0, v9
    iget-object v1, v11, Lcom/unity3d/player/r;->F [F
    const/4 v2, 4
    aput v0, v1, v2
    iget-object v0, v11, Lcom/unity3d/player/r;->c Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v11, Lcom/unity3d/player/r;->H Ljava/lang/Runnable;
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto/16 -1b1h
    move v0, v6
    goto -1dh
    move v6, v0
    goto -78h
    nop
    packed-switch-payload 1 2 3 4 5 6 7 8 9 a b
    packed-switch-payload 1 2 3
.end method

.method public final onStatusChanged(Ljava/lang/String; I Landroid/os/Bundle;)V
    .registers 4
    return-void
.end method
