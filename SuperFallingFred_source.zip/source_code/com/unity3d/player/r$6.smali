.class final Lcom/unity3d/player/r$6;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/r;

.method constructor <init>(Lcom/unity3d/player/r;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 9
    iget-object v0, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v0, Lcom/unity3d/player/r;->e(Lcom/unity3d/player/r;)Lcom/unity3d/player/UnityPlayer;
    move-result-object v0
    iget-object v1, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v1, Lcom/unity3d/player/r;->s(Lcom/unity3d/player/r;)[F
    move-result-object v1
    const/4 v2, 0
    aget v1, v1, v2
    iget-object v2, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v2, Lcom/unity3d/player/r;->s(Lcom/unity3d/player/r;)[F
    move-result-object v2
    const/4 v3, 1
    aget v2, v2, v3
    iget-object v3, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v3, Lcom/unity3d/player/r;->s(Lcom/unity3d/player/r;)[F
    move-result-object v3
    const/4 v4, 2
    aget v3, v3, v4
    iget-object v4, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v4, Lcom/unity3d/player/r;->s(Lcom/unity3d/player/r;)[F
    move-result-object v4
    const/4 v5, 3
    aget v4, v4, v5
    iget-object v5, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v5, Lcom/unity3d/player/r;->s(Lcom/unity3d/player/r;)[F
    move-result-object v5
    const/4 v6, 4
    aget v5, v5, v6
    iget-object v6, v8, Lcom/unity3d/player/r$6;->a Lcom/unity3d/player/r;
    invoke-static v6, Lcom/unity3d/player/r;->t(Lcom/unity3d/player/r;)D
    move-result-wide v6
    invoke-virtual/range v0 ... v7, Lcom/unity3d/player/UnityPlayer;->nativeCompass(F F F F F D)V
    return-void
.end method
