.class final Lcom/unity3d/player/UnityPlayer$20;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$20;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 9
    const/4 v1, 0
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$20;->a Lcom/unity3d/player/UnityPlayer;
    const-wide/high16 v6, -4616189618054758400
    move v2, v1
    move v3, v1
    move v4, v1
    move v5, v1
    invoke-virtual/range v0 ... v7, Lcom/unity3d/player/UnityPlayer;->nativeCompass(F F F F F D)V
    return-void
.end method
