.class final Lcom/unity3d/player/UnityPlayer$18;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    move-result-object v0
    if-nez v0, +003h
    return-void
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->removeView(Landroid/view/View;)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 0
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/y;)Lcom/unity3d/player/y;
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v0, Lcom/unity3d/player/UnityPlayer;->resume()V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$18;->a Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 0
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->d(Lcom/unity3d/player/UnityPlayer; Z)V
    goto -1dh
.end method
