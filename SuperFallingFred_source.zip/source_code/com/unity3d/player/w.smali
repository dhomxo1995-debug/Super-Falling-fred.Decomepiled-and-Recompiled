.class 0x0 Lcom/unity3d/player/w;
.super Landroid/opengl/GLSurfaceView;
.implements Lcom/unity3d/player/UnityGL;

.field private static a:Z
.field private static b:Z
.field private c:Lcom/unity3d/player/v;
.field private d:Z

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/unity3d/player/w;->a Z
    return-void
.end method

.method public constructor <init>(Landroid/content/Context; I Z Z Z I I I)V
    .registers 15
    const/4 v3, 0
    invoke-direct v6, v7, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V
    const/4 v0, 0
    iput-object v0, v6, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    iput-boolean v3, v6, Lcom/unity3d/player/w;->d Z
    sput-boolean v10, Lcom/unity3d/player/w;->a Z
    const/4 v0, 2
    if-ne v8, v0, +025h
    const/4 v0, 1
    sput-boolean v0, Lcom/unity3d/player/w;->b Z
    iput-boolean v9, v6, Lcom/unity3d/player/w;->d Z
    new-instance v0, Lcom/unity3d/player/w$a;
    invoke-direct v0, v3, Lcom/unity3d/player/w$a;-><init>(B)V
    invoke-virtual v6, v0, Lcom/unity3d/player/w;->setEGLContextFactory(Landroid/opengl/GLSurfaceView$EGLContextFactory;)V
    new-instance v0, Lcom/unity3d/player/v;
    move v1, v11
    move v2, v12
    move v4, v14
    move v5, v8
    invoke-direct/range v0 ... v5, Lcom/unity3d/player/v;-><init>(Z I I I I)V
    iput-object v0, v6, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    iget-object v0, v6, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    iget-object v0, v0, Lcom/unity3d/player/v;->a Landroid/opengl/GLSurfaceView$EGLConfigChooser;
    invoke-virtual v6, v0, Lcom/unity3d/player/w;->setEGLConfigChooser(Landroid/opengl/GLSurfaceView$EGLConfigChooser;)V
    invoke-virtual v6, Lcom/unity3d/player/w;->b()V
    return-void
    move v0, v3
    goto -23h
.end method

.method static synthetic a(Ljava/lang/String;)V
    .registers 1
    invoke-static v0, Lcom/unity3d/player/w;->b(Ljava/lang/String;)V
    return-void
.end method

.method static synthetic a(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    .registers 2
    invoke-static v0, v1, Lcom/unity3d/player/w;->b(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    return-void
.end method

.method private static b(Ljava/lang/String;)V
    .registers 2
    sget-boolean v0, Lcom/unity3d/player/w;->a Z
    if-eqz v0, +003h
    return-void
    const-string v0, "Unity"
    invoke-static v0, v1, Landroid/util/Log;->d(Ljava/lang/String; Ljava/lang/String;)I
    goto -6h
.end method

.method private static b(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    .registers 10
    const/4 v7, 2
    const/4 v1, 0
    move v0, v1
    if-ge v0, v7, +023h
    invoke-interface v9, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I
    move-result v2
    const/16 v3, 12288
    if-eq v2, v3, +01bh
    const-string v3, "Unity"
    const-string v4, "%s: EGL error: 0x%x"
    new-array v5, v7, [Ljava/lang/Object;
    aput-object v8, v5, v1
    const/4 v6, 1
    invoke-static v2, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v2
    aput-object v2, v5, v6
    invoke-static v4, v5, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v2
    invoke-static v3, v2, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String;)I
    add-int/lit8 v0, v0, 1
    goto -22h
    return-void
.end method

.method static synthetic c()Z
    .registers 1
    sget-boolean v0, Lcom/unity3d/player/w;->b Z
    return v0
.end method

.method public final a()V
    .registers 1
    invoke-super v0, Landroid/opengl/GLSurfaceView;->onDetachedFromWindow()V
    return-void
.end method

.method public final a(Z I)Z
    .registers 5
    iget-object v0, v2, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    invoke-virtual v0, v3, Lcom/unity3d/player/v;->a(Z)Z
    move-result v0
    or-int/lit8 v0, v0, 0
    iget-object v1, v2, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    invoke-virtual v1, v4, Lcom/unity3d/player/v;->a(I)Z
    move-result v1
    or-int/2addr v0, v1
    return v0
.end method

.method public final b()V
    .registers 3
    iget-boolean v0, v2, Lcom/unity3d/player/w;->d Z
    if-eqz v0, +018h
    const/4 v0, -3
    iget-object v1, v2, Lcom/unity3d/player/w;->c Lcom/unity3d/player/v;
    invoke-virtual v1, Lcom/unity3d/player/v;->a()Z
    move-result v1
    if-eqz v1, +007h
    iget-boolean v0, v2, Lcom/unity3d/player/w;->d Z
    if-eqz v0, +00dh
    const/4 v0, 1
    invoke-virtual v2, Lcom/unity3d/player/w;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v1
    invoke-interface v1, v0, Landroid/view/SurfaceHolder;->setFormat(I)V
    return-void
    const/4 v0, -1
    goto -16h
    const/4 v0, 2
    goto -bh
.end method

.method protected onDetachedFromWindow()V
    .registers 2
    const-string v0, "onDetachedFromWindow"
    invoke-static v0, Lcom/unity3d/player/w;->b(Ljava/lang/String;)V
    return-void
.end method

.method public onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 3
    const/4 v0, 0
    return v0
.end method
