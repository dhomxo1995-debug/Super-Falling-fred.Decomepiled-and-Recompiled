.class final Lcom/unity3d/player/UnityPlayer$5;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:I
.field private synthetic c:Z
.field private synthetic d:I
.field private synthetic e:I
.field private synthetic f:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I I Z I I)V
    .registers 7
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$5;->f Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$5;->a I
    iput v3, v0, Lcom/unity3d/player/UnityPlayer$5;->b I
    iput-boolean v4, v0, Lcom/unity3d/player/UnityPlayer$5;->c Z
    iput v5, v0, Lcom/unity3d/player/UnityPlayer$5;->d I
    iput v6, v0, Lcom/unity3d/player/UnityPlayer$5;->e I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 7
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer$5;->f Lcom/unity3d/player/UnityPlayer;
    iget v1, v6, Lcom/unity3d/player/UnityPlayer$5;->a I
    iget v2, v6, Lcom/unity3d/player/UnityPlayer$5;->b I
    iget-boolean v3, v6, Lcom/unity3d/player/UnityPlayer$5;->c Z
    iget v4, v6, Lcom/unity3d/player/UnityPlayer$5;->d I
    iget v5, v6, Lcom/unity3d/player/UnityPlayer$5;->e I
    invoke-static/range v0 ... v5, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I I Z I I)V
    return-void
.end method
