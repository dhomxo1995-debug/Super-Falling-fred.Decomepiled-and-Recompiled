.class final Lcom/unity3d/player/UnityPlayer$3;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 8
    const/4 v6, -2
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->g(Lcom/unity3d/player/UnityPlayer;)I
    move-result v0
    if-ltz v0, +05dh
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v1
    if-nez v1, +040h
    const/4 v1, 4
    new-array v1, v1, [I
    fill-array-data v1, +0000052h
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    new-instance v3, Landroid/widget/ProgressBar;
    iget-object v4, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v4, Lcom/unity3d/player/UnityPlayer;->i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    move-result-object v4
    const/4 v5, 0
    aget v0, v1, v0
    invoke-direct v3, v4, v5, v0, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context; Landroid/util/AttributeSet; I)V
    invoke-static v2, v3, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Landroid/widget/ProgressBar;)Landroid/widget/ProgressBar;
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v0
    const/4 v1, 1
    invoke-virtual v0, v1, Landroid/widget/ProgressBar;->setIndeterminate(Z)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v0
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;
    const/16 v2, 51
    invoke-direct v1, v6, v6, v2, Landroid/widget/FrameLayout$LayoutParams;-><init>(I I I)V
    invoke-virtual v0, v1, Landroid/widget/ProgressBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->addView(Landroid/view/View;)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v1, Landroid/widget/ProgressBar;->setVisibility(I)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer$3;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->bringChildToFront(Landroid/view/View;)V
    return-void
    nop
    fill-array-data-payload b'z\x00\x01\x01\x89\x02\x01\x01y\x00\x01\x01\x88\x02\x01\x01' | \x7a\x00\x01\x01\x89\x02\x01\x01\x79\x00\x01\x01\x88\x02\x01\x01
.end method
