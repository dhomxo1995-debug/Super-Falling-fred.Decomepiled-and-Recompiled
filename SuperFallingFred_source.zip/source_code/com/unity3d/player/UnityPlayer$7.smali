.class final Lcom/unity3d/player/UnityPlayer$7;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:I
.field private synthetic c:F
.field private synthetic d:F
.field private synthetic e:F
.field private synthetic f:F
.field private synthetic g:F
.field private synthetic h:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I I F F F F F)V
    .registers 9
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$7;->a I
    iput v3, v0, Lcom/unity3d/player/UnityPlayer$7;->b I
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$7;->c F
    iput v5, v0, Lcom/unity3d/player/UnityPlayer$7;->d F
    iput v6, v0, Lcom/unity3d/player/UnityPlayer$7;->e F
    iput v7, v0, Lcom/unity3d/player/UnityPlayer$7;->f F
    iput v8, v0, Lcom/unity3d/player/UnityPlayer$7;->g F
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 9
    const/4 v3, 1
    const/4 v1, 0
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->a I
    packed-switch v0, +0000060h
    move v0, v1
    move v2, v1
    iget-object v4, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    iget v5, v8, Lcom/unity3d/player/UnityPlayer$7;->c F
    iget v6, v8, Lcom/unity3d/player/UnityPlayer$7;->d F
    invoke-static v4, v2, v5, v6, v0, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I F F I)V
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->j(Lcom/unity3d/player/UnityPlayer;)I
    move-result v0
    int-to-float v0, v0
    iget v2, v8, Lcom/unity3d/player/UnityPlayer$7;->c F
    iget v4, v8, Lcom/unity3d/player/UnityPlayer$7;->d F
    sub-float v4, v0, v4
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->c F
    iget v5, v8, Lcom/unity3d/player/UnityPlayer$7;->e F
    sub-float v5, v0, v5
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->d F
    iget v6, v8, Lcom/unity3d/player/UnityPlayer$7;->f F
    sub-float/2addr v0, v6
    neg-float v6, v0
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->a I
    const/16 v7, 8
    if-ne v0, v7, +028h
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->g F
    iget-object v7, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v7, v5, v6, v0, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; F F F)V
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, v2, v4, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; F F)V
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->a I
    if-nez v0, +01ah
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, v3, Lcom/unity3d/player/UnityPlayer;->b(Lcom/unity3d/player/UnityPlayer; Z)V
    return-void
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->b I
    move v2, v1
    goto -41h
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->b I
    move v2, v3
    goto -45h
    const/4 v0, 2
    move v2, v0
    move v0, v1
    goto -49h
    const/4 v0, 3
    move v2, v0
    move v0, v1
    goto -4dh
    const/4 v0, 0
    goto -25h
    iget v0, v8, Lcom/unity3d/player/UnityPlayer$7;->a I
    if-ne v0, v3, -015h
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$7;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->b(Lcom/unity3d/player/UnityPlayer; Z)V
    goto -1ch
    nop
    packed-switch-payload 0 1 2 3 4 5 6 7
.end method
