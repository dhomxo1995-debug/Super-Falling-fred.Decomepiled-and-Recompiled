.class final Lcom/unity3d/player/q;
.super Landroid/widget/ImageView;

.field private a:Landroid/graphics/Bitmap;

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3
    invoke-direct v1, v2, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V
    const/4 v0, 0
    iput-object v0, v1, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    return-void
.end method

.method public final a()V
    .registers 6
    const/4 v4, 0
    iget-object v0, v5, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    if-nez v0, +003h
    return-void
    iget-object v0, v5, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    invoke-virtual v5, v0, Lcom/unity3d/player/q;->setImageBitmap(Landroid/graphics/Bitmap;)V
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;
    iget-object v1, v5, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    invoke-virtual v1, Landroid/graphics/Bitmap;->getWidth()I
    move-result v1
    iget-object v2, v5, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    invoke-virtual v2, Landroid/graphics/Bitmap;->getHeight()I
    move-result v2
    const/16 v3, 51
    invoke-direct v0, v1, v2, v3, Landroid/widget/FrameLayout$LayoutParams;-><init>(I I I)V
    invoke-virtual v5, v0, Lcom/unity3d/player/q;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v5, v4, v4, v4, v4, Lcom/unity3d/player/q;->setPadding(I I I I)V
    goto -1fh
.end method

.method public final a(I I)V
    .registers 11
    const/4 v0, 0
    mul-int v1, v9, v10
    mul-int/lit8 v1, v1, 4
    invoke-static v1, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;
    move-result-object v6
    invoke-static Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;
    move-result-object v1
    invoke-virtual v6, v1, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    invoke-virtual v6, v0, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;
    const/16 v4, 6408
    const/16 v5, 5121
    move v1, v0
    move v2, v9
    move v3, v10
    invoke-static/range v0 ... v6, Landroid/opengl/GLES10;->glReadPixels(I I I I I I Ljava/nio/Buffer;)V
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888 Landroid/graphics/Bitmap$Config;
    invoke-static v9, v10, v1, Landroid/graphics/Bitmap;->createBitmap(I I Landroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    move-result-object v1
    invoke-virtual v6, v0, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;
    invoke-virtual v1, v6, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V
    new-instance v6, Landroid/graphics/Matrix;
    invoke-direct v6, Landroid/graphics/Matrix;-><init>()V
    const/high16 v2, 1065353216
    const/high16 v3, -1082130432
    invoke-virtual v6, v2, v3, Landroid/graphics/Matrix;->preScale(F F)Z
    move v2, v0
    move v3, v0
    move v4, v9
    move v5, v10
    move v7, v0
    invoke-static/range v1 ... v7, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap; I I I I Landroid/graphics/Matrix; Z)Landroid/graphics/Bitmap;
    move-result-object v0
    iput-object v0, v8, Lcom/unity3d/player/q;->a Landroid/graphics/Bitmap;
    return-void
.end method
