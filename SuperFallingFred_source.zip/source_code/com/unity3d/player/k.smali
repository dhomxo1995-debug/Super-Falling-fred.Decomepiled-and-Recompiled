.class public final Lcom/unity3d/player/k;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static a(Landroid/view/MotionEvent;)I
    .registers 5
    const/4 v1, 2
    const/4 v0, 1
    invoke-virtual v4, Landroid/view/MotionEvent;->getButtonState()I
    move-result v2
    and-int/lit8 v3, v2, 1
    if-eq v3, v0, +00eh
    and-int/lit8 v3, v2, 2
    if-ne v3, v1, +003h
    return v0
    and-int/lit8 v0, v2, 4
    const/4 v2, 4
    if-ne v0, v2, +004h
    move v0, v1
    goto -7h
    const/4 v0, 0
    goto -9h
.end method
