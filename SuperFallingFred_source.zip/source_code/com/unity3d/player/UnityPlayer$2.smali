.class final Lcom/unity3d/player/UnityPlayer$2;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/w;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/w;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$2;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +00ah
    sget-object v0, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    const/4 v2, 0
    invoke-interface v0, v1, v2, Lcom/unity3d/player/j;->a(Landroid/opengl/GLSurfaceView; Z)V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-virtual v0, Lcom/unity3d/player/w;->onPause()V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$2;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->f(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/t;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-virtual v0, v1, Lcom/unity3d/player/t;->e(Landroid/view/View;)V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-virtual v0, Lcom/unity3d/player/w;->b()V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$2;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->f(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/t;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-virtual v0, v1, Lcom/unity3d/player/t;->d(Landroid/view/View;)V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    invoke-virtual v0, Lcom/unity3d/player/w;->onResume()V
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +00ah
    sget-object v0, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer$2;->a Lcom/unity3d/player/w;
    const/4 v2, 1
    invoke-interface v0, v1, v2, Lcom/unity3d/player/j;->a(Landroid/opengl/GLSurfaceView; Z)V
    return-void
.end method
