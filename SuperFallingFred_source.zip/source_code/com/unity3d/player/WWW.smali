.class 0x0 Lcom/unity3d/player/WWW;
.super Ljava/lang/Thread;

.field private a:I
.field private b:I
.field private c:Ljava/lang/String;
.field private d:[B
.field private e:Ljava/util/Map;

.method constructor <init>(I Ljava/lang/String; [B Ljava/util/Map;)V
    .registers 6
    invoke-direct v1, Ljava/lang/Thread;-><init>()V
    iput v2, v1, Lcom/unity3d/player/WWW;->b I
    iput-object v3, v1, Lcom/unity3d/player/WWW;->c Ljava/lang/String;
    iput-object v4, v1, Lcom/unity3d/player/WWW;->d [B
    iput-object v5, v1, Lcom/unity3d/player/WWW;->e Ljava/util/Map;
    const/4 v0, 0
    iput v0, v1, Lcom/unity3d/player/WWW;->a I
    invoke-virtual v1, Lcom/unity3d/player/WWW;->start()V
    return-void
.end method

.method private static native doneCallback(I)V
    # abstract or native method
.end method

.method private static native errorCallback(I Ljava/lang/String;)V
    # abstract or native method
.end method

.method private static native headerCallback(I Ljava/lang/String;)Z
    # abstract or native method
.end method

.method private static native progressCallback(I F F D I)V
    # abstract or native method
.end method

.method private static native readCallback(I [B I)Z
    # abstract or native method
.end method

.method protected headerCallback(Ljava/lang/String; Ljava/lang/String;)Z
    .registers 5
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct v0, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v0, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, ": "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, "
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget v1, v2, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->headerCallback(I Ljava/lang/String;)Z
    move-result v0
    return v0
.end method

.method protected headerCallback(Ljava/util/Map;)Z
    .registers 8
    if-eqz v7, +008h
    invoke-interface v7, Ljava/util/Map;->size()I
    move-result v0
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    invoke-interface v7, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v4
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +035h
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/util/List;
    invoke-interface v1, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v5
    invoke-interface v5, Ljava/util/Iterator;->hasNext()Z
    move-result v1
    if-eqz v1, -01ah
    invoke-interface v5, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Ljava/lang/String;
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2, ": "
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, "
"
    invoke-virtual v3, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    goto -22h
    iget v0, v6, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/WWW;->headerCallback(I Ljava/lang/String;)Z
    move-result v0
    goto -51h
.end method

.method protected progressCallback(I I I I J J)V
    .registers 22
    if-lez v17, +044h
    move/from16 v0, v16
    int-to-float v1, v0
    move/from16 v0, v17
    int-to-float v2, v0
    div-float v3, v1, v2
    const/high16 v4, 1065353216
    sub-int v1, v17, v16
    const/4 v2, 0
    invoke-static v1, v2, Ljava/lang/Math;->max(I I)I
    move-result v1
    const-wide v5, 4652007308841189376
    move/from16 v0, v16
    int-to-double v7, v0
    mul-double/2addr v5, v7
    sub-long v7, v18, v20
    long-to-double v7, v7
    const-wide v9, 4591870180066957722
    invoke-static v7, v8, v9, v10, Ljava/lang/Math;->max(D D)D
    move-result-wide v7
    div-double/2addr v5, v7
    int-to-double v1, v1
    div-double/2addr v1, v5
    invoke-static v1, v2, Ljava/lang/Double;->isInfinite(D)Z
    move-result v5
    if-nez v5, +008h
    invoke-static v1, v2, Ljava/lang/Double;->isNaN(D)Z
    move-result v5
    if-eqz v5, +004h
    const-wide/16 v1, 0
    move-wide v11, v1
    move v2, v4
    move-wide v4, v11
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    move/from16 v6, v17
    invoke-static/range v1 ... v6, Lcom/unity3d/player/WWW;->progressCallback(I F F D I)V
    return-void
    if-lez v15, -001h
    const/4 v3, 0
    div-int v1, v14, v15
    int-to-float v2, v1
    const-wide/16 v4, 0
    goto -10h
.end method

.method protected readCallback([B I)Z
    .registers 4
    iget v0, v1, Lcom/unity3d/player/WWW;->b I
    invoke-static v0, v2, v3, Lcom/unity3d/player/WWW;->readCallback(I [B I)Z
    move-result v0
    return v0
.end method

.method public run()V
    .registers 14
    iget v0, v13, Lcom/unity3d/player/WWW;->a I
    add-int/lit8 v0, v0, 1
    iput v0, v13, Lcom/unity3d/player/WWW;->a I
    const/4 v1, 5
    if-le v0, v1, +00ah
    iget v0, v13, Lcom/unity3d/player/WWW;->b I
    const-string v1, "Too many redirects"
    invoke-static v0, v1, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    return-void
    new-instance v11, Ljava/net/URL;
    iget-object v0, v13, Lcom/unity3d/player/WWW;->c Ljava/lang/String;
    invoke-direct v11, v0, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    invoke-virtual v11, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    move-result-object v9
    invoke-virtual v11, Ljava/net/URL;->getProtocol()Ljava/lang/String;
    move-result-object v0
    const-string v1, "file"
    invoke-virtual v0, v1, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +04dh
    invoke-virtual v11, Ljava/net/URL;->getHost()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +047h
    invoke-virtual v11, Ljava/net/URL;->getHost()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/String;->length()I
    move-result v0
    if-eqz v0, +03dh
    iget v0, v13, Lcom/unity3d/player/WWW;->b I
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v11, Ljava/net/URL;->getHost()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v11, Ljava/net/URL;->getFile()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " is not an absolute path!"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto -4ch
    move-exception v0
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/net/MalformedURLException;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto -57h
    move-exception v0
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/io/IOException;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto -62h
    iget-object v0, v13, Lcom/unity3d/player/WWW;->e Ljava/util/Map;
    if-eqz v0, +028h
    iget-object v0, v13, Lcom/unity3d/player/WWW;->e Ljava/util/Map;
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +018h
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-virtual v9, v1, v0, Ljava/net/URLConnection;->addRequestProperty(Ljava/lang/String; Ljava/lang/String;)V
    goto -1bh
    const/16 v10, 1428
    iget-object v0, v13, Lcom/unity3d/player/WWW;->d [B
    if-eqz v0, +03ah
    const/4 v0, 1
    invoke-virtual v9, v0, Ljava/net/URLConnection;->setDoOutput(Z)V
    invoke-virtual v9, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;
    move-result-object v12
    const/4 v1, 0
    iget-object v0, v13, Lcom/unity3d/player/WWW;->d [B
    array-length v0, v0
    if-ge v1, v0, +02ch
    const/16 v0, 1428
    iget-object v2, v13, Lcom/unity3d/player/WWW;->d [B
    array-length v2, v2
    sub-int/2addr v2, v1
    invoke-static v0, v2, Ljava/lang/Math;->min(I I)I
    move-result v0
    iget-object v2, v13, Lcom/unity3d/player/WWW;->d [B
    invoke-virtual v12, v2, v1, v0, Ljava/io/OutputStream;->write([B I I)V
    add-int/2addr v1, v0
    iget-object v0, v13, Lcom/unity3d/player/WWW;->d [B
    array-length v2, v0
    const/4 v3, 0
    const/4 v4, 0
    const-wide/16 v5, 0
    const-wide/16 v7, 0
    move-object v0, v13
    invoke-virtual/range v0 ... v8, Lcom/unity3d/player/WWW;->progressCallback(I I I I J J)V
    goto -22h
    move-exception v0
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/lang/Exception;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto/16 -0c9h
    instance-of v0, v9, Ljava/net/HttpURLConnection;
    if-eqz v0, +044h
    move-object v0, v9
    check-cast v0, Ljava/net/HttpURLConnection;
    invoke-virtual v0, Ljava/net/HttpURLConnection;->getResponseCode()I
    move-result v1
    invoke-virtual v0, Ljava/net/HttpURLConnection;->getHeaderFields()Ljava/util/Map;
    move-result-object v2
    if-eqz v2, +037h
    const/16 v3, 301
    if-eq v1, v3, +006h
    const/16 v3, 302
    if-ne v1, v3, +02fh
    const-string v1, "Location"
    invoke-interface v2, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/util/List;
    if-eqz v1, +025h
    invoke-interface v1, Ljava/util/List;->isEmpty()Z
    move-result v2
    if-nez v2, +01fh
    invoke-virtual v0, Ljava/net/HttpURLConnection;->disconnect()V
    const/4 v0, 0
    invoke-interface v1, v0, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v13, Lcom/unity3d/player/WWW;->c Ljava/lang/String;
    invoke-virtual v13, Lcom/unity3d/player/WWW;->run()V
    goto/16 -103h
    move-exception v0
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/io/IOException;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto/16 -10fh
    invoke-virtual v9, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;
    move-result-object v1
    invoke-virtual v13, v1, Lcom/unity3d/player/WWW;->headerCallback(Ljava/util/Map;)Z
    move-result v0
    if-eqz v1, +00ah
    const-string v2, "content-length"
    invoke-interface v1, v2, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +01ch
    invoke-virtual v9, Ljava/net/URLConnection;->getContentLength()I
    move-result v2
    const/4 v3, -1
    if-eq v2, v3, +015h
    if-nez v0, +012h
    const-string v0, "content-length"
    invoke-virtual v9, Ljava/net/URLConnection;->getContentLength()I
    move-result v2
    invoke-static v2, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v13, v0, v2, Lcom/unity3d/player/WWW;->headerCallback(Ljava/lang/String; Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +040h
    const/4 v0, 1
    if-eqz v1, +00ah
    const-string v2, "content-type"
    invoke-interface v1, v2, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    move-result v1
    if-nez v1, +017h
    invoke-virtual v9, Ljava/net/URLConnection;->getContentType()Ljava/lang/String;
    move-result-object v1
    if-eqz v1, +011h
    if-nez v0, +00eh
    const-string v0, "content-type"
    invoke-virtual v9, Ljava/net/URLConnection;->getContentType()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v13, v0, v1, Lcom/unity3d/player/WWW;->headerCallback(Ljava/lang/String; Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +023h
    const/4 v0, 1
    if-eqz v0, +022h
    iget v0, v13, Lcom/unity3d/player/WWW;->b I
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    iget-object v2, v13, Lcom/unity3d/player/WWW;->c Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " aborted"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto/16 -178h
    const/4 v0, 0
    goto -3eh
    const/4 v0, 0
    goto -21h
    invoke-virtual v9, Ljava/net/URLConnection;->getContentLength()I
    move-result v0
    if-lez v0, +060h
    invoke-virtual v9, Ljava/net/URLConnection;->getContentLength()I
    move-result v4
    invoke-virtual v11, Ljava/net/URL;->getProtocol()Ljava/lang/String;
    move-result-object v0
    const-string v1, "file"
    invoke-virtual v0, v1, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-nez v0, +00eh
    invoke-virtual v11, Ljava/net/URL;->getProtocol()Ljava/lang/String;
    move-result-object v0
    const-string v1, "jar"
    invoke-virtual v0, v1, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +070h
    if-nez v4, +044h
    const v0, 32768
    const/4 v3, 0
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v7
    new-array v10, v0, [B
    invoke-virtual v9, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;
    move-result-object v9
    const/4 v0, 0
    const/4 v1, -1
    if-eq v0, v1, +04ah
    invoke-virtual v13, v10, v0, Lcom/unity3d/player/WWW;->readCallback([B I)Z
    move-result v1
    if-eqz v1, +034h
    iget v0, v13, Lcom/unity3d/player/WWW;->b I
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    iget-object v2, v13, Lcom/unity3d/player/WWW;->c Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, " aborted"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto/16 -1d4h
    move-exception v0
    iget v1, v13, Lcom/unity3d/player/WWW;->b I
    invoke-virtual v0, Ljava/lang/Exception;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/WWW;->errorCallback(I Ljava/lang/String;)V
    goto/16 -1e0h
    const/4 v4, 0
    goto -5bh
    const v0, 32768
    invoke-static v4, v0, Ljava/lang/Math;->min(I I)I
    move-result v0
    goto -46h
    add-int/2addr v3, v0
    const/4 v1, 0
    const/4 v2, 0
    invoke-static Ljava/lang/System;->currentTimeMillis()J
    move-result-wide v5
    move-object v0, v13
    invoke-virtual/range v0 ... v8, Lcom/unity3d/player/WWW;->progressCallback(I I I I J J)V
    invoke-virtual v9, v10, Ljava/io/InputStream;->read([B)I
    move-result v0
    goto -4ah
    const/4 v1, 0
    const/4 v2, 0
    const-wide/16 v5, 0
    const-wide/16 v7, 0
    move-object v0, v13
    move v4, v3
    invoke-virtual/range v0 ... v8, Lcom/unity3d/player/WWW;->progressCallback(I I I I J J)V
    iget v0, v13, Lcom/unity3d/player/WWW;->b I
    invoke-static v0, Lcom/unity3d/player/WWW;->doneCallback(I)V
    goto/16 -20ch
    move v0, v10
    goto -6ah
.end method
