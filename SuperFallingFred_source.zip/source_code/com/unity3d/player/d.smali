.class final Lcom/unity3d/player/d;
.super Ljava/lang/Object;

.field final a:I
.field final b:[I

.method public constructor <init>(I [I)V
    .registers 3
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput v1, v0, Lcom/unity3d/player/d;->a I
    iput-object v2, v0, Lcom/unity3d/player/d;->b [I
    return-void
.end method
