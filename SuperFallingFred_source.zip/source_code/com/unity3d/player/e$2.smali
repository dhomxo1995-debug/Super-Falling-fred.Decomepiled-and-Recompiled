.class final Lcom/unity3d/player/e$2;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Landroid/view/View;
.field private synthetic b:Lcom/unity3d/player/e;

.method constructor <init>(Lcom/unity3d/player/e; Landroid/view/View;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/e$2;->b Lcom/unity3d/player/e;
    iput-object v2, v0, Lcom/unity3d/player/e$2;->a Landroid/view/View;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    iget-object v0, v3, Lcom/unity3d/player/e$2;->b Lcom/unity3d/player/e;
    iget-object v1, v3, Lcom/unity3d/player/e$2;->a Landroid/view/View;
    const/4 v2, 1
    invoke-virtual v0, v1, v2, Lcom/unity3d/player/e;->a(Landroid/view/View; Z)V
    return-void
.end method
