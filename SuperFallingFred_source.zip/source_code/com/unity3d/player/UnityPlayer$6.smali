.class final Lcom/unity3d/player/UnityPlayer$6;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:F
.field private synthetic c:F
.field private synthetic d:I
.field private synthetic e:J
.field private synthetic f:I
.field private synthetic g:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I F F I J I)V
    .registers 9
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$6;->g Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$6;->a I
    iput v3, v0, Lcom/unity3d/player/UnityPlayer$6;->b F
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$6;->c F
    iput v5, v0, Lcom/unity3d/player/UnityPlayer$6;->d I
    iput-wide v6, v0, Lcom/unity3d/player/UnityPlayer$6;->e J
    iput v8, v0, Lcom/unity3d/player/UnityPlayer$6;->f I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 9
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer$6;->g Lcom/unity3d/player/UnityPlayer;
    iget v1, v8, Lcom/unity3d/player/UnityPlayer$6;->a I
    iget v2, v8, Lcom/unity3d/player/UnityPlayer$6;->b F
    iget v3, v8, Lcom/unity3d/player/UnityPlayer$6;->c F
    iget v4, v8, Lcom/unity3d/player/UnityPlayer$6;->d I
    iget-wide v5, v8, Lcom/unity3d/player/UnityPlayer$6;->e J
    iget v7, v8, Lcom/unity3d/player/UnityPlayer$6;->f I
    invoke-static/range v0 ... v7, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I F F I J I)V
    return-void
.end method
