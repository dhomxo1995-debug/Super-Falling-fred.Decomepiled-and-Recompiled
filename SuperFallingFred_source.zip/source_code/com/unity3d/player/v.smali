.class 0x0 Lcom/unity3d/player/v;
.super Ljava/lang/Object;

.field private static final p:[I
.field private static final q:[I
.field private static final r:[[I
.field private static synthetic s:Z
.field final a:Landroid/opengl/GLSurfaceView$EGLConfigChooser;
.field private b:I
.field private c:Z
.field private d:I
.field private e:I
.field private f:I
.field private g:Z
.field private h:I
.field private i:I
.field private j:I
.field private k:I
.field private l:I
.field private m:I
.field private n:I
.field private o:Lcom/unity3d/player/u;

.method static constructor <clinit>()V
    .registers 4
    const/16 v3, 11
    const/4 v1, 1
    const/4 v2, 0
    const-class v0, Lcom/unity3d/player/v;
    invoke-virtual v0, Ljava/lang/Class;->desiredAssertionStatus()Z
    move-result v0
    if-nez v0, +026h
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/v;->s Z
    new-array v0, v3, [I
    fill-array-data v0, +0000021h
    sput-object v0, Lcom/unity3d/player/v;->p [I
    new-array v0, v3, [I
    fill-array-data v0, +0000034h
    sput-object v0, Lcom/unity3d/player/v;->q [I
    const/4 v0, 3
    new-array v0, v0, [[I
    new-array v3, v2, [I
    aput-object v3, v0, v2
    sget-object v2, Lcom/unity3d/player/v;->q [I
    aput-object v2, v0, v1
    const/4 v1, 2
    sget-object v2, Lcom/unity3d/player/v;->p [I
    aput-object v2, v0, v1
    sput-object v0, Lcom/unity3d/player/v;->r [[I
    return-void
    move v0, v2
    goto -24h
    fill-array-data-payload b'$0\x00\x00\x04\x00\x00\x00#0\x00\x00\x04\x00\x00\x00"0\x00\x00\x04\x00\x00\x00@0\x00\x00\x04\x00\x00\x0030\x00\x00\x04\x00\x00\x0080\x00\x00' | \x24\x30\x00\x00\x04\x00\x00\x00\x23\x30\x00\x00\x04\x00\x00\x00\x22\x30\x00\x00\x04\x00\x00\x00\x40\x30\x00\x00\x04\x00\x00\x00\x33\x30\x00\x00\x04\x00\x00\x00\x38\x30\x00\x00
    fill-array-data-payload b'$0\x00\x00\x05\x00\x00\x00#0\x00\x00\x06\x00\x00\x00"0\x00\x00\x05\x00\x00\x00@0\x00\x00\x01\x00\x00\x0030\x00\x00\x04\x00\x00\x0080\x00\x00' | \x24\x30\x00\x00\x05\x00\x00\x00\x23\x30\x00\x00\x06\x00\x00\x00\x22\x30\x00\x00\x05\x00\x00\x00\x40\x30\x00\x00\x01\x00\x00\x00\x33\x30\x00\x00\x04\x00\x00\x00\x38\x30\x00\x00
.end method

.method constructor <init>(Z I I I I)V
    .registers 7
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Lcom/unity3d/player/v$1;
    invoke-direct v0, v1, Lcom/unity3d/player/v$1;-><init>(Lcom/unity3d/player/v;)V
    iput-object v0, v1, Lcom/unity3d/player/v;->a Landroid/opengl/GLSurfaceView$EGLConfigChooser;
    iput v6, v1, Lcom/unity3d/player/v;->b I
    invoke-direct v1, v2, v3, v4, v5, Lcom/unity3d/player/v;->a(Z I I I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/v;)Lcom/unity3d/player/u;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/v;->o Lcom/unity3d/player/u;
    return-object v0
.end method

.method private a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; [Ljavax/microedition/khronos/egl/EGLConfig;)Lcom/unity3d/player/u;
    .registers 14
    const/16 v9, 8
    array-length v3, v13
    const/4 v0, 0
    move v2, v0
    if-ge v2, v3, +086h
    aget-object v1, v13, v2
    sget-boolean v0, Lcom/unity3d/player/v;->s Z
    if-nez v0, +00ah
    if-nez v1, +008h
    new-instance v0, Ljava/lang/AssertionError;
    invoke-direct v0, Ljava/lang/AssertionError;-><init>()V
    throw v0
    new-instance v0, Lcom/unity3d/player/u;
    invoke-direct v0, v11, v12, v1, Lcom/unity3d/player/u;-><init>(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig;)V
    const/16 v1, 12325
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    const/16 v4, 12326
    invoke-virtual v0, v4, Lcom/unity3d/player/u;->a(I)I
    move-result v4
    const/16 v5, 12337
    invoke-virtual v0, v5, Lcom/unity3d/player/u;->a(I)I
    move-result v5
    const/16 v6, 12513
    invoke-virtual v0, v6, Lcom/unity3d/player/u;->a(I)I
    move-result v6
    iget v7, v10, Lcom/unity3d/player/v;->l I
    if-lt v1, v7, +052h
    iget v1, v10, Lcom/unity3d/player/v;->m I
    if-lt v4, v1, +04eh
    iget v1, v10, Lcom/unity3d/player/v;->n I
    if-ge v5, v1, +008h
    add-int/lit8 v1, v6, -1
    iget v4, v10, Lcom/unity3d/player/v;->n I
    if-lt v1, v4, +044h
    const/16 v1, 12324
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v4
    const/16 v1, 12323
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v5
    const/16 v1, 12322
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v6
    const/16 v1, 12321
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v7
    const/16 v1, 12346
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    const/16 v8, 12345
    invoke-virtual v0, v8, Lcom/unity3d/player/u;->a(I)I
    move-result v8
    if-nez v8, +005h
    if-nez v1, +003h
    const/4 v1, 1
    if-ne v4, v9, +008h
    if-ne v5, v9, +006h
    if-ne v6, v9, +004h
    if-eqz v1, +013h
    iget v1, v10, Lcom/unity3d/player/v;->h I
    if-ne v4, v1, +00fh
    iget v1, v10, Lcom/unity3d/player/v;->i I
    if-ne v5, v1, +00bh
    iget v1, v10, Lcom/unity3d/player/v;->j I
    if-ne v6, v1, +007h
    iget v1, v10, Lcom/unity3d/player/v;->k I
    if-ne v7, v1, +003h
    return-object v0
    add-int/lit8 v0, v2, 1
    move v2, v0
    goto/16 -084h
    const/4 v0, 0
    goto -7h
.end method

.method private a(Z I I I)V
    .registers 9
    const/4 v1, 0
    const/16 v2, 8
    const/4 v3, 5
    if-eqz v5, +065h
    invoke-static Lcom/unity3d/player/v;->b()Z
    move-result v0
    if-eqz v0, +05fh
    const/4 v0, 1
    iput-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    iput v6, v4, Lcom/unity3d/player/v;->d I
    iput v7, v4, Lcom/unity3d/player/v;->e I
    iput v8, v4, Lcom/unity3d/player/v;->f I
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    iput-boolean v0, v4, Lcom/unity3d/player/v;->g Z
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    if-eqz v0, +050h
    move v0, v2
    iput v0, v4, Lcom/unity3d/player/v;->h I
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    if-eqz v0, +04bh
    move v0, v2
    iput v0, v4, Lcom/unity3d/player/v;->i I
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    if-eqz v0, +046h
    move v0, v2
    iput v0, v4, Lcom/unity3d/player/v;->j I
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    if-eqz v0, +041h
    invoke-static Lcom/unity3d/player/v;->c()Z
    move-result v0
    if-eqz v0, +03bh
    iput v2, v4, Lcom/unity3d/player/v;->k I
    iget v0, v4, Lcom/unity3d/player/v;->d I
    iput v0, v4, Lcom/unity3d/player/v;->l I
    iget v0, v4, Lcom/unity3d/player/v;->e I
    iput v0, v4, Lcom/unity3d/player/v;->m I
    iget v0, v4, Lcom/unity3d/player/v;->f I
    iput v0, v4, Lcom/unity3d/player/v;->n I
    if-eqz v5, +00dh
    invoke-static Lcom/unity3d/player/v;->b()Z
    move-result v0
    if-nez v0, +007h
    const-string v0, "Running on pre-Gingerbread device: DisplayBuffer doesn't support 32bits."
    invoke-static v3, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    iget-boolean v0, v4, Lcom/unity3d/player/v;->c Z
    if-eqz v0, +00dh
    invoke-static Lcom/unity3d/player/v;->c()Z
    move-result v0
    if-nez v0, +007h
    const-string v0, "Running on pre-Honeycomb device: DisplayBuffer won't contain alpha channel."
    invoke-static v3, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    invoke-direct v4, Lcom/unity3d/player/v;->d()Lcom/unity3d/player/u;
    move-result-object v0
    iput-object v0, v4, Lcom/unity3d/player/v;->o Lcom/unity3d/player/u;
    return-void
    move v0, v1
    goto -5dh
    move v0, v3
    goto -4eh
    const/4 v0, 6
    goto -49h
    move v0, v3
    goto -44h
    move v2, v1
    goto -3ah
.end method

.method private static b()Z
    .registers 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v1, 9
    if-lt v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method private static c()Z
    .registers 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v1, 11
    if-lt v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method private d()Lcom/unity3d/player/u;
    .registers 4
    invoke-static Ljavax/microedition/khronos/egl/EGLContext;->getEGL()Ljavax/microedition/khronos/egl/EGL;
    move-result-object v0
    check-cast v0, Ljavax/microedition/khronos/egl/EGL10;
    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_DEFAULT_DISPLAY Ljava/lang/Object;
    invoke-interface v0, v1, Ljavax/microedition/khronos/egl/EGL10;->eglGetDisplay(Ljava/lang/Object;)Ljavax/microedition/khronos/egl/EGLDisplay;
    move-result-object v1
    sget-object v2, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_DISPLAY Ljavax/microedition/khronos/egl/EGLDisplay;
    if-ne v1, v2, +00ah
    new-instance v0, Ljava/lang/RuntimeException;
    const-string v1, "eglGetDisplay failed"
    invoke-direct v0, v1, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    throw v0
    const/4 v2, 2
    new-array v2, v2, [I
    invoke-interface v0, v1, v2, Ljavax/microedition/khronos/egl/EGL10;->eglInitialize(Ljavax/microedition/khronos/egl/EGLDisplay; [I)Z
    move-result v2
    if-nez v2, +00ah
    new-instance v0, Ljava/lang/RuntimeException;
    const-string v1, "eglInitialize failed"
    invoke-direct v0, v1, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    throw v0
    invoke-virtual v3, v0, v1, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay;)Lcom/unity3d/player/u;
    move-result-object v0
    return-object v0
.end method

.method final a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay;)Lcom/unity3d/player/u;
    .registers 16
    const/4 v12, 5
    const/4 v4, 0
    sget-object v0, Lcom/unity3d/player/v;->r [[I
    iget v1, v13, Lcom/unity3d/player/v;->b I
    aget-object v2, v0, v1
    const/4 v0, 1
    new-array v5, v0, [I
    const/4 v3, 0
    move-object v0, v14
    move-object v1, v15
    invoke-interface/range v0 ... v5, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay; [I [Ljavax/microedition/khronos/egl/EGLConfig; I [I)Z
    aget v10, v5, v4
    if-gtz v10, +00ah
    new-instance v0, Ljava/lang/IllegalArgumentException;
    const-string v1, "No configs match configSpec"
    invoke-direct v0, v1, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    throw v0
    new-array v9, v10, [Ljavax/microedition/khronos/egl/EGLConfig;
    move-object v6, v14
    move-object v7, v15
    move-object v8, v2
    move-object v11, v5
    invoke-interface/range v6 ... v11, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay; [I [Ljavax/microedition/khronos/egl/EGLConfig; I [I)Z
    invoke-direct v13, v14, v15, v9, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; [Ljavax/microedition/khronos/egl/EGLConfig;)Lcom/unity3d/player/u;
    move-result-object v0
    if-nez v0, +018h
    iget v1, v13, Lcom/unity3d/player/v;->n I
    if-lez v1, +014h
    iget v0, v13, Lcom/unity3d/player/v;->n I
    const/4 v1, 2
    if-ne v0, v1, +00ah
    move v0, v4
    iput v0, v13, Lcom/unity3d/player/v;->n I
    invoke-direct v13, v14, v15, v9, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; [Ljavax/microedition/khronos/egl/EGLConfig;)Lcom/unity3d/player/u;
    move-result-object v0
    goto -12h
    iget v0, v13, Lcom/unity3d/player/v;->n I
    div-int/lit8 v0, v0, 2
    goto -bh
    if-nez v0, +010h
    iget v1, v13, Lcom/unity3d/player/v;->l I
    const/16 v2, 24
    if-ne v1, v2, +00ah
    const/16 v0, 16
    iput v0, v13, Lcom/unity3d/player/v;->l I
    invoke-direct v13, v14, v15, v9, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; [Ljavax/microedition/khronos/egl/EGLConfig;)Lcom/unity3d/player/u;
    move-result-object v0
    if-nez v0, +015h
    iget-boolean v1, v13, Lcom/unity3d/player/v;->g Z
    if-eqz v1, +011h
    iput-boolean v4, v13, Lcom/unity3d/player/v;->g Z
    iput v12, v13, Lcom/unity3d/player/v;->h I
    const/4 v0, 6
    iput v0, v13, Lcom/unity3d/player/v;->i I
    iput v12, v13, Lcom/unity3d/player/v;->j I
    iput v4, v13, Lcom/unity3d/player/v;->k I
    invoke-direct v13, v14, v15, v9, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; [Ljavax/microedition/khronos/egl/EGLConfig;)Lcom/unity3d/player/u;
    move-result-object v0
    if-nez v0, +009h
    new-instance v0, Lcom/unity3d/player/u;
    aget-object v1, v9, v4
    invoke-direct v0, v14, v15, v1, Lcom/unity3d/player/u;-><init>(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig;)V
    return-object v0
.end method

.method final a()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/v;->g Z
    return v0
.end method

.method final a(I)Z
    .registers 5
    iget v0, v3, Lcom/unity3d/player/v;->f I
    if-eq v0, v4, +006h
    iget v0, v3, Lcom/unity3d/player/v;->n I
    if-ne v0, v4, +004h
    const/4 v0, 0
    return v0
    iget-boolean v0, v3, Lcom/unity3d/player/v;->c Z
    iget v1, v3, Lcom/unity3d/player/v;->d I
    iget v2, v3, Lcom/unity3d/player/v;->e I
    invoke-direct v3, v0, v1, v2, v4, Lcom/unity3d/player/v;->a(Z I I I)V
    const/4 v0, 1
    goto -bh
.end method

.method final a(Z)Z
    .registers 7
    const/4 v1, 1
    const/4 v2, 0
    if-eqz v6, +013h
    invoke-static Lcom/unity3d/player/v;->b()Z
    move-result v0
    if-eqz v0, +00dh
    move v0, v1
    iget-boolean v3, v5, Lcom/unity3d/player/v;->c Z
    if-eq v3, v0, +006h
    iget-boolean v3, v5, Lcom/unity3d/player/v;->g Z
    if-ne v3, v0, +006h
    move v1, v2
    return v1
    move v0, v2
    goto -bh
    iget v2, v5, Lcom/unity3d/player/v;->d I
    iget v3, v5, Lcom/unity3d/player/v;->e I
    iget v4, v5, Lcom/unity3d/player/v;->f I
    invoke-direct v5, v0, v2, v3, v4, Lcom/unity3d/player/v;->a(Z I I I)V
    goto -ch
.end method

.method public toString()Ljava/lang/String;
    .registers 3
    new-instance v0, Ljava/lang/StringBuilder;
    const-string v1, "EGLConfigChooser

Requested:
mReqGlesVersion: "
    invoke-direct v0, v1, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    iget v1, v2, Lcom/unity3d/player/v;->b I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mReq32bit: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-boolean v1, v2, Lcom/unity3d/player/v;->c Z
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mReqDepthSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->d I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mReqStencilSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->e I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mReqAALevel: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->f I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "

Actual
m32bit: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-boolean v1, v2, Lcom/unity3d/player/v;->g Z
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mRedSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->h I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mGreenSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->i I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mBlueSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->j I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mAlphaSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->k I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mDepthSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->l I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mStencilSize: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->m I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "
mAALevel: "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget v1, v2, Lcom/unity3d/player/v;->n I
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "

Select default configuration: 
"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v1, v2, Lcom/unity3d/player/v;->o Lcom/unity3d/player/u;
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
