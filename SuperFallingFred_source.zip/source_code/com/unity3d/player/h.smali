.class public final Lcom/unity3d/player/h;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static a()I
    .registers 1
    invoke-static Landroid/hardware/Camera;->getNumberOfCameras()I
    move-result v0
    return v0
.end method

.method public static a(Landroid/view/MotionEvent;)I
    .registers 2
    invoke-virtual v1, Landroid/view/MotionEvent;->getSource()I
    move-result v0
    return v0
.end method

.method public static a(Landroid/hardware/Camera$Parameters;)Ljava/util/List;
    .registers 2
    invoke-virtual v1, Landroid/hardware/Camera$Parameters;->getSupportedPreviewFpsRange()Ljava/util/List;
    move-result-object v0
    if-eqz v0, +003h
    return-object v0
    new-instance v0, Ljava/util/ArrayList;
    invoke-direct v0, Ljava/util/ArrayList;-><init>()V
    goto -6h
.end method

.method public static a(Landroid/hardware/Camera$Parameters; [I)V
    .registers 4
    const/4 v0, 0
    aget v0, v3, v0
    const/4 v1, 1
    aget v1, v3, v1
    invoke-virtual v2, v0, v1, Landroid/hardware/Camera$Parameters;->setPreviewFpsRange(I I)V
    return-void
.end method

.method public static a(I)Z
    .registers 3
    const/4 v0, 1
    new-instance v1, Landroid/hardware/Camera$CameraInfo;
    invoke-direct v1, Landroid/hardware/Camera$CameraInfo;-><init>()V
    invoke-static v2, v1, Landroid/hardware/Camera;->getCameraInfo(I Landroid/hardware/Camera$CameraInfo;)V
    iget v1, v1, Landroid/hardware/Camera$CameraInfo;->facing I
    if-ne v1, v0, +003h
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public static b(I)I
    .registers 2
    new-instance v0, Landroid/hardware/Camera$CameraInfo;
    invoke-direct v0, Landroid/hardware/Camera$CameraInfo;-><init>()V
    invoke-static v1, v0, Landroid/hardware/Camera;->getCameraInfo(I Landroid/hardware/Camera$CameraInfo;)V
    iget v0, v0, Landroid/hardware/Camera$CameraInfo;->orientation I
    return v0
.end method

.method public static b(Landroid/hardware/Camera$Parameters;)V
    .registers 3
    invoke-virtual v2, Landroid/hardware/Camera$Parameters;->getSupportedFocusModes()Ljava/util/List;
    move-result-object v0
    const-string v1, "continuous-video"
    invoke-interface v0, v1, Ljava/util/List;->contains(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, +007h
    const-string v0, "continuous-video"
    invoke-virtual v2, v0, Landroid/hardware/Camera$Parameters;->setFocusMode(Ljava/lang/String;)V
    return-void
.end method

.method public static c(I)Landroid/hardware/Camera;
    .registers 2
    invoke-static v1, Landroid/hardware/Camera;->open(I)Landroid/hardware/Camera;
    move-result-object v0
    return-object v0
.end method
