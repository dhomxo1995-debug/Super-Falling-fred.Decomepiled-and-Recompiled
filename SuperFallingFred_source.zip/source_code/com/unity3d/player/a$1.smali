.class final Lcom/unity3d/player/a$1;
.super Ljava/lang/Object;
.implements Landroid/hardware/Camera$PreviewCallback;

.field private synthetic a:Lcom/unity3d/player/a$a;
.field private synthetic b:Lcom/unity3d/player/a;

.method constructor <init>(Lcom/unity3d/player/a; Lcom/unity3d/player/a$a;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/a$1;->b Lcom/unity3d/player/a;
    iput-object v2, v0, Lcom/unity3d/player/a$1;->a Lcom/unity3d/player/a$a;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onPreviewFrame([B Landroid/hardware/Camera;)V
    .registers 5
    iget-object v0, v2, Lcom/unity3d/player/a$1;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    if-eq v0, v4, +003h
    return-void
    iget-object v0, v2, Lcom/unity3d/player/a$1;->a Lcom/unity3d/player/a$a;
    iget-object v1, v2, Lcom/unity3d/player/a$1;->b Lcom/unity3d/player/a;
    invoke-interface v0, v1, v3, Lcom/unity3d/player/a$a;->onCameraFrame(Lcom/unity3d/player/a; [B)V
    goto -8h
.end method
