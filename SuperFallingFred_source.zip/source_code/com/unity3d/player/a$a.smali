.class interface abstract Lcom/unity3d/player/a$a;
.super Ljava/lang/Object;


.method public abstract onCameraFrame(Lcom/unity3d/player/a; [B)V
    # abstract or native method
.end method
