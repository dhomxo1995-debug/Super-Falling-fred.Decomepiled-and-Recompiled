.class final Lcom/unity3d/player/v$1;
.super Ljava/lang/Object;
.implements Landroid/opengl/GLSurfaceView$EGLConfigChooser;

.field private synthetic a:Lcom/unity3d/player/v;

.method constructor <init>(Lcom/unity3d/player/v;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/v$1;->a Lcom/unity3d/player/v;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final chooseConfig(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay;)Ljavax/microedition/khronos/egl/EGLConfig;
    .registers 6
    iget-object v0, v3, Lcom/unity3d/player/v$1;->a Lcom/unity3d/player/v;
    invoke-virtual v0, v4, v5, Lcom/unity3d/player/v;->a(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay;)Lcom/unity3d/player/u;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/v$1;->a Lcom/unity3d/player/v;
    invoke-static v1, Lcom/unity3d/player/v;->a(Lcom/unity3d/player/v;)Lcom/unity3d/player/u;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/u;->a(Lcom/unity3d/player/u;)Z
    move-result v1
    if-nez v1, +008h
    const/4 v1, 5
    const-string v2, "EGL configuration may not be compatiable with the current surface"
    invoke-static v1, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    iget-object v0, v0, Lcom/unity3d/player/u;->a Ljavax/microedition/khronos/egl/EGLConfig;
    return-object v0
.end method
