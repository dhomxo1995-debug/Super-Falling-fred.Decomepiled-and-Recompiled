.class final Lcom/unity3d/player/UnityPlayer$19;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$19;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 7
    const/4 v1, 0
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer$19;->a Lcom/unity3d/player/UnityPlayer;
    const-wide/16 v4, -1
    move v2, v1
    move v3, v1
    invoke-virtual/range v0 ... v5, Lcom/unity3d/player/UnityPlayer;->nativeGyro(F F F J)V
    return-void
.end method
