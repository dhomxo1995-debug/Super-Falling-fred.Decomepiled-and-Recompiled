.class final Lcom/unity3d/player/UnityPlayer$10;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;
.field private synthetic b:Ljava/lang/String;
.field private synthetic c:I
.field private synthetic d:Z
.field private synthetic e:Z
.field private synthetic f:Z
.field private synthetic g:Z
.field private synthetic h:Ljava/lang/String;
.field private synthetic i:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I Z Z Z Z Ljava/lang/String;)V
    .registers 10
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$10;->a Lcom/unity3d/player/UnityPlayer;
    iput-object v3, v0, Lcom/unity3d/player/UnityPlayer$10;->b Ljava/lang/String;
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$10;->c I
    iput-boolean v5, v0, Lcom/unity3d/player/UnityPlayer$10;->d Z
    iput-boolean v6, v0, Lcom/unity3d/player/UnityPlayer$10;->e Z
    iput-boolean v7, v0, Lcom/unity3d/player/UnityPlayer$10;->f Z
    iput-boolean v8, v0, Lcom/unity3d/player/UnityPlayer$10;->g Z
    iput-object v9, v0, Lcom/unity3d/player/UnityPlayer$10;->h Ljava/lang/String;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 11
    const/4 v2, 1
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->k(Lcom/unity3d/player/UnityPlayer;)Z
    move-result v0
    if-eqz v0, +01ah
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer$10;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    move-result-object v0
    const-string v1, "input_method"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;
    const/4 v1, 0
    invoke-virtual v0, v1, v2, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(I I)V
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, v2, Lcom/unity3d/player/UnityPlayer;->c(Lcom/unity3d/player/UnityPlayer; Z)Z
    return-void
    iget-object v9, v10, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    new-instance v0, Lcom/unity3d/player/s;
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    move-result-object v1
    iget-object v2, v10, Lcom/unity3d/player/UnityPlayer$10;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v3, v10, Lcom/unity3d/player/UnityPlayer$10;->b Ljava/lang/String;
    iget v4, v10, Lcom/unity3d/player/UnityPlayer$10;->c I
    iget-boolean v5, v10, Lcom/unity3d/player/UnityPlayer$10;->d Z
    iget-boolean v6, v10, Lcom/unity3d/player/UnityPlayer$10;->e Z
    iget-boolean v7, v10, Lcom/unity3d/player/UnityPlayer$10;->f Z
    iget-boolean v8, v10, Lcom/unity3d/player/UnityPlayer$10;->g Z
    iget-object v8, v10, Lcom/unity3d/player/UnityPlayer$10;->h Ljava/lang/String;
    invoke-direct/range v0 ... v8, Lcom/unity3d/player/s;-><init>(Landroid/content/Context; Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I Z Z Z Ljava/lang/String;)V
    iput-object v0, v9, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer$10;->i Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    invoke-virtual v0, Lcom/unity3d/player/s;->show()V
    goto -27h
.end method
