.class final Lcom/unity3d/player/UnityPlayer$27;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Z
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Z)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$27;->b Lcom/unity3d/player/UnityPlayer;
    iput-boolean v2, v0, Lcom/unity3d/player/UnityPlayer$27;->a Z
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$27;->b Lcom/unity3d/player/UnityPlayer;
    iget-boolean v1, v2, Lcom/unity3d/player/UnityPlayer$27;->a Z
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Z)V
    return-void
.end method
