.class public interface abstract Lcom/unity3d/player/j;
.super Ljava/lang/Object;


.method public abstract a(Landroid/opengl/GLSurfaceView; Z)V
    # abstract or native method
.end method

.method public abstract a(Landroid/view/View;)V
    # abstract or native method
.end method

.method public abstract a(Landroid/view/View; Z)V
    # abstract or native method
.end method

.method public abstract a(Landroid/os/Vibrator;)Z
    # abstract or native method
.end method

.method public abstract b(Landroid/view/View;)Z
    # abstract or native method
.end method

.method public abstract c(Landroid/view/View;)V
    # abstract or native method
.end method
