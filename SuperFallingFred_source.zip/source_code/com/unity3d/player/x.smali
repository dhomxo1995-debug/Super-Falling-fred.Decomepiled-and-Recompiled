.class final Lcom/unity3d/player/x;
.super Ljava/lang/Object;

.field private static a:Z
.field private b:Z
.field private c:Z
.field private d:Z
.field private e:Z
.field private f:Z
.field private g:Z

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/unity3d/player/x;->a Z
    return-void
.end method

.method constructor <init>()V
    .registers 2
    const/4 v0, 0
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    iput-boolean v0, v1, Lcom/unity3d/player/x;->b Z
    iput-boolean v0, v1, Lcom/unity3d/player/x;->c Z
    iput-boolean v0, v1, Lcom/unity3d/player/x;->d Z
    iput-boolean v0, v1, Lcom/unity3d/player/x;->e Z
    iput-boolean v0, v1, Lcom/unity3d/player/x;->f Z
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/x;->g Z
    return-void
.end method

.method static a()V
    .registers 1
    const/4 v0, 1
    sput-boolean v0, Lcom/unity3d/player/x;->a Z
    return-void
.end method

.method static b()Z
    .registers 1
    sget-boolean v0, Lcom/unity3d/player/x;->a Z
    return v0
.end method

.method final a(Z)V
    .registers 2
    iput-boolean v1, v0, Lcom/unity3d/player/x;->c Z
    return-void
.end method

.method final b(Z)V
    .registers 2
    iput-boolean v1, v0, Lcom/unity3d/player/x;->g Z
    return-void
.end method

.method final c()V
    .registers 2
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/x;->b Z
    return-void
.end method

.method final c(Z)V
    .registers 2
    iput-boolean v1, v0, Lcom/unity3d/player/x;->d Z
    return-void
.end method

.method final d()V
    .registers 2
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/x;->e Z
    return-void
.end method

.method final e()V
    .registers 2
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/x;->f Z
    return-void
.end method

.method final f()Z
    .registers 2
    sget-boolean v0, Lcom/unity3d/player/x;->a Z
    if-eqz v0, +014h
    iget-boolean v0, v1, Lcom/unity3d/player/x;->c Z
    if-eqz v0, +010h
    iget-boolean v0, v1, Lcom/unity3d/player/x;->b Z
    if-eqz v0, +00ch
    iget-boolean v0, v1, Lcom/unity3d/player/x;->g Z
    if-nez v0, +008h
    iget-boolean v0, v1, Lcom/unity3d/player/x;->d Z
    if-nez v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method final g()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/x;->d Z
    return v0
.end method

.method final h()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/x;->e Z
    return v0
.end method

.method final i()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/x;->f Z
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2
    invoke-super v1, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
