.class public Lcom/unity3d/player/UnityPlayer;
.super Landroid/widget/FrameLayout;
.implements Landroid/opengl/GLSurfaceView$Renderer;
.implements Lcom/unity3d/player/a$a;

.field private static J:Lcom/unity3d/player/b;
.field public static currentActivity:Landroid/app/Activity;
.field private static u:Z
.field private final A:Lcom/unity3d/player/r;
.field private B:Ljava/lang/String;
.field private C:Landroid/net/NetworkInfo;
.field private D:Landroid/os/Bundle;
.field private E:Ljava/util/List;
.field private F:Lcom/unity3d/player/y;
.field private G:Landroid/widget/ProgressBar;
.field private H:Ljava/lang/Runnable;
.field private I:Ljava/lang/Runnable;
.field private K:F
.field private L:F
.field private M:Landroid/content/BroadcastReceiver;
.field private N:Z
.field private O:I
.field private P:Z
.field  a:Lcom/unity3d/player/s;
.field private b:Z
.field private c:Z
.field private final d:Lcom/unity3d/player/l;
.field private final e:Lcom/unity3d/player/t;
.field private f:Z
.field private g:Lcom/unity3d/player/x;
.field private h:Landroid/os/Bundle;
.field private i:Landroid/content/SharedPreferences;
.field private j:Landroid/content/ContextWrapper;
.field private k:Z
.field private l:Lcom/unity3d/player/UnityGL;
.field private m:Lcom/unity3d/player/q;
.field private n:Landroid/os/PowerManager$WakeLock;
.field private o:Landroid/os/PowerManager$WakeLock;
.field private p:Landroid/os/PowerManager$WakeLock;
.field private q:Landroid/hardware/SensorManager;
.field private r:Landroid/view/WindowManager;
.field private s:Lorg/fmod/FMODAudioDevice;
.field private t:Landroid/os/Vibrator;
.field private v:Z
.field private w:I
.field private x:I
.field private y:I
.field private z:I

.method static constructor <clinit>()V
    .registers 2
    const/4 v1, 0
    sput-object v1, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    const/4 v0, 1
    sput-boolean v0, Lcom/unity3d/player/UnityPlayer;->u Z
    sput-object v1, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    new-instance v0, Lcom/unity3d/player/b;
    invoke-direct v0, Lcom/unity3d/player/b;-><init>()V
    sput-object v0, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    return-void
.end method

.method public constructor <init>(Landroid/content/ContextWrapper;)V
    .registers 8
    const/4 v2, 0
    const/4 v5, 1
    const/4 v0, 0
    const/4 v4, 0
    invoke-direct v6, v7, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    iput-boolean v4, v6, Lcom/unity3d/player/UnityPlayer;->b Z
    iput-boolean v4, v6, Lcom/unity3d/player/UnityPlayer;->c Z
    iput-boolean v4, v6, Lcom/unity3d/player/UnityPlayer;->f Z
    new-instance v1, Lcom/unity3d/player/x;
    invoke-direct v1, Lcom/unity3d/player/x;-><init>()V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->h Landroid/os/Bundle;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->i Landroid/content/SharedPreferences;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    iput-boolean v5, v6, Lcom/unity3d/player/UnityPlayer;->v Z
    iput v4, v6, Lcom/unity3d/player/UnityPlayer;->y I
    iput v4, v6, Lcom/unity3d/player/UnityPlayer;->z I
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->B Ljava/lang/String;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->C Landroid/net/NetworkInfo;
    new-instance v1, Landroid/os/Bundle;
    invoke-direct v1, Landroid/os/Bundle;-><init>()V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct v1, Ljava/util/ArrayList;-><init>()V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->G Landroid/widget/ProgressBar;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$3;
    invoke-direct v1, v6, Lcom/unity3d/player/UnityPlayer$3;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->H Ljava/lang/Runnable;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$4;
    invoke-direct v1, v6, Lcom/unity3d/player/UnityPlayer$4;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->I Ljava/lang/Runnable;
    iput v2, v6, Lcom/unity3d/player/UnityPlayer;->K F
    iput v2, v6, Lcom/unity3d/player/UnityPlayer;->L F
    new-instance v1, Lcom/unity3d/player/UnityPlayer$17;
    invoke-direct v1, v6, Lcom/unity3d/player/UnityPlayer$17;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->M Landroid/content/BroadcastReceiver;
    iput-boolean v4, v6, Lcom/unity3d/player/UnityPlayer;->N Z
    iput v5, v6, Lcom/unity3d/player/UnityPlayer;->O I
    iput-boolean v5, v6, Lcom/unity3d/player/UnityPlayer;->P Z
    new-instance v1, Lcom/unity3d/player/t;
    invoke-direct v1, v6, Lcom/unity3d/player/t;-><init>(Landroid/widget/FrameLayout;)V
    iput-object v1, v6, Lcom/unity3d/player/UnityPlayer;->e Lcom/unity3d/player/t;
    iput-object v7, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "android.app.NativeActivity"
    invoke-static v1, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    move-result-object v1
    iget-object v2, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v2, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    move-result v1
    iput-boolean v1, v6, Lcom/unity3d/player/UnityPlayer;->k Z
    iget-boolean v1, v6, Lcom/unity3d/player/UnityPlayer;->k Z
    if-eqz v1, +007h
    new-instance v0, Lcom/unity3d/player/o;
    invoke-direct v0, v7, Lcom/unity3d/player/o;-><init>(Landroid/content/ContextWrapper;)V
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->d Lcom/unity3d/player/l;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;
    move-result-object v1
    instance-of v0, v7, Landroid/app/Activity;
    if-eqz v0, +02ah
    move-object v0, v7
    check-cast v0, Landroid/app/Activity;
    sput-object v0, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v0, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v0
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->h Landroid/os/Bundle;
    const/4 v0, 3
    new-array v0, v0, [Ljava/lang/String;
    const-string v2, "com.unity3d.player.UnityPlayerActivity"
    aput-object v2, v0, v4
    const-string v2, "com.unity3d.player.UnityPlayerNativeActivity"
    aput-object v2, v0, v5
    const/4 v2, 2
    sget-object v3, Lcom/unity3d/player/UnityPlayer;->currentActivity Landroid/app/Activity;
    invoke-virtual v3, Landroid/app/Activity;->getLocalClassName()Ljava/lang/String;
    move-result-object v3
    aput-object v3, v0, v2
    invoke-static v7, v0, Lcom/unity3d/player/UnityPlayerProxyActivity;->copyPlayerPrefs(Landroid/content/Context; [Ljava/lang/String;)V
    invoke-virtual v7, v1, v4, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String; I)Landroid/content/SharedPreferences;
    move-result-object v0
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->i Landroid/content/SharedPreferences;
    invoke-direct v6, Lcom/unity3d/player/UnityPlayer;->a()V
    invoke-static Lcom/unity3d/player/UnityPlayer;->j()V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageCodePath()Ljava/lang/String;
    move-result-object v0
    invoke-direct v6, v0, Lcom/unity3d/player/UnityPlayer;->nativeFile(Ljava/lang/String;)V
    invoke-direct v6, Lcom/unity3d/player/UnityPlayer;->l()V
    new-instance v0, Lcom/unity3d/player/r;
    invoke-direct v0, v7, v6, Lcom/unity3d/player/r;-><init>(Landroid/content/Context; Lcom/unity3d/player/UnityPlayer;)V
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v1, 8
    if-lt v0, v1, +004h
    iput-boolean v5, v6, Lcom/unity3d/player/UnityPlayer;->f Z
    return-void
    move-exception v1
    goto -66h
.end method

.method public static native UnitySendMessage(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)V
    # abstract or native method
.end method

.method private static a(Landroid/view/MotionEvent;)I
    .registers 2
    sget-boolean v0, Lcom/unity3d/player/p;->e Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->k Lcom/unity3d/player/k;
    invoke-static v1, Lcom/unity3d/player/k;->a(Landroid/view/MotionEvent;)I
    move-result v0
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; Landroid/widget/ProgressBar;)Landroid/widget/ProgressBar;
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer;->G Landroid/widget/ProgressBar;
    return-object v1
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/y;)Lcom/unity3d/player/y;
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    return-object v1
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 10
    const/4 v1, 0
    const/4 v0, 0
    const-string v2, "MD5"
    invoke-static v2, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    move-result-object v3
    new-instance v4, Ljava/io/FileInputStream;
    invoke-direct v4, v9, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    new-instance v2, Ljava/io/File;
    invoke-direct v2, v9, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, Ljava/io/File;->length()J
    move-result-wide v5
    const-wide/32 v7, 65558
    invoke-static v5, v6, v7, v8, Ljava/lang/Math;->min(J J)J
    move-result-wide v7
    sub-long/2addr v5, v7
    invoke-virtual v4, v5, v6, Ljava/io/FileInputStream;->skip(J)J
    const/16 v2, 1024
    new-array v5, v2, [B
    move v2, v0
    const/4 v6, -1
    if-eq v2, v6, +00bh
    const/4 v6, 0
    invoke-virtual v3, v5, v6, v2, Ljava/security/MessageDigest;->update([B I I)V
    invoke-virtual v4, v5, Ljava/io/FileInputStream;->read([B)I
    move-result v2
    goto -bh
    invoke-virtual v3, Ljava/security/MessageDigest;->digest()[B
    move-result-object v2
    if-nez v2, +00dh
    move-object v0, v1
    return-object v0
    move-exception v2
    move-object v2, v1
    goto -6h
    move-exception v2
    move-object v2, v1
    goto -9h
    move-exception v2
    move-object v2, v1
    goto -ch
    new-instance v1, Ljava/lang/StringBuffer;
    invoke-direct v1, Ljava/lang/StringBuffer;-><init>()V
    array-length v3, v2
    if-ge v0, v3, +019h
    aget-byte v3, v2, v0
    and-int/lit16 v3, v3, 255
    add-int/lit16 v3, v3, 256
    const/16 v4, 16
    invoke-static v3, v4, Ljava/lang/Integer;->toString(I I)Ljava/lang/String;
    move-result-object v3
    const/4 v4, 1
    invoke-virtual v3, v4, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v3
    invoke-virtual v1, v3, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    add-int/lit8 v0, v0, 1
    goto -19h
    invoke-virtual v1, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;
    move-result-object v0
    goto -2dh
.end method

.method private a(Ljava/lang/String; Ljava/io/File;)Ljava/lang/String;
    .registers 6
    invoke-static Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v2, "android.permission.WRITE_EXTERNAL_STORAGE"
    invoke-virtual v1, v2, Landroid/content/ContextWrapper;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    move-result v1
    if-nez v1, +049h
    const-string v1, "mounted"
    invoke-virtual v1, v0, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, +041h
    invoke-static Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;
    move-result-object v0
    new-instance v1, Ljava/io/File;
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct v2, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v0, Ljava/io/File;->getPath()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, "/Android/data/"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    iget-object v2, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v2, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-direct v1, v0, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual v1, Ljava/io/File;->exists()Z
    move-result v0
    if-nez v0, +008h
    invoke-virtual v1, Ljava/io/File;->mkdirs()Z
    move-result v0
    if-eqz v0, +007h
    invoke-virtual v1, Ljava/io/File;->getPath()Ljava/lang/String;
    move-result-object v0
    return-object v0
    invoke-virtual v5, Ljava/io/File;->getPath()Ljava/lang/String;
    move-result-object v0
    goto -5h
.end method

.method private a()V
    .registers 10
    const/4 v7, 1
    const/4 v2, 0
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getAssets()Landroid/content/res/AssetManager;
    move-result-object v0
    const-string v1, "bin/Data/settings.xml"
    invoke-virtual v0, v1, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    move-result-object v0
    invoke-static Lorg/xmlpull/v1/XmlPullParserFactory;->newInstance()Lorg/xmlpull/v1/XmlPullParserFactory;
    move-result-object v1
    const/4 v3, 1
    invoke-virtual v1, v3, Lorg/xmlpull/v1/XmlPullParserFactory;->setNamespaceAware(Z)V
    invoke-virtual v1, Lorg/xmlpull/v1/XmlPullParserFactory;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;
    move-result-object v4
    const/4 v1, 0
    invoke-interface v4, v0, v1, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/InputStream; Ljava/lang/String;)V
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I
    move-result v0
    move-object v1, v2
    move-object v3, v2
    if-eq v0, v7, +07ah
    const/4 v5, 2
    if-ne v0, v5, +029h
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;
    move-result-object v3
    const/4 v0, 0
    move v8, v0
    move-object v0, v1
    move v1, v8
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getAttributeCount()I
    move-result v5
    if-ge v1, v5, +015h
    invoke-interface v4, v1, Lorg/xmlpull/v1/XmlPullParser;->getAttributeName(I)Ljava/lang/String;
    move-result-object v5
    const-string v6, "name"
    invoke-virtual v5, v6, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v5
    if-eqz v5, +006h
    invoke-interface v4, v1, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(I)Ljava/lang/String;
    move-result-object v0
    add-int/lit8 v1, v1, 1
    goto -18h
    move-object v1, v0
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->next()I
    move-result v0
    goto -2bh
    const/4 v5, 3
    if-ne v0, v5, +004h
    move-object v3, v2
    goto -9h
    const/4 v5, 4
    if-ne v0, v5, -00bh
    if-eqz v1, -00dh
    const-string v0, "integer"
    invoke-virtual v3, v0, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +011h
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getText()Ljava/lang/String;
    move-result-object v5
    invoke-static v5, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    move-result v5
    invoke-virtual v0, v1, v5, Landroid/os/Bundle;->putInt(Ljava/lang/String; I)V
    move-object v1, v2
    goto -25h
    const-string v0, "string"
    invoke-virtual v3, v0, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +028h
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getText()Ljava/lang/String;
    move-result-object v5
    invoke-virtual v0, v1, v5, Landroid/os/Bundle;->putString(Ljava/lang/String; Ljava/lang/String;)V
    goto -13h
    move-exception v0
    const/4 v1, 6
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "Unable to locate player settings. "
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, Ljava/lang/Exception;->getLocalizedMessage()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    invoke-direct v9, Lcom/unity3d/player/UnityPlayer;->b()V
    return-void
    const-string v0, "bool"
    invoke-virtual v3, v0, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +010h
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getText()Ljava/lang/String;
    move-result-object v5
    invoke-static v5, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z
    move-result v5
    invoke-virtual v0, v1, v5, Landroid/os/Bundle;->putBoolean(Ljava/lang/String; Z)V
    goto -45h
    const-string v0, "float"
    invoke-virtual v3, v0, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, -04ch
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-interface v4, Lorg/xmlpull/v1/XmlPullParser;->getText()Ljava/lang/String;
    move-result-object v5
    invoke-static v5, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F
    move-result v5
    invoke-virtual v0, v1, v5, Landroid/os/Bundle;->putFloat(Ljava/lang/String; F)V
    goto -5bh
.end method

.method private a(I Z)V
    .registers 13
    const/16 v2, 26
    const/4 v4, 0
    const/4 v9, 1
    const-string v0, "power"
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v1, v0, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/os/PowerManager;
    const-string v1, "Unity-ProjectRequestedWakeLock"
    invoke-virtual v0, v2, v1, Landroid/os/PowerManager;->newWakeLock(I Ljava/lang/String;)Landroid/os/PowerManager$WakeLock;
    move-result-object v1
    iput-object v1, v10, Lcom/unity3d/player/UnityPlayer;->n Landroid/os/PowerManager$WakeLock;
    const-string v1, "Unity-VideoPlayerWakeLock"
    invoke-virtual v0, v2, v1, Landroid/os/PowerManager;->newWakeLock(I Ljava/lang/String;)Landroid/os/PowerManager$WakeLock;
    move-result-object v1
    iput-object v1, v10, Lcom/unity3d/player/UnityPlayer;->o Landroid/os/PowerManager$WakeLock;
    const-string v1, "Unity-StartupWakeLock"
    invoke-virtual v0, v2, v1, Landroid/os/PowerManager;->newWakeLock(I Ljava/lang/String;)Landroid/os/PowerManager$WakeLock;
    move-result-object v0
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer;->p Landroid/os/PowerManager$WakeLock;
    invoke-direct v10, v9, Lcom/unity3d/player/UnityPlayer;->a(Z)V
    invoke-direct v10, Lcom/unity3d/player/UnityPlayer;->c()V
    invoke-direct v10, Lcom/unity3d/player/UnityPlayer;->initJni()V
    new-instance v0, Lcom/unity3d/player/PlayerPrefs;
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->i Landroid/content/SharedPreferences;
    invoke-direct v0, v1, Lcom/unity3d/player/PlayerPrefs;-><init>(Landroid/content/SharedPreferences;)V
    const-class v0, Lcom/unity3d/player/WWW;
    invoke-direct v10, v0, Lcom/unity3d/player/UnityPlayer;->nativeInitWWW(Ljava/lang/Class;)V
    sget-object v0, Landroid/os/Build;->PRODUCT Ljava/lang/String;
    const-string v1, "blaze"
    invoke-virtual v0, v1, Ljava/lang/String;->compareToIgnoreCase(Ljava/lang/String;)I
    move-result v0
    if-nez v0, +020h
    sget-object v0, Landroid/os/Build;->MODEL Ljava/lang/String;
    invoke-virtual v0, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v0
    const-string v1, "kindle"
    invoke-virtual v0, v1, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +012h
    new-instance v0, Lcom/unity3d/player/q;
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-direct v0, v1, Lcom/unity3d/player/q;-><init>(Landroid/content/Context;)V
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->e Lcom/unity3d/player/t;
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    invoke-virtual v0, v1, Lcom/unity3d/player/t;->a(Landroid/view/View;)V
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "sensor"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/hardware/SensorManager;
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "window"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/WindowManager;
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer;->r Landroid/view/WindowManager;
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    if-nez v0, +042h
    new-instance v0, Lcom/unity3d/player/UnityPlayer$22;
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    iget-object v2, v10, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    const-string v3, "32bit_display"
    invoke-virtual v2, v3, v4, Landroid/os/Bundle;->getBoolean(Ljava/lang/String; Z)Z
    move-result v5
    iget-object v2, v10, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    const-string v3, "24bit_depth"
    invoke-virtual v2, v3, v4, Landroid/os/Bundle;->getBoolean(Ljava/lang/String; Z)Z
    move-result v2
    if-eqz v2, +06dh
    const/16 v6, 24
    iget-object v2, v10, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    const-string v3, "default_aa"
    invoke-virtual v2, v3, v4, Landroid/os/Bundle;->getInt(Ljava/lang/String; I)I
    move-result v7
    move v2, v11
    move v3, v12
    move-object v8, v10
    invoke-direct/range v0 ... v8, Lcom/unity3d/player/UnityPlayer$22;-><init>(Landroid/content/Context; I Z Z Z I I Landroid/view/View;)V
    sget-boolean v1, Lcom/unity3d/player/p;->c Z
    if-eqz v1, +007h
    sget-object v1, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    invoke-interface v1, v0, v9, Lcom/unity3d/player/j;->a(Landroid/opengl/GLSurfaceView; Z)V
    invoke-virtual v0, v9, Lcom/unity3d/player/w;->setFocusable(Z)V
    invoke-virtual v0, v9, Lcom/unity3d/player/w;->setFocusableInTouchMode(Z)V
    sget-boolean v1, Lcom/unity3d/player/p;->c Z
    if-eqz v1, +007h
    sget-object v1, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    invoke-interface v1, v0, Lcom/unity3d/player/j;->a(Landroid/view/View;)V
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    invoke-interface v0, v10, Lcom/unity3d/player/UnityGL;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->c()V
    invoke-virtual v10, Lcom/unity3d/player/UnityPlayer;->getSettings()Landroid/os/Bundle;
    move-result-object v0
    const-string v1, "splash_mode"
    invoke-virtual v0, v1, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I
    move-result v0
    iget-object v1, v10, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v2, Lcom/unity3d/player/UnityPlayer$23;
    invoke-direct v2, v10, v11, v0, Lcom/unity3d/player/UnityPlayer$23;-><init>(Lcom/unity3d/player/UnityPlayer; I I)V
    invoke-interface v1, v2, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->h Landroid/os/Bundle;
    invoke-direct v10, v0, Lcom/unity3d/player/UnityPlayer;->nativeSetExtras(Landroid/os/Bundle;)V
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->d Lcom/unity3d/player/l;
    if-eqz v0, +015h
    iget-object v0, v10, Lcom/unity3d/player/UnityPlayer;->d Lcom/unity3d/player/l;
    invoke-interface v0, Lcom/unity3d/player/l;->a()Landroid/graphics/RectF;
    move-result-object v0
    if-eqz v0, +00dh
    invoke-virtual v0, Landroid/graphics/RectF;->width()F
    move-result v1
    invoke-virtual v0, Landroid/graphics/RectF;->height()F
    move-result v0
    invoke-direct v10, v1, v0, Lcom/unity3d/player/UnityPlayer;->nativeEnableTouchpad(F F)V
    invoke-virtual v10, Lcom/unity3d/player/UnityPlayer;->resume()V
    invoke-virtual v10, v9, Lcom/unity3d/player/UnityPlayer;->windowFocusChanged(Z)V
    return-void
    const/16 v6, 16
    goto -6bh
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer;)V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->b()V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; F F)V
    .registers 3
    invoke-direct v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->nativeSetMousePosition(F F)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; F F F)V
    .registers 4
    invoke-direct v0, v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->nativeSetMouseDelta(F F F)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I F F I)V
    .registers 5
    invoke-direct v0, v1, v2, v3, v4, Lcom/unity3d/player/UnityPlayer;->nativeQueueGUIEvent(I F F I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I F F I J I)V
    .registers 8
    invoke-direct/range v0 ... v7, Lcom/unity3d/player/UnityPlayer;->nativeTouch(I F F I J I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I I)V
    .registers 3
    invoke-direct v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->nativeInit(I I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I I F)V
    .registers 4
    invoke-direct v0, v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->nativeSetJoystickPosition(I I F)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I I Z I I)V
    .registers 6
    invoke-direct/range v0 ... v5, Lcom/unity3d/player/UnityPlayer;->nativeKeyState(I I Z I I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I Z)V
    .registers 3
    invoke-direct v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->a(I Z)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; I [B I I)V
    .registers 5
    invoke-direct v0, v1, v2, v3, v4, Lcom/unity3d/player/UnityPlayer;->nativeVideoFrameCallback(I [B I I)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String;)V
    .registers 2
    invoke-direct v0, v1, Lcom/unity3d/player/UnityPlayer;->nativeSetInputString(Ljava/lang/String;)V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/UnityPlayer; Z)V
    .registers 2
    invoke-direct v0, v1, Lcom/unity3d/player/UnityPlayer;->nativeFocusChanged(Z)V
    return-void
.end method

.method static a(Ljava/lang/Runnable;)V
    .registers 2
    new-instance v0, Ljava/lang/Thread;
    invoke-direct v0, v1, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    invoke-virtual v0, Ljava/lang/Thread;->start()V
    return-void
.end method

.method private static a(Ljava/lang/String; Landroid/os/PowerManager$WakeLock; Z)V
    .registers 10
    const/4 v6, 5
    const/4 v5, 1
    const/4 v4, 0
    invoke-virtual v8, Landroid/os/PowerManager$WakeLock;->isHeld()Z
    move-result v0
    if-ne v9, v0, +003h
    return-void
    if-eqz v9, +02bh
    invoke-virtual v8, Landroid/os/PowerManager$WakeLock;->acquire()V
    invoke-virtual v8, Landroid/os/PowerManager$WakeLock;->isHeld()Z
    move-result v0
    if-nez v0, -00ah
    const/4 v0, 5
    const-string v1, "Unable to acquire %s wake-lock. Make sure 'android.permission.WAKE_LOCK' has been set in the manifest."
    const/4 v2, 1
    new-array v2, v2, [Ljava/lang/Object;
    const/4 v3, 0
    aput-object v7, v2, v3
    invoke-static v1, v2, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -1ch
    move-exception v0
    const-string v0, "Unable to acquire/release %s wake-lock. Make sure 'android.permission.WAKE_LOCK' has been set in the manifest."
    new-array v1, v5, [Ljava/lang/Object;
    aput-object v7, v1, v4
    invoke-static v0, v1, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v0
    invoke-static v6, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -2bh
    if-nez v9, -02ch
    invoke-virtual v8, Landroid/os/PowerManager$WakeLock;->release()V
    goto -31h
.end method

.method private a(Z)V
    .registers 4
    const-string v0, "android.permission.WAKE_LOCK"
    invoke-direct v2, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +009h
    const-string v0, "startup"
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->p Landroid/os/PowerManager$WakeLock;
    invoke-static v0, v1, v3, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String; Landroid/os/PowerManager$WakeLock; Z)V
    return-void
.end method

.method private a(I Landroid/view/KeyEvent;)Z
    .registers 4
    invoke-virtual v3, Landroid/view/KeyEvent;->getAction()I
    move-result v0
    if-nez v0, +007h
    invoke-super v1, v2, v3, Landroid/widget/FrameLayout;->onKeyDown(I Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
    invoke-super v1, v2, v3, Landroid/widget/FrameLayout;->onKeyUp(I Landroid/view/KeyEvent;)Z
    move-result v0
    goto -5h
.end method

.method private static a(Landroid/content/Context;)[Ljava/lang/String;
    .registers 7
    const/4 v4, 0
    invoke-virtual v6, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v0
    new-instance v1, Ljava/util/Vector;
    invoke-direct v1, Ljava/util/Vector;-><init>()V
    invoke-virtual v6, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v2
    const/4 v3, 0
    invoke-virtual v2, v0, v3, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String; I)Landroid/content/pm/PackageInfo;
    move-result-object v2
    iget v2, v2, Landroid/content/pm/PackageInfo;->versionCode I
    invoke-static Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;
    move-result-object v3
    const-string v4, "mounted"
    invoke-virtual v3, v4, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v3
    if-eqz v3, +0a6h
    invoke-static Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;
    move-result-object v3
    new-instance v4, Ljava/io/File;
    new-instance v5, Ljava/lang/StringBuilder;
    invoke-direct v5, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v3, Ljava/io/File;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v5, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v5, "/Android/obb/"
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    invoke-direct v4, v3, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual v4, Ljava/io/File;->exists()Z
    move-result v3
    if-eqz v3, +07ch
    if-lez v2, +03dh
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    sget-object v5, Ljava/io/File;->separator Ljava/lang/String;
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v5, "main."
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v5, "."
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v5, ".obb"
    invoke-virtual v3, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v3
    new-instance v5, Ljava/io/File;
    invoke-direct v5, v3, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual v5, Ljava/io/File;->isFile()Z
    move-result v5
    if-eqz v5, +005h
    invoke-virtual v1, v3, Ljava/util/Vector;->add(Ljava/lang/Object;)Z
    if-lez v2, +03dh
    new-instance v3, Ljava/lang/StringBuilder;
    invoke-direct v3, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v3
    sget-object v4, Ljava/io/File;->separator Ljava/lang/String;
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    const-string v4, "patch."
    invoke-virtual v3, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v3
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "."
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, ".obb"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    new-instance v2, Ljava/io/File;
    invoke-direct v2, v0, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, Ljava/io/File;->isFile()Z
    move-result v2
    if-eqz v2, +005h
    invoke-virtual v1, v0, Ljava/util/Vector;->add(Ljava/lang/Object;)Z
    invoke-virtual v1, Ljava/util/Vector;->size()I
    move-result v0
    new-array v0, v0, [Ljava/lang/String;
    invoke-virtual v1, v0, Ljava/util/Vector;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    return-object v0
    move-exception v0
    new-array v0, v4, [Ljava/lang/String;
    goto -4h
.end method

.method private b()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-eqz v0, +013h
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->isFinishing()Z
    move-result v0
    if-nez v0, +009h
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->finish()V
    return-void
.end method

.method static synthetic b(Lcom/unity3d/player/UnityPlayer;)V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->nativeDone()V
    return-void
.end method

.method static synthetic b(Lcom/unity3d/player/UnityPlayer; Z)V
    .registers 3
    const/4 v0, 0
    invoke-direct v1, v0, v2, Lcom/unity3d/player/UnityPlayer;->nativeSetMouseButton(I Z)V
    return-void
.end method

.method private b(Ljava/lang/Runnable;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-eqz v0, +00ah
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, v3, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
    const/4 v0, 5
    const-string v1, "Not running Unity from an Activity; ignored..."
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -7h
.end method

.method private b(Z)V
    .registers 4
    const-string v0, "video"
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->o Landroid/os/PowerManager$WakeLock;
    invoke-static v0, v1, v3, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String; Landroid/os/PowerManager$WakeLock; Z)V
    return-void
.end method

.method private b(I Landroid/view/KeyEvent;)Z
    .registers 11
    const/4 v1, 4
    const/4 v4, 0
    const/4 v7, 1
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-nez v0, +008h
    if-ne v9, v1, +005h
    invoke-virtual v8, Lcom/unity3d/player/UnityPlayer;->kill()V
    return v7
    invoke-virtual v8, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v0
    if-eqz v0, +004h
    move v7, v4
    goto -8h
    const/16 v0, 25
    if-eq v9, v0, +006h
    const/16 v0, 24
    if-ne v9, v0, +007h
    invoke-direct v8, v9, v10, Lcom/unity3d/player/UnityPlayer;->a(I Landroid/view/KeyEvent;)Z
    move-result v7
    goto -15h
    if-ne v9, v1, +02dh
    invoke-virtual v10, Landroid/view/KeyEvent;->getMetaState()I
    move-result v0
    const/4 v1, 2
    if-ne v0, v1, +026h
    const/16 v9, 101
    move v2, v9
    invoke-virtual v10, Landroid/view/KeyEvent;->getMetaState()I
    move-result v0
    invoke-virtual v10, v0, Landroid/view/KeyEvent;->getUnicodeChar(I)I
    move-result v3
    invoke-virtual v10, Landroid/view/KeyEvent;->getAction()I
    move-result v0
    if-nez v0, +003h
    move v4, v7
    invoke-virtual v10, Landroid/view/KeyEvent;->getScanCode()I
    move-result v5
    invoke-virtual v10, Landroid/view/KeyEvent;->getDeviceId()I
    move-result v6
    new-instance v0, Lcom/unity3d/player/UnityPlayer$5;
    move-object v1, v8
    invoke-direct/range v0 ... v6, Lcom/unity3d/player/UnityPlayer$5;-><init>(Lcom/unity3d/player/UnityPlayer; I I Z I I)V
    invoke-virtual v8, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -42h
    move v2, v9
    goto -22h
.end method

.method private b(Landroid/view/MotionEvent;)Z
    .registers 14
    const/4 v11, 1
    iget-boolean v0, v12, Lcom/unity3d/player/UnityPlayer;->k Z
    if-eqz v0, +003h
    return v11
    invoke-virtual v13, Landroid/view/MotionEvent;->getPointerCount()I
    move-result v10
    const/4 v0, 0
    move v9, v0
    if-ge v9, v10, -007h
    if-nez v9, +035h
    invoke-virtual v13, Landroid/view/MotionEvent;->getAction()I
    move-result v0
    and-int/lit16 v1, v0, 255
    shr-int/lit8 v1, v1, 8
    if-ne v9, v1, +02fh
    and-int/lit16 v2, v0, 255
    invoke-virtual v13, v9, Landroid/view/MotionEvent;->getX(I)F
    move-result v4
    invoke-virtual v13, v9, Landroid/view/MotionEvent;->getY(I)F
    move-result v5
    iget v6, v12, Lcom/unity3d/player/UnityPlayer;->K F
    iget v7, v12, Lcom/unity3d/player/UnityPlayer;->L F
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +01fh
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-static v13, v9, Lcom/unity3d/player/i;->a(Landroid/view/MotionEvent; I)F
    move-result v8
    invoke-static v13, Lcom/unity3d/player/UnityPlayer;->a(Landroid/view/MotionEvent;)I
    move-result v3
    new-instance v0, Lcom/unity3d/player/UnityPlayer$7;
    move-object v1, v12
    invoke-direct/range v0 ... v8, Lcom/unity3d/player/UnityPlayer$7;-><init>(Lcom/unity3d/player/UnityPlayer; I I F F F F F)V
    invoke-virtual v12, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    iput v4, v12, Lcom/unity3d/player/UnityPlayer;->K F
    iput v5, v12, Lcom/unity3d/player/UnityPlayer;->L F
    add-int/lit8 v0, v9, 1
    move v9, v0
    goto -3ah
    const/4 v2, 2
    goto -2ch
    const/4 v8, 0
    goto -18h
.end method

.method private b(Ljava/lang/String;)Z
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, v2, Landroid/content/ContextWrapper;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    move-result v0
    if-nez v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method private c()V
    .registers 3
    iget-boolean v0, v2, Lcom/unity3d/player/UnityPlayer;->k Z
    if-eqz v0, +012h
    new-instance v1, Lcom/unity3d/player/n;
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-direct v1, v0, Lcom/unity3d/player/n;-><init>(Landroid/app/Activity;)V
    invoke-virtual v1, Lcom/unity3d/player/n;->a()Z
    move-result v0
    invoke-virtual v2, v0, Lcom/unity3d/player/UnityPlayer;->nativeForwardEventsToDalvik(Z)V
    return-void
.end method

.method static synthetic c(Lcom/unity3d/player/UnityPlayer;)V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->f()V
    return-void
.end method

.method private c(Z)V
    .registers 9
    const/16 v6, 11
    const/16 v5, 10
    const/16 v4, 9
    const/4 v3, 4
    iget-boolean v0, v7, Lcom/unity3d/player/UnityPlayer;->N Z
    if-nez v0, +003h
    return-void
    if-eqz v8, +03fh
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v3, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    iget v3, v7, Lcom/unity3d/player/UnityPlayer;->O I
    invoke-virtual v0, v1, v2, v3, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v4, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    iget v3, v7, Lcom/unity3d/player/UnityPlayer;->O I
    invoke-virtual v0, v1, v2, v3, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v5, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    iget v3, v7, Lcom/unity3d/player/UnityPlayer;->O I
    invoke-virtual v0, v1, v2, v3, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v6, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    iget v3, v7, Lcom/unity3d/player/UnityPlayer;->O I
    invoke-virtual v0, v1, v2, v3, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    goto -3fh
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v3, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor;)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v4, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor;)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v5, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor;)V
    iget-object v0, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v7, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v6, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor;)V
    goto -74h
.end method

.method private c(Landroid/view/MotionEvent;)Z
    .registers 5
    const/4 v2, 1
    iget-boolean v0, v3, Lcom/unity3d/player/UnityPlayer;->k Z
    if-eqz v0, +003h
    return v2
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, -003h
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-virtual v0, v4, Lcom/unity3d/player/i;->a(Landroid/view/MotionEvent;)[Lcom/unity3d/player/i$a;
    move-result-object v0
    new-instance v1, Lcom/unity3d/player/UnityPlayer$8;
    invoke-direct v1, v3, v0, Lcom/unity3d/player/UnityPlayer$8;-><init>(Lcom/unity3d/player/UnityPlayer; [Lcom/unity3d/player/i$a;)V
    invoke-virtual v3, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -13h
.end method

.method static synthetic c(Lcom/unity3d/player/UnityPlayer; Z)Z
    .registers 2
    iput-boolean v1, v0, Lcom/unity3d/player/UnityPlayer;->c Z
    return v1
.end method

.method private d()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00ch
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/unity3d/player/a;
    invoke-virtual v0, Lcom/unity3d/player/a;->c()V
    goto -fh
    return-void
.end method

.method static synthetic d(Lcom/unity3d/player/UnityPlayer; Z)V
    .registers 2
    invoke-direct v0, v1, Lcom/unity3d/player/UnityPlayer;->b(Z)V
    return-void
.end method

.method private d(Z)V
    .registers 6
    const/4 v3, 2
    iget-boolean v0, v4, Lcom/unity3d/player/UnityPlayer;->P Z
    if-nez v0, +003h
    return-void
    if-eqz v5, +011h
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v4, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v4, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v3, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    const/4 v3, 1
    invoke-virtual v0, v1, v2, v3, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    goto -11h
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v4, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v2, v4, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v2, v3, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor;)V
    goto -1fh
.end method

.method static synthetic d(Lcom/unity3d/player/UnityPlayer;)Z
    .registers 2
    invoke-direct v1, Lcom/unity3d/player/UnityPlayer;->nativePause()Z
    move-result v0
    return v0
.end method

.method private e()V
    .registers 6
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +028h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/unity3d/player/a;
    invoke-virtual v0, v5, Lcom/unity3d/player/a;->a(Lcom/unity3d/player/a$a;)V
    goto -fh
    move-exception v2
    new-instance v3, Ljava/lang/StringBuilder;
    const-string v4, "Unable to initialize camera: "
    invoke-direct v3, v4, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v2
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    const/4 v3, 6
    invoke-static v3, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    invoke-virtual v0, Lcom/unity3d/player/a;->c()V
    goto -2bh
    return-void
.end method

.method static synthetic e(Lcom/unity3d/player/UnityPlayer;)V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->nativeResume()V
    return-void
.end method

.method static synthetic f(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/t;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->e Lcom/unity3d/player/t;
    return-object v0
.end method

.method private f()V
    .registers 4
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    if-eqz v0, +00bh
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    iget v1, v3, Lcom/unity3d/player/UnityPlayer;->w I
    iget v2, v3, Lcom/unity3d/player/UnityPlayer;->x I
    invoke-virtual v0, v1, v2, Lcom/unity3d/player/q;->a(I I)V
    return-void
.end method

.method static synthetic g(Lcom/unity3d/player/UnityPlayer;)I
    .registers 2
    invoke-direct v1, Lcom/unity3d/player/UnityPlayer;->nativeActivityIndicatorStyle()I
    move-result v0
    return v0
.end method

.method private g()V
    .registers 7
    const/4 v5, 0
    const/4 v1, 1
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->f()Z
    move-result v0
    if-nez v0, +003h
    return-void
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    if-eqz v0, +00bh
    invoke-direct v6, v1, Lcom/unity3d/player/UnityPlayer;->b(Z)V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    invoke-virtual v0, Lcom/unity3d/player/y;->onResume()V
    goto -dh
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, v1, Lcom/unity3d/player/x;->c(Z)V
    invoke-direct v6, Lcom/unity3d/player/UnityPlayer;->e()V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    invoke-interface v0, Lcom/unity3d/player/UnityGL;->onResume()V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    iget-object v2, v6, Lcom/unity3d/player/UnityPlayer;->M Landroid/content/BroadcastReceiver;
    new-instance v3, Landroid/content/IntentFilter;
    const-string v4, "android.hardware.usb.action.USB_DEVICE_DETACHED"
    invoke-direct v3, v4, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, v2, v3, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver; Landroid/content/IntentFilter;)Landroid/content/Intent;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v2, v6, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-object v3, v6, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    invoke-virtual v3, v1, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v3
    invoke-virtual v0, v2, v3, v1, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    invoke-direct v6, v1, Lcom/unity3d/player/UnityPlayer;->c(Z)V
    invoke-direct v6, v1, Lcom/unity3d/player/UnityPlayer;->d(Z)V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, Lcom/unity3d/player/r;->e()V
    iput-object v5, v6, Lcom/unity3d/player/UnityPlayer;->B Ljava/lang/String;
    iput-object v5, v6, Lcom/unity3d/player/UnityPlayer;->C Landroid/net/NetworkInfo;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-eqz v0, +005h
    invoke-direct v6, Lcom/unity3d/player/UnityPlayer;->l()V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-virtual v6, v0, Lcom/unity3d/player/UnityPlayer;->indexOfChild(Landroid/view/View;)I
    move-result v0
    const/4 v2, -1
    if-ne v0, v2, +05bh
    move v0, v1
    if-eqz v0, +011h
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Lcom/unity3d/player/w;
    if-eqz v0, +00bh
    iget-object v1, v6, Lcom/unity3d/player/UnityPlayer;->e Lcom/unity3d/player/t;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-virtual v1, v0, Lcom/unity3d/player/t;->d(Landroid/view/View;)V
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-eqz v0, +00ch
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$26;
    invoke-direct v1, v6, Lcom/unity3d/player/UnityPlayer$26;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-interface v0, v1, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    sget-boolean v0, Lcom/unity3d/player/UnityPlayer;->u Z
    if-eqz v0, +00dh
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    if-nez v0, +009h
    new-instance v0, Lorg/fmod/FMODAudioDevice;
    invoke-direct v0, Lorg/fmod/FMODAudioDevice;-><init>()V
    iput-object v0, v6, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    if-eqz v0, +00fh
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    invoke-virtual v0, Lorg/fmod/FMODAudioDevice;->isRunning()Z
    move-result v0
    if-nez v0, +007h
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    invoke-virtual v0, Lorg/fmod/FMODAudioDevice;->start()V
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, -0a1h
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Landroid/view/View;
    if-eqz v0, -0a7h
    sget-object v1, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-interface v1, v0, Lcom/unity3d/player/j;->c(Landroid/view/View;)V
    goto/16 -0b2h
    const/4 v0, 0
    goto -59h
.end method

.method static synthetic h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->G Landroid/widget/ProgressBar;
    return-object v0
.end method

.method private h()V
    .registers 5
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-eqz v0, +02ah
    const/4 v0, 0
    invoke-virtual v4, Lcom/unity3d/player/UnityPlayer;->getSettings()Landroid/os/Bundle;
    move-result-object v1
    const-string v2, "hide_status_bar"
    const/4 v3, 1
    invoke-virtual v1, v2, v3, Landroid/os/Bundle;->getBoolean(Ljava/lang/String; Z)Z
    move-result v1
    if-nez v1, +019h
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    new-instance v1, Landroid/graphics/Rect;
    invoke-direct v1, Landroid/graphics/Rect;-><init>()V
    invoke-virtual v0, Landroid/app/Activity;->getWindow()Landroid/view/Window;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Window;->getDecorView()Landroid/view/View;
    move-result-object v0
    invoke-virtual v0, v1, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V
    iget v0, v1, Landroid/graphics/Rect;->top I
    int-to-float v0, v0
    invoke-direct v4, v0, Lcom/unity3d/player/UnityPlayer;->nativeSetTouchDeltaY(F)V
    return-void
.end method

.method static synthetic i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    return-object v0
.end method

.method private i()V
    .registers 4
    const-string v0, "assets/bin/"
    new-instance v1, Ljava/lang/StringBuilder;
    invoke-direct v1, Ljava/lang/StringBuilder;-><init>()V
    iget-object v2, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v2, Landroid/content/ContextWrapper;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;
    move-result-object v2
    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->dataDir Ljava/lang/String;
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, "/lib"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-direct v3, v0, v1, Lcom/unity3d/player/UnityPlayer;->unityAndroidInit(Ljava/lang/String; Ljava/lang/String;)Z
    invoke-direct v3, Lcom/unity3d/player/UnityPlayer;->unityAndroidPrepareGameLoop()V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->d()V
    return-void
.end method

.method private final native initJni()V
    # abstract or native method
.end method

.method static synthetic j(Lcom/unity3d/player/UnityPlayer;)I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/UnityPlayer;->x I
    return v0
.end method

.method private static j()V
    .registers 4
    const-string v0, "mono"
    invoke-static v0, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    invoke-virtual v0, Lcom/unity3d/player/b;->a()I
    move-result v0
    and-int/lit8 v1, v0, 2
    if-eqz v1, +011h
    and-int/lit16 v1, v0, 128
    if-eqz v1, +006h
    and-int/lit8 v0, v0, 8
    if-nez v0, +009h
    const/4 v0, 6
    const-string v1, "CPU features not supported! (no ARMv6+ / VFP)"
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-void
    const-string v0, "unity"
    invoke-static v0, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    invoke-static Lcom/unity3d/player/x;->a()V
    goto -9h
    move-exception v0
    const/4 v1, 5
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "Unable to load libraries: "
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -1eh
.end method

.method private k()Z
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v0
    const-string v1, "android.hardware.camera"
    invoke-virtual v0, v1, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    move-result v0
    if-nez v0, +010h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v0
    const-string v1, "android.hardware.camera.front"
    invoke-virtual v0, v1, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method static synthetic k(Lcom/unity3d/player/UnityPlayer;)Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/UnityPlayer;->b Z
    return v0
.end method

.method private l()V
    .registers 7
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    const-string v1, "useObb"
    invoke-virtual v0, v1, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z
    move-result v0
    if-nez v0, +003h
    return-void
    iget-object v0, v6, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->a(Landroid/content/Context;)[Ljava/lang/String;
    move-result-object v1
    array-length v2, v1
    const/4 v0, 0
    if-ge v0, v2, -009h
    aget-object v3, v1, v0
    invoke-static v3, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4
    iget-object v5, v6, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-virtual v5, v4, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z
    move-result v5
    if-eqz v5, +005h
    invoke-direct v6, v3, Lcom/unity3d/player/UnityPlayer;->nativeFile(Ljava/lang/String;)V
    iget-object v3, v6, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    invoke-virtual v3, v4, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    add-int/lit8 v0, v0, 1
    goto -1ah
.end method

.method static synthetic l(Lcom/unity3d/player/UnityPlayer;)Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/UnityPlayer;->c Z
    return v0
.end method

.method static synthetic m(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    const/4 v0, 1
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->nativeSetInputCanceled(Z)V
    return-void
.end method

.method static synthetic n(Lcom/unity3d/player/UnityPlayer;)V
    .registers 1
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->nativeSoftInputClosed()V
    return-void
.end method

.method private final native nativeActivityIndicatorStyle()I
    # abstract or native method
.end method

.method private final native nativeDone()V
    # abstract or native method
.end method

.method private final native nativeEnableTouchpad(F F)V
    # abstract or native method
.end method

.method private final native nativeFile(Ljava/lang/String;)V
    # abstract or native method
.end method

.method private final native nativeFocusChanged(Z)V
    # abstract or native method
.end method

.method private final native nativeGetGLContext()Ljava/lang/String;
    # abstract or native method
.end method

.method private final native nativeGetGLScreen()Ljava/lang/String;
    # abstract or native method
.end method

.method private final native nativeGetLicensePolicy()I
    # abstract or native method
.end method

.method private final native nativeInit(I I)V
    # abstract or native method
.end method

.method private final native nativeInitWWW(Ljava/lang/Class;)V
    # abstract or native method
.end method

.method private final native nativeIsAutorotationOn()Z
    # abstract or native method
.end method

.method private final native nativeJoyButtonState(I I Z)V
    # abstract or native method
.end method

.method private final native nativeKeyState(I I Z I I)V
    # abstract or native method
.end method

.method private final native nativePause()Z
    # abstract or native method
.end method

.method private final native nativeQueueGUIEvent(I F F I)V
    # abstract or native method
.end method

.method private final native nativeRecreateGfxState()V
    # abstract or native method
.end method

.method private final native nativeRender()Z
    # abstract or native method
.end method

.method private final native nativeRequested32bitDisplayBuffer()Z
    # abstract or native method
.end method

.method private final native nativeRequestedAA()I
    # abstract or native method
.end method

.method private final native nativeResize(I I I I)V
    # abstract or native method
.end method

.method private final native nativeResume()V
    # abstract or native method
.end method

.method private final native nativeSetExtras(Landroid/os/Bundle;)V
    # abstract or native method
.end method

.method private final native nativeSetInputCanceled(Z)V
    # abstract or native method
.end method

.method private final native nativeSetInputString(Ljava/lang/String;)V
    # abstract or native method
.end method

.method private final native nativeSetJoystickPosition(I I F)V
    # abstract or native method
.end method

.method private final native nativeSetMouseButton(I Z)V
    # abstract or native method
.end method

.method private final native nativeSetMouseDelta(F F F)V
    # abstract or native method
.end method

.method private final native nativeSetMousePosition(F F)V
    # abstract or native method
.end method

.method private final native nativeSetTouchDeltaY(F)V
    # abstract or native method
.end method

.method private final native nativeSoftInputClosed()V
    # abstract or native method
.end method

.method private final native nativeTouch(I F F I J I)V
    # abstract or native method
.end method

.method private final native nativeVideoFrameCallback(I [B I I)V
    # abstract or native method
.end method

.method static synthetic o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    return-object v0
.end method

.method private final native unityAndroidInit(Ljava/lang/String; Ljava/lang/String;)Z
    # abstract or native method
.end method

.method private final native unityAndroidPrepareGameLoop()V
    # abstract or native method
.end method

.method protected Location_IsServiceEnabledByUser()Z
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, Lcom/unity3d/player/r;->a()Z
    move-result v0
    return v0
.end method

.method protected Location_SetDesiredAccuracy(F)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, v2, Lcom/unity3d/player/r;->b(F)V
    return-void
.end method

.method protected Location_SetDistanceFilter(F)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, v2, Lcom/unity3d/player/r;->a(F)V
    return-void
.end method

.method protected Location_StartUpdatingLocation()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, Lcom/unity3d/player/r;->b()V
    return-void
.end method

.method protected Location_StopUpdatingLocation()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, Lcom/unity3d/player/r;->c()V
    return-void
.end method

.method protected closeCamera(I)V
    .registers 5
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +016h
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Lcom/unity3d/player/a;
    invoke-virtual v0, Lcom/unity3d/player/a;->a()I
    move-result v2
    if-ne v2, v4, -010h
    invoke-virtual v0, Lcom/unity3d/player/a;->c()V
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    invoke-interface v1, v0, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    return-void
.end method

.method public configurationChanged(Landroid/content/res/Configuration;)V
    .registers 5
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Landroid/view/SurfaceView;
    if-eqz v0, +00dh
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/SurfaceView;
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    invoke-interface v0, Landroid/view/SurfaceHolder;->setSizeFromLayout()V
    iget-boolean v0, v3, Lcom/unity3d/player/UnityPlayer;->c Z
    if-eqz v0, +016h
    iget v0, v4, Landroid/content/res/Configuration;->hardKeyboardHidden I
    const/4 v1, 2
    if-ne v0, v1, +011h
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "input_method"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;
    const/4 v1, 0
    const/4 v2, 1
    invoke-virtual v0, v1, v2, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(I I)V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    if-eqz v0, +007h
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    invoke-virtual v0, Lcom/unity3d/player/y;->updateVideoLayout()V
    return-void
.end method

.method protected dispatchTouchEvent(I I I F F J I)Z
    .registers 18
    iget-object v0, v9, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-nez v0, +004h
    const/4 v0, 1
    return v0
    iget-boolean v0, v9, Lcom/unity3d/player/UnityPlayer;->k Z
    if-nez v0, +01bh
    and-int/lit16 v5, v11, 255
    const v0, 65280
    and-int/2addr v0, v11
    shr-int/lit8 v0, v0, 8
    if-ne v10, v0, +013h
    new-instance v0, Lcom/unity3d/player/UnityPlayer$6;
    move-object v1, v9
    move v2, v12
    move v3, v13
    move v4, v14
    move-wide v6, v15
    move/from16 v8, v17
    invoke-direct/range v0 ... v8, Lcom/unity3d/player/UnityPlayer$6;-><init>(Lcom/unity3d/player/UnityPlayer; I F F I J I)V
    invoke-virtual v9, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    const/4 v0, 1
    goto -1fh
    const/4 v5, 2
    goto -12h
.end method

.method protected enableSensorCompensation(Z)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iput-boolean v2, v0, Lcom/unity3d/player/r;->a Z
    return-void
.end method

.method protected forwardMotionEventToDalvik(J J I I [I [F I F F I I I I I [J [F)V
    .registers 39
    move-object/from16 v0, v20
    iget-object v1, v0, Lcom/unity3d/player/UnityPlayer;->d Lcom/unity3d/player/l;
    if-eqz v1, +029h
    move-object/from16 v0, v20
    iget-object v1, v0, Lcom/unity3d/player/UnityPlayer;->d Lcom/unity3d/player/l;
    move-wide/from16 v2, v21
    move-wide/from16 v4, v23
    move/from16 v6, v25
    move/from16 v7, v26
    move-object/from16 v8, v27
    move-object/from16 v9, v28
    move/from16 v10, v29
    move/from16 v11, v30
    move/from16 v12, v31
    move/from16 v13, v32
    move/from16 v14, v33
    move/from16 v15, v34
    move/from16 v16, v35
    move/from16 v17, v36
    move-object/from16 v18, v37
    move-object/from16 v19, v38
    invoke-interface/range v1 ... v19, Lcom/unity3d/player/l;->a(J J I I [I [F I F F I I I I I [J [F)V
    return-void
.end method

.method protected getCPUType()Ljava/lang/String;
    .registers 2
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    invoke-virtual v0, Lcom/unity3d/player/b;->b()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method protected getCacheDir()Ljava/lang/String;
    .registers 3
    const-string v0, "/cache"
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v1, Landroid/content/ContextWrapper;->getCacheDir()Ljava/io/File;
    move-result-object v1
    invoke-direct v2, v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String; Ljava/io/File;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method protected getCameraOrientation(I)I
    .registers 3
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    invoke-static v2, Lcom/unity3d/player/h;->b(I)I
    move-result v0
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method protected getConnectedJoysticks()[I
    .registers 2
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-virtual v0, Lcom/unity3d/player/i;->a()[I
    move-result-object v0
    return-object v0
    const/4 v0, 0
    goto -2h
.end method

.method protected getDeviceOrientation()I
    .registers 9
    const/4 v7, 2
    const/16 v4, 9
    const/4 v2, 0
    const/4 v1, 1
    iget-object v0, v8, Lcom/unity3d/player/UnityPlayer;->r Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v5
    invoke-virtual v8, Lcom/unity3d/player/UnityPlayer;->getResources()Landroid/content/res/Resources;
    move-result-object v0
    invoke-virtual v0, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    move-result-object v0
    iget v0, v0, Landroid/content/res/Configuration;->orientation I
    if-ne v0, v7, +013h
    move v0, v1
    sget v3, Landroid/os/Build$VERSION;->SDK_INT I
    if-lt v3, v4, +010h
    const/16 v3, 8
    sget v6, Landroid/os/Build$VERSION;->SDK_INT I
    if-lt v6, v4, +00ch
    if-nez v5, +00ch
    if-eqz v0, +003h
    move v1, v2
    return v1
    move v0, v2
    goto -11h
    move v3, v2
    goto -dh
    move v4, v1
    goto -bh
    if-ne v5, v1, +008h
    if-eqz v0, +004h
    move v1, v2
    goto -ch
    move v1, v4
    goto -eh
    if-ne v5, v7, +008h
    if-eqz v0, +004h
    move v1, v3
    goto -14h
    move v1, v4
    goto -16h
    const/4 v2, 3
    if-ne v5, v2, -018h
    if-eqz v0, -01ah
    move v1, v3
    goto -1dh
.end method

.method protected getDeviceUniqueIdentifier()Ljava/lang/String;
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->B Ljava/lang/String;
    if-nez v0, +012h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "phone"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/telephony/TelephonyManager;
    invoke-virtual v0, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;
    move-result-object v0
    iput-object v0, v2, Lcom/unity3d/player/UnityPlayer;->B Ljava/lang/String;
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->B Ljava/lang/String;
    if-eqz v0, +010h
    invoke-virtual v0, Ljava/lang/String;->length()I
    move-result v1
    if-eqz v1, +00ah
    return-object v0
    move-exception v0
    const/4 v0, 5
    const-string v1, "android.permission.READ_PHONE_STATE not available?"
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;
    move-result-object v0
    const-string v1, "android_id"
    invoke-static v0, v1, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    goto -14h
.end method

.method protected getFilesDir()Ljava/lang/String;
    .registers 3
    const-string v0, "/files"
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v1, Landroid/content/ContextWrapper;->getFilesDir()Ljava/io/File;
    move-result-object v1
    invoke-direct v2, v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String; Ljava/io/File;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method protected getGyroUpdateDelay()I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/UnityPlayer;->O I
    return v0
.end method

.method protected getInternetReachability()I
    .registers 4
    const/4 v1, 0
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->C Landroid/net/NetworkInfo;
    if-nez v0, +012h
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v2, "connectivity"
    invoke-virtual v0, v2, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/net/ConnectivityManager;
    invoke-virtual v0, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;
    move-result-object v0
    iput-object v0, v3, Lcom/unity3d/player/UnityPlayer;->C Landroid/net/NetworkInfo;
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->C Landroid/net/NetworkInfo;
    if-nez v0, +004h
    move v0, v1
    return v0
    invoke-virtual v0, Landroid/net/NetworkInfo;->isConnected()Z
    move-result v2
    if-nez v2, +004h
    move v0, v1
    goto -8h
    invoke-virtual v0, Landroid/net/NetworkInfo;->getType()I
    move-result v0
    add-int/lit8 v0, v0, 1
    goto -fh
    move-exception v0
    const/4 v0, 5
    const-string v2, "android.permission.ACCESS_NETWORK_STATE not available?"
    invoke-static v0, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    move v0, v1
    goto -18h
.end method

.method protected getIsGyroAvailable()Z
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v0
    const-string v1, "android.hardware.sensor.gyroscope"
    invoke-virtual v0, v1, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    move-result v0
    return v0
.end method

.method protected getIsGyroEnabled()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/UnityPlayer;->N Z
    return v0
.end method

.method protected getJoystickAxes(I)[I
    .registers 3
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-static v2, Lcom/unity3d/player/i;->a(I)[I
    move-result-object v0
    return-object v0
    const/4 v0, 0
    goto -2h
.end method

.method protected getJoystickName(I)Ljava/lang/String;
    .registers 3
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-static v2, Lcom/unity3d/player/i;->b(I)Ljava/lang/String;
    move-result-object v0
    return-object v0
    const/4 v0, 0
    goto -2h
.end method

.method protected getNumCameras()I
    .registers 2
    invoke-direct v1, Lcom/unity3d/player/UnityPlayer;->k()Z
    move-result v0
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    invoke-static Lcom/unity3d/player/h;->a()I
    move-result v0
    goto -bh
    const/4 v0, 1
    goto -dh
.end method

.method protected getOrientation()I
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-nez v0, +004h
    const/4 v0, 1
    return v0
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->getRequestedOrientation()I
    move-result v0
    goto -9h
.end method

.method protected getPackageName()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method protected getScreenDPI()F
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    new-instance v1, Landroid/util/DisplayMetrics;
    invoke-direct v1, Landroid/util/DisplayMetrics;-><init>()V
    invoke-virtual v0, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;
    move-result-object v0
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, v1, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V
    iget v0, v1, Landroid/util/DisplayMetrics;->xdpi F
    iget v1, v1, Landroid/util/DisplayMetrics;->ydpi F
    add-float/2addr v0, v1
    const/high16 v1, 1056964608
    mul-float/2addr v0, v1
    goto -1dh
.end method

.method protected getScreenOrientationAngle()I
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->r Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v0
    mul-int/lit8 v0, v0, 90
    rsub-int v0, v0, 360
    rem-int/lit16 v0, v0, 360
    return v0
.end method

.method protected getScreenTimeout()I
    .registers 4
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;
    move-result-object v0
    const-string v1, "screen_off_timeout"
    const/16 v2, 15000
    invoke-static v0, v1, v2, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver; Ljava/lang/String; I)I
    move-result v0
    div-int/lit16 v0, v0, 1000
    return v0
.end method

.method public getSettings()Landroid/os/Bundle;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->D Landroid/os/Bundle;
    return-object v0
.end method

.method protected getTotalMemory()I
    .registers 2
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    invoke-virtual v0, Lcom/unity3d/player/b;->c()I
    move-result v0
    return v0
.end method

.method public getView()Landroid/view/View;
    .registers 1
    return-object v0
.end method

.method protected hasWakeLock()Z
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->n Landroid/os/PowerManager$WakeLock;
    invoke-virtual v0, Landroid/os/PowerManager$WakeLock;->isHeld()Z
    move-result v0
    return v0
.end method

.method protected hideSoftInput()V
    .registers 2
    new-instance v0, Lcom/unity3d/player/UnityPlayer$12;
    invoke-direct v0, v1, Lcom/unity3d/player/UnityPlayer$12;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected hideVideoPlayer()V
    .registers 2
    new-instance v0, Lcom/unity3d/player/UnityPlayer$18;
    invoke-direct v0, v1, Lcom/unity3d/player/UnityPlayer$18;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method public init(I Z)V
    .registers 7
    const/4 v3, 0
    invoke-static Lcom/unity3d/player/x;->b()Z
    move-result v0
    if-nez v0, +02bh
    new-instance v0, Landroid/app/AlertDialog$Builder;
    iget-object v1, v4, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-direct v0, v1, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V
    const-string v1, "Failure to initialize!"
    invoke-virtual v0, v1, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    const-string v1, "OK"
    new-instance v2, Lcom/unity3d/player/UnityPlayer$1;
    invoke-direct v2, v4, Lcom/unity3d/player/UnityPlayer$1;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-virtual v0, v1, v2, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence; Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    const-string v1, "Your hardware does not support this application, sorry!"
    invoke-virtual v0, v1, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    invoke-virtual v0, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
    move-result-object v0
    invoke-virtual v0, v3, Landroid/app/AlertDialog;->setCancelable(Z)V
    invoke-virtual v0, Landroid/app/AlertDialog;->show()V
    return-void
    sget-object v0, Landroid/os/Build;->MANUFACTURER Ljava/lang/String;
    const-string v1, "samsung"
    invoke-virtual v0, v1, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +03bh
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v1, 8
    if-ge v0, v1, +035h
    sget-object v0, Lcom/unity3d/player/UnityPlayer;->J Lcom/unity3d/player/b;
    invoke-virtual v0, Lcom/unity3d/player/b;->a()I
    move-result v0
    and-int/lit8 v0, v0, 16
    if-eqz v0, +02bh
    new-instance v0, Landroid/app/AlertDialog$Builder;
    iget-object v1, v4, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-direct v0, v1, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V
    const-string v1, "Old Android OS detected!"
    invoke-virtual v0, v1, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    const-string v1, "OK"
    new-instance v2, Lcom/unity3d/player/UnityPlayer$11;
    invoke-direct v2, v4, v5, v6, Lcom/unity3d/player/UnityPlayer$11;-><init>(Lcom/unity3d/player/UnityPlayer; I Z)V
    invoke-virtual v0, v1, v2, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence; Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    const-string v1, "This application requires at least Android OS version 2.2 on Samsung devices. Your device seems to be running an older OS version.
Please contact your carrier or the hardware vendor and ask them how to install a more recent version. It is a simple process that your provider's customer service can help you with."
    invoke-virtual v0, v1, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    move-result-object v0
    invoke-virtual v0, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
    move-result-object v0
    invoke-virtual v0, v3, Landroid/app/AlertDialog;->setCancelable(Z)V
    invoke-virtual v0, Landroid/app/AlertDialog;->show()V
    goto -43h
    invoke-direct v4, v5, v6, Lcom/unity3d/player/UnityPlayer;->a(I Z)V
    goto -47h
.end method

.method protected initCamera(I I I I)[I
    .registers 10
    new-instance v1, Lcom/unity3d/player/a;
    invoke-direct v1, v6, v7, v8, v9, Lcom/unity3d/player/a;-><init>(I I I I)V
    invoke-virtual v1, v5, Lcom/unity3d/player/a;->a(Lcom/unity3d/player/a$a;)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->E Ljava/util/List;
    invoke-interface v0, v1, Ljava/util/List;->add(Ljava/lang/Object;)Z
    invoke-virtual v1, Lcom/unity3d/player/a;->b()Landroid/hardware/Camera$Size;
    move-result-object v2
    const/4 v0, 2
    new-array v0, v0, [I
    const/4 v3, 0
    iget v4, v2, Landroid/hardware/Camera$Size;->width I
    aput v4, v0, v3
    const/4 v3, 1
    iget v2, v2, Landroid/hardware/Camera$Size;->height I
    aput v2, v0, v3
    return-object v0
    move-exception v0
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "Unable to initialize camera: "
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    const/4 v2, 6
    invoke-static v2, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    invoke-virtual v1, Lcom/unity3d/player/a;->c()V
    const/4 v0, 0
    goto -1dh
.end method

.method protected isCameraFrontFacing(I)Z
    .registers 3
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    invoke-static v2, Lcom/unity3d/player/h;->a(I)Z
    move-result v0
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method protected isCompassAvailable()Z
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v0, Landroid/content/ContextWrapper;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v0
    const-string v1, "android.hardware.sensor.compass"
    invoke-virtual v0, v1, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    move-result v0
    return v0
.end method

.method protected isCompassEnabled()Z
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/UnityPlayer;->P Z
    return v0
.end method

.method protected isFinishing()Z
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-eqz v0, +00eh
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->isFinishing()Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method protected isSensorCompensationEnabled()Z
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    iget-boolean v0, v0, Lcom/unity3d/player/r;->a Z
    return v0
.end method

.method protected kill()V
    .registers 2
    invoke-static Landroid/os/Process;->myPid()I
    move-result v0
    invoke-static v0, Landroid/os/Process;->killProcess(I)V
    return-void
.end method

.method protected loadLibrary(Ljava/lang/String;)Z
    .registers 7
    const/4 v4, 6
    const/4 v0, 0
    invoke-static v6, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    const/4 v0, 1
    return v0
    move-exception v1
    new-instance v1, Ljava/lang/StringBuilder;
    const-string v2, "Unable to find "
    invoke-direct v1, v2, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v1, v6, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v4, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -14h
    move-exception v1
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "Unknown error "
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v4, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -28h
.end method

.method final native nativeAttitude(F F F F J)V
    # abstract or native method
.end method

.method final native nativeCompass(F F F F F D)V
    # abstract or native method
.end method

.method final native nativeDeviceOrientation(I)V
    # abstract or native method
.end method

.method final native nativeForwardEventsToDalvik(Z)V
    # abstract or native method
.end method

.method final native nativeGravity(F F F J)V
    # abstract or native method
.end method

.method final native nativeGyro(F F F J)V
    # abstract or native method
.end method

.method final native nativeJoystickRemoved()V
    # abstract or native method
.end method

.method final native nativeLinearAcc(F F F J)V
    # abstract or native method
.end method

.method final native nativeSensor(F F F J)V
    # abstract or native method
.end method

.method protected native nativeSetLocation(F F F F D)V
    # abstract or native method
.end method

.method protected native nativeSetLocationStatus(I)V
    # abstract or native method
.end method

.method public onCameraFrame(Lcom/unity3d/player/a; [B)V
    .registers 9
    invoke-virtual v6, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v0
    if-eqz v0, +003h
    return-void
    invoke-virtual v7, Lcom/unity3d/player/a;->a()I
    move-result v2
    invoke-virtual v7, Lcom/unity3d/player/a;->b()Landroid/hardware/Camera$Size;
    move-result-object v4
    new-instance v0, Lcom/unity3d/player/UnityPlayer$15;
    move-object v1, v6
    move-object v3, v8
    move-object v5, v7
    invoke-direct/range v0 ... v5, Lcom/unity3d/player/UnityPlayer$15;-><init>(Lcom/unity3d/player/UnityPlayer; I [B Landroid/hardware/Camera$Size; Lcom/unity3d/player/a;)V
    invoke-virtual v6, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -14h
.end method

.method public onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .registers 6
    const/4 v1, 0
    invoke-virtual v4, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v0
    if-eqz v0, +003h
    return-void
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->nativeRender()Z
    move-result v0
    if-nez v0, +006h
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->b()V
    goto -ah
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-nez v0, +03fh
    iget-boolean v0, v4, Lcom/unity3d/player/UnityPlayer;->v Z
    if-eqz v0, +005h
    iput-boolean v1, v4, Lcom/unity3d/player/UnityPlayer;->v Z
    goto -19h
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->i()V
    iget v0, v4, Lcom/unity3d/player/UnityPlayer;->w I
    iget v1, v4, Lcom/unity3d/player/UnityPlayer;->x I
    iget v2, v4, Lcom/unity3d/player/UnityPlayer;->w I
    iget v3, v4, Lcom/unity3d/player/UnityPlayer;->x I
    invoke-direct v4, v0, v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->nativeResize(I I I I)V
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->nativeResume()V
    const/4 v0, 1
    invoke-virtual v4, v0, Lcom/unity3d/player/UnityPlayer;->windowFocusChanged(Z)V
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Lcom/unity3d/player/w;
    if-eqz v0, -033h
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Lcom/unity3d/player/w;
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->nativeRequested32bitDisplayBuffer()Z
    move-result v1
    invoke-direct v4, Lcom/unity3d/player/UnityPlayer;->nativeRequestedAA()I
    move-result v2
    invoke-virtual v0, v1, v2, Lcom/unity3d/player/w;->a(Z I)Z
    move-result v1
    if-eqz v1, -045h
    new-instance v1, Lcom/unity3d/player/UnityPlayer$2;
    invoke-direct v1, v4, v0, Lcom/unity3d/player/UnityPlayer$2;-><init>(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/w;)V
    invoke-direct v4, v1, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    goto -4fh
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->i()Z
    move-result v0
    if-nez v0, -027h
    iget-object v0, v4, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->e()V
    invoke-direct v4, v1, Lcom/unity3d/player/UnityPlayer;->a(Z)V
    goto -31h
.end method

.method public onKeyDown(I Landroid/view/KeyEvent;)Z
    .registers 4
    invoke-direct v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->b(I Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
.end method

.method public onKeyPreIme(I Landroid/view/KeyEvent;)Z
    .registers 4
    iget-boolean v0, v1, Lcom/unity3d/player/UnityPlayer;->c Z
    if-eqz v0, +00ah
    const/4 v0, 4
    if-ne v2, v0, +007h
    invoke-direct v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->b(I Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
    invoke-super v1, v2, v3, Landroid/widget/FrameLayout;->onKeyPreIme(I Landroid/view/KeyEvent;)Z
    move-result v0
    goto -5h
.end method

.method public onKeyUp(I Landroid/view/KeyEvent;)Z
    .registers 4
    invoke-direct v1, v2, v3, Lcom/unity3d/player/UnityPlayer;->b(I Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
.end method

.method public onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10; I I)V
    .registers 7
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Landroid/view/SurfaceView;
    if-eqz v0, +02bh
    iget v0, v3, Lcom/unity3d/player/UnityPlayer;->y I
    if-nez v0, +006h
    iget v0, v3, Lcom/unity3d/player/UnityPlayer;->z I
    if-eqz v0, +023h
    iget v0, v3, Lcom/unity3d/player/UnityPlayer;->y I
    if-ne v0, v5, +006h
    iget v0, v3, Lcom/unity3d/player/UnityPlayer;->z I
    if-eq v0, v6, +01bh
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +038h
    sget-object v1, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/SurfaceView;
    invoke-interface v1, v0, Lcom/unity3d/player/j;->b(Landroid/view/View;)Z
    move-result v0
    iget v1, v3, Lcom/unity3d/player/UnityPlayer;->y I
    iget v2, v3, Lcom/unity3d/player/UnityPlayer;->z I
    invoke-virtual v3, v1, v2, v0, Lcom/unity3d/player/UnityPlayer;->setScreenSize(I I Z)V
    iget v5, v3, Lcom/unity3d/player/UnityPlayer;->y I
    iget v6, v3, Lcom/unity3d/player/UnityPlayer;->z I
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Landroid/view/View;
    if-eqz v0, +01fh
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-virtual v0, Landroid/view/View;->getWidth()I
    move-result v1
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-virtual v0, Landroid/view/View;->getHeight()I
    move-result v0
    iput v5, v3, Lcom/unity3d/player/UnityPlayer;->w I
    iput v6, v3, Lcom/unity3d/player/UnityPlayer;->x I
    invoke-direct v3, v5, v6, v1, v0, Lcom/unity3d/player/UnityPlayer;->nativeResize(I I I I)V
    invoke-direct v3, Lcom/unity3d/player/UnityPlayer;->h()V
    return-void
    const/4 v0, 0
    goto -2dh
    move v0, v6
    move v1, v5
    goto -fh
.end method

.method public onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10; Ljavax/microedition/khronos/egl/EGLConfig;)V
    .registers 3
    invoke-direct v0, Lcom/unity3d/player/UnityPlayer;->nativeRecreateGfxState()V
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 16
    const/4 v11, 0
    const/4 v9, 1
    iget-object v0, v14, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-nez v0, +004h
    move v0, v9
    return v0
    iget-boolean v0, v14, Lcom/unity3d/player/UnityPlayer;->k Z
    if-eqz v0, +004h
    move v0, v9
    goto -6h
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +011h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    invoke-static v15, Lcom/unity3d/player/h;->a(Landroid/view/MotionEvent;)I
    move-result v8
    const/16 v0, 8194
    if-ne v8, v0, +00ah
    invoke-direct v14, v15, Lcom/unity3d/player/UnityPlayer;->b(Landroid/view/MotionEvent;)Z
    move-result v0
    goto -19h
    const/16 v8, 4098
    goto -bh
    const v0, 16777232
    if-ne v8, v0, +007h
    invoke-direct v14, v15, Lcom/unity3d/player/UnityPlayer;->c(Landroid/view/MotionEvent;)Z
    move-result v0
    goto -26h
    invoke-virtual v15, Landroid/view/MotionEvent;->getPointerCount()I
    move-result v12
    move v1, v11
    if-ge v1, v12, +039h
    invoke-virtual v15, v1, Landroid/view/MotionEvent;->getPointerId(I)I
    move-result v3
    invoke-virtual v15, Landroid/view/MotionEvent;->getHistorySize()I
    move-result v13
    move v10, v11
    if-ge v10, v13, +017h
    const/4 v2, 2
    invoke-virtual v15, v1, v10, Landroid/view/MotionEvent;->getHistoricalX(I I)F
    move-result v4
    invoke-virtual v15, v1, v10, Landroid/view/MotionEvent;->getHistoricalY(I I)F
    move-result v5
    invoke-virtual v15, v10, Landroid/view/MotionEvent;->getHistoricalEventTime(I)J
    move-result-wide v6
    move-object v0, v14
    invoke-virtual/range v0 ... v8, Lcom/unity3d/player/UnityPlayer;->dispatchTouchEvent(I I I F F J I)Z
    add-int/lit8 v0, v10, 1
    move v10, v0
    goto -16h
    invoke-virtual v15, Landroid/view/MotionEvent;->getAction()I
    move-result v2
    invoke-virtual v15, v1, Landroid/view/MotionEvent;->getX(I)F
    move-result v4
    invoke-virtual v15, v1, Landroid/view/MotionEvent;->getY(I)F
    move-result v5
    invoke-virtual v15, Landroid/view/MotionEvent;->getEventTime()J
    move-result-wide v6
    move-object v0, v14
    invoke-virtual/range v0 ... v8, Lcom/unity3d/player/UnityPlayer;->dispatchTouchEvent(I I I F F J I)Z
    add-int/lit8 v1, v1, 1
    goto -38h
    move v0, v9
    goto -66h
.end method

.method protected openURL(Ljava/lang/String;)V
    .registers 6
    new-instance v0, Landroid/content/Intent;
    const-string v1, "android.intent.action.VIEW"
    invoke-direct v0, v1, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-static v5, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v1
    invoke-virtual v0, v1, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;
    invoke-virtual v1, Landroid/net/Uri;->isRelative()Z
    move-result v1
    if-eqz v1, +01ah
    new-instance v1, Ljava/io/File;
    invoke-direct v1, v5, Ljava/io/File;-><init>(Ljava/lang/String;)V
    invoke-static v1, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;
    move-result-object v1
    invoke-static Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;
    move-result-object v2
    invoke-static v5, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    invoke-virtual v2, v3, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri; Ljava/lang/String;)Landroid/content/Intent;
    iget-object v1, v4, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    invoke-virtual v1, v0, Landroid/content/ContextWrapper;->startActivity(Landroid/content/Intent;)V
    return-void
.end method

.method public pause()V
    .registers 6
    const/4 v4, 0
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    if-eqz v0, +00bh
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->F Lcom/unity3d/player/y;
    invoke-virtual v0, Lcom/unity3d/player/y;->onPause()V
    invoke-direct v5, v4, Lcom/unity3d/player/UnityPlayer;->b(Z)V
    return-void
    invoke-direct v5, v4, Lcom/unity3d/player/UnityPlayer;->a(Z)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->g()Z
    move-result v0
    if-eqz v0, -00ah
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, v4, Lcom/unity3d/player/x;->c(Z)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    const/4 v1, 1
    invoke-virtual v0, v1, Lcom/unity3d/player/x;->b(Z)V
    invoke-direct v5, Lcom/unity3d/player/UnityPlayer;->d()V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    if-eqz v0, +007h
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->s Lorg/fmod/FMODAudioDevice;
    invoke-virtual v0, Lorg/fmod/FMODAudioDevice;->stop()V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-eqz v0, +027h
    new-instance v0, Ljava/util/concurrent/Semaphore;
    invoke-direct v0, v4, Ljava/util/concurrent/Semaphore;-><init>(I)V
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v1
    if-eqz v1, +05bh
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v2, Lcom/unity3d/player/UnityPlayer$24;
    invoke-direct v2, v5, v0, Lcom/unity3d/player/UnityPlayer$24;-><init>(Lcom/unity3d/player/UnityPlayer; Ljava/util/concurrent/Semaphore;)V
    invoke-interface v1, v2, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    const-wide/16 v1, 10
    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS Ljava/util/concurrent/TimeUnit;
    invoke-virtual v0, v1, v2, v3, Ljava/util/concurrent/Semaphore;->tryAcquire(J Ljava/util/concurrent/TimeUnit;)Z
    invoke-virtual v0, Ljava/util/concurrent/Semaphore;->drainPermits()I
    move-result v0
    if-lez v0, +005h
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayer;->quit()V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer;->M Landroid/content/BroadcastReceiver;
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    iget-boolean v0, v5, Lcom/unity3d/player/UnityPlayer;->f Z
    if-eqz v0, +01ah
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v0, v0, Lcom/unity3d/player/w;
    if-eqz v0, +014h
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    if-eqz v0, +007h
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->m Lcom/unity3d/player/q;
    invoke-virtual v0, Lcom/unity3d/player/q;->a()V
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer;->e Lcom/unity3d/player/t;
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v0, Landroid/view/View;
    invoke-virtual v1, v0, Lcom/unity3d/player/t;->e(Landroid/view/View;)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    invoke-interface v0, Lcom/unity3d/player/UnityGL;->onPause()V
    invoke-direct v5, v4, Lcom/unity3d/player/UnityPlayer;->c(Z)V
    invoke-direct v5, v4, Lcom/unity3d/player/UnityPlayer;->d(Z)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->q Landroid/hardware/SensorManager;
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, v1, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer;->A Lcom/unity3d/player/r;
    invoke-virtual v0, Lcom/unity3d/player/r;->d()V
    invoke-virtual v5, v4, Lcom/unity3d/player/UnityPlayer;->setWakeLock(Z)V
    goto/16 -08dh
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v2, Lcom/unity3d/player/UnityPlayer$25;
    invoke-direct v2, v5, v0, Lcom/unity3d/player/UnityPlayer$25;-><init>(Lcom/unity3d/player/UnityPlayer; Ljava/util/concurrent/Semaphore;)V
    invoke-interface v1, v2, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    goto -59h
    move-exception v1
    goto -54h
.end method

.method protected queueEvent(Ljava/lang/Runnable;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-nez v0, +003h
    return-void
    invoke-virtual v2, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v0
    if-nez v0, -005h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$21;
    invoke-direct v1, v2, v3, Lcom/unity3d/player/UnityPlayer$21;-><init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/Runnable;)V
    invoke-interface v0, v1, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    goto -11h
.end method

.method public quit()V
    .registers 2
    invoke-static Lcom/unity3d/player/x;->b()Z
    move-result v0
    if-eqz v0, +00ah
    invoke-virtual v1, Lcom/unity3d/player/UnityPlayer;->removeAllViews()V
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    invoke-interface v0, Lcom/unity3d/player/UnityGL;->a()V
    invoke-virtual v1, Lcom/unity3d/player/UnityPlayer;->kill()V
    return-void
.end method

.method protected reportSoftInputStr(Ljava/lang/String; I Z)V
    .registers 5
    const/4 v0, 1
    if-ne v3, v0, +005h
    invoke-virtual v1, Lcom/unity3d/player/UnityPlayer;->hideSoftInput()V
    new-instance v0, Lcom/unity3d/player/UnityPlayer$14;
    invoke-direct v0, v1, v4, v2, v3, Lcom/unity3d/player/UnityPlayer$14;-><init>(Lcom/unity3d/player/UnityPlayer; Z Ljava/lang/String; I)V
    invoke-virtual v1, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    return-void
.end method

.method public resume()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->i()Z
    move-result v0
    if-nez v0, +006h
    const/4 v0, 1
    invoke-direct v2, v0, Lcom/unity3d/player/UnityPlayer;->a(Z)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    const/4 v1, 0
    invoke-virtual v0, v1, Lcom/unity3d/player/x;->b(Z)V
    invoke-direct v2, Lcom/unity3d/player/UnityPlayer;->g()V
    return-void
.end method

.method protected setCompassEnabled(Z)V
    .registers 5
    const/4 v1, 1
    const/4 v0, 0
    iget-boolean v2, v3, Lcom/unity3d/player/UnityPlayer;->P Z
    if-ne v2, v4, +003h
    return-void
    if-eqz v4, +011h
    if-eqz v4, +009h
    invoke-virtual v3, Lcom/unity3d/player/UnityPlayer;->isCompassAvailable()Z
    move-result v2
    if-eqz v2, +003h
    move v0, v1
    iput-boolean v0, v3, Lcom/unity3d/player/UnityPlayer;->P Z
    invoke-direct v3, v1, Lcom/unity3d/player/UnityPlayer;->d(Z)V
    goto -11h
    invoke-direct v3, v0, Lcom/unity3d/player/UnityPlayer;->d(Z)V
    iput-boolean v4, v3, Lcom/unity3d/player/UnityPlayer;->P Z
    new-instance v0, Lcom/unity3d/player/UnityPlayer$20;
    invoke-direct v0, v3, Lcom/unity3d/player/UnityPlayer$20;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-virtual v3, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -1fh
.end method

.method protected setGyroEnabled(Z)V
    .registers 5
    const/4 v1, 1
    const/4 v0, 0
    iget-boolean v2, v3, Lcom/unity3d/player/UnityPlayer;->N Z
    if-ne v2, v4, +003h
    return-void
    if-eqz v4, +011h
    if-eqz v4, +009h
    invoke-virtual v3, Lcom/unity3d/player/UnityPlayer;->getIsGyroAvailable()Z
    move-result v2
    if-eqz v2, +003h
    move v0, v1
    iput-boolean v0, v3, Lcom/unity3d/player/UnityPlayer;->N Z
    invoke-direct v3, v1, Lcom/unity3d/player/UnityPlayer;->c(Z)V
    goto -11h
    invoke-direct v3, v0, Lcom/unity3d/player/UnityPlayer;->c(Z)V
    iput-boolean v4, v3, Lcom/unity3d/player/UnityPlayer;->N Z
    new-instance v0, Lcom/unity3d/player/UnityPlayer$19;
    invoke-direct v0, v3, Lcom/unity3d/player/UnityPlayer$19;-><init>(Lcom/unity3d/player/UnityPlayer;)V
    invoke-virtual v3, v0, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    goto -1fh
.end method

.method protected setGyroUpdateDelay(I)V
    .registers 2
    iput v1, v0, Lcom/unity3d/player/UnityPlayer;->O I
    return-void
.end method

.method protected setHideInputField(Z)V
    .registers 2
    iput-boolean v1, v0, Lcom/unity3d/player/UnityPlayer;->b Z
    return-void
.end method

.method protected setOrientation(I)V
    .registers 5
    const/16 v2, 9
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    instance-of v0, v0, Landroid/app/Activity;
    if-nez v0, +003h
    return-void
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual v0, Landroid/app/Activity;->getRequestedOrientation()I
    move-result v1
    if-eq v4, v1, -009h
    sget v1, Landroid/os/Build$VERSION;->SDK_INT I
    if-ge v1, v2, +008h
    if-eq v4, v2, -00fh
    const/16 v1, 8
    if-eq v4, v1, -013h
    invoke-virtual v0, v4, Landroid/app/Activity;->setRequestedOrientation(I)V
    goto -18h
.end method

.method protected setScreenSize(I I Z)V
    .registers 11
    const/4 v1, 1
    const/4 v4, -1
    const/4 v0, 0
    iget-object v2, v7, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    instance-of v2, v2, Landroid/view/SurfaceView;
    if-nez v2, +009h
    const/4 v0, 5
    const-string v1, "setScreenSize: Unable to retrieve surface holder"
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-void
    iget-object v3, v7, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    check-cast v3, Landroid/view/SurfaceView;
    invoke-virtual v3, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v2
    invoke-interface v2, Landroid/view/SurfaceHolder;->getSurfaceFrame()Landroid/graphics/Rect;
    invoke-virtual v3, Landroid/view/SurfaceView;->getWidth()I
    move-result v2
    if-ne v2, v8, +008h
    invoke-virtual v3, Landroid/view/SurfaceView;->getHeight()I
    move-result v2
    if-eq v2, v9, +006h
    if-nez v8, +01dh
    if-nez v9, +01bh
    move v2, v1
    if-ne v8, v4, +01ah
    if-ne v9, v4, +018h
    if-nez v1, +01dh
    if-eqz v2, +016h
    iput v0, v7, Lcom/unity3d/player/UnityPlayer;->y I
    iput v0, v7, Lcom/unity3d/player/UnityPlayer;->z I
    new-instance v0, Lcom/unity3d/player/UnityPlayer$9;
    move v4, v8
    move v5, v9
    move v6, v10
    invoke-direct/range v0 ... v6, Lcom/unity3d/player/UnityPlayer$9;-><init>(Z Z Landroid/view/SurfaceView; I I Z)V
    invoke-direct v7, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    goto -34h
    move v2, v0
    goto -19h
    move v1, v0
    goto -17h
    iput v8, v7, Lcom/unity3d/player/UnityPlayer;->y I
    iput v9, v7, Lcom/unity3d/player/UnityPlayer;->z I
    goto -14h
    iget v0, v7, Lcom/unity3d/player/UnityPlayer;->y I
    if-nez v0, -017h
    iget v0, v7, Lcom/unity3d/player/UnityPlayer;->z I
    goto -1bh
.end method

.method protected setSoftInputStr(Ljava/lang/String;)V
    .registers 3
    new-instance v0, Lcom/unity3d/player/UnityPlayer$13;
    invoke-direct v0, v1, v2, Lcom/unity3d/player/UnityPlayer$13;-><init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String;)V
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected setWakeLock(Z)V
    .registers 4
    const-string v0, "project"
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->n Landroid/os/PowerManager$WakeLock;
    invoke-static v0, v1, v3, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/String; Landroid/os/PowerManager$WakeLock; Z)V
    return-void
.end method

.method protected showSoftInput(Ljava/lang/String; I Z Z Z Z Ljava/lang/String;)V
    .registers 18
    new-instance v0, Lcom/unity3d/player/UnityPlayer$10;
    move-object v1, v10
    move-object v2, v10
    move-object v3, v11
    move v4, v12
    move v5, v13
    move v6, v14
    move v7, v15
    move/from16 v8, v16
    move-object/from16 v9, v17
    invoke-direct/range v0 ... v9, Lcom/unity3d/player/UnityPlayer$10;-><init>(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I Z Z Z Z Ljava/lang/String;)V
    invoke-direct v10, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected showVideoPlayer(Ljava/lang/String; I I I Z I I)V
    .registers 17
    new-instance v0, Lcom/unity3d/player/UnityPlayer$16;
    move-object v1, v9
    move-object v2, v10
    move v3, v11
    move v4, v12
    move v5, v13
    move v6, v14
    move v7, v15
    move/from16 v8, v16
    invoke-direct/range v0 ... v8, Lcom/unity3d/player/UnityPlayer$16;-><init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I I I Z I I)V
    invoke-direct v9, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected startActivityIndicator()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->H Ljava/lang/Runnable;
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected stopActivityIndicator()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer;->I Ljava/lang/Runnable;
    invoke-direct v1, v0, Lcom/unity3d/player/UnityPlayer;->b(Ljava/lang/Runnable;)V
    return-void
.end method

.method protected vibrate(I)V
    .registers 5
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    if-nez v0, +00eh
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "vibrator"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/os/Vibrator;
    iput-object v0, v3, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    if-nez v4, +008h
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    invoke-virtual v0, Landroid/os/Vibrator;->cancel()V
    return-void
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    int-to-long v1, v4
    invoke-virtual v0, v1, v2, Landroid/os/Vibrator;->vibrate(J)V
    goto -7h
    move-exception v0
    const/4 v0, 5
    const-string v1, "android.permission.VIBRATE not available?"
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -fh
.end method

.method protected vibrationSupported()Z
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    if-nez v0, +00eh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->j Landroid/content/ContextWrapper;
    const-string v1, "vibrator"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/os/Vibrator;
    iput-object v0, v2, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +00bh
    sget-object v0, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer;->t Landroid/os/Vibrator;
    invoke-interface v0, v1, Lcom/unity3d/player/j;->a(Landroid/os/Vibrator;)Z
    move-result v0
    return v0
    const/4 v0, 1
    goto -2h
.end method

.method public windowFocusChanged(Z)V
    .registers 4
    const/4 v1, 1
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, v3, Lcom/unity3d/player/x;->a(Z)V
    if-eqz v3, +00bh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    if-eqz v0, +007h
    const-string v0, ""
    invoke-virtual v2, v0, v1, v1, Lcom/unity3d/player/UnityPlayer;->reportSoftInputStr(Ljava/lang/String; I Z)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->g Lcom/unity3d/player/x;
    invoke-virtual v0, Lcom/unity3d/player/x;->h()Z
    move-result v0
    if-eqz v0, +00ch
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer;->l Lcom/unity3d/player/UnityGL;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$27;
    invoke-direct v1, v2, v3, Lcom/unity3d/player/UnityPlayer$27;-><init>(Lcom/unity3d/player/UnityPlayer; Z)V
    invoke-interface v0, v1, Lcom/unity3d/player/UnityGL;->queueEvent(Ljava/lang/Runnable;)V
    invoke-direct v2, Lcom/unity3d/player/UnityPlayer;->g()V
    return-void
.end method
