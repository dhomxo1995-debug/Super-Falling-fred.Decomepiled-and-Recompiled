.class abstract Lcom/unity3d/player/c;
.super Ljava/lang/Object;
.implements Landroid/view/SurfaceHolder$Callback;

.field private final a:Landroid/app/Activity;
.field private final b:I
.field private c:Landroid/view/SurfaceView;

.method constructor <init>(I)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    sget-object v0, Lcom/unity3d/player/t;->a Lcom/unity3d/player/t;
    invoke-virtual v0, Lcom/unity3d/player/t;->a()Landroid/content/Context;
    move-result-object v0
    check-cast v0, Landroid/app/Activity;
    iput-object v0, v1, Lcom/unity3d/player/c;->a Landroid/app/Activity;
    const/4 v0, 3
    iput v0, v1, Lcom/unity3d/player/c;->b I
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/c;->c Landroid/view/SurfaceView;
    return-object v0
.end method

.method static synthetic a(Lcom/unity3d/player/c; Landroid/view/SurfaceView;)Landroid/view/SurfaceView;
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/c;->c Landroid/view/SurfaceView;
    return-object v1
.end method

.method static synthetic b(Lcom/unity3d/player/c;)I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/c;->b I
    return v0
.end method

.method final a()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/c;->a Landroid/app/Activity;
    new-instance v1, Lcom/unity3d/player/c$1;
    invoke-direct v1, v2, Lcom/unity3d/player/c$1;-><init>(Lcom/unity3d/player/c;)V
    invoke-virtual v0, v1, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method

.method final b()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/c;->a Landroid/app/Activity;
    new-instance v1, Lcom/unity3d/player/c$2;
    invoke-direct v1, v2, Lcom/unity3d/player/c$2;-><init>(Lcom/unity3d/player/c;)V
    invoke-virtual v0, v1, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder; I I I)V
    .registers 5
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .registers 2
    return-void
.end method
