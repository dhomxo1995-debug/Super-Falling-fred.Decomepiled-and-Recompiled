.class final Lcom/unity3d/player/w$a;
.super Ljava/lang/Object;
.implements Landroid/opengl/GLSurfaceView$EGLContextFactory;


.method private constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method synthetic constructor <init>(B)V
    .registers 2
    invoke-direct v0, Lcom/unity3d/player/w$a;-><init>()V
    return-void
.end method

.method public final createContext(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLContext;
    .registers 9
    const/4 v1, 2
    const/4 v2, 1
    new-instance v3, Lcom/unity3d/player/u;
    invoke-direct v3, v6, v7, v8, Lcom/unity3d/player/u;-><init>(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig;)V
    new-instance v4, Ljava/lang/StringBuilder;
    const-string v0, "Creating OpenGL ES "
    invoke-direct v4, v0, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-static Lcom/unity3d/player/w;->c()Z
    move-result v0
    if-eqz v0, +049h
    const-string v0, "2.0"
    invoke-virtual v4, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v4, " context ("
    invoke-virtual v0, v4, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v3, Lcom/unity3d/player/u;->a()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v0, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v3, ")"
    invoke-virtual v0, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Lcom/unity3d/player/w;->a(Ljava/lang/String;)V
    const-string v0, "Before eglCreateContext"
    invoke-static v0, v6, Lcom/unity3d/player/w;->a(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    const/4 v0, 3
    new-array v3, v0, [I
    const/4 v0, 0
    const/16 v4, 12440
    aput v4, v3, v0
    invoke-static Lcom/unity3d/player/w;->c()Z
    move-result v0
    if-eqz v0, +018h
    move v0, v1
    aput v0, v3, v2
    const/16 v0, 12344
    aput v0, v3, v1
    sget-object v0, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT Ljavax/microedition/khronos/egl/EGLContext;
    invoke-interface v6, v7, v8, v0, v3, Ljavax/microedition/khronos/egl/EGL10;->eglCreateContext(Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig; Ljavax/microedition/khronos/egl/EGLContext; [I)Ljavax/microedition/khronos/egl/EGLContext;
    move-result-object v0
    const-string v1, "After eglCreateContext"
    invoke-static v1, v6, Lcom/unity3d/player/w;->a(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    return-object v0
    const-string v0, "1.x"
    goto -47h
    move v0, v2
    goto -16h
.end method

.method public final destroyContext(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLContext;)V
    .registers 4
    invoke-interface v1, v2, v3, Ljavax/microedition/khronos/egl/EGL10;->eglDestroyContext(Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLContext;)Z
    return-void
.end method
