.class final Lcom/unity3d/player/UnityPlayer$25;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/util/concurrent/Semaphore;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Ljava/util/concurrent/Semaphore;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$25;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$25;->a Ljava/util/concurrent/Semaphore;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$25;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->c(Lcom/unity3d/player/UnityPlayer;)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$25;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->d(Lcom/unity3d/player/UnityPlayer;)Z
    move-result v0
    if-eqz v0, +00eh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$25;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->b(Lcom/unity3d/player/UnityPlayer;)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$25;->a Ljava/util/concurrent/Semaphore;
    const/4 v1, 2
    invoke-virtual v0, v1, Ljava/util/concurrent/Semaphore;->release(I)V
    return-void
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$25;->a Ljava/util/concurrent/Semaphore;
    invoke-virtual v0, Ljava/util/concurrent/Semaphore;->release()V
    goto -6h
.end method
