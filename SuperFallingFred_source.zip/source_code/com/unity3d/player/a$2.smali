.class final Lcom/unity3d/player/a$2;
.super Lcom/unity3d/player/c;

.field private a:Landroid/hardware/Camera;
.field private synthetic b:Lcom/unity3d/player/a;

.method constructor <init>(Lcom/unity3d/player/a;)V
    .registers 3
    iput-object v2, v1, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    const/4 v0, 3
    invoke-direct v1, v0, Lcom/unity3d/player/c;-><init>(I)V
    iget-object v0, v1, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iput-object v0, v1, Lcom/unity3d/player/a$2;->a Landroid/hardware/Camera;
    return-void
.end method

.method public final surfaceCreated(Landroid/view/SurfaceHolder;)V
    .registers 7
    iget-object v0, v5, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    invoke-static v0, Lcom/unity3d/player/a;->a(Lcom/unity3d/player/a;)[Ljava/lang/Object;
    move-result-object v1
    monitor-enter v1
    iget-object v0, v5, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v2, v5, Lcom/unity3d/player/a$2;->a Landroid/hardware/Camera;
    if-eq v0, v2, +004h
    monitor-exit v1
    return-void
    iget-object v0, v5, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, v6, Landroid/hardware/Camera;->setPreviewDisplay(Landroid/view/SurfaceHolder;)V
    iget-object v0, v5, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, Landroid/hardware/Camera;->startPreview()V
    monitor-exit v1
    goto -10h
    move-exception v0
    monitor-exit v1
    throw v0
    move-exception v0
    const/4 v2, 6
    new-instance v3, Ljava/lang/StringBuilder;
    const-string v4, "Unable to initialize webcam data stream: "
    invoke-direct v3, v4, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v0, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v3, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -1dh
.end method

.method public final surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .registers 5
    iget-object v0, v3, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    invoke-static v0, Lcom/unity3d/player/a;->a(Lcom/unity3d/player/a;)[Ljava/lang/Object;
    move-result-object v1
    monitor-enter v1
    iget-object v0, v3, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v2, v3, Lcom/unity3d/player/a$2;->a Landroid/hardware/Camera;
    if-eq v0, v2, +004h
    monitor-exit v1
    return-void
    iget-object v0, v3, Lcom/unity3d/player/a$2;->b Lcom/unity3d/player/a;
    iget-object v0, v0, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, Landroid/hardware/Camera;->stopPreview()V
    monitor-exit v1
    goto -9h
    move-exception v0
    monitor-exit v1
    throw v0
.end method
