.class final Lcom/unity3d/player/UnityPlayer$9;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Z
.field private synthetic b:Z
.field private synthetic c:Landroid/view/SurfaceView;
.field private synthetic d:I
.field private synthetic e:I
.field private synthetic f:Z

.method constructor <init>(Z Z Landroid/view/SurfaceView; I I Z)V
    .registers 7
    iput-boolean v1, v0, Lcom/unity3d/player/UnityPlayer$9;->a Z
    iput-boolean v2, v0, Lcom/unity3d/player/UnityPlayer$9;->b Z
    iput-object v3, v0, Lcom/unity3d/player/UnityPlayer$9;->c Landroid/view/SurfaceView;
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$9;->d I
    iput v5, v0, Lcom/unity3d/player/UnityPlayer$9;->e I
    iput-boolean v6, v0, Lcom/unity3d/player/UnityPlayer$9;->f Z
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    iget-boolean v0, v3, Lcom/unity3d/player/UnityPlayer$9;->a Z
    if-nez v0, +014h
    iget-boolean v0, v3, Lcom/unity3d/player/UnityPlayer$9;->b Z
    if-eqz v0, +01eh
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$9;->c Landroid/view/SurfaceView;
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    invoke-interface v0, Landroid/view/SurfaceHolder;->setSizeFromLayout()V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$9;->c Landroid/view/SurfaceView;
    invoke-virtual v0, Landroid/view/SurfaceView;->invalidate()V
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +00bh
    sget-object v0, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    iget-object v1, v3, Lcom/unity3d/player/UnityPlayer$9;->c Landroid/view/SurfaceView;
    iget-boolean v2, v3, Lcom/unity3d/player/UnityPlayer$9;->f Z
    invoke-interface v0, v1, v2, Lcom/unity3d/player/j;->a(Landroid/view/View; Z)V
    return-void
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$9;->c Landroid/view/SurfaceView;
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    iget v1, v3, Lcom/unity3d/player/UnityPlayer$9;->d I
    iget v2, v3, Lcom/unity3d/player/UnityPlayer$9;->e I
    invoke-interface v0, v1, v2, Landroid/view/SurfaceHolder;->setFixedSize(I I)V
    goto -20h
.end method
