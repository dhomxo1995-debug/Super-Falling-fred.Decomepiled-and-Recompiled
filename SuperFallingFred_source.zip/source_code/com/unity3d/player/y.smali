.class public final Lcom/unity3d/player/y;
.super Landroid/widget/FrameLayout;
.implements Landroid/hardware/SensorEventListener;
.implements Landroid/media/MediaPlayer$OnBufferingUpdateListener;
.implements Landroid/media/MediaPlayer$OnCompletionListener;
.implements Landroid/media/MediaPlayer$OnPreparedListener;
.implements Landroid/media/MediaPlayer$OnVideoSizeChangedListener;
.implements Landroid/view/SurfaceHolder$Callback;
.implements Landroid/widget/MediaController$MediaPlayerControl;

.field private final a:Lcom/unity3d/player/UnityPlayer;
.field private final b:Landroid/content/Context;
.field private final c:Landroid/view/SurfaceView;
.field private final d:Landroid/view/SurfaceHolder;
.field private final e:Ljava/lang/String;
.field private final f:I
.field private final g:I
.field private final h:Z
.field private final i:J
.field private final j:J
.field private final k:Landroid/widget/FrameLayout;
.field private final l:Landroid/hardware/SensorManager;
.field private final m:Landroid/view/WindowManager;
.field private n:I
.field private o:I
.field private p:I
.field private q:I
.field private r:Landroid/media/MediaPlayer;
.field private s:Landroid/widget/MediaController;
.field private t:Z
.field private u:Z
.field private v:I
.field private w:Z
.field private x:I
.field private y:Z

.method protected constructor <init>(Lcom/unity3d/player/UnityPlayer; Landroid/content/Context; Ljava/lang/String; I I I Z J J)V
    .registers 15
    const/4 v2, 1
    const/4 v0, 0
    invoke-direct v3, v5, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    iput-boolean v0, v3, Lcom/unity3d/player/y;->t Z
    iput-boolean v0, v3, Lcom/unity3d/player/y;->u Z
    iput v0, v3, Lcom/unity3d/player/y;->v I
    iput-boolean v0, v3, Lcom/unity3d/player/y;->w Z
    iput v0, v3, Lcom/unity3d/player/y;->x I
    iput-object v4, v3, Lcom/unity3d/player/y;->a Lcom/unity3d/player/UnityPlayer;
    iput-object v5, v3, Lcom/unity3d/player/y;->b Landroid/content/Context;
    iput-object v3, v3, Lcom/unity3d/player/y;->k Landroid/widget/FrameLayout;
    new-instance v0, Landroid/view/SurfaceView;
    invoke-direct v0, v5, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V
    iput-object v0, v3, Lcom/unity3d/player/y;->c Landroid/view/SurfaceView;
    iget-object v0, v3, Lcom/unity3d/player/y;->c Landroid/view/SurfaceView;
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    iput-object v0, v3, Lcom/unity3d/player/y;->d Landroid/view/SurfaceHolder;
    iget-object v0, v3, Lcom/unity3d/player/y;->d Landroid/view/SurfaceHolder;
    invoke-interface v0, v3, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V
    iget-object v0, v3, Lcom/unity3d/player/y;->d Landroid/view/SurfaceHolder;
    const/4 v1, 3
    invoke-interface v0, v1, Landroid/view/SurfaceHolder;->setType(I)V
    iget-object v0, v3, Lcom/unity3d/player/y;->k Landroid/widget/FrameLayout;
    invoke-virtual v0, v7, Landroid/widget/FrameLayout;->setBackgroundColor(I)V
    iget-object v0, v3, Lcom/unity3d/player/y;->k Landroid/widget/FrameLayout;
    iget-object v1, v3, Lcom/unity3d/player/y;->c Landroid/view/SurfaceView;
    invoke-virtual v0, v1, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V
    iget-object v0, v3, Lcom/unity3d/player/y;->b Landroid/content/Context;
    const-string v1, "sensor"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/hardware/SensorManager;
    iput-object v0, v3, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    iget-object v0, v3, Lcom/unity3d/player/y;->b Landroid/content/Context;
    const-string v1, "window"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/WindowManager;
    iput-object v0, v3, Lcom/unity3d/player/y;->m Landroid/view/WindowManager;
    iput-object v6, v3, Lcom/unity3d/player/y;->e Ljava/lang/String;
    iput v8, v3, Lcom/unity3d/player/y;->f I
    iput v9, v3, Lcom/unity3d/player/y;->g I
    iput-boolean v10, v3, Lcom/unity3d/player/y;->h Z
    iput-wide v11, v3, Lcom/unity3d/player/y;->i J
    iput-wide v13, v3, Lcom/unity3d/player/y;->j J
    invoke-virtual v3, v2, Lcom/unity3d/player/y;->setFocusable(Z)V
    invoke-virtual v3, v2, Lcom/unity3d/player/y;->setFocusableInTouchMode(Z)V
    iget-object v0, v3, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    iget-object v1, v3, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    invoke-virtual v1, v2, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v1
    invoke-virtual v0, v3, v1, v2, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    iput-boolean v2, v3, Lcom/unity3d/player/y;->y Z
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/y;)Lcom/unity3d/player/UnityPlayer;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y;->a Lcom/unity3d/player/UnityPlayer;
    return-object v0
.end method

.method private a()V
    .registers 9
    const/4 v7, 1
    invoke-virtual v8, Lcom/unity3d/player/y;->doCleanUp()V
    new-instance v0, Landroid/media/MediaPlayer;
    invoke-direct v0, Landroid/media/MediaPlayer;-><init>()V
    iput-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    iget-boolean v0, v8, Lcom/unity3d/player/y;->h Z
    if-eqz v0, +05eh
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    iget-object v1, v8, Lcom/unity3d/player/y;->b Landroid/content/Context;
    iget-object v2, v8, Lcom/unity3d/player/y;->e Ljava/lang/String;
    invoke-static v2, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    move-result-object v2
    invoke-virtual v0, v1, v2, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context; Landroid/net/Uri;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    iget-object v1, v8, Lcom/unity3d/player/y;->d Landroid/view/SurfaceHolder;
    invoke-virtual v0, v1, Landroid/media/MediaPlayer;->setDisplay(Landroid/view/SurfaceHolder;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, v8, Landroid/media/MediaPlayer;->setOnBufferingUpdateListener(Landroid/media/MediaPlayer$OnBufferingUpdateListener;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, v8, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, v8, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, v8, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    const/4 v1, 3
    invoke-virtual v0, v1, Landroid/media/MediaPlayer;->setAudioStreamType(I)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->prepare()V
    iget v0, v8, Lcom/unity3d/player/y;->f I
    if-eqz v0, +006h
    iget v0, v8, Lcom/unity3d/player/y;->f I
    if-ne v0, v7, +022h
    new-instance v0, Landroid/widget/MediaController;
    iget-object v1, v8, Lcom/unity3d/player/y;->b Landroid/content/Context;
    invoke-direct v0, v1, Landroid/widget/MediaController;-><init>(Landroid/content/Context;)V
    iput-object v0, v8, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    iget-object v0, v8, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    invoke-virtual v0, v8, Landroid/widget/MediaController;->setMediaPlayer(Landroid/widget/MediaController$MediaPlayerControl;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    iget-object v1, v8, Lcom/unity3d/player/y;->c Landroid/view/SurfaceView;
    invoke-virtual v0, v1, Landroid/widget/MediaController;->setAnchorView(Landroid/view/View;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    const/4 v1, 1
    invoke-virtual v0, v1, Landroid/widget/MediaController;->setEnabled(Z)V
    iget-object v0, v8, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    invoke-virtual v0, Landroid/widget/MediaController;->show()V
    return-void
    iget-wide v0, v8, Lcom/unity3d/player/y;->j J
    const-wide/16 v2, 0
    cmp-long v0, v0, v2
    if-eqz v0, +01fh
    new-instance v6, Ljava/io/FileInputStream;
    iget-object v0, v8, Lcom/unity3d/player/y;->e Ljava/lang/String;
    invoke-direct v6, v0, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v6, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;
    move-result-object v1
    iget-wide v2, v8, Lcom/unity3d/player/y;->i J
    iget-wide v4, v8, Lcom/unity3d/player/y;->j J
    invoke-virtual/range v0 ... v5, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor; J J)V
    invoke-virtual v6, Ljava/io/FileInputStream;->close()V
    goto -6eh
    move-exception v0
    invoke-virtual v8, Lcom/unity3d/player/y;->onDestroy()V
    goto -25h
    invoke-virtual v8, Lcom/unity3d/player/y;->getResources()Landroid/content/res/Resources;
    move-result-object v0
    invoke-virtual v0, Landroid/content/res/Resources;->getAssets()Landroid/content/res/AssetManager;
    move-result-object v0
    iget-object v1, v8, Lcom/unity3d/player/y;->e Ljava/lang/String;
    invoke-virtual v0, v1, Landroid/content/res/AssetManager;->openFd(Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;
    move-result-object v6
    iget-object v0, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v6, Landroid/content/res/AssetFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;
    move-result-object v1
    invoke-virtual v6, Landroid/content/res/AssetFileDescriptor;->getStartOffset()J
    move-result-wide v2
    invoke-virtual v6, Landroid/content/res/AssetFileDescriptor;->getLength()J
    move-result-wide v4
    invoke-virtual/range v0 ... v5, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor; J J)V
    invoke-virtual v6, Landroid/content/res/AssetFileDescriptor;->close()V
    goto/16 -096h
    move-exception v0
    new-instance v0, Ljava/io/FileInputStream;
    iget-object v1, v8, Lcom/unity3d/player/y;->e Ljava/lang/String;
    invoke-direct v0, v1, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    iget-object v1, v8, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;
    move-result-object v2
    invoke-virtual v1, v2, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V
    invoke-virtual v0, Ljava/io/FileInputStream;->close()V
    goto/16 -0ach
.end method

.method private b()V
    .registers 2
    invoke-virtual v1, Lcom/unity3d/player/y;->isPlaying()Z
    move-result v0
    if-eqz v0, +003h
    return-void
    invoke-virtual v1, Lcom/unity3d/player/y;->updateVideoLayout()V
    iget-boolean v0, v1, Lcom/unity3d/player/y;->w Z
    if-nez v0, -006h
    invoke-virtual v1, Lcom/unity3d/player/y;->start()V
    goto -bh
.end method

.method public final canPause()Z
    .registers 2
    const/4 v0, 1
    return v0
.end method

.method public final canSeekBackward()Z
    .registers 2
    const/4 v0, 1
    return v0
.end method

.method public final canSeekForward()Z
    .registers 2
    const/4 v0, 1
    return v0
.end method

.method protected final doCleanUp()V
    .registers 3
    const/4 v1, 0
    iget-object v0, v2, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-eqz v0, +00ah
    iget-object v0, v2, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->release()V
    const/4 v0, 0
    iput-object v0, v2, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    iput v1, v2, Lcom/unity3d/player/y;->p I
    iput v1, v2, Lcom/unity3d/player/y;->q I
    iput-boolean v1, v2, Lcom/unity3d/player/y;->u Z
    iput-boolean v1, v2, Lcom/unity3d/player/y;->t Z
    return-void
.end method

.method public final getBufferPercentage()I
    .registers 2
    iget-boolean v0, v1, Lcom/unity3d/player/y;->h Z
    if-eqz v0, +005h
    iget v0, v1, Lcom/unity3d/player/y;->v I
    return v0
    const/16 v0, 100
    goto -3h
.end method

.method public final getCurrentPosition()I
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->getCurrentPosition()I
    move-result v0
    goto -7h
.end method

.method public final getDuration()I
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v0, +004h
    const/4 v0, 0
    return v0
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->getDuration()I
    move-result v0
    goto -7h
.end method

.method public final isPlaying()Z
    .registers 5
    const/4 v1, 1
    const/4 v2, 0
    iget-boolean v0, v4, Lcom/unity3d/player/y;->u Z
    if-eqz v0, +00eh
    iget-boolean v0, v4, Lcom/unity3d/player/y;->t Z
    if-eqz v0, +00ah
    move v0, v1
    iget-object v3, v4, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v3, +009h
    if-nez v0, +005h
    return v1
    move v0, v2
    goto -8h
    move v1, v2
    goto -4h
    iget-object v3, v4, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v3, Landroid/media/MediaPlayer;->isPlaying()Z
    move-result v3
    if-nez v3, -00bh
    if-eqz v0, -00dh
    move v1, v2
    goto -10h
.end method

.method public final onAccuracyChanged(Landroid/hardware/Sensor; I)V
    .registers 3
    return-void
.end method

.method public final onBufferingUpdate(Landroid/media/MediaPlayer; I)V
    .registers 3
    iput v2, v0, Lcom/unity3d/player/y;->v I
    return-void
.end method

.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .registers 2
    invoke-virtual v0, Lcom/unity3d/player/y;->onDestroy()V
    return-void
.end method

.method protected final onDestroy()V
    .registers 2
    invoke-virtual v1, Lcom/unity3d/player/y;->onPause()V
    invoke-virtual v1, Lcom/unity3d/player/y;->doCleanUp()V
    iget-object v0, v1, Lcom/unity3d/player/y;->a Lcom/unity3d/player/UnityPlayer;
    new-instance v0, Lcom/unity3d/player/y$1;
    invoke-direct v0, v1, Lcom/unity3d/player/y$1;-><init>(Lcom/unity3d/player/y;)V
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->a(Ljava/lang/Runnable;)V
    return-void
.end method

.method public final onKeyDown(I Landroid/view/KeyEvent;)Z
    .registers 5
    const/4 v0, 4
    if-eq v3, v0, +00fh
    iget v0, v2, Lcom/unity3d/player/y;->f I
    const/4 v1, 2
    if-ne v0, v1, +00fh
    if-eqz v3, +00dh
    invoke-virtual v4, Landroid/view/KeyEvent;->isSystem()Z
    move-result v0
    if-nez v0, +007h
    invoke-virtual v2, Lcom/unity3d/player/y;->onDestroy()V
    const/4 v0, 1
    return v0
    iget-object v0, v2, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    if-eqz v0, +009h
    iget-object v0, v2, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    invoke-virtual v0, v3, v4, Landroid/widget/MediaController;->onKeyDown(I Landroid/view/KeyEvent;)Z
    move-result v0
    goto -bh
    invoke-super v2, v3, v4, Landroid/widget/FrameLayout;->onKeyDown(I Landroid/view/KeyEvent;)Z
    move-result v0
    goto -10h
.end method

.method protected final onPause()V
    .registers 3
    const/4 v1, 0
    iget-object v0, v2, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    invoke-virtual v0, v2, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V
    iget-boolean v0, v2, Lcom/unity3d/player/y;->w Z
    if-nez v0, +007h
    invoke-virtual v2, Lcom/unity3d/player/y;->pause()V
    iput-boolean v1, v2, Lcom/unity3d/player/y;->w Z
    iget-object v0, v2, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-eqz v0, +00ah
    iget-object v0, v2, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->getCurrentPosition()I
    move-result v0
    iput v0, v2, Lcom/unity3d/player/y;->x I
    iput-boolean v1, v2, Lcom/unity3d/player/y;->y Z
    return-void
.end method

.method public final onPrepared(Landroid/media/MediaPlayer;)V
    .registers 3
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/y;->u Z
    iget-boolean v0, v1, Lcom/unity3d/player/y;->u Z
    if-eqz v0, +009h
    iget-boolean v0, v1, Lcom/unity3d/player/y;->t Z
    if-eqz v0, +005h
    invoke-direct v1, Lcom/unity3d/player/y;->b()V
    return-void
.end method

.method protected final onResume()V
    .registers 4
    const/4 v2, 1
    iget-boolean v0, v3, Lcom/unity3d/player/y;->y Z
    if-nez v0, +014h
    iget-object v0, v3, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    iget-object v1, v3, Lcom/unity3d/player/y;->l Landroid/hardware/SensorManager;
    invoke-virtual v1, v2, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;
    move-result-object v1
    invoke-virtual v0, v3, v1, v2, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener; Landroid/hardware/Sensor; I)Z
    iget-boolean v0, v3, Lcom/unity3d/player/y;->w Z
    if-nez v0, +005h
    invoke-virtual v3, Lcom/unity3d/player/y;->start()V
    iput-boolean v2, v3, Lcom/unity3d/player/y;->y Z
    return-void
.end method

.method public final onSensorChanged(Landroid/hardware/SensorEvent;)V
    .registers 4
    iget-object v0, v3, Landroid/hardware/SensorEvent;->sensor Landroid/hardware/Sensor;
    invoke-virtual v0, Landroid/hardware/Sensor;->getType()I
    move-result v0
    const/4 v1, 1
    if-ne v0, v1, +01bh
    iget-object v0, v2, Lcom/unity3d/player/y;->m Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getOrientation()I
    move-result v0
    iget-object v1, v2, Lcom/unity3d/player/y;->a Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v1, Lcom/unity3d/player/UnityPlayer;->getOrientation()I
    move-result v1
    invoke-static v3, v0, v1, Lcom/unity3d/player/r;->a(Landroid/hardware/SensorEvent; I I)I
    move-result v0
    iget-object v1, v2, Lcom/unity3d/player/y;->a Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v1, v0, Lcom/unity3d/player/UnityPlayer;->nativeDeviceOrientation(I)V
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 5
    invoke-virtual v4, Landroid/view/MotionEvent;->getAction()I
    move-result v0
    and-int/lit16 v0, v0, 255
    iget v1, v3, Lcom/unity3d/player/y;->f I
    const/4 v2, 2
    if-ne v1, v2, +009h
    if-nez v0, +007h
    invoke-virtual v3, Lcom/unity3d/player/y;->onDestroy()V
    const/4 v0, 1
    return v0
    iget-object v0, v3, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    if-eqz v0, +009h
    iget-object v0, v3, Lcom/unity3d/player/y;->s Landroid/widget/MediaController;
    invoke-virtual v0, v4, Landroid/widget/MediaController;->onTouchEvent(Landroid/view/MotionEvent;)Z
    move-result v0
    goto -bh
    invoke-super v3, v4, Landroid/widget/FrameLayout;->onTouchEvent(Landroid/view/MotionEvent;)Z
    move-result v0
    goto -10h
.end method

.method public final onVideoSizeChanged(Landroid/media/MediaPlayer; I I)V
    .registers 5
    if-eqz v3, +004h
    if-nez v4, +003h
    return-void
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/y;->t Z
    iput v3, v1, Lcom/unity3d/player/y;->p I
    iput v4, v1, Lcom/unity3d/player/y;->q I
    iget-boolean v0, v1, Lcom/unity3d/player/y;->u Z
    if-eqz v0, -00ah
    iget-boolean v0, v1, Lcom/unity3d/player/y;->t Z
    if-eqz v0, -00eh
    invoke-direct v1, Lcom/unity3d/player/y;->b()V
    goto -13h
.end method

.method public final pause()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v0, +003h
    return-void
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->pause()V
    const/4 v0, 1
    iput-boolean v0, v1, Lcom/unity3d/player/y;->w Z
    goto -9h
.end method

.method public final seekTo(I)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v0, +003h
    return-void
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, v2, Landroid/media/MediaPlayer;->seekTo(I)V
    goto -6h
.end method

.method public final start()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    if-nez v0, +003h
    return-void
    iget-object v0, v1, Lcom/unity3d/player/y;->r Landroid/media/MediaPlayer;
    invoke-virtual v0, Landroid/media/MediaPlayer;->start()V
    const/4 v0, 0
    iput-boolean v0, v1, Lcom/unity3d/player/y;->w Z
    goto -9h
.end method

.method public final surfaceChanged(Landroid/view/SurfaceHolder; I I I)V
    .registers 5
    iput v3, v0, Lcom/unity3d/player/y;->n I
    iput v4, v0, Lcom/unity3d/player/y;->o I
    return-void
.end method

.method public final surfaceCreated(Landroid/view/SurfaceHolder;)V
    .registers 3
    invoke-direct v1, Lcom/unity3d/player/y;->a()V
    iget v0, v1, Lcom/unity3d/player/y;->x I
    invoke-virtual v1, v0, Lcom/unity3d/player/y;->seekTo(I)V
    return-void
.end method

.method public final surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .registers 2
    invoke-virtual v0, Lcom/unity3d/player/y;->doCleanUp()V
    return-void
.end method

.method protected final updateVideoLayout()V
    .registers 6
    iget-object v0, v5, Lcom/unity3d/player/y;->b Landroid/content/Context;
    const-string v1, "window"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/WindowManager;
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v1
    invoke-virtual v1, Landroid/view/Display;->getWidth()I
    move-result v1
    iput v1, v5, Lcom/unity3d/player/y;->n I
    invoke-interface v0, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    move-result-object v0
    invoke-virtual v0, Landroid/view/Display;->getHeight()I
    move-result v0
    iput v0, v5, Lcom/unity3d/player/y;->o I
    iget v1, v5, Lcom/unity3d/player/y;->n I
    iget v0, v5, Lcom/unity3d/player/y;->o I
    iget v2, v5, Lcom/unity3d/player/y;->g I
    const/4 v3, 1
    if-eq v2, v3, +007h
    iget v2, v5, Lcom/unity3d/player/y;->g I
    const/4 v3, 2
    if-ne v2, v3, +02eh
    iget v2, v5, Lcom/unity3d/player/y;->p I
    int-to-float v2, v2
    iget v3, v5, Lcom/unity3d/player/y;->q I
    int-to-float v3, v3
    div-float/2addr v2, v3
    iget v3, v5, Lcom/unity3d/player/y;->n I
    int-to-float v3, v3
    iget v4, v5, Lcom/unity3d/player/y;->o I
    int-to-float v4, v4
    div-float/2addr v3, v4
    cmpg-float v3, v3, v2
    if-gtz v3, +016h
    iget v0, v5, Lcom/unity3d/player/y;->n I
    int-to-float v0, v0
    div-float/2addr v0, v2
    float-to-int v0, v0
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;
    const/16 v3, 17
    invoke-direct v2, v1, v0, v3, Landroid/widget/FrameLayout$LayoutParams;-><init>(I I I)V
    iget-object v0, v5, Lcom/unity3d/player/y;->k Landroid/widget/FrameLayout;
    iget-object v1, v5, Lcom/unity3d/player/y;->c Landroid/view/SurfaceView;
    invoke-virtual v0, v1, v2, Landroid/widget/FrameLayout;->updateViewLayout(Landroid/view/View; Landroid/view/ViewGroup$LayoutParams;)V
    return-void
    iget v1, v5, Lcom/unity3d/player/y;->o I
    int-to-float v1, v1
    mul-float/2addr v1, v2
    float-to-int v1, v1
    goto -14h
    iget v2, v5, Lcom/unity3d/player/y;->g I
    if-nez v2, -017h
    iget v1, v5, Lcom/unity3d/player/y;->p I
    iget v0, v5, Lcom/unity3d/player/y;->q I
    goto -1dh
.end method
