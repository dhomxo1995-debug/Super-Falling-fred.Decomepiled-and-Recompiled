.class final Lcom/unity3d/player/r$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/r;

.method constructor <init>(Lcom/unity3d/player/r;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 7
    iget-object v0, v6, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-static v0, Lcom/unity3d/player/r;->e(Lcom/unity3d/player/r;)Lcom/unity3d/player/UnityPlayer;
    move-result-object v0
    iget-object v1, v6, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-static v1, Lcom/unity3d/player/r;->a(Lcom/unity3d/player/r;)F
    move-result v1
    iget-object v2, v6, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-static v2, Lcom/unity3d/player/r;->b(Lcom/unity3d/player/r;)F
    move-result v2
    iget-object v3, v6, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-static v3, Lcom/unity3d/player/r;->c(Lcom/unity3d/player/r;)F
    move-result v3
    iget-object v4, v6, Lcom/unity3d/player/r$1;->a Lcom/unity3d/player/r;
    invoke-static v4, Lcom/unity3d/player/r;->d(Lcom/unity3d/player/r;)J
    move-result-wide v4
    invoke-virtual/range v0 ... v5, Lcom/unity3d/player/UnityPlayer;->nativeSensor(F F F J)V
    return-void
.end method
