.class final Lcom/unity3d/player/y$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/y;

.method constructor <init>(Lcom/unity3d/player/y;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/y$1;->a Lcom/unity3d/player/y;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/y$1;->a Lcom/unity3d/player/y;
    invoke-static v0, Lcom/unity3d/player/y;->a(Lcom/unity3d/player/y;)Lcom/unity3d/player/UnityPlayer;
    move-result-object v0
    invoke-virtual v0, Lcom/unity3d/player/UnityPlayer;->hideVideoPlayer()V
    return-void
.end method
