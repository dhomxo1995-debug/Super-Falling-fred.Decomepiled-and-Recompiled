.class final Lcom/unity3d/player/UnityPlayer$23;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:I
.field private synthetic c:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I I)V
    .registers 4
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$23;->c Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$23;->a I
    iput v3, v0, Lcom/unity3d/player/UnityPlayer$23;->b I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$23;->c Lcom/unity3d/player/UnityPlayer;
    iget v1, v3, Lcom/unity3d/player/UnityPlayer$23;->a I
    iget v2, v3, Lcom/unity3d/player/UnityPlayer$23;->b I
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I I)V
    return-void
.end method
