.class final Lcom/unity3d/player/UnityPlayer$8;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:[Lcom/unity3d/player/i$a;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; [Lcom/unity3d/player/i$a;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$8;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$8;->a [Lcom/unity3d/player/i$a;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 10
    const/4 v1, 0
    iget-object v3, v9, Lcom/unity3d/player/UnityPlayer$8;->a [Lcom/unity3d/player/i$a;
    array-length v4, v3
    move v2, v1
    if-ge v2, v4, +01eh
    aget-object v5, v3, v2
    iget v0, v5, Lcom/unity3d/player/i$a;->a I
    add-int/lit8 v6, v0, 1
    move v0, v1
    iget-object v7, v5, Lcom/unity3d/player/i$a;->b [F
    array-length v7, v7
    if-ge v0, v7, +00eh
    iget-object v7, v9, Lcom/unity3d/player/UnityPlayer$8;->b Lcom/unity3d/player/UnityPlayer;
    iget-object v8, v5, Lcom/unity3d/player/i$a;->b [F
    aget v8, v8, v0
    invoke-static v7, v6, v0, v8, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I I F)V
    add-int/lit8 v0, v0, 1
    goto -10h
    add-int/lit8 v0, v2, 1
    move v2, v0
    goto -1dh
    return-void
.end method
