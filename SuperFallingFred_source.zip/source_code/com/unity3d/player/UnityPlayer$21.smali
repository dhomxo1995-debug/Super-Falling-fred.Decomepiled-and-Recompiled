.class final Lcom/unity3d/player/UnityPlayer$21;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/lang/Runnable;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/Runnable;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$21;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$21;->a Ljava/lang/Runnable;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$21;->b Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v0, Lcom/unity3d/player/UnityPlayer;->isFinishing()Z
    move-result v0
    if-nez v0, +007h
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$21;->a Ljava/lang/Runnable;
    invoke-interface v0, Ljava/lang/Runnable;->run()V
    return-void
.end method
