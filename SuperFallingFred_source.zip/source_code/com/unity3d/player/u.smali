.class final Lcom/unity3d/player/u;
.super Ljava/lang/Object;

.field final a:Ljavax/microedition/khronos/egl/EGLConfig;
.field private b:Ljavax/microedition/khronos/egl/EGL10;
.field private c:Ljavax/microedition/khronos/egl/EGLDisplay;

.method constructor <init>(Ljavax/microedition/khronos/egl/EGL10; Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig;)V
    .registers 4
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-object v1, v0, Lcom/unity3d/player/u;->b Ljavax/microedition/khronos/egl/EGL10;
    iput-object v2, v0, Lcom/unity3d/player/u;->c Ljavax/microedition/khronos/egl/EGLDisplay;
    iput-object v3, v0, Lcom/unity3d/player/u;->a Ljavax/microedition/khronos/egl/EGLConfig;
    return-void
.end method

.method private static a(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    .registers 10
    const/4 v7, 2
    const/4 v1, 0
    move v0, v1
    if-ge v0, v7, +022h
    invoke-interface v9, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I
    move-result v2
    const/16 v3, 12288
    if-eq v2, v3, +01ah
    const/4 v3, 6
    const-string v4, "%s: EGL error: 0x%x"
    new-array v5, v7, [Ljava/lang/Object;
    aput-object v8, v5, v1
    const/4 v6, 1
    invoke-static v2, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v2
    aput-object v2, v5, v6
    invoke-static v4, v5, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v2
    invoke-static v3, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    add-int/lit8 v0, v0, 1
    goto -21h
    return-void
.end method

.method final a(I)I
    .registers 8
    const/4 v5, 1
    const/4 v0, 0
    new-array v1, v5, [I
    iget-object v2, v6, Lcom/unity3d/player/u;->b Ljavax/microedition/khronos/egl/EGL10;
    iget-object v3, v6, Lcom/unity3d/player/u;->c Ljavax/microedition/khronos/egl/EGLDisplay;
    iget-object v4, v6, Lcom/unity3d/player/u;->a Ljavax/microedition/khronos/egl/EGLConfig;
    invoke-interface v2, v3, v4, v7, v1, Ljavax/microedition/khronos/egl/EGL10;->eglGetConfigAttrib(Ljavax/microedition/khronos/egl/EGLDisplay; Ljavax/microedition/khronos/egl/EGLConfig; I [I)Z
    move-result v2
    if-eqz v2, +005h
    aget v0, v1, v0
    return v0
    iget-object v1, v6, Lcom/unity3d/player/u;->b Ljavax/microedition/khronos/egl/EGL10;
    invoke-interface v1, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I
    move-result v1
    const/16 v2, 12292
    if-eq v1, v2, +014h
    const/4 v2, 6
    const-string v3, "findConfigAttrib: EGL error: 0x%x"
    new-array v4, v5, [Ljava/lang/Object;
    invoke-static v1, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v1
    aput-object v1, v4, v0
    invoke-static v3, v4, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v1
    invoke-static v2, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    new-instance v1, Ljava/lang/StringBuilder;
    const-string v2, "findConfigAttrib ("
    invoke-direct v1, v2, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-static v7, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v2, ")"
    invoke-virtual v1, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    iget-object v2, v6, Lcom/unity3d/player/u;->b Ljavax/microedition/khronos/egl/EGL10;
    invoke-static v1, v2, Lcom/unity3d/player/u;->a(Ljava/lang/String; Ljavax/microedition/khronos/egl/EGL10;)V
    goto -3bh
.end method

.method final a()Ljava/lang/String;
    .registers 13
    const/4 v11, 2
    const/16 v0, 12320
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    const/16 v0, 12324
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v2
    const/16 v0, 12323
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v3
    const/16 v0, 12322
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v4
    const/16 v0, 12321
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v5
    const/16 v0, 12325
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v6
    const/16 v0, 12326
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v7
    const/16 v0, 12337
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v8
    const/16 v0, 12513
    invoke-virtual v12, v0, Lcom/unity3d/player/u;->a(I)I
    move-result v9
    new-instance v10, Ljava/lang/StringBuilder;
    invoke-direct v10, Ljava/lang/StringBuilder;-><init>()V
    if-nez v5, +063h
    const-string v0, "RGB"
    invoke-virtual v10, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, " "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v2, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v3, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v4, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    if-nez v5, +03ch
    const-string v0, ""
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, " "
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v6, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v1, "/"
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-static v7, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    if-ge v8, v11, +01dh
    const-string v0, ""
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    if-ge v9, v11, +029h
    const-string v0, ""
    invoke-virtual v1, v0, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
    const-string v0, "RGBA"
    goto -61h
    invoke-static v5, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v0
    goto -3ch
    new-instance v0, Ljava/lang/StringBuilder;
    const-string v2, " AAx"
    invoke-direct v0, v2, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-static v8, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    goto -2ch
    new-instance v0, Ljava/lang/StringBuilder;
    const-string v2, " CSAAx"
    invoke-direct v0, v2, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-static v9, Ljava/lang/Integer;->toString(I)Ljava/lang/String;
    move-result-object v2
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    goto -38h
.end method

.method final a(Lcom/unity3d/player/u;)Z
    .registers 7
    const/16 v1, 12324
    const/16 v4, 12323
    const/16 v3, 12322
    const/16 v2, 12321
    invoke-virtual v5, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v0
    invoke-virtual v6, v1, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    if-ne v0, v1, +022h
    invoke-virtual v5, v4, Lcom/unity3d/player/u;->a(I)I
    move-result v0
    invoke-virtual v6, v4, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    if-ne v0, v1, +018h
    invoke-virtual v5, v3, Lcom/unity3d/player/u;->a(I)I
    move-result v0
    invoke-virtual v6, v3, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    if-ne v0, v1, +00eh
    invoke-virtual v5, v2, Lcom/unity3d/player/u;->a(I)I
    move-result v0
    invoke-virtual v6, v2, Lcom/unity3d/player/u;->a(I)I
    move-result v1
    if-ne v0, v1, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public final toString()Ljava/lang/String;
    .registers 11
    const/16 v0, 35
    const/4 v9, 2
    const/4 v8, 1
    const/4 v1, 0
    new-array v2, v0, [I
    fill-array-data v2, +00000f9h
    new-array v3, v0, [Ljava/lang/String;
    const-string v0, "EGL_BUFFER_SIZE"
    aput-object v0, v3, v1
    const-string v0, "EGL_ALPHA_SIZE"
    aput-object v0, v3, v8
    const-string v0, "EGL_BLUE_SIZE"
    aput-object v0, v3, v9
    const/4 v0, 3
    const-string v4, "EGL_GREEN_SIZE"
    aput-object v4, v3, v0
    const/4 v0, 4
    const-string v4, "EGL_RED_SIZE"
    aput-object v4, v3, v0
    const/4 v0, 5
    const-string v4, "EGL_DEPTH_SIZE"
    aput-object v4, v3, v0
    const/4 v0, 6
    const-string v4, "EGL_STENCIL_SIZE"
    aput-object v4, v3, v0
    const/4 v0, 7
    const-string v4, "EGL_CONFIG_CAVEAT"
    aput-object v4, v3, v0
    const/16 v0, 8
    const-string v4, "EGL_CONFIG_ID"
    aput-object v4, v3, v0
    const/16 v0, 9
    const-string v4, "EGL_LEVEL"
    aput-object v4, v3, v0
    const/16 v0, 10
    const-string v4, "EGL_MAX_PBUFFER_HEIGHT"
    aput-object v4, v3, v0
    const/16 v0, 11
    const-string v4, "EGL_MAX_PBUFFER_PIXELS"
    aput-object v4, v3, v0
    const/16 v0, 12
    const-string v4, "EGL_MAX_PBUFFER_WIDTH"
    aput-object v4, v3, v0
    const/16 v0, 13
    const-string v4, "EGL_NATIVE_RENDERABLE"
    aput-object v4, v3, v0
    const/16 v0, 14
    const-string v4, "EGL_NATIVE_VISUAL_ID"
    aput-object v4, v3, v0
    const/16 v0, 15
    const-string v4, "EGL_NATIVE_VISUAL_TYPE"
    aput-object v4, v3, v0
    const/16 v0, 16
    const-string v4, "EGL_PRESERVED_RESOURCES"
    aput-object v4, v3, v0
    const/16 v0, 17
    const-string v4, "EGL_SAMPLES"
    aput-object v4, v3, v0
    const/16 v0, 18
    const-string v4, "EGL_SAMPLE_BUFFERS"
    aput-object v4, v3, v0
    const/16 v0, 19
    const-string v4, "EGL_SURFACE_TYPE"
    aput-object v4, v3, v0
    const/16 v0, 20
    const-string v4, "EGL_TRANSPARENT_TYPE"
    aput-object v4, v3, v0
    const/16 v0, 21
    const-string v4, "EGL_TRANSPARENT_RED_VALUE"
    aput-object v4, v3, v0
    const/16 v0, 22
    const-string v4, "EGL_TRANSPARENT_GREEN_VALUE"
    aput-object v4, v3, v0
    const/16 v0, 23
    const-string v4, "EGL_TRANSPARENT_BLUE_VALUE"
    aput-object v4, v3, v0
    const/16 v0, 24
    const-string v4, "EGL_BIND_TO_TEXTURE_RGB"
    aput-object v4, v3, v0
    const/16 v0, 25
    const-string v4, "EGL_BIND_TO_TEXTURE_RGBA"
    aput-object v4, v3, v0
    const/16 v0, 26
    const-string v4, "EGL_MIN_SWAP_INTERVAL"
    aput-object v4, v3, v0
    const/16 v0, 27
    const-string v4, "EGL_MAX_SWAP_INTERVAL"
    aput-object v4, v3, v0
    const/16 v0, 28
    const-string v4, "EGL_LUMINANCE_SIZE"
    aput-object v4, v3, v0
    const/16 v0, 29
    const-string v4, "EGL_ALPHA_MASK_SIZE"
    aput-object v4, v3, v0
    const/16 v0, 30
    const-string v4, "EGL_COLOR_BUFFER_TYPE"
    aput-object v4, v3, v0
    const/16 v0, 31
    const-string v4, "EGL_RENDERABLE_TYPE"
    aput-object v4, v3, v0
    const/16 v0, 32
    const-string v4, "EGL_CONFORMANT"
    aput-object v4, v3, v0
    const/16 v0, 33
    const-string v4, "EGL_COVERAGE_BUFFERS_NV"
    aput-object v4, v3, v0
    const/16 v0, 34
    const-string v4, "EGL_COVERAGE_SAMPLES_NV"
    aput-object v4, v3, v0
    new-instance v4, Ljava/lang/StringBuilder;
    invoke-direct v4, Ljava/lang/StringBuilder;-><init>()V
    move v0, v1
    array-length v5, v2
    if-ge v0, v5, +020h
    const-string v5, "  %s: %d
"
    new-array v6, v9, [Ljava/lang/Object;
    aget-object v7, v3, v0
    aput-object v7, v6, v1
    aget v7, v2, v0
    invoke-virtual v10, v7, Lcom/unity3d/player/u;->a(I)I
    move-result v7
    invoke-static v7, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    move-result-object v7
    aput-object v7, v6, v8
    invoke-static v5, v6, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v5
    invoke-virtual v4, v5, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    add-int/lit8 v0, v0, 1
    goto -20h
    invoke-virtual v4, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
    nop
    fill-array-data-payload b' 0\x00\x00!0\x00\x00"0\x00\x00#0\x00\x00$0\x00\x00%0\x00\x00&0\x00\x00\'0\x00\x00(0\x00\x00)0\x00\x00*0\x00\x00+0\x00\x00,0\x00\x00-0\x00\x00.0\x00\x00/0\x00\x0000\x00\x0010\x00\x0020\x00\x0030\x00\x0040\x00\x0070\x00\x0060\x00\x0050\x00\x0090\x00\x00:0\x00\x00;0\x00\x00<0\x00\x00=0\x00\x00>0\x00\x00?0\x00\x00@0\x00\x00B0\x00\x00\xe00\x00\x00\xe10\x00\x00' | \x20\x30\x00\x00\x21\x30\x00\x00\x22\x30\x00\x00\x23\x30\x00\x00\x24\x30\x00\x00\x25\x30\x00\x00\x26\x30\x00\x00\x27\x30\x00\x00\x28\x30\x00\x00\x29\x30\x00\x00\x2a\x30\x00\x00\x2b\x30\x00\x00\x2c\x30\x00\x00\x2d\x30\x00\x00\x2e\x30\x00\x00\x2f\x30\x00\x00\x30\x30\x00\x00\x31\x30\x00\x00\x32\x30\x00\x00\x33\x30\x00\x00\x34\x30\x00\x00\x37\x30\x00\x00\x36\x30\x00\x00\x35\x30\x00\x00\x39\x30\x00\x00\x3a\x30\x00\x00\x3b\x30\x00\x00\x3c\x30\x00\x00\x3d\x30\x00\x00\x3e\x30\x00\x00\x3f\x30\x00\x00\x40\x30\x00\x00\x42\x30\x00\x00\xe0\x30\x00\x00\xe1\x30\x00\x00
.end method
