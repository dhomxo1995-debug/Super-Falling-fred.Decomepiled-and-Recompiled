.class final Lcom/unity3d/player/UnityPlayer$14;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Z
.field private synthetic b:Ljava/lang/String;
.field private synthetic c:I
.field private synthetic d:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Z Ljava/lang/String; I)V
    .registers 5
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$14;->d Lcom/unity3d/player/UnityPlayer;
    iput-boolean v2, v0, Lcom/unity3d/player/UnityPlayer$14;->a Z
    iput-object v3, v0, Lcom/unity3d/player/UnityPlayer$14;->b Ljava/lang/String;
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$14;->c I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-boolean v0, v2, Lcom/unity3d/player/UnityPlayer$14;->a Z
    if-eqz v0, +019h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$14;->d Lcom/unity3d/player/UnityPlayer;
    const-string v1, ""
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String;)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$14;->d Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->m(Lcom/unity3d/player/UnityPlayer;)V
    iget v0, v2, Lcom/unity3d/player/UnityPlayer$14;->c I
    const/4 v1, 1
    if-ne v0, v1, +007h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$14;->d Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->n(Lcom/unity3d/player/UnityPlayer;)V
    return-void
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$14;->b Ljava/lang/String;
    if-eqz v0, -00dh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$14;->d Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer$14;->b Ljava/lang/String;
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String;)V
    goto -16h
.end method
