.class final Lcom/unity3d/player/UnityPlayer$13;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/lang/String;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$13;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$13;->a Ljava/lang/String;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$13;->b Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    if-eqz v0, +00fh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$13;->a Ljava/lang/String;
    if-eqz v0, +00bh
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$13;->b Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    iget-object v1, v2, Lcom/unity3d/player/UnityPlayer$13;->a Ljava/lang/String;
    invoke-virtual v0, v1, Lcom/unity3d/player/s;->a(Ljava/lang/String;)V
    return-void
.end method
