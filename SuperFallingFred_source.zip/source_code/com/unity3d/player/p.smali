.class public final Lcom/unity3d/player/p;
.super Ljava/lang/Object;

.field static final a:Z
.field static final b:Z
.field static final c:Z
.field static final d:Z
.field static final e:Z
.field static final f:Lcom/unity3d/player/f;
.field static final g:Lcom/unity3d/player/g;
.field static final h:Lcom/unity3d/player/h;
.field static final i:Lcom/unity3d/player/j;
.field static final j:Lcom/unity3d/player/i;
.field static final k:Lcom/unity3d/player/k;
.field private static l:Z

.method static constructor <clinit>()V
    .registers 5
    const/4 v3, 0
    const/4 v1, 1
    const/4 v2, 0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/4 v4, 5
    if-lt v0, v4, +074h
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/p;->l Z
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 8
    if-lt v0, v4, +06dh
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/p;->a Z
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 9
    if-lt v0, v4, +066h
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/p;->b Z
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 11
    if-lt v0, v4, +05fh
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/p;->c Z
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 12
    if-lt v0, v4, +058h
    move v0, v1
    sput-boolean v0, Lcom/unity3d/player/p;->d Z
    sget v0, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 14
    if-lt v0, v4, +051h
    sput-boolean v1, Lcom/unity3d/player/p;->e Z
    sget-boolean v0, Lcom/unity3d/player/p;->l Z
    if-eqz v0, +04dh
    new-instance v0, Lcom/unity3d/player/f;
    invoke-direct v0, Lcom/unity3d/player/f;-><init>()V
    sput-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    sget-boolean v0, Lcom/unity3d/player/p;->a Z
    if-eqz v0, +044h
    new-instance v0, Lcom/unity3d/player/g;
    invoke-direct v0, Lcom/unity3d/player/g;-><init>()V
    sput-object v0, Lcom/unity3d/player/p;->g Lcom/unity3d/player/g;
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +03bh
    new-instance v0, Lcom/unity3d/player/h;
    invoke-direct v0, Lcom/unity3d/player/h;-><init>()V
    sput-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    sget-boolean v0, Lcom/unity3d/player/p;->c Z
    if-eqz v0, +032h
    new-instance v0, Lcom/unity3d/player/e;
    invoke-direct v0, Lcom/unity3d/player/e;-><init>()V
    sput-object v0, Lcom/unity3d/player/p;->i Lcom/unity3d/player/j;
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +029h
    new-instance v0, Lcom/unity3d/player/i;
    invoke-direct v0, Lcom/unity3d/player/i;-><init>()V
    sput-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    sget-boolean v0, Lcom/unity3d/player/p;->e Z
    if-eqz v0, +007h
    new-instance v3, Lcom/unity3d/player/k;
    invoke-direct v3, Lcom/unity3d/player/k;-><init>()V
    sput-object v3, Lcom/unity3d/player/p;->k Lcom/unity3d/player/k;
    return-void
    move v0, v2
    goto -72h
    move v0, v2
    goto -6bh
    move v0, v2
    goto -64h
    move v0, v2
    goto -5dh
    move v0, v2
    goto -56h
    move v1, v2
    goto -50h
    move-object v0, v3
    goto -47h
    move-object v0, v3
    goto -3eh
    move-object v0, v3
    goto -35h
    move-object v0, v3
    goto -2ch
    move-object v0, v3
    goto -23h
.end method
