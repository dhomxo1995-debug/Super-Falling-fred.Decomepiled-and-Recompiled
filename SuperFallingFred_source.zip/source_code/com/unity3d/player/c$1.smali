.class final Lcom/unity3d/player/c$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/c;

.method constructor <init>(Lcom/unity3d/player/c;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    iget-object v0, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v0, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v0
    if-nez v0, +049h
    iget-object v0, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    new-instance v1, Landroid/view/SurfaceView;
    sget-object v2, Lcom/unity3d/player/t;->a Lcom/unity3d/player/t;
    invoke-virtual v2, Lcom/unity3d/player/t;->a()Landroid/content/Context;
    move-result-object v2
    invoke-direct v1, v2, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V
    invoke-static v0, v1, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c; Landroid/view/SurfaceView;)Landroid/view/SurfaceView;
    iget-object v0, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v0, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v0
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v1, Lcom/unity3d/player/c;->b(Lcom/unity3d/player/c;)I
    move-result v1
    invoke-interface v0, v1, Landroid/view/SurfaceHolder;->setType(I)V
    iget-object v0, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v0, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v0
    invoke-virtual v0, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;
    move-result-object v0
    iget-object v1, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-interface v0, v1, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V
    sget-object v0, Lcom/unity3d/player/t;->a Lcom/unity3d/player/t;
    iget-object v1, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v1, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/t;->b(Landroid/view/View;)V
    iget-object v0, v3, Lcom/unity3d/player/c$1;->a Lcom/unity3d/player/c;
    invoke-static v0, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v0
    const/4 v1, 0
    invoke-virtual v0, v1, Landroid/view/SurfaceView;->setVisibility(I)V
    return-void
.end method
