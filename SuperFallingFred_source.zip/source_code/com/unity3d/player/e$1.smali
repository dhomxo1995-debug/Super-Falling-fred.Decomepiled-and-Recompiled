.class final Lcom/unity3d/player/e$1;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnSystemUiVisibilityChangeListener;

.field final synthetic a:Landroid/view/View;

.method constructor <init>(Landroid/view/View;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/e$1;->a Landroid/view/View;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onSystemUiVisibilityChange(I)V
    .registers 6
    invoke-static Lcom/unity3d/player/e;->a()I
    move-result v0
    xor-int/2addr v0, v5
    invoke-static v5, Lcom/unity3d/player/e;->a(I)I
    and-int/lit8 v0, v0, 1
    if-eqz v0, +016h
    and-int/lit8 v0, v5, 1
    if-nez v0, +012h
    iget-object v0, v4, Lcom/unity3d/player/e$1;->a Landroid/view/View;
    invoke-virtual v0, Landroid/view/View;->getHandler()Landroid/os/Handler;
    move-result-object v0
    new-instance v1, Lcom/unity3d/player/e$1$1;
    invoke-direct v1, v4, v5, Lcom/unity3d/player/e$1$1;-><init>(Lcom/unity3d/player/e$1; I)V
    const-wide/16 v2, 1000
    invoke-virtual v0, v1, v2, v3, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable; J)Z
    return-void
.end method
