.class final Lcom/unity3d/player/UnityPlayer$11;
.super Ljava/lang/Object;
.implements Landroid/content/DialogInterface$OnClickListener;

.field private synthetic a:I
.field private synthetic b:Z
.field private synthetic c:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I Z)V
    .registers 4
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$11;->c Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$11;->a I
    iput-boolean v3, v0, Lcom/unity3d/player/UnityPlayer$11;->b Z
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onClick(Landroid/content/DialogInterface; I)V
    .registers 6
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$11;->c Lcom/unity3d/player/UnityPlayer;
    iget v1, v3, Lcom/unity3d/player/UnityPlayer$11;->a I
    iget-boolean v2, v3, Lcom/unity3d/player/UnityPlayer$11;->b Z
    invoke-static v0, v1, v2, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I Z)V
    return-void
.end method
