.class final Lcom/unity3d/player/s$3;
.super Ljava/lang/Object;
.implements Landroid/widget/TextView$OnEditorActionListener;

.field private synthetic a:Lcom/unity3d/player/s;

.method constructor <init>(Lcom/unity3d/player/s;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/s$3;->a Lcom/unity3d/player/s;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onEditorAction(Landroid/widget/TextView; I Landroid/view/KeyEvent;)Z
    .registers 7
    const/4 v2, 0
    const/4 v0, 6
    if-ne v5, v0, +00dh
    iget-object v0, v3, Lcom/unity3d/player/s$3;->a Lcom/unity3d/player/s;
    iget-object v1, v3, Lcom/unity3d/player/s$3;->a Lcom/unity3d/player/s;
    invoke-static v1, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s;)Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, v2, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s; Ljava/lang/String; Z)V
    return v2
.end method
