.class final Lcom/unity3d/player/s$1;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnFocusChangeListener;

.field private synthetic a:Lcom/unity3d/player/s;

.method constructor <init>(Lcom/unity3d/player/s;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/s$1;->a Lcom/unity3d/player/s;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onFocusChange(Landroid/view/View; Z)V
    .registers 5
    if-eqz v4, +00ch
    iget-object v0, v2, Lcom/unity3d/player/s$1;->a Lcom/unity3d/player/s;
    invoke-virtual v0, Lcom/unity3d/player/s;->getWindow()Landroid/view/Window;
    move-result-object v0
    const/4 v1, 5
    invoke-virtual v0, v1, Landroid/view/Window;->setSoftInputMode(I)V
    return-void
.end method
