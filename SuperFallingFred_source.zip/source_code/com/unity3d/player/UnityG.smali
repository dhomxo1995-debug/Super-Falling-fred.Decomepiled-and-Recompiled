.class public interface abstract Lcom/unity3d/player/UnityGL;
.super Ljava/lang/Object;


.method public abstract a()V
    # abstract or native method
.end method

.method public abstract onPause()V
    # abstract or native method
.end method

.method public abstract onResume()V
    # abstract or native method
.end method

.method public abstract queueEvent(Ljava/lang/Runnable;)V
    # abstract or native method
.end method

.method public abstract setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V
    # abstract or native method
.end method
