.class final Lcom/unity3d/player/UnityPlayer$24;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/util/concurrent/Semaphore;
.field private synthetic b:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Ljava/util/concurrent/Semaphore;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$24;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$24;->a Ljava/util/concurrent/Semaphore;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$24;->b Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->b(Lcom/unity3d/player/UnityPlayer;)V
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$24;->a Ljava/util/concurrent/Semaphore;
    invoke-virtual v0, Ljava/util/concurrent/Semaphore;->release()V
    return-void
.end method
