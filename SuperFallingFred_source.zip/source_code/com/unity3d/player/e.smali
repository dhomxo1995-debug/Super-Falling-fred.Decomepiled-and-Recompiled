.class public final Lcom/unity3d/player/e;
.super Ljava/lang/Object;
.implements Lcom/unity3d/player/j;

.field private static a:I

.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method static synthetic a()I
    .registers 1
    sget v0, Lcom/unity3d/player/e;->a I
    return v0
.end method

.method static synthetic a(I)I
    .registers 1
    sput v0, Lcom/unity3d/player/e;->a I
    return v0
.end method

.method public final a(Landroid/opengl/GLSurfaceView; Z)V
    .registers 3
    invoke-virtual v1, v2, Landroid/opengl/GLSurfaceView;->setPreserveEGLContextOnPause(Z)V
    return-void
.end method

.method public final a(Landroid/view/View;)V
    .registers 3
    invoke-virtual v2, Landroid/view/View;->getSystemUiVisibility()I
    move-result v0
    sput v0, Lcom/unity3d/player/e;->a I
    new-instance v0, Lcom/unity3d/player/e$1;
    invoke-direct v0, v2, Lcom/unity3d/player/e$1;-><init>(Landroid/view/View;)V
    invoke-virtual v2, v0, Landroid/view/View;->setOnSystemUiVisibilityChangeListener(Landroid/view/View$OnSystemUiVisibilityChangeListener;)V
    return-void
.end method

.method public final a(Landroid/view/View; Z)V
    .registers 4
    if-eqz v3, +00eh
    sget v0, Lcom/unity3d/player/e;->a I
    or-int/lit8 v0, v0, 1
    sput v0, Lcom/unity3d/player/e;->a I
    sget v0, Lcom/unity3d/player/e;->a I
    invoke-virtual v2, v0, Landroid/view/View;->setSystemUiVisibility(I)V
    return-void
    sget v0, Lcom/unity3d/player/e;->a I
    and-int/lit8 v0, v0, -2
    sput v0, Lcom/unity3d/player/e;->a I
    goto -ch
.end method

.method public final a(Landroid/os/Vibrator;)Z
    .registers 3
    invoke-virtual v2, Landroid/os/Vibrator;->hasVibrator()Z
    move-result v0
    return v0
.end method

.method public final b(Landroid/view/View;)Z
    .registers 3
    invoke-virtual v2, Landroid/view/View;->getSystemUiVisibility()I
    move-result v0
    and-int/lit8 v0, v0, 1
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method

.method public final c(Landroid/view/View;)V
    .registers 6
    invoke-virtual v4, v5, Lcom/unity3d/player/e;->b(Landroid/view/View;)Z
    move-result v0
    if-nez v0, +003h
    return-void
    const/4 v0, 0
    invoke-virtual v4, v5, v0, Lcom/unity3d/player/e;->a(Landroid/view/View; Z)V
    invoke-virtual v5, Landroid/view/View;->getHandler()Landroid/os/Handler;
    move-result-object v0
    new-instance v1, Lcom/unity3d/player/e$2;
    invoke-direct v1, v4, v5, Lcom/unity3d/player/e$2;-><init>(Lcom/unity3d/player/e; Landroid/view/View;)V
    const-wide/16 v2, 500
    invoke-virtual v0, v1, v2, v3, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable; J)Z
    goto -13h
.end method
