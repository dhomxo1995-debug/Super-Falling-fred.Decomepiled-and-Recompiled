package com.unity3d.player;
public class UnityPlayerActivity extends android.app.Activity {
    private com.unity3d.player.UnityPlayer a;

    public UnityPlayerActivity()
    {
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p2)
    {
        super.onConfigurationChanged(p2);
        this.a.configurationChanged(p2);
        return;
    }

    protected void onCreate(android.os.Bundle p5)
    {
        super.onCreate(p5);
        this.setTheme(16973831);
        this.requestWindowFeature(1);
        this.a = new com.unity3d.player.UnityPlayer(this);
        if (this.a.getSettings().getBoolean("hide_status_bar", 1)) {
            this.getWindow().setFlags(1024, 1024);
        }
        this.a.init(this.a.getSettings().getInt("gles_mode", 1), 0);
        android.view.View v0_8 = this.a.getView();
        this.setContentView(v0_8);
        v0_8.requestFocus();
        return;
    }

    protected void onDestroy()
    {
        super.onDestroy();
        this.a.quit();
        return;
    }

    public boolean onKeyDown(int p2, android.view.KeyEvent p3)
    {
        return this.a.onKeyDown(p2, p3);
    }

    public boolean onKeyUp(int p2, android.view.KeyEvent p3)
    {
        return this.a.onKeyUp(p2, p3);
    }

    protected void onPause()
    {
        super.onPause();
        this.a.pause();
        if (this.isFinishing()) {
            this.a.quit();
        }
        return;
    }

    protected void onResume()
    {
        super.onResume();
        this.a.resume();
        return;
    }

    public void onWindowFocusChanged(boolean p2)
    {
        super.onWindowFocusChanged(p2);
        this.a.windowFocusChanged(p2);
        return;
    }
}
