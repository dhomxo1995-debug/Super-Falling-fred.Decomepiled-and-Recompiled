.class 0x0 Lcom/unity3d/player/UnityPlayer$17;
.super Landroid/content/BroadcastReceiver;

.field final synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$17;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Landroid/content/BroadcastReceiver;-><init>()V
    return-void
.end method

.method public onReceive(Landroid/content/Context; Landroid/content/Intent;)V
    .registers 5
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$17;->a Lcom/unity3d/player/UnityPlayer;
    new-instance v1, Lcom/unity3d/player/UnityPlayer$17$1;
    invoke-direct v1, v2, Lcom/unity3d/player/UnityPlayer$17$1;-><init>(Lcom/unity3d/player/UnityPlayer$17;)V
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->queueEvent(Ljava/lang/Runnable;)V
    return-void
    move-exception v0
    goto -2h
.end method
