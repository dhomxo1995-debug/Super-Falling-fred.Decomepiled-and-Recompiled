.class 0x0 Lcom/unity3d/player/PlayerPrefs;
.super Ljava/lang/Object;

.field private a:Landroid/content/SharedPreferences;
.field private b:Landroid/content/SharedPreferences$Editor;
.field private c:Ljava/util/concurrent/atomic/AtomicBoolean;

.method constructor <init>(Landroid/content/SharedPreferences;)V
    .registers 4
    invoke-direct v2, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;
    const/4 v1, 0
    invoke-direct v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V
    iput-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    iput-object v3, v2, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    invoke-interface v0, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    iput-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-direct v2, Lcom/unity3d/player/PlayerPrefs;->InitPlayerPrefs()V
    return-void
.end method

.method private DeleteAll()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    const/4 v1, 1
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    return-void
.end method

.method private DeleteKey(Ljava/lang/String;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, v3, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    const/4 v1, 1
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    return-void
.end method

.method private GetFloat(Ljava/lang/String; F)F
    .registers 4
    invoke-direct v1, Lcom/unity3d/player/PlayerPrefs;->Sync()V
    iget-object v0, v1, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    invoke-interface v0, v2, v3, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String; F)F
    move-result v3
    return v3
    move-exception v0
    goto -2h
.end method

.method private GetInt(Ljava/lang/String; I)I
    .registers 4
    invoke-direct v1, Lcom/unity3d/player/PlayerPrefs;->Sync()V
    iget-object v0, v1, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    invoke-interface v0, v2, v3, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String; I)I
    move-result v3
    return v3
    move-exception v0
    goto -2h
.end method

.method private GetString(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    invoke-direct v1, Lcom/unity3d/player/PlayerPrefs;->Sync()V
    iget-object v0, v1, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    invoke-interface v0, v2, v3, Landroid/content/SharedPreferences;->getString(Ljava/lang/String; Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3
    return-object v3
    move-exception v0
    goto -2h
.end method

.method private HasKey(Ljava/lang/String;)Z
    .registers 3
    invoke-direct v1, Lcom/unity3d/player/PlayerPrefs;->Sync()V
    iget-object v0, v1, Lcom/unity3d/player/PlayerPrefs;->a Landroid/content/SharedPreferences;
    invoke-interface v0, v2, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z
    move-result v0
    return v0
.end method

.method private final native InitPlayerPrefs()V
    # abstract or native method
.end method

.method private SetFloat(Ljava/lang/String; F)Z
    .registers 5
    const/4 v1, 1
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, v3, v4, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String; F)Landroid/content/SharedPreferences$Editor;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    return v1
.end method

.method private SetInt(Ljava/lang/String; I)Z
    .registers 5
    const/4 v1, 1
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, v3, v4, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String; I)Landroid/content/SharedPreferences$Editor;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    return v1
.end method

.method private SetString(Ljava/lang/String; Ljava/lang/String;)Z
    .registers 5
    const/4 v1, 1
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, v3, v4, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String; Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    return v1
.end method

.method private Sync()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->c Ljava/util/concurrent/atomic/AtomicBoolean;
    const/4 v1, 0
    invoke-virtual v0, v1, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z
    move-result v0
    if-nez v0, +003h
    return-void
    iget-object v0, v2, Lcom/unity3d/player/PlayerPrefs;->b Landroid/content/SharedPreferences$Editor;
    invoke-interface v0, Landroid/content/SharedPreferences$Editor;->commit()Z
    goto -6h
.end method
