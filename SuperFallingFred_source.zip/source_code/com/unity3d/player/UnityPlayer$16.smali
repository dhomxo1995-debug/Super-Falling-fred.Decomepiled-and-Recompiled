.class final Lcom/unity3d/player/UnityPlayer$16;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Ljava/lang/String;
.field private synthetic b:I
.field private synthetic c:I
.field private synthetic d:I
.field private synthetic e:Z
.field private synthetic f:I
.field private synthetic g:I
.field private synthetic h:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I I I Z I I)V
    .registers 9
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    iput-object v2, v0, Lcom/unity3d/player/UnityPlayer$16;->a Ljava/lang/String;
    iput v3, v0, Lcom/unity3d/player/UnityPlayer$16;->b I
    iput v4, v0, Lcom/unity3d/player/UnityPlayer$16;->c I
    iput v5, v0, Lcom/unity3d/player/UnityPlayer$16;->d I
    iput-boolean v6, v0, Lcom/unity3d/player/UnityPlayer$16;->e Z
    iput v7, v0, Lcom/unity3d/player/UnityPlayer$16;->f I
    iput v8, v0, Lcom/unity3d/player/UnityPlayer$16;->g I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 14
    iget-object v0, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    move-result-object v0
    if-eqz v0, +003h
    return-void
    iget-object v0, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 1
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->d(Lcom/unity3d/player/UnityPlayer; Z)V
    iget-object v0, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v0, Lcom/unity3d/player/UnityPlayer;->pause()V
    iget-object v12, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    new-instance v0, Lcom/unity3d/player/y;
    iget-object v1, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    iget-object v2, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v2, Lcom/unity3d/player/UnityPlayer;->i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    move-result-object v2
    iget-object v3, v13, Lcom/unity3d/player/UnityPlayer$16;->a Ljava/lang/String;
    iget v4, v13, Lcom/unity3d/player/UnityPlayer$16;->b I
    iget v5, v13, Lcom/unity3d/player/UnityPlayer$16;->c I
    iget v6, v13, Lcom/unity3d/player/UnityPlayer$16;->d I
    iget-boolean v7, v13, Lcom/unity3d/player/UnityPlayer$16;->e Z
    iget v8, v13, Lcom/unity3d/player/UnityPlayer$16;->f I
    int-to-long v8, v8
    iget v10, v13, Lcom/unity3d/player/UnityPlayer$16;->g I
    int-to-long v10, v10
    invoke-direct/range v0 ... v11, Lcom/unity3d/player/y;-><init>(Lcom/unity3d/player/UnityPlayer; Landroid/content/Context; Ljava/lang/String; I I I Z J J)V
    invoke-static v12, v0, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Lcom/unity3d/player/y;)Lcom/unity3d/player/y;
    iget-object v0, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    iget-object v1, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v1, Lcom/unity3d/player/UnityPlayer;->o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->addView(Landroid/view/View;)V
    iget-object v0, v13, Lcom/unity3d/player/UnityPlayer$16;->h Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->o(Lcom/unity3d/player/UnityPlayer;)Lcom/unity3d/player/y;
    move-result-object v0
    invoke-virtual v0, Lcom/unity3d/player/y;->requestFocus()Z
    goto -42h
.end method
