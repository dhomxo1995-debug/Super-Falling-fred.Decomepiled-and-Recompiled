.class public interface abstract Lcom/unity3d/player/l;
.super Ljava/lang/Object;


.method public abstract a()Landroid/graphics/RectF;
    # abstract or native method
.end method

.method public abstract a(J J I I [I [F I F F I I I I I [J [F)V
    # abstract or native method
.end method
