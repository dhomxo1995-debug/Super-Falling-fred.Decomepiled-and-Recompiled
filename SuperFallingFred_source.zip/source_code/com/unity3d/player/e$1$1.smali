.class final Lcom/unity3d/player/e$1$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:Lcom/unity3d/player/e$1;

.method constructor <init>(Lcom/unity3d/player/e$1; I)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/e$1$1;->b Lcom/unity3d/player/e$1;
    iput v2, v0, Lcom/unity3d/player/e$1$1;->a I
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/e$1$1;->b Lcom/unity3d/player/e$1;
    iget-object v0, v0, Lcom/unity3d/player/e$1;->a Landroid/view/View;
    iget v1, v2, Lcom/unity3d/player/e$1$1;->a I
    or-int/lit8 v1, v1, 1
    invoke-virtual v0, v1, Landroid/view/View;->setSystemUiVisibility(I)V
    return-void
.end method
