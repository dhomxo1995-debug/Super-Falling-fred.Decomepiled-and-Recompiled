.class 0x0 Lcom/unity3d/player/ReflectionHelper;
.super Ljava/lang/Object;

.field protected static LOG:Z
.field protected static final LOGV:Z

.method static constructor <clinit>()V
    .registers 1
    const/4 v0, 0
    sput-boolean v0, Lcom/unity3d/player/ReflectionHelper;->LOG Z
    return-void
.end method

.method constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private static a(Ljava/lang/Class; Ljava/lang/Class;)F
    .registers 3
    invoke-virtual v1, v2, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, +005h
    const/high16 v0, 1065353216
    return v0
    invoke-virtual v1, Ljava/lang/Class;->isPrimitive()Z
    move-result v0
    if-nez v0, +01dh
    invoke-virtual v2, Ljava/lang/Class;->isPrimitive()Z
    move-result v0
    if-nez v0, +017h
    invoke-virtual v1, v2, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;
    move-result-object v0
    if-eqz v0, +006h
    const/high16 v0, 1056964608
    goto -15h
    move-exception v0
    invoke-virtual v2, v1, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;
    move-result-object v0
    if-eqz v0, +007h
    const v0, 1036831949
    goto -20h
    move-exception v0
    const/4 v0, 0
    goto -23h
.end method

.method private static a(Ljava/lang/Class; [Ljava/lang/Class; [Ljava/lang/Class;)F
    .registers 9
    const/4 v1, 0
    array-length v0, v8
    if-nez v0, +006h
    const v0, 1036831949
    return v0
    if-nez v7, +00ah
    move v0, v1
    add-int/lit8 v0, v0, 1
    array-length v2, v8
    if-eq v0, v2, +006h
    const/4 v0, 0
    goto -ah
    array-length v0, v7
    goto -8h
    const/high16 v0, 1065353216
    if-eqz v7, +015h
    array-length v4, v7
    move v2, v1
    if-ge v1, v4, +011h
    aget-object v5, v7, v1
    add-int/lit8 v3, v2, 1
    aget-object v2, v8, v2
    invoke-static v5, v2, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/Class; Ljava/lang/Class;)F
    move-result v2
    mul-float/2addr v0, v2
    add-int/lit8 v1, v1, 1
    move v2, v3
    goto -10h
    array-length v1, v8
    add-int/lit8 v1, v1, -1
    aget-object v1, v8, v1
    invoke-static v6, v1, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/Class; Ljava/lang/Class;)F
    move-result v1
    mul-float/2addr v0, v1
    goto -2eh
.end method

.method private static a(Ljava/lang/String; [I)Ljava/lang/Class;
    .registers 6
    const/4 v2, 0
    aget v0, v5, v2
    invoke-virtual v4, Ljava/lang/String;->length()I
    move-result v1
    if-ge v0, v1, +09ch
    aget v0, v5, v2
    add-int/lit8 v1, v0, 1
    aput v1, v5, v2
    invoke-virtual v4, v0, Ljava/lang/String;->charAt(I)C
    move-result v0
    const/16 v1, 40
    if-eq v0, v1, -014h
    const/16 v1, 41
    if-eq v0, v1, -018h
    const/16 v1, 76
    if-ne v0, v1, +024h
    const/16 v0, 59
    aget v1, v5, v2
    invoke-virtual v4, v0, v1, Ljava/lang/String;->indexOf(I I)I
    move-result v0
    const/4 v1, -1
    if-eq v0, v1, +07bh
    aget v1, v5, v2
    invoke-virtual v4, v1, v0, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v1
    add-int/lit8 v0, v0, 1
    aput v0, v5, v2
    const/16 v0, 47
    const/16 v2, 46
    invoke-virtual v1, v0, v2, Ljava/lang/String;->replace(C C)Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    move-result-object v0
    return-object v0
    const/16 v1, 90
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Boolean;->TYPE Ljava/lang/Class;
    goto -7h
    const/16 v1, 73
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Integer;->TYPE Ljava/lang/Class;
    goto -eh
    const/16 v1, 70
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Float;->TYPE Ljava/lang/Class;
    goto -15h
    const/16 v1, 86
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Void;->TYPE Ljava/lang/Class;
    goto -1ch
    const/16 v1, 66
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Byte;->TYPE Ljava/lang/Class;
    goto -23h
    const/16 v1, 83
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Short;->TYPE Ljava/lang/Class;
    goto -2ah
    const/16 v1, 74
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Long;->TYPE Ljava/lang/Class;
    goto -31h
    const/16 v1, 68
    if-ne v0, v1, +005h
    sget-object v0, Ljava/lang/Double;->TYPE Ljava/lang/Class;
    goto -38h
    const/16 v1, 91
    if-ne v0, v1, +00fh
    invoke-static v4, v5, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/String; [I)Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, v2, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class; I)Ljava/lang/Object;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    goto -49h
    const/4 v1, 5
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "! parseType; "
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, v0, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    move-result-object v0
    const-string v2, " is not known!"
    invoke-virtual v0, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v1, v0, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    const/4 v0, 0
    goto -64h
    move-exception v0
    goto -3h
.end method

.method private static a(Ljava/lang/String;)[Ljava/lang/Class;
    .registers 6
    const/4 v0, 0
    const/4 v1, 1
    new-array v1, v1, [I
    aput v0, v1, v0
    new-instance v2, Ljava/util/ArrayList;
    invoke-direct v2, Ljava/util/ArrayList;-><init>()V
    aget v3, v1, v0
    invoke-virtual v5, Ljava/lang/String;->length()I
    move-result v4
    if-ge v3, v4, +00ch
    invoke-static v5, v1, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/String; [I)Ljava/lang/Class;
    move-result-object v3
    if-eqz v3, +006h
    invoke-virtual v2, v3, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    goto -11h
    invoke-virtual v2, Ljava/util/ArrayList;->size()I
    move-result v1
    new-array v3, v1, [Ljava/lang/Class;
    invoke-virtual v2, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    move-result-object v4
    move v1, v0
    invoke-interface v4, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00eh
    invoke-interface v4, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Class;
    add-int/lit8 v2, v1, 1
    aput-object v0, v3, v1
    move v1, v2
    goto -11h
    return-object v3
.end method

.method protected static getConstructorID(Ljava/lang/Class; Ljava/lang/String;)Ljava/lang/reflect/Constructor;
    .registers 11
    invoke-static v10, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/String;)[Ljava/lang/Class;
    move-result-object v5
    const/4 v3, 0
    const/4 v1, 0
    invoke-virtual v9, Ljava/lang/Class;->getConstructors()[Ljava/lang/reflect/Constructor;
    move-result-object v6
    array-length v7, v6
    const/4 v0, 0
    move v4, v0
    if-ge v4, v7, +01fh
    aget-object v2, v6, v4
    sget-object v0, Ljava/lang/Void;->TYPE Ljava/lang/Class;
    invoke-virtual v2, Ljava/lang/reflect/Constructor;->getParameterTypes()[Ljava/lang/Class;
    move-result-object v8
    invoke-static v0, v8, v5, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/Class; [Ljava/lang/Class; [Ljava/lang/Class;)F
    move-result v0
    cmpl-float v8, v0, v1
    if-lez v8, +03ah
    const/high16 v1, 1065353216
    cmpl-float v1, v0, v1
    if-eqz v1, +00ah
    move-object v1, v2
    add-int/lit8 v2, v4, 1
    move v4, v2
    move-object v3, v1
    move v1, v0
    goto -1eh
    move-object v2, v3
    if-nez v2, +029h
    const/4 v0, 6
    new-instance v1, Ljava/lang/StringBuilder;
    const-string v3, "! getConstructorID(""
    invoke-direct v1, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v9, Ljava/lang/Class;->getName()Ljava/lang/String;
    move-result-object v3
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v3, "", ""
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, v10, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    const-string v3, "") FAILED!"
    invoke-virtual v1, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-static v0, v1, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-object v2
    move v0, v1
    move-object v1, v3
    goto -33h
.end method

.method protected static getFieldID(Ljava/lang/Class; Ljava/lang/String; Ljava/lang/String; Z)Ljava/lang/reflect/Field;
    .registers 15
    const/4 v4, 0
    const/high16 v10, 1065353216
    invoke-static v13, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/String;)[Ljava/lang/Class;
    move-result-object v6
    const/4 v0, 0
    move v1, v0
    move-object v0, v4
    if-eqz v11, +060h
    invoke-virtual v11, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;
    move-result-object v7
    array-length v8, v7
    const/4 v2, 0
    move v5, v2
    move-object v3, v0
    if-ge v5, v8, +07fh
    aget-object v2, v7, v5
    invoke-virtual v2, Ljava/lang/reflect/Field;->getModifiers()I
    move-result v0
    invoke-static v0, Ljava/lang/reflect/Modifier;->isStatic(I)Z
    move-result v0
    if-ne v14, v0, +070h
    invoke-virtual v2, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, v12, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    move-result v0
    if-nez v0, +066h
    invoke-virtual v2, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;
    move-result-object v0
    invoke-static v0, v4, v6, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/Class; [Ljava/lang/Class; [Ljava/lang/Class;)F
    move-result v0
    cmpl-float v9, v0, v1
    if-lez v9, +05ah
    cmpl-float v1, v0, v10
    if-eqz v1, +009h
    move-object v1, v2
    add-int/lit8 v2, v5, 1
    move v5, v2
    move-object v3, v1
    move v1, v0
    goto -2eh
    move v1, v0
    move-object v0, v2
    cmpl-float v2, v1, v10
    if-eqz v2, +023h
    invoke-virtual v11, Ljava/lang/Class;->isPrimitive()Z
    move-result v2
    if-nez v2, +01dh
    invoke-virtual v11, Ljava/lang/Class;->isInterface()Z
    move-result v2
    if-nez v2, +017h
    const-class v2, Ljava/lang/Object;
    invoke-virtual v11, v2, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +00fh
    sget-object v2, Ljava/lang/Void;->TYPE Ljava/lang/Class;
    invoke-virtual v11, v2, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +007h
    invoke-virtual v11, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    move-result-object v11
    goto -5fh
    if-nez v0, +025h
    const/4 v1, 6
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "! getFieldID(""
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "", ""
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v13, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "") FAILED!"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-object v0
    move v0, v1
    move-object v1, v3
    goto -55h
    move-object v0, v3
    goto -4fh
.end method

.method protected static getMethodID(Ljava/lang/Class; Ljava/lang/String; Ljava/lang/String; Z)Ljava/lang/reflect/Method;
    .registers 15
    const/high16 v9, 1065353216
    invoke-static v13, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/String;)[Ljava/lang/Class;
    move-result-object v5
    const/4 v1, 0
    const/4 v0, 0
    move v10, v0
    move-object v0, v1
    move v1, v10
    if-eqz v11, +064h
    invoke-virtual v11, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;
    move-result-object v6
    array-length v7, v6
    const/4 v2, 0
    move v4, v2
    move-object v3, v0
    if-ge v4, v7, +083h
    aget-object v2, v6, v4
    invoke-virtual v2, Ljava/lang/reflect/Method;->getModifiers()I
    move-result v0
    invoke-static v0, Ljava/lang/reflect/Modifier;->isStatic(I)Z
    move-result v0
    if-ne v14, v0, +074h
    invoke-virtual v2, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, v12, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    move-result v0
    if-nez v0, +06ah
    invoke-virtual v2, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;
    move-result-object v0
    invoke-virtual v2, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;
    move-result-object v8
    invoke-static v0, v8, v5, Lcom/unity3d/player/ReflectionHelper;->a(Ljava/lang/Class; [Ljava/lang/Class; [Ljava/lang/Class;)F
    move-result v0
    cmpl-float v8, v0, v1
    if-lez v8, +05ah
    cmpl-float v1, v0, v9
    if-eqz v1, +009h
    move-object v1, v2
    add-int/lit8 v2, v4, 1
    move v4, v2
    move-object v3, v1
    move v1, v0
    goto -32h
    move v1, v0
    move-object v0, v2
    cmpl-float v2, v1, v9
    if-eqz v2, +023h
    invoke-virtual v11, Ljava/lang/Class;->isPrimitive()Z
    move-result v2
    if-nez v2, +01dh
    invoke-virtual v11, Ljava/lang/Class;->isInterface()Z
    move-result v2
    if-nez v2, +017h
    const-class v2, Ljava/lang/Object;
    invoke-virtual v11, v2, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +00fh
    sget-object v2, Ljava/lang/Void;->TYPE Ljava/lang/Class;
    invoke-virtual v11, v2, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, +007h
    invoke-virtual v11, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    move-result-object v11
    goto -63h
    if-nez v0, +025h
    const/4 v1, 6
    new-instance v2, Ljava/lang/StringBuilder;
    const-string v3, "! getMethodID(""
    invoke-direct v2, v3, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v2, v12, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "", ""
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, v13, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "") FAILED!"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    return-object v0
    move v0, v1
    move-object v1, v3
    goto -55h
    move-object v0, v3
    goto -4fh
.end method
