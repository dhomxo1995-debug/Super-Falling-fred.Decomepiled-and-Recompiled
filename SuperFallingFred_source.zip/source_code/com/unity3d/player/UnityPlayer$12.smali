.class final Lcom/unity3d/player/UnityPlayer$12;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 4
    const/4 v2, 0
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->l(Lcom/unity3d/player/UnityPlayer;)Z
    move-result v0
    if-eqz v0, +01ah
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->i(Lcom/unity3d/player/UnityPlayer;)Landroid/content/ContextWrapper;
    move-result-object v0
    const-string v1, "input_method"
    invoke-virtual v0, v1, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;
    const/4 v1, 1
    invoke-virtual v0, v1, v2, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(I I)V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, v2, Lcom/unity3d/player/UnityPlayer;->c(Lcom/unity3d/player/UnityPlayer; Z)Z
    return-void
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    if-eqz v0, -005h
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    invoke-virtual v0, Lcom/unity3d/player/s;->dismiss()V
    iget-object v0, v3, Lcom/unity3d/player/UnityPlayer$12;->a Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 0
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer;->a Lcom/unity3d/player/s;
    goto -13h
.end method
