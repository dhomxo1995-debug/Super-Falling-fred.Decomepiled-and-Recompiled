.class public final Lcom/unity3d/player/f;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static a(I)I
    .registers 2
    const/16 v0, 12
    return v0
.end method

.method public static a(Landroid/hardware/Camera$Parameters;)Ljava/util/List;
    .registers 7
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct v1, Ljava/util/ArrayList;-><init>()V
    invoke-virtual v6, Landroid/hardware/Camera$Parameters;->getSupportedPreviewFrameRates()Ljava/util/List;
    move-result-object v0
    if-eqz v0, +027h
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v2
    invoke-interface v2, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +01dh
    invoke-interface v2, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/Integer;
    invoke-virtual v0, Ljava/lang/Integer;->intValue()I
    move-result v0
    const/4 v3, 2
    new-array v3, v3, [I
    const/4 v4, 0
    mul-int/lit16 v5, v0, 1000
    aput v5, v3, v4
    const/4 v4, 1
    mul-int/lit16 v0, v0, 1000
    aput v0, v3, v4
    invoke-interface v1, v3, Ljava/util/List;->add(Ljava/lang/Object;)Z
    goto -20h
    return-object v1
.end method

.method public static a(Landroid/hardware/Camera$Parameters; [I)V
    .registers 3
    const/4 v0, 0
    aget v0, v2, v0
    div-int/lit16 v0, v0, 1000
    invoke-virtual v1, v0, Landroid/hardware/Camera$Parameters;->setPreviewFrameRate(I)V
    return-void
.end method

.method public static a(Landroid/hardware/Camera;)V
    .registers 2
    const/4 v0, 0
    invoke-virtual v1, v0, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V
    return-void
.end method

.method public static a(Landroid/hardware/Camera; Landroid/hardware/Camera$PreviewCallback;)V
    .registers 2
    invoke-virtual v0, v1, Landroid/hardware/Camera;->setPreviewCallback(Landroid/hardware/Camera$PreviewCallback;)V
    return-void
.end method

.method public static b(Landroid/hardware/Camera$Parameters;)V
    .registers 2
    invoke-virtual v1, Landroid/hardware/Camera$Parameters;->getSupportedColorEffects()Ljava/util/List;
    move-result-object v0
    if-eqz v0, +007h
    const-string v0, "none"
    invoke-virtual v1, v0, Landroid/hardware/Camera$Parameters;->setColorEffect(Ljava/lang/String;)V
    return-void
.end method
