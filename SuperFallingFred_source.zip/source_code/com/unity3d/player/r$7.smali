.class final Lcom/unity3d/player/r$7;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/r;

.method constructor <init>(Lcom/unity3d/player/r;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/r$7;->a Lcom/unity3d/player/r;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/r$7;->a Lcom/unity3d/player/r;
    invoke-static v0, Lcom/unity3d/player/r;->e(Lcom/unity3d/player/r;)Lcom/unity3d/player/UnityPlayer;
    move-result-object v0
    iget-object v1, v2, Lcom/unity3d/player/r$7;->a Lcom/unity3d/player/r;
    invoke-static v1, Lcom/unity3d/player/r;->u(Lcom/unity3d/player/r;)I
    move-result v1
    invoke-virtual v0, v1, Lcom/unity3d/player/UnityPlayer;->nativeDeviceOrientation(I)V
    return-void
.end method
