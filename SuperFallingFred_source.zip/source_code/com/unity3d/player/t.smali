.class final Lcom/unity3d/player/t;
.super Ljava/lang/Object;

.field public static a:Lcom/unity3d/player/t;
.field private final b:Landroid/widget/FrameLayout;
.field private c:Ljava/util/Set;
.field private d:Landroid/view/View;
.field private e:Landroid/view/View;

.method constructor <init>(Landroid/widget/FrameLayout;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/HashSet;
    invoke-direct v0, Ljava/util/HashSet;-><init>()V
    iput-object v0, v1, Lcom/unity3d/player/t;->c Ljava/util/Set;
    iput-object v2, v1, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    sput-object v1, Lcom/unity3d/player/t;->a Lcom/unity3d/player/t;
    return-void
.end method

.method private f(Landroid/view/View;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    iget-object v1, v2, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v1, Landroid/widget/FrameLayout;->getChildCount()I
    move-result v1
    invoke-virtual v0, v3, v1, Landroid/widget/FrameLayout;->addView(Landroid/view/View; I)V
    return-void
.end method

.method private g(Landroid/view/View;)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v0, v2, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V
    iget-object v0, v1, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v0, Landroid/widget/FrameLayout;->requestLayout()V
    return-void
.end method

.method public final a()Landroid/content/Context;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v0, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;
    move-result-object v0
    return-object v0
.end method

.method public final a(Landroid/view/View;)V
    .registers 4
    iput-object v3, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    iget-object v0, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    const/4 v1, 4
    invoke-virtual v0, v1, Landroid/view/View;->setVisibility(I)V
    iget-object v0, v2, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    iget-object v1, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    invoke-virtual v0, v1, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V
    return-void
.end method

.method public final b(Landroid/view/View;)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/t;->c Ljava/util/Set;
    invoke-interface v0, v2, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    iget-object v0, v1, Lcom/unity3d/player/t;->d Landroid/view/View;
    if-eqz v0, +005h
    invoke-direct v1, v2, Lcom/unity3d/player/t;->f(Landroid/view/View;)V
    return-void
.end method

.method public final c(Landroid/view/View;)V
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/t;->c Ljava/util/Set;
    invoke-interface v0, v2, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    iget-object v0, v1, Lcom/unity3d/player/t;->d Landroid/view/View;
    if-eqz v0, +005h
    invoke-direct v1, v2, Lcom/unity3d/player/t;->g(Landroid/view/View;)V
    return-void
.end method

.method public final d(Landroid/view/View;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/t;->d Landroid/view/View;
    if-eq v0, v3, +029h
    iput-object v3, v2, Lcom/unity3d/player/t;->d Landroid/view/View;
    iget-object v0, v2, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v0, v3, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V
    iget-object v0, v2, Lcom/unity3d/player/t;->c Ljava/util/Set;
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00ch
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/View;
    invoke-direct v2, v0, Lcom/unity3d/player/t;->f(Landroid/view/View;)V
    goto -fh
    iget-object v0, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    if-eqz v0, +008h
    iget-object v0, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    const/4 v1, 4
    invoke-virtual v0, v1, Landroid/view/View;->setVisibility(I)V
    return-void
.end method

.method public final e(Landroid/view/View;)V
    .registers 4
    iget-object v0, v2, Lcom/unity3d/player/t;->d Landroid/view/View;
    if-ne v0, v3, +02ah
    iget-object v0, v2, Lcom/unity3d/player/t;->c Ljava/util/Set;
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v1
    invoke-interface v1, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +00ch
    invoke-interface v1, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/View;
    invoke-direct v2, v0, Lcom/unity3d/player/t;->g(Landroid/view/View;)V
    goto -fh
    iget-object v0, v2, Lcom/unity3d/player/t;->b Landroid/widget/FrameLayout;
    invoke-virtual v0, v3, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V
    const/4 v0, 0
    iput-object v0, v2, Lcom/unity3d/player/t;->d Landroid/view/View;
    iget-object v0, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    if-eqz v0, +008h
    iget-object v0, v2, Lcom/unity3d/player/t;->e Landroid/view/View;
    const/4 v1, 0
    invoke-virtual v0, v1, Landroid/view/View;->setVisibility(I)V
    return-void
.end method
