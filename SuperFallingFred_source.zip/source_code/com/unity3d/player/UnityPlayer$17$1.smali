.class final Lcom/unity3d/player/UnityPlayer$17$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer$17;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer$17;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$17$1;->a Lcom/unity3d/player/UnityPlayer$17;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$17$1;->a Lcom/unity3d/player/UnityPlayer$17;
    iget-object v0, v0, Lcom/unity3d/player/UnityPlayer$17;->a Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v0, Lcom/unity3d/player/UnityPlayer;->nativeJoystickRemoved()V
    return-void
.end method
