.class final Lcom/unity3d/player/o$1;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/o;

.method constructor <init>(Lcom/unity3d/player/o;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/o$1;->a Lcom/unity3d/player/o;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method private static a(Landroid/view/View; Landroid/view/MotionEvent;)V
    .registers 3
    sget-boolean v0, Lcom/unity3d/player/p;->d Z
    if-eqz v0, +007h
    sget-object v0, Lcom/unity3d/player/p;->j Lcom/unity3d/player/i;
    invoke-static v1, v2, Lcom/unity3d/player/i;->a(Landroid/view/View; Landroid/view/MotionEvent;)Z
    return-void
.end method

.method public final run()V
    .registers 5
    iget-object v0, v4, Lcom/unity3d/player/o$1;->a Lcom/unity3d/player/o;
    invoke-static v0, Lcom/unity3d/player/o;->a(Lcom/unity3d/player/o;)Ljava/util/Queue;
    move-result-object v0
    invoke-interface v0, Ljava/util/Queue;->poll()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/MotionEvent;
    if-eqz v0, +035h
    iget-object v1, v4, Lcom/unity3d/player/o$1;->a Lcom/unity3d/player/o;
    invoke-static v1, Lcom/unity3d/player/o;->b(Lcom/unity3d/player/o;)Landroid/app/NativeActivity;
    move-result-object v1
    invoke-virtual v1, Landroid/app/NativeActivity;->getWindow()Landroid/view/Window;
    move-result-object v1
    invoke-virtual v1, Landroid/view/Window;->getDecorView()Landroid/view/View;
    move-result-object v1
    invoke-virtual v0, Landroid/view/MotionEvent;->getSource()I
    move-result v2
    and-int/lit8 v3, v2, 2
    if-eqz v3, +013h
    invoke-virtual v0, Landroid/view/MotionEvent;->getAction()I
    move-result v2
    and-int/lit16 v2, v2, 255
    packed-switch v2, +0000018h
    invoke-static v1, v0, Lcom/unity3d/player/o$1;->a(Landroid/view/View; Landroid/view/MotionEvent;)V
    goto -30h
    invoke-virtual v1, v0, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    goto -34h
    and-int/lit8 v2, v2, 4
    if-eqz v2, +006h
    invoke-virtual v1, v0, Landroid/view/View;->dispatchTrackballEvent(Landroid/view/MotionEvent;)Z
    goto -3ch
    invoke-static v1, v0, Lcom/unity3d/player/o$1;->a(Landroid/view/View; Landroid/view/MotionEvent;)V
    goto -40h
    return-void
    packed-switch-payload 0 1 2 3 4 5 6
.end method
