.class final Lcom/unity3d/player/c$2;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/c;

.method constructor <init>(Lcom/unity3d/player/c;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/c$2;->a Lcom/unity3d/player/c;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/c$2;->a Lcom/unity3d/player/c;
    invoke-static v0, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v0
    if-eqz v0, +00dh
    sget-object v0, Lcom/unity3d/player/t;->a Lcom/unity3d/player/t;
    iget-object v1, v2, Lcom/unity3d/player/c$2;->a Lcom/unity3d/player/c;
    invoke-static v1, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c;)Landroid/view/SurfaceView;
    move-result-object v1
    invoke-virtual v0, v1, Lcom/unity3d/player/t;->c(Landroid/view/View;)V
    iget-object v0, v2, Lcom/unity3d/player/c$2;->a Lcom/unity3d/player/c;
    const/4 v1, 0
    invoke-static v0, v1, Lcom/unity3d/player/c;->a(Lcom/unity3d/player/c; Landroid/view/SurfaceView;)Landroid/view/SurfaceView;
    return-void
.end method
