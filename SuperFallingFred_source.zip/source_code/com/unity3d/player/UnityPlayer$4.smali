.class final Lcom/unity3d/player/UnityPlayer$4;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$4;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$4;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v0
    if-eqz v0, +013h
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$4;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->h(Lcom/unity3d/player/UnityPlayer;)Landroid/widget/ProgressBar;
    move-result-object v0
    const/16 v1, 8
    invoke-virtual v0, v1, Landroid/widget/ProgressBar;->setVisibility(I)V
    iget-object v0, v2, Lcom/unity3d/player/UnityPlayer$4;->a Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 0
    invoke-static v0, v1, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; Landroid/widget/ProgressBar;)Landroid/widget/ProgressBar;
    return-void
.end method
