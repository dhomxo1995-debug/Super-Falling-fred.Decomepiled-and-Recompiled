.class final Lcom/unity3d/player/b;
.super Ljava/lang/Object;

.field private a:I
.field private b:Ljava/lang/String;
.field private c:I

.method constructor <init>()V
    .registers 9
    const/4 v7, 1
    const/4 v3, 0
    invoke-direct v8, Ljava/lang/Object;-><init>()V
    iput v3, v8, Lcom/unity3d/player/b;->a I
    iput v3, v8, Lcom/unity3d/player/b;->c I
    const-string v0, "/proc/cpuinfo"
    invoke-static v0, Lcom/unity3d/player/b;->a(Ljava/lang/String;)Ljava/util/Map;
    move-result-object v4
    const-string v0, "CPU architecture"
    invoke-interface v4, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    const-string v1, "Features"
    invoke-interface v4, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v1
    check-cast v1, Ljava/lang/String;
    if-eqz v0, +06bh
    invoke-virtual v0, Ljava/lang/String;->length()I
    move-result v5
    move v2, v3
    if-ge v2, v5, +00fh
    invoke-virtual v0, v2, Ljava/lang/String;->charAt(I)C
    move-result v6
    invoke-static v6, Ljava/lang/Character;->isDigit(C)Z
    move-result v6
    if-eqz v6, +005h
    add-int/lit8 v2, v2, 1
    goto -eh
    invoke-virtual v0, v3, v2, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v0
    sget-object v2, Landroid/os/Build;->CPU_ABI Ljava/lang/String;
    invoke-virtual v2, Ljava/lang/String;->toLowerCase()Ljava/lang/String;
    move-result-object v2
    const-string v3, "arm"
    invoke-virtual v2, v3, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    move-result v2
    if-eqz v2, +045h
    iget v2, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v2, v2, 2
    iput v2, v8, Lcom/unity3d/player/b;->a I
    invoke-static v0, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/Integer;->intValue()I
    move-result v2
    const/4 v3, 7
    if-lt v2, v3, +012h
    sget-object v2, Landroid/os/Build;->CPU_ABI Ljava/lang/String;
    const-string v3, "armeabi"
    invoke-virtual v2, v3, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v2
    if-nez v2, +008h
    iget v2, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v2, v2, 16
    iput v2, v8, Lcom/unity3d/player/b;->a I
    invoke-static v0, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/Integer;->intValue()I
    move-result v2
    const/4 v3, 6
    if-lt v2, v3, +008h
    iget v2, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v2, v2, 8
    iput v2, v8, Lcom/unity3d/player/b;->a I
    invoke-static v0, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Integer;->intValue()I
    move-result v0
    const/4 v2, 5
    if-lt v0, v2, +008h
    iget v0, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v0, v0, 4
    iput v0, v8, Lcom/unity3d/player/b;->a I
    if-eqz v1, +02ch
    const-string v0, "vfpv3"
    invoke-virtual v1, v0, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v0
    if-eqz v0, +008h
    iget v0, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v0, v0, 32
    iput v0, v8, Lcom/unity3d/player/b;->a I
    const-string v0, "neon"
    invoke-virtual v1, v0, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v0
    if-eqz v0, +008h
    iget v0, v8, Lcom/unity3d/player/b;->a I
    or-int/lit8 v0, v0, 64
    iput v0, v8, Lcom/unity3d/player/b;->a I
    const-string v0, "vfp"
    invoke-virtual v1, v0, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v0
    if-eqz v0, +008h
    iget v0, v8, Lcom/unity3d/player/b;->a I
    or-int/lit16 v0, v0, 128
    iput v0, v8, Lcom/unity3d/player/b;->a I
    sget-object v0, Landroid/os/Build;->CPU_ABI Ljava/lang/String;
    const-string v1, "x86"
    invoke-virtual v0, v1, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, +004h
    iput v7, v8, Lcom/unity3d/player/b;->a I
    iget v0, v8, Lcom/unity3d/player/b;->a I
    if-ne v0, v7, +029h
    const-string v0, "model name"
    invoke-interface v4, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v8, Lcom/unity3d/player/b;->b Ljava/lang/String;
    iget-object v0, v8, Lcom/unity3d/player/b;->b Ljava/lang/String;
    if-nez v0, +006h
    const-string v0, "<unknown>"
    iput-object v0, v8, Lcom/unity3d/player/b;->b Ljava/lang/String;
    const-string v0, "/proc/meminfo"
    invoke-static v0, Lcom/unity3d/player/b;->a(Ljava/lang/String;)Ljava/util/Map;
    move-result-object v0
    const-string v1, "MemTotal"
    invoke-interface v0, v1, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    invoke-static v0, Lcom/unity3d/player/b;->b(Ljava/lang/String;)I
    move-result v0
    iput v0, v8, Lcom/unity3d/player/b;->c I
    return-void
    const-string v0, "Processor"
    invoke-interface v4, v0, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    iput-object v0, v8, Lcom/unity3d/player/b;->b Ljava/lang/String;
    goto -27h
.end method

.method private static a(Ljava/lang/String;)Ljava/util/Map;
    .registers 6
    new-instance v1, Ljava/util/HashMap;
    invoke-direct v1, Ljava/util/HashMap;-><init>()V
    new-instance v0, Ljava/io/FileReader;
    invoke-direct v0, v5, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    new-instance v2, Ljava/io/LineNumberReader;
    const/16 v3, 8192
    invoke-direct v2, v0, v3, Ljava/io/LineNumberReader;-><init>(Ljava/io/Reader; I)V
    invoke-virtual v2, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;
    move-result-object v0
    if-eqz v0, +02fh
    const/16 v3, 58
    invoke-virtual v0, v3, Ljava/lang/String;->indexOf(I)I
    move-result v3
    if-ltz v3, +018h
    const/4 v4, 0
    invoke-virtual v0, v4, v3, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v4
    invoke-virtual v4, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object v4
    add-int/lit8 v3, v3, 1
    invoke-virtual v0, v3, Ljava/lang/String;->substring(I)Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object v0
    invoke-interface v1, v4, v0, Ljava/util/Map;->put(Ljava/lang/Object; Ljava/lang/Object;)Ljava/lang/Object;
    invoke-virtual v2, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;
    move-result-object v0
    goto -24h
    move-exception v0
    const-string v2, "FileNotFoundException"
    invoke-virtual v0, Ljava/io/FileNotFoundException;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, v0, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String;)I
    return-object v1
    move-exception v0
    const-string v2, "IOException"
    invoke-virtual v0, Ljava/io/IOException;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static v2, v0, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String;)I
    goto -bh
.end method

.method private static b(Ljava/lang/String;)I
    .registers 5
    const/4 v1, 0
    invoke-virtual v4, Ljava/lang/String;->length()I
    move-result v2
    move v0, v1
    if-ge v0, v2, +00fh
    invoke-virtual v4, v0, Ljava/lang/String;->charAt(I)C
    move-result v3
    invoke-static v3, Ljava/lang/Character;->isDigit(C)Z
    move-result v3
    if-eqz v3, +005h
    add-int/lit8 v0, v0, 1
    goto -eh
    invoke-virtual v4, v1, v0, Ljava/lang/String;->substring(I I)Ljava/lang/String;
    move-result-object v0
    invoke-static v0, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Integer;->intValue()I
    move-result v0
    return v0
.end method

.method public final a()I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/b;->a I
    return v0
.end method

.method public final b()Ljava/lang/String;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/b;->b Ljava/lang/String;
    return-object v0
.end method

.method public final c()I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/b;->c I
    div-int/lit16 v0, v0, 1024
    return v0
.end method
