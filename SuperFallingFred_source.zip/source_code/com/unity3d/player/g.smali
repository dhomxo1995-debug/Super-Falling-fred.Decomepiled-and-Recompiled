.class public final Lcom/unity3d/player/g;
.super Ljava/lang/Object;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static a(I)I
    .registers 2
    const/16 v0, 17
    invoke-static v0, Landroid/graphics/ImageFormat;->getBitsPerPixel(I)I
    move-result v0
    return v0
.end method

.method public static a(Landroid/hardware/Camera;)V
    .registers 2
    const/4 v0, 0
    invoke-virtual v1, v0, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V
    return-void
.end method

.method public static a(Landroid/hardware/Camera; Landroid/hardware/Camera$Size; I Landroid/hardware/Camera$PreviewCallback;)V
    .registers 6
    iget v0, v3, Landroid/hardware/Camera$Size;->width I
    iget v1, v3, Landroid/hardware/Camera$Size;->height I
    mul-int/2addr v0, v1
    mul-int/2addr v0, v4
    div-int/lit8 v0, v0, 8
    add-int/lit16 v0, v0, 4096
    new-array v1, v0, [B
    invoke-virtual v2, v1, Landroid/hardware/Camera;->addCallbackBuffer([B)V
    new-array v0, v0, [B
    invoke-virtual v2, v0, Landroid/hardware/Camera;->addCallbackBuffer([B)V
    invoke-virtual v2, v5, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V
    return-void
.end method

.method public static a(Landroid/hardware/Camera; [B)V
    .registers 2
    invoke-virtual v0, v1, Landroid/hardware/Camera;->addCallbackBuffer([B)V
    return-void
.end method
