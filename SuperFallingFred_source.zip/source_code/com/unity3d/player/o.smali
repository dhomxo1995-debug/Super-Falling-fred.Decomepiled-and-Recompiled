.class public final Lcom/unity3d/player/o;
.super Ljava/lang/Object;
.implements Lcom/unity3d/player/l;

.field private final a:Ljava/util/Queue;
.field private final b:Landroid/app/NativeActivity;
.field private c:Ljava/lang/Runnable;

.method public constructor <init>(Landroid/content/ContextWrapper;)V
    .registers 3
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;
    invoke-direct v0, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V
    iput-object v0, v1, Lcom/unity3d/player/o;->a Ljava/util/Queue;
    new-instance v0, Lcom/unity3d/player/o$1;
    invoke-direct v0, v1, Lcom/unity3d/player/o$1;-><init>(Lcom/unity3d/player/o;)V
    iput-object v0, v1, Lcom/unity3d/player/o;->c Ljava/lang/Runnable;
    check-cast v2, Landroid/app/NativeActivity;
    iput-object v2, v1, Lcom/unity3d/player/o;->b Landroid/app/NativeActivity;
    return-void
.end method

.method private static a([Landroid/view/MotionEvent$PointerCoords; [F I)I
    .registers 7
    const/4 v0, 0
    array-length v1, v4
    if-ge v0, v1, +042h
    new-instance v1, Landroid/view/MotionEvent$PointerCoords;
    invoke-direct v1, Landroid/view/MotionEvent$PointerCoords;-><init>()V
    aput-object v1, v4, v0
    add-int/lit8 v2, v6, 1
    aget v3, v5, v6
    iput v3, v1, Landroid/view/MotionEvent$PointerCoords;->orientation F
    add-int/lit8 v3, v2, 1
    aget v2, v5, v2
    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->pressure F
    add-int/lit8 v2, v3, 1
    aget v3, v5, v3
    iput v3, v1, Landroid/view/MotionEvent$PointerCoords;->size F
    add-int/lit8 v3, v2, 1
    aget v2, v5, v2
    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->toolMajor F
    add-int/lit8 v2, v3, 1
    aget v3, v5, v3
    iput v3, v1, Landroid/view/MotionEvent$PointerCoords;->toolMinor F
    add-int/lit8 v3, v2, 1
    aget v2, v5, v2
    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->touchMajor F
    add-int/lit8 v2, v3, 1
    aget v3, v5, v3
    iput v3, v1, Landroid/view/MotionEvent$PointerCoords;->touchMinor F
    add-int/lit8 v3, v2, 1
    aget v2, v5, v2
    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->x F
    add-int/lit8 v6, v3, 1
    aget v2, v5, v3
    iput v2, v1, Landroid/view/MotionEvent$PointerCoords;->y F
    add-int/lit8 v0, v0, 1
    goto -42h
    return v6
.end method

.method static synthetic a(Lcom/unity3d/player/o;)Ljava/util/Queue;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/o;->a Ljava/util/Queue;
    return-object v0
.end method

.method private static a(I [F)[Landroid/view/MotionEvent$PointerCoords;
    .registers 4
    new-array v0, v2, [Landroid/view/MotionEvent$PointerCoords;
    const/4 v1, 0
    invoke-static v0, v3, v1, Lcom/unity3d/player/o;->a([Landroid/view/MotionEvent$PointerCoords; [F I)I
    return-object v0
.end method

.method static synthetic b(Lcom/unity3d/player/o;)Landroid/app/NativeActivity;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/o;->b Landroid/app/NativeActivity;
    return-object v0
.end method

.method public final a()Landroid/graphics/RectF;
    .registers 9
    const v7, 1048584
    const/4 v1, 0
    const/4 v6, 0
    invoke-static Landroid/view/InputDevice;->getDeviceIds()[I
    move-result-object v2
    move v0, v1
    array-length v3, v2
    if-ge v0, v3, +02fh
    aget v3, v2, v0
    invoke-static v3, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;
    move-result-object v3
    if-eqz v3, +024h
    invoke-virtual v3, Landroid/view/InputDevice;->getSources()I
    move-result v4
    and-int/2addr v4, v7
    if-ne v4, v7, +01dh
    invoke-virtual v3, v1, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;
    move-result-object v4
    const/4 v5, 1
    invoke-virtual v3, v5, Landroid/view/InputDevice;->getMotionRange(I)Landroid/view/InputDevice$MotionRange;
    move-result-object v3
    if-eqz v4, +012h
    if-eqz v3, +010h
    new-instance v0, Landroid/graphics/RectF;
    invoke-virtual v4, Landroid/view/InputDevice$MotionRange;->getRange()F
    move-result v1
    invoke-virtual v3, Landroid/view/InputDevice$MotionRange;->getRange()F
    move-result v2
    invoke-direct v0, v6, v6, v1, v2, Landroid/graphics/RectF;-><init>(F F F F)V
    return-object v0
    add-int/lit8 v0, v0, 1
    goto -2fh
    const/4 v0, 0
    goto -5h
.end method

.method public final a(J J I I [I [F I F F I I I I I [J [F)V
    .registers 36
    move-object/from16 v0, v17
    iget-object v2, v0, Lcom/unity3d/player/o;->b Landroid/app/NativeActivity;
    if-eqz v2, +052h
    move/from16 v0, v23
    move-object/from16 v1, v25
    invoke-static v0, v1, Lcom/unity3d/player/o;->a(I [F)[Landroid/view/MotionEvent$PointerCoords;
    move-result-object v9
    move-wide/from16 v2, v18
    move-wide/from16 v4, v20
    move/from16 v6, v22
    move/from16 v7, v23
    move-object/from16 v8, v24
    move/from16 v10, v26
    move/from16 v11, v27
    move/from16 v12, v28
    move/from16 v13, v29
    move/from16 v14, v30
    move/from16 v15, v31
    move/from16 v16, v32
    invoke-static/range v2 ... v16, Landroid/view/MotionEvent;->obtain(J J I I [I [Landroid/view/MotionEvent$PointerCoords; I F F I I I I)Landroid/view/MotionEvent;
    move-result-object v4
    const/4 v3, 0
    const/4 v2, 0
    move/from16 v0, v33
    if-ge v2, v0, +016h
    move/from16 v0, v23
    new-array v5, v0, [Landroid/view/MotionEvent$PointerCoords;
    move-object/from16 v0, v35
    invoke-static v5, v0, v3, Lcom/unity3d/player/o;->a([Landroid/view/MotionEvent$PointerCoords; [F I)I
    move-result v3
    aget-wide v6, v34, v2
    move/from16 v0, v26
    invoke-virtual v4, v6, v7, v5, v0, Landroid/view/MotionEvent;->addBatch(J [Landroid/view/MotionEvent$PointerCoords; I)V
    add-int/lit8 v2, v2, 1
    goto -17h
    move-object/from16 v0, v17
    iget-object v2, v0, Lcom/unity3d/player/o;->a Ljava/util/Queue;
    invoke-interface v2, v4, Ljava/util/Queue;->add(Ljava/lang/Object;)Z
    move-object/from16 v0, v17
    iget-object v2, v0, Lcom/unity3d/player/o;->b Landroid/app/NativeActivity;
    move-object/from16 v0, v17
    iget-object v3, v0, Lcom/unity3d/player/o;->c Ljava/lang/Runnable;
    invoke-virtual v2, v3, Landroid/app/NativeActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method
