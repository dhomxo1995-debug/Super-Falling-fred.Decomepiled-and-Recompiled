.class 0x0 Lcom/unity3d/player/UnityJavaRunnable;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private final a:I

.method constructor <init>(I)V
    .registers 2
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput v1, v0, Lcom/unity3d/player/UnityJavaRunnable;->a I
    return-void
.end method

.method private native nativeFinalize(I)V
    # abstract or native method
.end method

.method private native nativeRun(I)V
    # abstract or native method
.end method

.method protected finalize()V
    .registers 2
    iget v0, v1, Lcom/unity3d/player/UnityJavaRunnable;->a I
    invoke-direct v1, v0, Lcom/unity3d/player/UnityJavaRunnable;->nativeFinalize(I)V
    invoke-super v1, Ljava/lang/Object;->finalize()V
    return-void
    move-exception v0
    invoke-super v1, Ljava/lang/Object;->finalize()V
    throw v0
.end method

.method public run()V
    .registers 2
    iget v0, v1, Lcom/unity3d/player/UnityJavaRunnable;->a I
    invoke-direct v1, v0, Lcom/unity3d/player/UnityJavaRunnable;->nativeRun(I)V
    return-void
.end method
