.class final Lcom/unity3d/player/UnityPlayer$22;
.super Lcom/unity3d/player/w;

.field private synthetic a:Landroid/view/View;

.method constructor <init>(Landroid/content/Context; I Z Z Z I I Landroid/view/View;)V
    .registers 19
    move-object/from16 v0, v18
    iput-object v0, v10, Lcom/unity3d/player/UnityPlayer$22;->a Landroid/view/View;
    const/4 v5, 0
    const/4 v8, 0
    move-object v1, v10
    move-object v2, v11
    move v3, v12
    move v4, v13
    move v6, v15
    move/from16 v7, v16
    move/from16 v9, v17
    invoke-direct/range v1 ... v9, Lcom/unity3d/player/w;-><init>(Landroid/content/Context; I Z Z Z I I I)V
    return-void
.end method

.method public final onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 3
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$22;->a Landroid/view/View;
    invoke-virtual v0, v2, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z
    move-result v0
    return v0
.end method

.method public final onKeyPreIme(I Landroid/view/KeyEvent;)Z
    .registers 4
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$22;->a Landroid/view/View;
    invoke-virtual v0, v2, v3, Landroid/view/View;->onKeyPreIme(I Landroid/view/KeyEvent;)Z
    move-result v0
    if-nez v0, +008h
    invoke-super v1, v2, v3, Lcom/unity3d/player/w;->onKeyPreIme(I Landroid/view/KeyEvent;)Z
    move-result v0
    if-eqz v0, +004h
    const/4 v0, 1
    return v0
    const/4 v0, 0
    goto -2h
.end method
