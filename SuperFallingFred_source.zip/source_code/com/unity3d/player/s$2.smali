.class final Lcom/unity3d/player/s$2;
.super Landroid/widget/EditText;

.field private synthetic a:Lcom/unity3d/player/s;

.method constructor <init>(Lcom/unity3d/player/s; Landroid/content/Context;)V
    .registers 3
    iput-object v1, v0, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    invoke-direct v0, v2, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V
    return-void
.end method

.method public final onKeyPreIme(I Landroid/view/KeyEvent;)Z
    .registers 6
    const/4 v0, 1
    const/4 v1, 4
    if-ne v4, v1, +00dh
    iget-object v1, v3, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    iget-object v2, v3, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    invoke-static v2, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s;)Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, v0, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s; Ljava/lang/String; Z)V
    const/16 v1, 84
    if-ne v4, v1, +003h
    return v0
    invoke-super v3, v4, v5, Landroid/widget/EditText;->onKeyPreIme(I Landroid/view/KeyEvent;)Z
    move-result v0
    goto -5h
.end method

.method public final onWindowFocusChanged(Z)V
    .registers 5
    invoke-super v3, v4, Landroid/widget/EditText;->onWindowFocusChanged(Z)V
    if-eqz v4, +015h
    iget-object v0, v3, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    invoke-static v0, Lcom/unity3d/player/s;->b(Lcom/unity3d/player/s;)Landroid/content/Context;
    move-result-object v0
    const-string v1, "input_method"
    invoke-virtual v0, v1, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;
    const/4 v1, 0
    invoke-virtual v0, v3, v1, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View; I)Z
    return-void
    iget-object v0, v3, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    iget-object v1, v3, Lcom/unity3d/player/s$2;->a Lcom/unity3d/player/s;
    invoke-static v1, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s;)Ljava/lang/String;
    move-result-object v1
    const/4 v2, 1
    invoke-static v0, v1, v2, Lcom/unity3d/player/s;->a(Lcom/unity3d/player/s; Ljava/lang/String; Z)V
    goto -dh
.end method
