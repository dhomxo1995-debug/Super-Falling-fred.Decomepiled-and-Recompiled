.class final Lcom/unity3d/player/a;
.super Ljava/lang/Object;

.field  a:Landroid/hardware/Camera;
.field private final b:[Ljava/lang/Object;
.field private final c:I
.field private final d:I
.field private final e:I
.field private final f:I
.field private g:Landroid/hardware/Camera$Parameters;
.field private h:Landroid/hardware/Camera$Size;
.field private i:I
.field private j:[I
.field private k:Lcom/unity3d/player/c;

.method public constructor <init>(I I I I)V
    .registers 6
    invoke-direct v1, Ljava/lang/Object;-><init>()V
    const/4 v0, 0
    new-array v0, v0, [Ljava/lang/Object;
    iput-object v0, v1, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    iput v2, v1, Lcom/unity3d/player/a;->c I
    const/16 v0, 640
    invoke-static v3, v0, Lcom/unity3d/player/a;->a(I I)I
    move-result v0
    iput v0, v1, Lcom/unity3d/player/a;->d I
    const/16 v0, 480
    invoke-static v4, v0, Lcom/unity3d/player/a;->a(I I)I
    move-result v0
    iput v0, v1, Lcom/unity3d/player/a;->e I
    const/16 v0, 24
    invoke-static v5, v0, Lcom/unity3d/player/a;->a(I I)I
    move-result v0
    iput v0, v1, Lcom/unity3d/player/a;->f I
    return-void
.end method

.method private static final a(I I)I
    .registers 2
    if-eqz v0, +003h
    return v0
    move v0, v1
    goto -2h
.end method

.method static synthetic a(Lcom/unity3d/player/a;)[Ljava/lang/Object;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    return-object v0
.end method

.method private b(Lcom/unity3d/player/a$a;)V
    .registers 7
    iget-object v1, v5, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    monitor-enter v1
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +06fh
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    iget v0, v5, Lcom/unity3d/player/a;->c I
    invoke-static v0, Lcom/unity3d/player/h;->c(I)Landroid/hardware/Camera;
    move-result-object v0
    iput-object v0, v5, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v0, v5, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;
    move-result-object v0
    iput-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-direct v5, Lcom/unity3d/player/a;->f()Landroid/hardware/Camera$Size;
    move-result-object v0
    iput-object v0, v5, Lcom/unity3d/player/a;->h Landroid/hardware/Camera$Size;
    invoke-direct v5, Lcom/unity3d/player/a;->e()[I
    move-result-object v0
    iput-object v0, v5, Lcom/unity3d/player/a;->j [I
    invoke-direct v5, Lcom/unity3d/player/a;->d()I
    move-result v0
    iput v0, v5, Lcom/unity3d/player/a;->i I
    sget-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    iget-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-static v0, Lcom/unity3d/player/f;->b(Landroid/hardware/Camera$Parameters;)V
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    iget-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-static v0, Lcom/unity3d/player/h;->b(Landroid/hardware/Camera$Parameters;)V
    iget-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    iget-object v2, v5, Lcom/unity3d/player/a;->h Landroid/hardware/Camera$Size;
    iget v2, v2, Landroid/hardware/Camera$Size;->width I
    iget-object v3, v5, Lcom/unity3d/player/a;->h Landroid/hardware/Camera$Size;
    iget v3, v3, Landroid/hardware/Camera$Size;->height I
    invoke-virtual v0, v2, v3, Landroid/hardware/Camera$Parameters;->setPreviewSize(I I)V
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +02dh
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    iget-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    iget-object v2, v5, Lcom/unity3d/player/a;->j [I
    invoke-static v0, v2, Lcom/unity3d/player/h;->a(Landroid/hardware/Camera$Parameters; [I)V
    iget-object v0, v5, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v2, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-virtual v0, v2, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    new-instance v0, Lcom/unity3d/player/a$1;
    invoke-direct v0, v5, v6, Lcom/unity3d/player/a$1;-><init>(Lcom/unity3d/player/a; Lcom/unity3d/player/a$a;)V
    sget-boolean v2, Lcom/unity3d/player/p;->a Z
    if-eqz v2, +021h
    sget-object v2, Lcom/unity3d/player/p;->g Lcom/unity3d/player/g;
    iget-object v2, v5, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v3, v5, Lcom/unity3d/player/a;->h Landroid/hardware/Camera$Size;
    iget v4, v5, Lcom/unity3d/player/a;->i I
    invoke-static v2, v3, v4, v0, Lcom/unity3d/player/g;->a(Landroid/hardware/Camera; Landroid/hardware/Camera$Size; I Landroid/hardware/Camera$PreviewCallback;)V
    monitor-exit v1
    return-void
    invoke-static Landroid/hardware/Camera;->open()Landroid/hardware/Camera;
    move-result-object v0
    goto -69h
    sget-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    iget-object v0, v5, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    iget-object v2, v5, Lcom/unity3d/player/a;->j [I
    invoke-static v0, v2, Lcom/unity3d/player/f;->a(Landroid/hardware/Camera$Parameters; [I)V
    goto -2bh
    move-exception v0
    monitor-exit v1
    throw v0
    sget-object v2, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    iget-object v2, v5, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-static v2, v0, Lcom/unity3d/player/f;->a(Landroid/hardware/Camera; Landroid/hardware/Camera$PreviewCallback;)V
    goto -1bh
.end method

.method private final d()I
    .registers 3
    const/16 v1, 17
    iget-object v0, v2, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-virtual v0, v1, Landroid/hardware/Camera$Parameters;->setPreviewFormat(I)V
    sget-boolean v0, Lcom/unity3d/player/p;->a Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->g Lcom/unity3d/player/g;
    invoke-static v1, Lcom/unity3d/player/g;->a(I)I
    move-result v0
    return v0
    sget-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    invoke-static v1, Lcom/unity3d/player/f;->a(I)I
    move-result v0
    goto -7h
.end method

.method private final e()[I
    .registers 16
    const/4 v12, 1
    const/4 v11, 0
    iget v0, v15, Lcom/unity3d/player/a;->f I
    mul-int/lit16 v0, v0, 1000
    int-to-double v6, v0
    sget-boolean v0, Lcom/unity3d/player/p;->b Z
    if-eqz v0, +053h
    sget-object v0, Lcom/unity3d/player/p;->h Lcom/unity3d/player/h;
    iget-object v0, v15, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-static v0, Lcom/unity3d/player/h;->a(Landroid/hardware/Camera$Parameters;)Ljava/util/List;
    move-result-object v0
    const/4 v1, 2
    new-array v3, v1, [I
    iget v1, v15, Lcom/unity3d/player/a;->f I
    mul-int/lit16 v1, v1, 1000
    aput v1, v3, v11
    iget v1, v15, Lcom/unity3d/player/a;->f I
    mul-int/lit16 v1, v1, 1000
    aput v1, v3, v12
    const-wide v1, 9218868437227405311
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v8
    invoke-interface v8, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +036h
    invoke-interface v8, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, [I
    aget v4, v0, v11
    int-to-double v4, v4
    div-double v4, v6, v4
    invoke-static v4, v5, Ljava/lang/Math;->log(D)D
    move-result-wide v4
    invoke-static v4, v5, Ljava/lang/Math;->abs(D)D
    move-result-wide v4
    aget v9, v0, v12
    int-to-double v9, v9
    div-double v9, v6, v9
    invoke-static v9, v10, Ljava/lang/Math;->log(D)D
    move-result-wide v9
    invoke-static v9, v10, Ljava/lang/Math;->abs(D)D
    move-result-wide v9
    add-double/2addr v4, v9
    cmpg-double v9, v4, v1
    if-gez v9, +012h
    move-object v2, v0
    move-wide v0, v4
    move-object v3, v2
    move-wide v13, v0
    move-wide v1, v13
    goto -30h
    sget-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    iget-object v0, v15, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-static v0, Lcom/unity3d/player/f;->a(Landroid/hardware/Camera$Parameters;)Ljava/util/List;
    move-result-object v0
    goto -51h
    return-object v3
    move-wide v13, v1
    move-wide v0, v13
    move-object v2, v3
    goto -11h
.end method

.method private final f()Landroid/hardware/Camera$Size;
    .registers 16
    iget v0, v15, Lcom/unity3d/player/a;->d I
    int-to-double v6, v0
    iget v0, v15, Lcom/unity3d/player/a;->e I
    int-to-double v8, v0
    iget-object v0, v15, Lcom/unity3d/player/a;->g Landroid/hardware/Camera$Parameters;
    invoke-virtual v0, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;
    move-result-object v0
    const/4 v5, 0
    const-wide v3, 9218868437227405311
    invoke-interface v0, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v10
    invoke-interface v10, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +02dh
    invoke-interface v10, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/hardware/Camera$Size;
    iget v1, v0, Landroid/hardware/Camera$Size;->width I
    int-to-double v1, v1
    div-double v1, v6, v1
    invoke-static v1, v2, Ljava/lang/Math;->log(D)D
    move-result-wide v1
    invoke-static v1, v2, Ljava/lang/Math;->abs(D)D
    move-result-wide v1
    iget v11, v0, Landroid/hardware/Camera$Size;->height I
    int-to-double v11, v11
    div-double v11, v8, v11
    invoke-static v11, v12, Ljava/lang/Math;->log(D)D
    move-result-wide v11
    invoke-static v11, v12, Ljava/lang/Math;->abs(D)D
    move-result-wide v11
    add-double/2addr v1, v11
    cmpg-double v11, v1, v3
    if-gez v11, +009h
    move-wide v13, v1
    move-object v2, v0
    move-wide v0, v13
    move-wide v3, v0
    move-object v5, v2
    goto -30h
    return-object v5
    move-wide v0, v3
    move-object v2, v5
    goto -6h
.end method

.method public final a()I
    .registers 2
    iget v0, v1, Lcom/unity3d/player/a;->c I
    return v0
.end method

.method public final a(Lcom/unity3d/player/a$a;)V
    .registers 4
    iget-object v1, v2, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    monitor-enter v1
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    if-nez v0, +005h
    invoke-direct v2, v3, Lcom/unity3d/player/a;->b(Lcom/unity3d/player/a$a;)V
    iget-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    if-nez v0, +00eh
    new-instance v0, Lcom/unity3d/player/a$2;
    invoke-direct v0, v2, Lcom/unity3d/player/a$2;-><init>(Lcom/unity3d/player/a;)V
    iput-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    iget-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    invoke-virtual v0, Lcom/unity3d/player/c;->a()V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public final a([B)V
    .registers 4
    iget-object v1, v2, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    monitor-enter v1
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    if-eqz v0, +00dh
    sget-boolean v0, Lcom/unity3d/player/p;->a Z
    if-eqz v0, +009h
    sget-object v0, Lcom/unity3d/player/p;->g Lcom/unity3d/player/g;
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-static v0, v3, Lcom/unity3d/player/g;->a(Landroid/hardware/Camera; [B)V
    monitor-exit v1
    return-void
    move-exception v0
    monitor-exit v1
    throw v0
.end method

.method public final b()Landroid/hardware/Camera$Size;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/a;->h Landroid/hardware/Camera$Size;
    return-object v0
.end method

.method public final c()V
    .registers 3
    iget-object v1, v2, Lcom/unity3d/player/a;->b [Ljava/lang/Object;
    monitor-enter v1
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    if-eqz v0, +01ah
    sget-boolean v0, Lcom/unity3d/player/p;->a Z
    if-eqz v0, +024h
    sget-object v0, Lcom/unity3d/player/p;->g Lcom/unity3d/player/g;
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-static v0, Lcom/unity3d/player/g;->a(Landroid/hardware/Camera;)V
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, Landroid/hardware/Camera;->stopPreview()V
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-virtual v0, Landroid/hardware/Camera;->release()V
    const/4 v0, 0
    iput-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    iget-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    if-eqz v0, +00ah
    iget-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    invoke-virtual v0, Lcom/unity3d/player/c;->b()V
    const/4 v0, 0
    iput-object v0, v2, Lcom/unity3d/player/a;->k Lcom/unity3d/player/c;
    monitor-exit v1
    return-void
    sget-object v0, Lcom/unity3d/player/p;->f Lcom/unity3d/player/f;
    iget-object v0, v2, Lcom/unity3d/player/a;->a Landroid/hardware/Camera;
    invoke-static v0, Lcom/unity3d/player/f;->a(Landroid/hardware/Camera;)V
    goto -22h
    move-exception v0
    monitor-exit v1
    throw v0
.end method
