.class final Lcom/unity3d/player/r$5;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:Lcom/unity3d/player/r;

.method constructor <init>(Lcom/unity3d/player/r;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 8
    iget-object v0, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static v0, Lcom/unity3d/player/r;->e(Lcom/unity3d/player/r;)Lcom/unity3d/player/UnityPlayer;
    move-result-object v0
    iget-object v1, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static v1, Lcom/unity3d/player/r;->r(Lcom/unity3d/player/r;)[F
    move-result-object v1
    const/4 v2, 0
    aget v1, v1, v2
    iget-object v2, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static v2, Lcom/unity3d/player/r;->r(Lcom/unity3d/player/r;)[F
    move-result-object v2
    const/4 v3, 1
    aget v2, v2, v3
    iget-object v3, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static v3, Lcom/unity3d/player/r;->r(Lcom/unity3d/player/r;)[F
    move-result-object v3
    const/4 v4, 2
    aget v3, v3, v4
    iget-object v4, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static v4, Lcom/unity3d/player/r;->r(Lcom/unity3d/player/r;)[F
    move-result-object v4
    const/4 v5, 3
    aget v4, v4, v5
    iget-object v5, v7, Lcom/unity3d/player/r$5;->a Lcom/unity3d/player/r;
    invoke-static Lcom/unity3d/player/r;->f()J
    move-result-wide v5
    invoke-virtual/range v0 ... v6, Lcom/unity3d/player/UnityPlayer;->nativeAttitude(F F F F J)V
    return-void
.end method
