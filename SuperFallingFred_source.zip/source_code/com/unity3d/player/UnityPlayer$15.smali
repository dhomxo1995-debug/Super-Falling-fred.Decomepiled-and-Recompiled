.class final Lcom/unity3d/player/UnityPlayer$15;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private synthetic a:I
.field private synthetic b:[B
.field private synthetic c:Landroid/hardware/Camera$Size;
.field private synthetic d:Lcom/unity3d/player/a;
.field private synthetic e:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer; I [B Landroid/hardware/Camera$Size; Lcom/unity3d/player/a;)V
    .registers 6
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$15;->e Lcom/unity3d/player/UnityPlayer;
    iput v2, v0, Lcom/unity3d/player/UnityPlayer$15;->a I
    iput-object v3, v0, Lcom/unity3d/player/UnityPlayer$15;->b [B
    iput-object v4, v0, Lcom/unity3d/player/UnityPlayer$15;->c Landroid/hardware/Camera$Size;
    iput-object v5, v0, Lcom/unity3d/player/UnityPlayer$15;->d Lcom/unity3d/player/a;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final run()V
    .registers 6
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer$15;->e Lcom/unity3d/player/UnityPlayer;
    iget v1, v5, Lcom/unity3d/player/UnityPlayer$15;->a I
    iget-object v2, v5, Lcom/unity3d/player/UnityPlayer$15;->b [B
    iget-object v3, v5, Lcom/unity3d/player/UnityPlayer$15;->c Landroid/hardware/Camera$Size;
    iget v3, v3, Landroid/hardware/Camera$Size;->width I
    iget-object v4, v5, Lcom/unity3d/player/UnityPlayer$15;->c Landroid/hardware/Camera$Size;
    iget v4, v4, Landroid/hardware/Camera$Size;->height I
    invoke-static v0, v1, v2, v3, v4, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer; I [B I I)V
    iget-object v0, v5, Lcom/unity3d/player/UnityPlayer$15;->d Lcom/unity3d/player/a;
    iget-object v1, v5, Lcom/unity3d/player/UnityPlayer$15;->b [B
    invoke-virtual v0, v1, Lcom/unity3d/player/a;->a([B)V
    return-void
.end method
