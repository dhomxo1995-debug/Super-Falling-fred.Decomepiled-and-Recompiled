.class public final Lcom/unity3d/player/n;
.super Ljava/lang/Object;

.field private final a:Landroid/os/Bundle;

.method public constructor <init>(Landroid/app/Activity;)V
    .registers 7
    invoke-direct v5, Ljava/lang/Object;-><init>()V
    sget-object v0, Landroid/os/Bundle;->EMPTY Landroid/os/Bundle;
    invoke-virtual v6, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    move-result-object v1
    invoke-virtual v6, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;
    move-result-object v2
    const/16 v3, 128
    invoke-virtual v1, v2, v3, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName; I)Landroid/content/pm/ActivityInfo;
    move-result-object v1
    if-eqz v1, +008h
    iget-object v3, v1, Landroid/content/pm/ActivityInfo;->metaData Landroid/os/Bundle;
    if-eqz v3, +004h
    iget-object v0, v1, Landroid/content/pm/ActivityInfo;->metaData Landroid/os/Bundle;
    new-instance v1, Landroid/os/Bundle;
    invoke-direct v1, v0, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V
    iput-object v1, v5, Lcom/unity3d/player/n;->a Landroid/os/Bundle;
    return-void
    move-exception v1
    const/4 v1, 6
    new-instance v3, Ljava/lang/StringBuilder;
    const-string v4, "Unable to retreive meta data for activity '"
    invoke-direct v3, v4, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual v3, v2, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, "'"
    invoke-virtual v2, v3, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual v2, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    invoke-static v1, v2, Lcom/unity3d/player/m;->Log(I Ljava/lang/String;)V
    goto -22h
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 5
    const-string v0, "%s.%s"
    const/4 v1, 2
    new-array v1, v1, [Ljava/lang/Object;
    const/4 v2, 0
    const-string v3, "unityplayer"
    aput-object v3, v1, v2
    const/4 v2, 1
    aput-object v4, v1, v2
    invoke-static v0, v1, Ljava/lang/String;->format(Ljava/lang/String; [Ljava/lang/Object;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public final a()Z
    .registers 3
    iget-object v0, v2, Lcom/unity3d/player/n;->a Landroid/os/Bundle;
    const-string v1, "ForwardNativeEventsToDalvik"
    invoke-static v1, Lcom/unity3d/player/n;->a(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z
    move-result v0
    return v0
.end method
