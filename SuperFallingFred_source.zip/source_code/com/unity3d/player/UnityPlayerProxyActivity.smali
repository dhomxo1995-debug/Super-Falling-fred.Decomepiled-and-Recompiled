.class public Lcom/unity3d/player/UnityPlayerProxyActivity;
.super Landroid/app/Activity;


.method public constructor <init>()V
    .registers 1
    invoke-direct v0, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected static copyPlayerPrefs(Landroid/content/Context; [Ljava/lang/String;)V
    .registers 11
    const/4 v3, 0
    invoke-virtual v9, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v9, v0, v3, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String; I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface v0, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;
    move-result-object v1
    invoke-interface v1, Ljava/util/Map;->isEmpty()Z
    move-result v1
    if-nez v1, +003h
    return-void
    invoke-interface v0, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v4
    array-length v5, v10
    move v2, v3
    if-ge v2, v5, -007h
    aget-object v0, v10, v2
    invoke-virtual v9, v0, v3, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String; I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface v0, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;
    move-result-object v0
    invoke-interface v0, Ljava/util/Map;->isEmpty()Z
    move-result v1
    if-nez v1, +061h
    invoke-interface v0, Ljava/util/Map;->entrySet()Ljava/util/Set;
    move-result-object v0
    invoke-interface v0, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    move-result-object v6
    invoke-interface v6, Ljava/util/Iterator;->hasNext()Z
    move-result v0
    if-eqz v0, +050h
    invoke-interface v6, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/util/Map$Entry;
    invoke-interface v0, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    move-result-object v1
    invoke-virtual v1, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v7
    const-class v8, Ljava/lang/Integer;
    if-ne v7, v8, +012h
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    check-cast v1, Ljava/lang/Integer;
    invoke-virtual v1, Ljava/lang/Integer;->intValue()I
    move-result v1
    invoke-interface v4, v0, v1, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String; I)Landroid/content/SharedPreferences$Editor;
    goto -27h
    invoke-virtual v1, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v7
    const-class v8, Ljava/lang/Float;
    if-ne v7, v8, +012h
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    check-cast v1, Ljava/lang/Float;
    invoke-virtual v1, Ljava/lang/Float;->floatValue()F
    move-result v1
    invoke-interface v4, v0, v1, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String; F)Landroid/content/SharedPreferences$Editor;
    goto -3fh
    invoke-virtual v1, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v7
    const-class v8, Ljava/lang/String;
    if-ne v7, v8, -046h
    invoke-interface v0, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Ljava/lang/String;
    check-cast v1, Ljava/lang/String;
    invoke-interface v4, v0, v1, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String; Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    goto -53h
    invoke-interface v4, Landroid/content/SharedPreferences$Editor;->commit()Z
    add-int/lit8 v0, v2, 1
    move v2, v0
    goto -74h
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 7
    const/4 v0, 1
    const/4 v1, 0
    invoke-super v5, v6, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    const/4 v2, 2
    new-array v3, v2, [Ljava/lang/String;
    const-string v2, "com.unity3d.player.UnityPlayerActivity"
    aput-object v2, v3, v1
    const-string v2, "com.unity3d.player.UnityPlayerNativeActivity"
    aput-object v2, v3, v0
    invoke-static v5, v3, Lcom/unity3d/player/UnityPlayerProxyActivity;->copyPlayerPrefs(Landroid/content/Context; [Ljava/lang/String;)V
    sget v2, Landroid/os/Build$VERSION;->SDK_INT I
    const/16 v4, 9
    if-lt v2, v4, +029h
    move v2, v0
    if-eqz v2, +028h
    aget-object v0, v3, v0
    invoke-static v0, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    move-result-object v0
    new-instance v1, Landroid/content/Intent;
    invoke-direct v1, v5, v0, Landroid/content/Intent;-><init>(Landroid/content/Context; Ljava/lang/Class;)V
    const/high16 v0, 65536
    invoke-virtual v1, v0, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayerProxyActivity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    invoke-virtual v0, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    move-result-object v0
    if-eqz v0, +005h
    invoke-virtual v1, v0, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;
    invoke-virtual v5, v1, Lcom/unity3d/player/UnityPlayerProxyActivity;->startActivity(Landroid/content/Intent;)V
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayerProxyActivity;->finish()V
    return-void
    move v2, v1
    goto -27h
    move v0, v1
    goto -27h
    move-exception v0
    invoke-virtual v0, Ljava/lang/ClassNotFoundException;->printStackTrace()V
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayerProxyActivity;->finish()V
    goto -ch
    move-exception v0
    invoke-virtual v5, Lcom/unity3d/player/UnityPlayerProxyActivity;->finish()V
    throw v0
.end method
