.class final Lcom/unity3d/player/UnityPlayer$1;
.super Ljava/lang/Object;
.implements Landroid/content/DialogInterface$OnClickListener;

.field private synthetic a:Lcom/unity3d/player/UnityPlayer;

.method constructor <init>(Lcom/unity3d/player/UnityPlayer;)V
    .registers 2
    iput-object v1, v0, Lcom/unity3d/player/UnityPlayer$1;->a Lcom/unity3d/player/UnityPlayer;
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public final onClick(Landroid/content/DialogInterface; I)V
    .registers 4
    iget-object v0, v1, Lcom/unity3d/player/UnityPlayer$1;->a Lcom/unity3d/player/UnityPlayer;
    invoke-static v0, Lcom/unity3d/player/UnityPlayer;->a(Lcom/unity3d/player/UnityPlayer;)V
    return-void
.end method
