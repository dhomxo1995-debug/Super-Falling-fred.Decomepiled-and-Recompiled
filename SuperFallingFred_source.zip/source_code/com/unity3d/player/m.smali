.class final Lcom/unity3d/player/m;
.super Ljava/lang/Object;


.method protected static Log(I Ljava/lang/String;)V
    .registers 3
    const/4 v0, 6
    if-ne v1, v0, +007h
    const-string v0, "Unity"
    invoke-static v0, v2, Landroid/util/Log;->e(Ljava/lang/String; Ljava/lang/String;)I
    const/4 v0, 5
    if-ne v1, v0, +007h
    const-string v0, "Unity"
    invoke-static v0, v2, Landroid/util/Log;->w(Ljava/lang/String; Ljava/lang/String;)I
    return-void
.end method
