.class public final Lcom/unity3d/player/s;
.super Landroid/app/Dialog;
.implements Landroid/text/TextWatcher;
.implements Landroid/view/View$OnClickListener;

.field private a:Landroid/content/Context;
.field private b:Lcom/unity3d/player/UnityPlayer;

.method public constructor <init>(Landroid/content/Context; Lcom/unity3d/player/UnityPlayer; Ljava/lang/String; I Z Z Z Ljava/lang/String;)V
    .registers 18
    invoke-direct v9, v10, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V
    const/4 v0, 0
    iput-object v0, v9, Lcom/unity3d/player/s;->a Landroid/content/Context;
    const/4 v0, 0
    iput-object v0, v9, Lcom/unity3d/player/s;->b Lcom/unity3d/player/UnityPlayer;
    iput-object v10, v9, Lcom/unity3d/player/s;->a Landroid/content/Context;
    iput-object v11, v9, Lcom/unity3d/player/s;->b Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v9, Lcom/unity3d/player/s;->getWindow()Landroid/view/Window;
    move-result-object v0
    const/16 v1, 80
    invoke-virtual v0, v1, Landroid/view/Window;->setGravity(I)V
    invoke-virtual v9, Lcom/unity3d/player/s;->getWindow()Landroid/view/Window;
    move-result-object v0
    const/4 v1, 1
    invoke-virtual v0, v1, Landroid/view/Window;->requestFeature(I)Z
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;
    const/4 v1, 0
    invoke-direct v0, v1, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V
    invoke-virtual v9, Lcom/unity3d/player/s;->getWindow()Landroid/view/Window;
    move-result-object v1
    invoke-virtual v1, v0, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    invoke-virtual v9, Lcom/unity3d/player/s;->createSoftInputView()Landroid/view/View;
    move-result-object v0
    invoke-virtual v9, v0, Lcom/unity3d/player/s;->setContentView(Landroid/view/View;)V
    invoke-virtual v9, Lcom/unity3d/player/s;->getWindow()Landroid/view/Window;
    move-result-object v0
    const/4 v1, 2
    invoke-virtual v0, v1, Landroid/view/Window;->clearFlags(I)V
    const v0, 1057292289
    invoke-virtual v9, v0, Lcom/unity3d/player/s;->findViewById(I)Landroid/view/View;
    move-result-object v1
    check-cast v1, Landroid/widget/EditText;
    const v0, 1057292290
    invoke-virtual v9, v0, Lcom/unity3d/player/s;->findViewById(I)Landroid/view/View;
    move-result-object v0
    move-object v8, v0
    check-cast v8, Landroid/widget/Button;
    move-object v0, v9
    move-object v2, v12
    move v3, v13
    move v4, v14
    move v5, v15
    move/from16 v6, v16
    move-object/from16 v7, v17
    invoke-direct/range v0 ... v7, Lcom/unity3d/player/s;->a(Landroid/widget/EditText; Ljava/lang/String; I Z Z Z Ljava/lang/String;)V
    invoke-virtual v8, v9, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    new-instance v0, Lcom/unity3d/player/s$1;
    invoke-direct v0, v9, Lcom/unity3d/player/s$1;-><init>(Lcom/unity3d/player/s;)V
    invoke-virtual v1, v0, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V
    return-void
.end method

.method private static a(I Z Z Z)I
    .registers 7
    const/4 v0, 0
    if-eqz v4, +016h
    const v1, 32768
    move v2, v1
    if-eqz v5, +012h
    const/high16 v1, 131072
    or-int/2addr v1, v2
    if-eqz v6, +004h
    const/16 v0, 128
    or-int/2addr v0, v1
    if-ltz v3, +005h
    const/4 v1, 7
    if-le v3, v1, +007h
    return v0
    move v2, v0
    goto -11h
    move v1, v0
    goto -fh
    const/16 v1, 8
    new-array v1, v1, [I
    fill-array-data v1, +0000007h
    aget v1, v1, v3
    or-int/2addr v0, v1
    goto -fh
    fill-array-data-payload b'\x01\x00\x00\x00\x01@\x00\x00\x020\x00\x00\x11\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00a\x00\x00\x00!\x00\x00\x00' | \x01\x00\x00\x00\x01\x40\x00\x00\x02\x30\x00\x00\x11\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x61\x00\x00\x00\x21\x00\x00\x00
.end method

.method private a()Ljava/lang/String;
    .registers 2
    const v0, 1057292289
    invoke-virtual v1, v0, Lcom/unity3d/player/s;->findViewById(I)Landroid/view/View;
    move-result-object v0
    check-cast v0, Landroid/widget/EditText;
    if-nez v0, +004h
    const/4 v0, 0
    return-object v0
    invoke-virtual v0, Landroid/widget/EditText;->getText()Landroid/text/Editable;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-virtual v0, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object v0
    goto -dh
.end method

.method static synthetic a(Lcom/unity3d/player/s;)Ljava/lang/String;
    .registers 2
    invoke-direct v1, Lcom/unity3d/player/s;->a()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method private a(Landroid/widget/EditText; Ljava/lang/String; I Z Z Z Ljava/lang/String;)V
    .registers 10
    const/4 v0, 6
    invoke-virtual v3, v0, Landroid/widget/EditText;->setImeOptions(I)V
    invoke-virtual v3, v4, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    invoke-virtual v3, v9, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V
    invoke-static v5, v6, v7, v8, Lcom/unity3d/player/s;->a(I Z Z Z)I
    move-result v0
    invoke-virtual v3, v0, Landroid/widget/EditText;->setInputType(I)V
    invoke-virtual v3, v2, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V
    invoke-virtual v3, Landroid/widget/EditText;->getInputType()I
    move-result v0
    invoke-static Landroid/text/method/TextKeyListener;->getInstance()Landroid/text/method/TextKeyListener;
    move-result-object v1
    invoke-virtual v3, v1, Landroid/widget/EditText;->setKeyListener(Landroid/text/method/KeyListener;)V
    invoke-virtual v3, v0, Landroid/widget/EditText;->setRawInputType(I)V
    const/4 v0, 1
    invoke-virtual v3, v0, Landroid/widget/EditText;->setClickable(Z)V
    if-nez v7, +005h
    invoke-virtual v3, Landroid/widget/EditText;->selectAll()V
    return-void
.end method

.method static synthetic a(Lcom/unity3d/player/s; Ljava/lang/String; Z)V
    .registers 3
    invoke-direct v0, v1, v2, Lcom/unity3d/player/s;->a(Ljava/lang/String; Z)V
    return-void
.end method

.method private a(Ljava/lang/String; Z)V
    .registers 5
    iget-object v0, v2, Lcom/unity3d/player/s;->b Lcom/unity3d/player/UnityPlayer;
    const/4 v1, 1
    invoke-virtual v0, v3, v1, v4, Lcom/unity3d/player/UnityPlayer;->reportSoftInputStr(Ljava/lang/String; I Z)V
    return-void
.end method

.method static synthetic b(Lcom/unity3d/player/s;)Landroid/content/Context;
    .registers 2
    iget-object v0, v1, Lcom/unity3d/player/s;->a Landroid/content/Context;
    return-object v0
.end method

.method public final a(Ljava/lang/String;)V
    .registers 4
    const v0, 1057292289
    invoke-virtual v2, v0, Lcom/unity3d/player/s;->findViewById(I)Landroid/view/View;
    move-result-object v0
    check-cast v0, Landroid/widget/EditText;
    if-eqz v0, +00ch
    invoke-virtual v0, v3, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    invoke-virtual v3, Ljava/lang/String;->length()I
    move-result v1
    invoke-virtual v0, v1, Landroid/widget/EditText;->setSelection(I)V
    return-void
.end method

.method public final afterTextChanged(Landroid/text/Editable;)V
    .registers 5
    const/4 v2, 0
    iget-object v0, v3, Lcom/unity3d/player/s;->b Lcom/unity3d/player/UnityPlayer;
    invoke-virtual v4, Ljava/lang/Object;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-virtual v0, v1, v2, v2, Lcom/unity3d/player/UnityPlayer;->reportSoftInputStr(Ljava/lang/String; I Z)V
    return-void
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence; I I I)V
    .registers 5
    return-void
.end method

.method protected final createSoftInputView()Landroid/view/View;
    .registers 11
    const v9, 1057292290
    const v8, 1057292289
    const/16 v7, 15
    const/4 v3, -1
    const/4 v6, -2
    new-instance v1, Landroid/widget/RelativeLayout;
    iget-object v0, v10, Lcom/unity3d/player/s;->a Landroid/content/Context;
    invoke-direct v1, v0, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;
    invoke-direct v0, v3, v3, Landroid/view/ViewGroup$LayoutParams;-><init>(I I)V
    invoke-virtual v1, v0, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    new-instance v0, Lcom/unity3d/player/s$2;
    iget-object v2, v10, Lcom/unity3d/player/s;->a Landroid/content/Context;
    invoke-direct v0, v10, v2, Lcom/unity3d/player/s$2;-><init>(Lcom/unity3d/player/s; Landroid/content/Context;)V
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v2, v3, v6, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    invoke-virtual v2, v7, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V
    const/4 v3, 0
    invoke-virtual v2, v3, v9, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I I)V
    invoke-virtual v0, v2, Landroid/widget/EditText;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v0, v8, Landroid/widget/EditText;->setId(I)V
    invoke-virtual v1, v0, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V
    new-instance v0, Landroid/widget/Button;
    iget-object v2, v10, Lcom/unity3d/player/s;->a Landroid/content/Context;
    invoke-direct v0, v2, Landroid/widget/Button;-><init>(Landroid/content/Context;)V
    iget-object v2, v10, Lcom/unity3d/player/s;->a Landroid/content/Context;
    invoke-virtual v2, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    move-result-object v2
    const-string v3, "ok"
    const-string v4, "string"
    const-string v5, "android"
    invoke-virtual v2, v3, v4, v5, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String; Ljava/lang/String; Ljava/lang/String;)I
    move-result v2
    invoke-virtual v0, v2, Landroid/widget/Button;->setText(I)V
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;
    invoke-direct v2, v6, v6, Landroid/widget/RelativeLayout$LayoutParams;-><init>(I I)V
    invoke-virtual v2, v7, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V
    const/16 v3, 11
    invoke-virtual v2, v3, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V
    invoke-virtual v0, v2, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    invoke-virtual v0, v9, Landroid/widget/Button;->setId(I)V
    invoke-virtual v1, v0, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V
    invoke-virtual v1, v8, Landroid/view/View;->findViewById(I)Landroid/view/View;
    move-result-object v0
    check-cast v0, Landroid/widget/EditText;
    new-instance v2, Lcom/unity3d/player/s$3;
    invoke-direct v2, v10, Lcom/unity3d/player/s$3;-><init>(Lcom/unity3d/player/s;)V
    invoke-virtual v0, v2, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V
    return-object v1
.end method

.method public final onBackPressed()V
    .registers 3
    invoke-direct v2, Lcom/unity3d/player/s;->a()Ljava/lang/String;
    move-result-object v0
    const/4 v1, 1
    invoke-direct v2, v0, v1, Lcom/unity3d/player/s;->a(Ljava/lang/String; Z)V
    return-void
.end method

.method public final onClick(Landroid/view/View;)V
    .registers 4
    invoke-direct v2, Lcom/unity3d/player/s;->a()Ljava/lang/String;
    move-result-object v0
    const/4 v1, 0
    invoke-direct v2, v0, v1, Lcom/unity3d/player/s;->a(Ljava/lang/String; Z)V
    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence; I I I)V
    .registers 5
    return-void
.end method
