.class public final Lcom/unity3d/player/i$a;
.super Ljava/lang/Object;

.field final a:I
.field final b:[F

.method public constructor <init>(I [F)V
    .registers 3
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput v1, v0, Lcom/unity3d/player/i$a;->a I
    iput-object v2, v0, Lcom/unity3d/player/i$a;->b [F
    return-void
.end method
