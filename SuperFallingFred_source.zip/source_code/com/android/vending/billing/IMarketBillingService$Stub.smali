.class public abstract Lcom/android/vending/billing/IMarketBillingService$Stub;
.super Landroid/os/Binder;
.implements Lcom/android/vending/billing/IMarketBillingService;

.field private static final DESCRIPTOR:Ljava/lang/String;
.field static final TRANSACTION_sendBillingRequest:I

.method public constructor <init>()V
    .registers 2
    invoke-direct v1, Landroid/os/Binder;-><init>()V
    const-string v0, "com.android.vending.billing.IMarketBillingService"
    invoke-virtual v1, v1, v0, Lcom/android/vending/billing/IMarketBillingService$Stub;->attachInterface(Landroid/os/IInterface; Ljava/lang/String;)V
    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/android/vending/billing/IMarketBillingService;
    .registers 3
    if-nez v2, +004h
    const/4 v0, 0
    return-object v0
    const-string v1, "com.android.vending.billing.IMarketBillingService"
    invoke-interface v2, v1, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;
    move-result-object v0
    if-eqz v0, +009h
    instance-of v1, v0, Lcom/android/vending/billing/IMarketBillingService;
    if-eqz v1, +005h
    check-cast v0, Lcom/android/vending/billing/IMarketBillingService;
    goto -fh
    new-instance v0, Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;
    invoke-direct v0, v2, Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;-><init>(Landroid/os/IBinder;)V
    goto -15h
.end method

.method public asBinder()Landroid/os/IBinder;
    .registers 1
    return-object v0
.end method

.method public onTransact(I Landroid/os/Parcel; Landroid/os/Parcel; I)Z
    .registers 9
    const/4 v2, 1
    sparse-switch v5, +0000039h
    invoke-super v4, v5, v6, v7, v8, Landroid/os/Binder;->onTransact(I Landroid/os/Parcel; Landroid/os/Parcel; I)Z
    move-result v2
    return v2
    const-string v3, "com.android.vending.billing.IMarketBillingService"
    invoke-virtual v7, v3, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    goto -6h
    const-string v3, "com.android.vending.billing.IMarketBillingService"
    invoke-virtual v6, v3, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    invoke-virtual v6, Landroid/os/Parcel;->readInt()I
    move-result v3
    if-eqz v3, +01ah
    sget-object v3, Landroid/os/Bundle;->CREATOR Landroid/os/Parcelable$Creator;
    invoke-interface v3, v6, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/os/Bundle;
    invoke-virtual v4, v0, Lcom/android/vending/billing/IMarketBillingService$Stub;->sendBillingRequest(Landroid/os/Bundle;)Landroid/os/Bundle;
    move-result-object v1
    invoke-virtual v7, Landroid/os/Parcel;->writeNoException()V
    if-eqz v1, +00bh
    invoke-virtual v7, v2, Landroid/os/Parcel;->writeInt(I)V
    invoke-virtual v1, v7, v2, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel; I)V
    goto -29h
    const/4 v0, 0
    goto -11h
    const/4 v3, 0
    invoke-virtual v7, v3, Landroid/os/Parcel;->writeInt(I)V
    goto -30h
    nop
    sparse-switch-payload 1 5f4e5446
.end method
