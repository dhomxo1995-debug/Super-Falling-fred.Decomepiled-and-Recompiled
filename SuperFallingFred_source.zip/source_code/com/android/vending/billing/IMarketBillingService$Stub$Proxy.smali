.class 0x0 Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;
.super Ljava/lang/Object;
.implements Lcom/android/vending/billing/IMarketBillingService;

.field private mRemote:Landroid/os/IBinder;

.method constructor <init>(Landroid/os/IBinder;)V
    .registers 2
    invoke-direct v0, Ljava/lang/Object;-><init>()V
    iput-object v1, v0, Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;->mRemote Landroid/os/IBinder;
    return-void
.end method

.method public asBinder()Landroid/os/IBinder;
    .registers 2
    iget-object v0, v1, Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;->mRemote Landroid/os/IBinder;
    return-object v0
.end method

.method public getInterfaceDescriptor()Ljava/lang/String;
    .registers 2
    const-string v0, "com.android.vending.billing.IMarketBillingService"
    return-object v0
.end method

.method public sendBillingRequest(Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 8
    invoke-static Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    move-result-object v0
    invoke-static Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    move-result-object v1
    const-string v3, "com.android.vending.billing.IMarketBillingService"
    invoke-virtual v0, v3, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    if-eqz v7, +029h
    const/4 v3, 1
    invoke-virtual v0, v3, Landroid/os/Parcel;->writeInt(I)V
    const/4 v3, 0
    invoke-virtual v7, v0, v3, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel; I)V
    iget-object v3, v6, Lcom/android/vending/billing/IMarketBillingService$Stub$Proxy;->mRemote Landroid/os/IBinder;
    const/4 v4, 1
    const/4 v5, 0
    invoke-interface v3, v4, v0, v1, v5, Landroid/os/IBinder;->transact(I Landroid/os/Parcel; Landroid/os/Parcel; I)Z
    invoke-virtual v1, Landroid/os/Parcel;->readException()V
    invoke-virtual v1, Landroid/os/Parcel;->readInt()I
    move-result v3
    if-eqz v3, +01eh
    sget-object v3, Landroid/os/Bundle;->CREATOR Landroid/os/Parcelable$Creator;
    invoke-interface v3, v1, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Landroid/os/Bundle;
    invoke-virtual v1, Landroid/os/Parcel;->recycle()V
    invoke-virtual v0, Landroid/os/Parcel;->recycle()V
    return-object v2
    const/4 v3, 0
    invoke-virtual v0, v3, Landroid/os/Parcel;->writeInt(I)V
    goto -23h
    move-exception v3
    invoke-virtual v1, Landroid/os/Parcel;->recycle()V
    invoke-virtual v0, Landroid/os/Parcel;->recycle()V
    throw v3
    const/4 v2, 0
    goto -15h
.end method
