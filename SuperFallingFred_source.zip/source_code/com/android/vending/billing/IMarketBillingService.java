package com.android.vending.billing;
public interface IMarketBillingService implements android.os.IInterface {

    public abstract android.os.Bundle sendBillingRequest(android.os.Bundle p0);
}
