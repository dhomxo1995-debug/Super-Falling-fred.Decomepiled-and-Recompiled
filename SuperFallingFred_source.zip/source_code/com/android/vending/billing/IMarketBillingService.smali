.class public interface abstract Lcom/android/vending/billing/IMarketBillingService;
.super Ljava/lang/Object;
.implements Landroid/os/IInterface;


.method public abstract sendBillingRequest(Landroid/os/Bundle;)Landroid/os/Bundle;
    # abstract or native method
.end method
